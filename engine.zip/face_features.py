from common import node, number, path


OPTIONS = {
    "eye_shape": {"almond": "Вытянутые", "open": "Округлые открытые", "narrow": "Узкие"},
    "eye_spacing": {"balanced": "Средняя", "close": "Сближенная", "wide": "Широкая"},
    "eye_tilt": {"level": "Вровень", "down": "Наружный угол ниже", "up": "Наружный угол выше"},
    "eyelid": {"crease": "Открытая складка", "hooded": "Нависшее веко", "smooth": "Гладкое веко"},
    "inner_fold": {"open": "Открытый угол", "folded": "Угол под складкой"},
    "brow_shape": {"arched": "Дугообразные", "straight": "Прямые", "angular": "С изломом"},
    "brow_weight": {"medium": "Средние", "thin": "Тонкие", "thick": "Густые"},
    "brow_height": {"medium": "Средняя", "low": "Низкая", "high": "Высокая"},
    "iris": {"brown": "Карие", "hazel": "Ореховые", "gray": "Серые", "blue": "Голубые", "green": "Зелёные"},
    "nose_bridge": {"straight": "Прямая", "convex": "Выпуклая", "concave": "Слегка вогнутая"},
    "nose_length": {"medium": "Средний", "short": "Короткий", "long": "Длинный"},
    "nose_width": {"medium": "Среднее", "narrow": "Узкое", "wide": "Широкое"},
    "nose_tip": {"round": "Округлый", "defined": "Очерченный узкий", "broad": "Широкий"},
    "mouth_width": {"medium": "Средний", "narrow": "Узкий", "wide": "Широкий"},
    "lip_volume": {"medium": "Средние", "thin": "Тонкие", "full": "Полные"},
    "lip_shape": {"soft": "Мягкий контур", "bow": "Выраженная дуга верхней губы", "lower": "Акцент на нижней губе"},
    "expression": {"neutral": "Нейтральное", "smile": "Лёгкая улыбка", "tense": "Напряжение", "open": "Открытый рот"},
    "gaze": {"direct": "Прямо", "left": "Влево", "right": "Вправо"},
}

LABELS = {
    "eye_shape": "Контур глаз",
    "eye_spacing": "Посадка глаз",
    "eye_tilt": "Наклон глаз",
    "eyelid": "Верхнее веко",
    "inner_fold": "Внутренний угол глаза",
    "brow_shape": "Форма бровей",
    "brow_weight": "Густота бровей",
    "brow_height": "Высота бровей",
    "iris": "Цвет радужки",
    "nose_bridge": "Спинка носа",
    "nose_length": "Длина носа",
    "nose_width": "Ширина основания носа",
    "nose_tip": "Кончик носа",
    "mouth_width": "Ширина рта",
    "lip_volume": "Объём губ",
    "lip_shape": "Контур губ",
    "expression": "Выражение лица",
    "gaze": "Направление взгляда",
}

_EYE_CURVES = {
    "almond": ("C-16 -6 -9 -14 0 -14 C9 -14 15 -7 19.5 0", "C14 8 7 12 -1 12 C-11 12 -17 8 -21 0Z", -19),
    "open": ("C-19 -12 -11 -18 -0.5 -18 C9 -18 17 -11 19.5 0", "C17 12 9 16 -1 16 C-12 16 -19 11 -21 0Z", -23),
    "narrow": ("C-15 -5 -9 -8.5 0 -8.5 C9 -8.5 15 -4.5 19.5 0", "C14 5 6 7.5 -1 7.5 C-11 7.5 -17 5 -21 0Z", -15),
}

_IRIS_COLORS = {
    "brown": "#785641",
    "hazel": "#947342",
    "gray": "#737879",
    "blue": "#577c8a",
    "green": "#687c54",
}

_BROW_PROFILES = {
    "arched": (-.5, -4.6, -5, -5.4, -3),
    "straight": (.4, -1.1, -1.3, -1.5, -1),
    "angular": (.1, -2, -6.7, -4.4, -2.7),
}

_BROW_COLORS = {
    "dark_chestnut": ("#382625", "#835c4b"),
    "black": ("#292325", "#6c5753"),
    "chestnut": ("#513027", "#956748"),
    "light_brown": ("#604935", "#a0815e"),
    "blond": ("#735536", "#bc9a66"),
    "red": ("#6a392d", "#ae6850"),
}

_BRIDGE_PLANES = {
    "straight": (
        "M157.5 150 Q160 147 162 153 L160.5 177 156 183 152 182 Q156 172 157.5 150Z",
        "M162 150 Q166 160 164 176 L170 183 166 186 160.5 177Z",
        "M163.5 155 Q165 166 163.5 175.5",
    ),
    "convex": (
        "M157 148 Q161 145 164 153 Q164 167 160 177 L156 184 152 182 Q156 170 157 148Z",
        "M163 148 Q169 156 165.5 173 L171 183 167 187 160 177 Q165 160 163 148Z",
        "M164.5 153 Q167 163 164.5 176",
    ),
    "concave": (
        "M159 151 Q161 148 161 154 Q157 169 162 177 L158 183 152 182 Q156 174 156 166Z",
        "M161 151 Q166 155 162.5 165 Q161.5 174 170 183 L167 187 161 178 Q156.5 170 161 151Z",
        "M163.5 154 Q160 165 163 175",
    ),
}


def _choice(look, field):
    return look.get(field, next(iter(OPTIONS[field])))


def _draw_eye(parent, defs, look, skin, side, center):
    slope = {"level": 0, "down": -.12, "up": .12}[_choice(look, "eye_tilt")]
    eye = node(parent, "g", transform=f"matrix({side} {number(slope)} 0 1 {number(center)} 160)")
    upper, lower, fold = _EYE_CURVES[_choice(look, "eye_shape")]
    aperture = f"M-21 0 {upper} {lower}"
    clip_id = "face-features-eye-left" if side == 1 else "face-features-eye-right"
    clip = node(defs, "clipPath", id=clip_id)
    path(clip, aperture)

    lid = _choice(look, "eyelid")
    old = look.get("age") == "old"
    if lid == "hooded" or old:
        path(eye, f"M-21 0 C-18 {fold + 2} -9 {fold + 1} -1 {fold} Q12 {fold} 19.5 0Z", skin.shade, opacity=".94" if lid == "hooded" else ".64")
    if lid == "crease":
        path(eye, f"M-16 {fold + 7} Q-7 {fold - 2} 4 {fold} Q11 {fold + 1} 15 {fold + 6}", class_="etch", opacity=".86")
    elif lid == "hooded":
        path(eye, f"M-16 {fold + 8} Q-4 {fold - 1} 8 {fold + 2} L13 {fold + 5}", class_="etch", opacity=".72")
    else:
        path(eye, f"M-14 {fold + 6} Q-7 {fold + 1} 5 {fold + 3} L13 {fold + 7}", skin.light, opacity=".65")

    path(eye, aperture, class_="white")
    contents = node(eye, "g", clip_path=f"url(#{clip_id})")
    gaze = {"direct": 0, "left": -3.4, "right": 3.4}[_choice(look, "gaze")]
    iris = node(contents, "g", transform=f"translate({number(gaze * side)} 0) scale({side} 1)")
    path(iris, "M-9.8 0 C-10.4 -7 -6.6 -10.9 0 -11.1 C6.1 -11.2 10.5 -7 10.1 -.3 C10.2 5.9 6.4 11 0 10.8 C-6.1 10.7 -9.7 7.2 -9.8 0Z", _IRIS_COLORS[_choice(look, "iris")], stroke="#352526", stroke_width="1.4")
    path(iris, "M-5.8 -.2C-5.9-3.8-3.5-6 .1-6 3.8-6 6-3.6 6 .1 6 3.9 3.3 6.3-.2 6.2-3.9 6.1-6 3.3-5.8-.2Z", "#2a2020")
    path(iris, "M-4.7-4.1Q-4.4-7.4-1.1-7.6 .9-6.3-.3-3.9-2.9-2-4.7-4.1Z", "#f3e4bd")
    path(eye, f"M-21 0 {upper}", "none", stroke="#2a1d1c", stroke_width="3.7" if _choice(look, "expression") == "tense" else "3.15", stroke_linecap="round")
    if _choice(look, "inner_fold") == "folded":
        path(eye, "M18.8 -3.8 Q14.2 -3.4 15 1.4 Q16.5 3.2 19.8 .6Z", skin.shade)
        path(eye, "M18.8 -3.8 Q14.2 -3.4 15 1.4", class_="etch")
    if old:
        lower_crease = {"almond": 13.5, "open": 16.5, "narrow": 10}[_choice(look, "eye_shape")]
        path(eye, f"M-20 8 Q-13 {lower_crease} -5 {lower_crease}", class_="etch", opacity=".76")


def _draw_brow(parent, look, side, center):
    height = {"medium": 127.5, "low": 131, "high": 121.5}[_choice(look, "brow_height")]
    weight = {"medium": 2.7, "thin": 1.45, "thick": 4}[_choice(look, "brow_weight")]
    tilt = .10 if _choice(look, "expression") == "tense" else 0
    brow = node(parent, "g", transform=f"matrix({side} {number(tilt)} 0 1 {number(center)} {number(height)})")
    tail, arc, peak, inside, head = _BROW_PROFILES[_choice(look, "brow_shape")]
    tip = .68 * weight
    silhouette = (
        f"M-22 3 C-17 {tail - tip} -10 {arc - weight} -4 {peak - weight} "
        f"C3 {inside - weight} 14 {head - weight} 20 {-1 - tip} Q21 -1 20 {-1 + tip} "
        f"C14 {head + weight} 3 {inside + weight} -4 {peak + weight} "
        f"C-10 {arc + weight} -17 {tail + tip} -22 3Z"
    )
    color, light = _BROW_COLORS.get(look.get("hair_color"), _BROW_COLORS["dark_chestnut"])
    gray = look.get("graying")
    if gray == "full":
        color, light = "#5d5754", "#a79a8a"
    elif gray == "mixed":
        light = "#a39686"
    path(brow, silhouette, color)
    path(brow, f"M-14 {(tail + arc) / 2} Q-7 {arc - .7} -4 {peak - .6} Q1 {inside - .7} 8 {inside}", "none", stroke=light, stroke_width="1.1", stroke_linecap="round")


def _draw_nose(parent, defs, look, skin):
    bridge = node(parent, "g", clip_path="url(#face-features-nose-bridge)")
    clip = node(defs, "clipPath", id="face-features-nose-bridge")
    path(clip, "M154 144H167V179L172 185V187H149V185L154 179Z")
    light, shade, contour = _BRIDGE_PLANES[_choice(look, "nose_bridge")]
    path(bridge, light, skin.light)
    path(bridge, shade, skin.shade, opacity=".93")
    path(bridge, contour, class_="etch", opacity=".9")

    half = {"medium": 16, "narrow": 10.5, "wide": 22.5}[_choice(look, "nose_width")]
    bottom = {"medium": 200, "short": 194, "long": 205}[_choice(look, "nose_length")]
    tip = {"round": 6, "defined": 3.8, "broad": 8.5}[_choice(look, "nose_tip")]
    left = 160 - half
    right = 160 + half
    left_root = 160 - half * .58
    right_root = 160 + half * .58
    nostril = number(half * .50)
    plane = (
        f"M156 180 Q160 177 165 180 C167 {max(180, bottom - 18)} {right_root} {max(180, bottom - 16)} {right - 2} {bottom - 12} "
        f"Q{right + 2} {bottom - 8} {right} {bottom - 4} Q{right - 3} {bottom + 2} {right_root} {bottom - 2} "
        f"Q160 {bottom + 3} {left_root} {bottom - 2} Q{left + 4} {bottom + 1} {left} {bottom - 4} "
        f"Q{left - 2} {bottom - 8} {left + 2} {bottom - 11} Q154 {bottom - 15} 156 180Z"
    )
    path(parent, plane, skin.shade)
    path(parent, f"M157 181 Q164 {max(180, bottom - 20)} {160 + tip} {bottom - 9} Q{160 + tip * .7} {bottom - 4} 160 {bottom - 4.5} Q{160 - tip * .85} {bottom - 5} {160 - tip} {bottom - 8} Q153 {bottom - 13} 157 181Z", skin.light)
    path(parent, f"M{left_root} {max(181, bottom - 14)} Q{left - 3} {bottom - 9} {left + .5} {bottom - 5} Q{left + 2} {bottom - 2} {left + 5} {bottom - 3} M{right_root} {max(181, bottom - 15)} Q{right + 3} {bottom - 10} {right - .5} {bottom - 5} Q{right - 2} {bottom - 2} {right - 5} {bottom - 3}", class_="seam")
    path(parent, f"M{number(160 - half * .70)} {bottom - 4} q{nostril} -4 {nostril} 1 q-{nostril} -1 -{nostril} -1Z M{number(160 + half * .20)} {bottom - 3} q1 -5 {nostril} -1 q-2 0 -{nostril} 1Z", "#3b2524")
    path(parent, f"M156.8 {bottom - 1.7} Q160.25 {bottom + 1} 163.3 {bottom - 1.7}", class_="seam")


def _draw_mouth(parent, look, skin):
    half = {"medium": 27, "narrow": 20, "wide": 34}[_choice(look, "mouth_width")]
    upper, lower = {"medium": (6, 7), "thin": (3.5, 4.5), "full": (8, 10)}[_choice(look, "lip_volume")]
    shape = _choice(look, "lip_shape")
    upper += {"soft": 0, "bow": 1, "lower": -1}[shape]
    lower += {"soft": 0, "bow": 0, "lower": 1.7}[shape]
    cupid = {"soft": 1.5, "bow": 4.2, "lower": .8}[shape]
    corner, center, opening = {
        "neutral": (221, 222, 0),
        "smile": (217.5, 222, 2.7),
        "tense": (222, 220.5, 0),
        "open": (220, 221, 8.5),
    }[_choice(look, "expression")]
    left, right = 160 - half, 160 + half
    near_left, near_right = number(160 - half * .55), number(160 + half * .55)
    peak = center - upper
    top = (
        f"M{left} {corner} C{near_left} {corner - 1} 151 {peak} 154 {peak} "
        f"Q157 {peak} 160 {peak + cupid} Q163 {peak} 166 {peak} C169 {peak} {near_right} {corner - 1} {right} {corner}"
    )
    parting = f"C{near_left} {center - .6} 153 {center - 1} 160 {center} C167 {center - 1.3} {near_right} {center + .25} {right} {corner}"
    bottom = center + opening + lower
    path(parent, f"{top} C{near_right} {bottom - 2} 171 {bottom} 160 {bottom} C148 {bottom} {near_left} {bottom - 2} {left} {corner}Z", skin.lip)
    path(parent, f"{top} C{near_right} {center + .25} 167 {center - 1.3} 160 {center} C153 {center - 1} {near_left} {center - .6} {left} {corner}Z", "#56322f", opacity=".72")
    if opening:
        cavity = center + opening
        path(parent, f"M{left} {corner} {parting} C{near_right} {cavity} 169 {cavity} 160 {cavity} C150 {cavity} {near_left} {cavity} {left} {corner}Z", "#362324")
        if opening > 4:
            path(parent, f"M{left + 8} {corner + 1} Q153 {center - .8} 160 {center + .55} Q167 {center - 1.1} {right - 8} {corner + 1} Q171 {center + 3.4} 160 {center + 3.7} Q148 {center + 3.4} {left + 8} {corner + 1}Z", "#eed7ae")
    else:
        path(parent, f"M{left} {corner} {parting}", class_="seam")
    path(parent, f"M{number(160 - half * .32)} {bottom - 2.8} Q160 {bottom - 1.3} {number(160 + half * .3)} {bottom - 2.8}", "none", stroke=skin.light, stroke_width="1.4", stroke_linecap="round", opacity=".76")


def draw_features(parent, defs, look, head):
    eyes = node(parent, "g", data_part="eyes")
    brows = node(parent, "g", data_part="brows")
    nose = node(parent, "g", data_part="nose")
    mouth = node(parent, "g", data_part="mouth")
    spacing = {"balanced": 32.5, "close": 30.5, "wide": 37.5}[_choice(look, "eye_spacing")]
    # У острия века остаётся участок кожи даже в проёме платка на узком лице.
    spacing = min(spacing, head.temple_half - 29)
    for side in (1, -1):
        center = 160 - side * spacing
        _draw_eye(eyes, defs, look, head.skin, side, center)
        _draw_brow(brows, look, side, center)
    _draw_nose(nose, defs, look, head.skin)
    _draw_mouth(mouth, look, head.skin)
