from dataclasses import dataclass
from xml.etree import ElementTree as ET

SVG = "http://www.w3.org/2000/svg"
XLINK = "http://www.w3.org/1999/xlink"
ET.register_namespace("", SVG)
ET.register_namespace("xlink", XLINK)


@dataclass(frozen=True)
class Skin:
    base: str
    light: str
    shade: str
    blush: str
    lip: str


@dataclass(frozen=True)
class HeadGeometry:
    cheek_half: float
    temple_half: float
    top_y: float
    jaw_half: float
    chin_y: float
    neck_half: float
    skin: Skin


def tag(name):
    return f"{{{SVG}}}{name}"


def number(value):
    return f"{value:.3f}".rstrip("0").rstrip(".")


def node(parent, name, **attrs):
    attributes = {
        key.rstrip("_").replace("_", "-"): number(value) if isinstance(value, float) else str(value)
        for key, value in attrs.items()
        if value is not None
    }
    return ET.SubElement(parent, tag(name), attributes)


def path(parent, d, fill=None, **attrs):
    return node(parent, "path", d=d, fill=fill, **attrs)


def use(parent, identifier, **attrs):
    element = node(parent, "use", **attrs)
    element.set(f"{{{XLINK}}}href", "#" + identifier)
    return element
