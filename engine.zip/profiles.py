"""Авторские веса для генерации портретов. Исторические частоты не оценивались."""

from collections.abc import Iterable, Mapping


PROFILES = {
    "novgorod": "Новгород · местный набор",
    "east_eurasia": "Восточная Евразия",
    "sub_saharan": "Африка южнее Сахары",
    "free": "Свободный выбор",
}
DEFAULT_PROFILE = "novgorod"
PROFILE_VERSION = "rus13-style-pools-v1"

_WEIGHTS = {
    "novgorod": {
        "skin": {"warm": 5, "fair": 5, "olive": 2, "tan": 0, "brown": 0, "deep": 0},
        "hair_color": {"dark_chestnut": 3, "black": 2, "chestnut": 3, "light_brown": 4, "blond": 2, "red": 1},
        "hair_texture": {"straight": 3, "wavy": 3, "curly": 2, "coiled": 1},
        "iris": {"brown": 3, "hazel": 3, "gray": 3, "blue": 3, "green": 2},
        "nose_width": {"medium": 4, "narrow": 3, "wide": 2},
    },
    "east_eurasia": {
        "skin": {"warm": 3, "fair": 1, "olive": 5, "tan": 5, "brown": 2, "deep": 0},
        "hair_color": {"dark_chestnut": 4, "black": 5, "chestnut": 2, "light_brown": 1, "blond": 1, "red": 1},
        "hair_texture": {"straight": 5, "wavy": 3, "curly": 2, "coiled": 1},
        "iris": {"brown": 5, "hazel": 3, "gray": 1, "blue": 1, "green": 1},
        "eye_shape": {"almond": 5, "open": 2, "narrow": 3},
        "eye_tilt": {"level": 4, "up": 4, "down": 2},
        "eyelid": {"crease": 2, "hooded": 3, "smooth": 4},
        "inner_fold": {"open": 2, "folded": 3},
        "nose_width": {"medium": 4, "narrow": 2, "wide": 3},
    },
    "sub_saharan": {
        "skin": {"warm": 0, "fair": 0, "olive": 1, "tan": 3, "brown": 5, "deep": 5},
        "nose_width": {"medium": 3, "narrow": 2, "wide": 4},
        "hair_color": {"dark_chestnut": 4, "black": 5, "chestnut": 2, "light_brown": 1, "blond": 1, "red": 1},
        "hair_texture": {"straight": 1, "wavy": 2, "curly": 4, "coiled": 5},
        "iris": {"brown": 5, "hazel": 3, "gray": 1, "blue": 1, "green": 1},
    },
    "free": {},
}


def weights_for(profile: str, field: str, options: Iterable[str] | Mapping[str, object]) -> dict[str, int]:
    weights = _WEIGHTS[profile].get(field, {})
    return {variant: weights.get(variant, 1) for variant in options}
