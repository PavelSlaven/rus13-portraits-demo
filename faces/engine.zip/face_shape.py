"""Фронтальные контуры головы, плоскости кожи и устойчивые приметы.

Косметика отложена до подбора источников для конкретной сцены.
"""

from common import EYE_HEIGHTS, HeadGeometry, Skin, brow_top, node, number, path


OPTIONS = {
    "skull": {
        "oval": "Овальный", "long": "Вытянутый узкий",
        "short_wide": "Широкий короткий", "wide_temples": "Широкий в висках",
    },
    "forehead": {"medium": "Средний", "low": "Низкий", "high": "Высокий"},
    "cheekbone": {"soft": "Мягкие", "high": "Высокие", "wide": "Широкие"},
    "cheeks": {"medium": "Средние", "hollow": "Впалые", "full": "Полные"},
    "jaw": {"round": "Округлая", "tapered": "Сужающаяся", "angular": "Широкая угловатая"},
    "chin": {"round": "Округлый", "square": "Квадратный", "pointed": "Заострённый"},
    "chin_height": {"medium": "Средняя", "short": "Небольшая", "long": "Большая"},
    "ear_size": {"medium": "Средние", "small": "Малые", "large": "Крупные"},
    "ear_outset": {"medium": "Слегка выступают", "close": "Прилегают", "prominent": "Заметно выступают"},
    "neck": {"medium": "Средняя", "narrow": "Узкая", "wide": "Широкая"},
    "age": {"adult": "Взрослый", "young": "Юный", "old": "Старый"},
    "skin": {
        "warm": "Светлый тёплый", "fair": "Светлый прохладный", "olive": "Оливковый",
        "tan": "Золотистый смуглый", "brown": "Коричневый тёплый", "deep": "Тёмно-коричневый",
    },
    "marks": {
        "none": "Без примет", "freckles": "Веснушки", "mole": "Родинка на левой щеке",
        "cheek_scar": "Шрам на правой щеке", "brow_scar": "Шрам над левой бровью",
    },
    "asymmetry": {
        "none": "Нейтральная", "left_cheek": "Чуть полнее левая щека",
        "right_jaw": "Чуть выраженнее правый угол челюсти",
    },
    "skin_state": {"plain": "Обычная", "tanned": "Загар", "flushed": "Румянец", "dusty": "Дорожная пыль"},
}

LABELS = {
    "skull": "Форма черепа", "forehead": "Лоб", "cheekbone": "Скулы", "cheeks": "Объём щёк",
    "jaw": "Челюсть", "chin": "Форма подбородка", "chin_height": "Высота подбородка",
    "ear_size": "Размер ушей", "ear_outset": "Посадка ушей", "neck": "Шея", "age": "Возраст",
    "skin": "Тон кожи", "marks": "Устойчивые приметы", "asymmetry": "Асимметрия",
    "skin_state": "Состояние кожи",
}

DETAILS = {
    "forehead_outline": {"standard": "Обычный", "tapered": "Суженный кверху", "broad": "Широкий вверху"},
    "cheek_relief": {"standard": "Обычный", "soft": "Мягкий", "sculpted": "Выраженный"},
    "jaw_width": {"standard": "Обычная", "narrow": "Узкая", "wide": "Широкая"},
    "jaw_height": {"standard": "Обычная", "high": "Высокая", "low": "Низкая"},
    "chin_width": {"standard": "Обычная", "narrow": "Узкий", "wide": "Широкий"},
    "chin_mark": {"standard": "Обычный", "cleft": "Раздвоенный", "dimple": "С ямочкой"},
    "ear_rim": {"standard": "Обычный", "round": "Округлый", "angular": "Угловатый"},
    "earlobe": {"standard": "Обычная", "attached": "Приросшая", "free": "Свободная"},
    "ear_height": {"standard": "Обычная", "high": "Высокая", "low": "Низкая"},
    "freckle_pattern": {
        "standard": "Обычные", "nose": "На переносице", "cheeks": "На щеках", "scattered": "Россыпью",
    },
}

DETAIL_LABELS = {
    "forehead_outline": "Верхний контур лба", "cheek_relief": "Рельеф щёк",
    "jaw_width": "Ширина челюсти", "jaw_height": "Высота угла челюсти",
    "chin_width": "Ширина подбородка", "chin_mark": "Рельеф подбородка",
    "ear_rim": "Край ушной раковины", "earlobe": "Мочка уха", "ear_height": "Высота посадки ушей",
    "freckle_pattern": "Распределение веснушек",
}

_PALETTES = {
    "warm": Skin("#dcb08c", "#edc5a0", "#a87460", "#bb816d", "#a36053"),
    "fair": Skin("#edbeaa", "#f8d6be", "#b68179", "#ca8c84", "#aa635f"),
    "olive": Skin("#c1a37b", "#dfbd92", "#8d6a53", "#a46e57", "#91594b"),
    "tan": Skin("#bc8a62", "#d9a77b", "#845743", "#a26752", "#8f5044"),
    "brown": Skin("#a47151", "#c89065", "#6d4534", "#8c523f", "#774335"),
    "deep": Skin("#80533f", "#a87456", "#553529", "#714032", "#603729"),
}

_SKULL = {"oval": (71, 68, 75), "long": (65, 63, 68), "short_wide": (75, 73, 83), "wide_temples": (71, 75, 75)}
_FOREHEAD = {"medium": 0, "low": 5, "high": -5}
_FOREHEAD_WIDTH = {"standard": 0, "tapered": -12, "broad": 12}
_CHEEKBONE = {"soft": (0, 177), "high": (2, 169), "wide": (6, 176)}
_CHEEKS = {"medium": 0, "hollow": -7, "full": 6}
_JAW = {"round": (59, 219), "tapered": (46, 217), "angular": (65, 225)}
_CHIN_HEIGHT = {"medium": 0, "short": -8, "long": 8}
_EAR_SIZE = {"medium": 1, "small": .79, "large": 1.19}
_EAR_OUTSET = {"medium": 1, "close": .72, "prominent": 1.3}
_NECK = {"medium": 30, "narrow": 26, "wide": 35}
_EAR_RIMS = {
    "standard": "M -4 -15 C 7 -26 22 -25 27 -14",
    "round": "M -4 -15 C 6 -29 23 -30 27 -14",
    "angular": "M -4 -15 Q 9 -27 18 -25 L 25 -20 Q 27 -18 27 -14",
}
_EARLOBES = {
    "standard": "C 34 1 24 21 12 23 L -4 18 Z",
    "attached": "C 34 1 23 19 14 20 Q 5 20 -4 14 Z",
    "free": "C 34 1 25 19 16 24 C 13 30 9 31 9 25 Q 8 22 12 19 L -4 15 Z",
}
_FRECKLES = {
    "standard": (
        (111, 188, 1.7), (117, 191, 1.4), (123, 186, 1.55), (128, 190, 1.2),
        (134, 185, 1.05), (188, 188, 1.2), (193, 184, 1.25), (197, 190, 1.7),
        (204, 186, 1.6), (210, 189, 1.35),
    ),
    "nose": (
        (144, 179, 1.3), (146, 184, 1.5), (148, 175, 1.45), (152, 178, 1.35),
        (151, 183, 1.35), (168.5, 175, 1.45), (170, 181, 1.5), (174, 177, 1.35),
        (175, 184, 1.35), (178, 180, 1.25),
    ),
    "cheeks": (
        (107, 184, 1.4), (111, 192, 1.75), (116, 186, 1.55), (120, 194, 1.3),
        (125, 188, 1.65), (129, 194, 1.1), (188, 194, 1.3), (193, 190, 1.55),
        (198, 193, 1.45), (204, 186, 1.6), (209, 194, 1.75), (213, 188, 1.25),
    ),
    "scattered": (
        (108, 186, 1.6), (118, 196, 1.3), (125, 184, 1.45), (134, 195, 1.15),
        (143, 185, 1.25), (151, 177, 1.4), (169, 177, 1.25), (175, 182, 1.5),
        (187, 191, 1.35), (195, 183, 1.45), (204, 197, 1.65),
        (211, 184, 1.25), (215, 192, 1.55),
    ),
}


def _selected(look, field):
    return look.get(field, next(iter(OPTIONS[field])))


def _mix(color, pigment, amount):
    channels = (
        round(int(color[start:start + 2], 16) * (1 - amount)
              + int(pigment[start:start + 2], 16) * amount)
        for start in (1, 3, 5)
    )
    return "#" + "".join(f"{channel:02x}" for channel in channels)


def _skin(look):
    skin = _PALETTES[_selected(look, "skin")]
    if _selected(look, "skin_state") != "tanned":
        return skin
    pigment = _mix(skin.shade, "#995d38", .18)
    return Skin(
        _mix(skin.base, pigment, .24), _mix(skin.light, pigment, .28),
        _mix(skin.shade, "#573626", .11), _mix(skin.blush, pigment, .18),
        _mix(skin.lip, pigment, .14),
    )


def make_head(look) -> HeadGeometry:
    cheek, temple, top = _SKULL[_selected(look, "skull")]
    jaw, _ = _JAW[_selected(look, "jaw")]
    age = _selected(look, "age")
    women = look.get("cast") == "women"
    cheek += _CHEEKBONE[_selected(look, "cheekbone")][0]
    cheek += {"adult": 0, "young": 1, "old": -1}[age]
    jaw += {"adult": 0, "young": -2, "old": 2}[age] - 2 * women
    neck = _NECK[_selected(look, "neck")] - women
    top += _FOREHEAD[_selected(look, "forehead")]
    chin = 255 + _CHIN_HEIGHT[_selected(look, "chin_height")] - 2 * women
    cheek = min(78, max(63, cheek))
    jaw = min(65, jaw)
    jaw_width = look.get("jaw_width", "standard")
    if jaw_width == "narrow":
        jaw -= 7
    elif jaw_width == "wide":
        jaw = min(cheek + 5, jaw + 7)
    return HeadGeometry(
        cheek_half=cheek, temple_half=temple,
        top_y=min(88, max(66, top)), jaw_half=jaw,
        chin_y=chin, neck_half=neck, skin=_skin(look),
    )


def _coordinates(*values):
    return " ".join(number(value) for value in values)


def _outline_half(look, head, side):
    skull = _selected(look, "skull")
    asymmetry = _selected(look, "asymmetry")
    _, cheek_y = _CHEEKBONE[_selected(look, "cheekbone")]
    cheek = head.cheek_half
    cheek_volume = _CHEEKS[_selected(look, "cheeks")]
    jaw = head.jaw_half
    jaw_kind = _selected(look, "jaw")
    jaw_width = look.get("jaw_width", "standard")
    _, jaw_y = _JAW[jaw_kind]
    age = _selected(look, "age")
    if side == 1 and asymmetry == "left_cheek":
        cheek = min(78, cheek + 3)
        cheek_volume += 3
    if side == -1 and asymmetry == "right_jaw":
        jaw = min(cheek + 5 if jaw_width == "wide" else 65, jaw + 3)
        jaw_y += 2
    if age == "old":
        jaw_y += 3
        cheek_volume -= 3
    if age == "young":
        cheek_volume += 2
    temple, top, chin = head.temple_half, head.top_y, head.chin_y
    forehead_width = _FOREHEAD_WIDTH[look.get("forehead_outline", "standard")]
    crown = {"oval": 36, "long": 31, "short_wide": 45, "wide_temples": 39}[skull] + forehead_width
    mid_cheek = min(cheek, cheek - 5 + cheek_volume * .75)
    jaw_y += {"standard": 0, "high": -7, "low": 6}[look.get("jaw_height", "standard")]
    if jaw_kind != "angular":
        jaw_edge = cheek + 1 if jaw_width == "wide" else mid_cheek - 2
        jaw = min(jaw + cheek_volume * .35, jaw_edge)
        if jaw_width == "wide":
            mid_cheek = max(mid_cheek, jaw - 3)
    jaw_controls = {
        "round": ((jaw - 8, jaw_y + 13), (33, chin - 7)),
        "tapered": ((jaw - 6, jaw_y + 10), (27, chin - 9)),
        "angular": ((jaw - 2, jaw_y + 13), (jaw - 11, chin - 9)),
    }
    chin_corners = {
        "round": ((19, chin - 3), (11, chin), (0, chin)),
        "square": ((26, chin - 1), (19, chin), (0, chin)),
        "pointed": ((15, chin - 6), (5, chin - 1), (0, chin)),
    }
    chin_anchor, chin_control, chin_point = chin_corners[_selected(look, "chin")]
    if look.get("chin_mark") == "cleft":
        chin_point = (0, chin - 3.5)
    jaw_control, chin_approach = jaw_controls[jaw_kind]
    chin_width = {"standard": 0, "narrow": -4, "wide": 5}[look.get("chin_width", "standard")]
    chin_anchor = (chin_anchor[0] + chin_width, chin_anchor[1])
    chin_control = (chin_control[0] + chin_width * .7, chin_control[1])
    if chin_width:
        chin_approach = (chin_approach[0] + chin_width, chin_approach[1])
    if jaw_width != "standard" or chin_width:
        jaw_control = (max(chin_anchor[0], jaw_control[0]), jaw_control[1])
        chin_approach = (min(jaw_control[0], max(chin_anchor[0], chin_approach[0])), chin_approach[1])
    # Короткий подбородок и низкий угол челюсти делят один вертикальный зазор.
    jaw_control = (jaw_control[0], min(jaw_control[1], chin_approach[1]))

    return [
        ((crown, top), (temple - 4, top + 17 - forehead_width / 3), (temple, 128)),
        ((temple + 1, 143), (cheek, cheek_y - 13), (cheek, cheek_y)),
        ((cheek, cheek_y + 12), (mid_cheek, 207), (jaw, jaw_y)),
        (jaw_control, chin_approach, chin_anchor),
        ((chin_anchor[0] - 4, chin_anchor[1] + 1), chin_control, chin_point),
    ]


def _outline(look, head):
    top = (0, head.top_y)
    right = _outline_half(look, head, 1)
    left = _outline_half(look, head, -1)
    previous = [top] + [curve[-1] for curve in left[:-1]]
    reverse_left = [
        ((-second[0], second[1]), (-first[0], first[1]), (-start[0], start[1]))
        for start, (first, second, _) in reversed(list(zip(previous, left)))
    ]
    return "M " + _coordinates(160, head.top_y) + " " + " ".join(
        "C " + _coordinates(*(value for x, y in curve for value in (160 + x, y)))
        for curve in right + reverse_left
    ) + " Z"


def draw_neck(parent, look, head):
    width = head.neck_half
    left, right = 160 - width, 160 + width
    neck = node(parent, "g", id="face-shape-neck")
    neck_fill = _mix(head.skin.base, head.skin.shade, .23)
    path(neck, " ".join((
        "M", _coordinates(left + 5, 219),
        "Q", _coordinates(left + 4, 249, left - 2, 263),
        "Q", _coordinates(left - 9, 270, left - 25, 278),
        "L", _coordinates(left - 8, 301, right + 8, 301, right + 25, 278),
        "Q", _coordinates(right + 9, 270, right + 2, 263),
        "Q", _coordinates(right - 3, 250, right - 5, 219), "Z",
    )), neck_fill, class_="edge")
    path(neck, " ".join((
        "M", _coordinates(left + 5, 224, right - 5, 224),
        "Q", _coordinates(right - 4, 247, right + 1, 262),
        "Q 178 275 160 277 Q 142 275",
        _coordinates(left, 266), "Q", _coordinates(left + 5, 249, left + 5, 224), "Z",
    )), head.skin.shade)
    path(neck, "M 136 257 q 10 9 21 12 m -16 -3 7 4 m 32 -12 q -4 7 -9 11",
         class_="etch", opacity=".75")
    if _selected(look, "age") == "old":
        path(neck, "M 141 273 q 19 8 40 -1 m -31 8 q 9 3 19 0", class_="etch", opacity=".75")


def _draw_ears(parent, look, head):
    height = _EAR_SIZE[_selected(look, "ear_size")]
    width = _EAR_OUTSET[_selected(look, "ear_outset")]
    width *= .76 + .24 * height
    ear_y = {"standard": 179, "high": 173, "low": 185}[look.get("ear_height", "standard")]
    rim = _EAR_RIMS[look.get("ear_rim", "standard")]
    lobe = _EARLOBES[look.get("earlobe", "standard")]
    color = _mix(head.skin.base, head.skin.shade, .40)
    if _selected(look, "skin_state") == "flushed":
        color = _mix(color, head.skin.blush, .55)
    ears = node(parent, "g", id="face-shape-ears")
    for side in (-1, 1):
        anchor = 160 + side * (head.cheek_half - 10)
        ear = node(ears, "g", transform=(
            f"translate({_coordinates(anchor, ear_y)}) scale({_coordinates(side * width, height)})"
        ))
        path(ear, f"{rim} {lobe}", color, class_="edge")
        path(ear, "M 7 -15 C 16 -20 24 -16 26 -9 C 22 -14 16 -14 13 -11 L 10 -1 Z",
             head.skin.light, opacity=".66")
        path(ear, "M 23 -7 Q 20 -17 10 -11 L 7 2 M 22 1 Q 15 -2 11 6",
             class_="seam")


def _draw_planes(parent, look, head):
    skin = head.skin
    top = head.top_y
    state = _selected(look, "skin_state")
    age = _selected(look, "age")
    edge_shade = _mix(skin.base, skin.shade, .64)
    path(parent, " ".join((
        "M 70 141 Q 104 91 123", _coordinates(top + 30),
        "Q 102 148 105 189 Q 110 231 160", _coordinates(head.chin_y - 5),
        "Q 192 244 211 214 Q 223 186 211 133 Q 235 151 250 174",
        "L 250 265 70 265 Z",
    )), edge_shade)
    if _selected(look, "jaw") == "angular":
        path(parent, "M 205 229 Q 219 217 231 194 L 242 245 182 260 Q 197 245 205 229 Z",
             skin.shade, opacity=".74")
    forehead = _FOREHEAD[_selected(look, "forehead")]
    forehead_width = _FOREHEAD_WIDTH[look.get("forehead_outline", "standard")]
    path(parent, " ".join((
        "M 109", _coordinates(135 + forehead * .3),
        "Q", _coordinates(114 - forehead_width / 2, top + 26, 142, top + 25),
        "Q", _coordinates(173, top + 16, 195 + forehead_width, top + 34),
        "Q", _coordinates(174 + forehead_width / 2, top + 25, 152, top + 39), "Q 130 126 109",
        _coordinates(135 + forehead * .3), "Z",
    )), skin.light)
    light_y = {"soft": 182, "high": 178, "wide": 181}[_selected(look, "cheekbone")]
    cheek_volume = _CHEEKS[_selected(look, "cheeks")]
    cheek_relief = look.get("cheek_relief", "standard")
    cheek_light = {"standard": ".72", "soft": ".46", "sculpted": ".86"}[cheek_relief]
    blush = skin.blush if state == "flushed" else _mix(skin.base, skin.blush, .70)
    for side in (-1, 1):
        cheek = node(parent, "g", transform=f"translate(160 0) scale({side} 1)")
        outer = head.cheek_half - 9
        width = 8 if _selected(look, "cheekbone") == "wide" else 5
        offset = 2 if side == 1 else 0
        path(cheek, " ".join((
            "M", _coordinates(25 + offset, light_y + 8),
            "Q", _coordinates(39, light_y - 2, outer - width, light_y - 1 + offset),
            "L", _coordinates(outer - 1, light_y + 4),
            "Q", _coordinates(outer - 11, light_y + 12 + offset, 32, light_y + 12), "Z",
        )), skin.light, opacity=cheek_light)
        path(cheek, " ".join((
            "M", _coordinates(27 + offset, light_y + 10),
            "Q", _coordinates(39, light_y + (2 if state == "flushed" else 6), outer - 2, light_y + 5 + offset),
            "L", _coordinates(outer - 5, light_y + (17 if state == "flushed" else 12)),
            "Q", _coordinates(42, light_y + 20 + cheek_volume / 2, 32 + offset, light_y + 17), "Z",
        )), blush)
        if cheek_relief == "soft":
            path(cheek, "M 42 203 Q 51 197 61 195 Q 57 208 45 215 Z",
                 skin.shade, opacity=".23")
        elif cheek_relief == "sculpted":
            path(cheek, "M 42 215 Q 52 205 62 195 Q 58 213 46 220 Z",
                 skin.shade, opacity=".79")
            path(cheek, "M 49 216 Q 55 212 58 208", class_="etch", opacity=".65")
        if cheek_volume < 0:
            path(cheek, "M 56 198 Q 48 209 38 224 Q 52 218 62 202 Z",
                 skin.shade, opacity=".40" if cheek_relief == "soft" else ".73")
        elif cheek_volume > 0:
            path(cheek, "M 28 203 Q 46 205 55 198 Q 50 211 37 211 Z",
                 skin.light, opacity=".44" if cheek_relief == "soft" else ".62")
    path(parent, "M 92 183 Q 99 211 120 232 L 132 247 119 248 Q 98 234 85 212 Z "
                 "M 229 184 Q 224 217 203 241 L 193 250 209 247 Q 230 233 240 211 Z",
         "url(#ink-lines)", opacity=".25" if age == "young" else ".42")
    path(parent, " ".join((
        "M", _coordinates(138, head.chin_y - 21),
        "Q", _coordinates(160, head.chin_y - 15, 182, head.chin_y - 22),
        "L", _coordinates(177, head.chin_y - 13),
        "Q", _coordinates(160, head.chin_y - 9, 141, head.chin_y - 15), "Z",
    )), skin.light)
    if age != "young":
        path(parent, "M 104 202 l 9 5 m -8 1 6 4 m 97 -11 9 -5 m -9 11 8 -5 "
                     "m -97 17 5 6 m 74 1 5 -8", class_="etch", opacity=".65")


def _temple_lines(look, head):
    wide_spacing = look.get("eye_spacing") == "wide" and head.temple_half < 68
    width = look.get("eye_width", "standard")
    height = look.get("eye_height", "standard")
    if width == height == "standard":
        if wide_spacing:
            return "M 103 173 l -3 2 m 5 1 -3 2 M 217 173 l 3 2 m -5 1 3 2 "
        return "M 102 162 l -5 2 m 6 2 -5 4 M 218 160 l 7 1 m -7 4 5 3 "

    spacing = min(
        {"balanced": 32.5, "close": 30.5, "wide": 37.5}[look.get("eye_spacing", "balanced")],
        head.temple_half - 29,
    )
    outer = {"standard": 21, "narrow": 17, "wide": 26}[width]
    eye_edge = 160 - spacing - outer
    tilt = {"level": 0, "down": -.12, "up": .12}[look.get("eye_tilt", "level")]
    eye_y = 160 + EYE_HEIGHTS[height] - outer * tilt
    strokes = (
        ((103, 173, -3, 2), (105, 176, -3, 2), (217, 173, 3, 2), (215, 176, 3, 2))
        if wide_spacing else
        ((102, 162, -5, 2), (103, 166, -5, 4), (218, 160, 7, 1), (218, 165, 5, 3))
    )
    positioned = []
    for x, y, dx, dy in strokes:
        inner_x = max(x, x + dx) if x < 160 else 320 - min(x, x + dx)
        if eye_edge - inner_x <= 3 and y <= eye_y + 4 and y + dy >= eye_y - 3:
            y += 11 if y < 170 else 5
        positioned.append(f"M {x} {y} l {dx} {dy} ")
    return "".join(positioned)


def _draw_age(parent, look, head):
    age = _selected(look, "age")
    if age != "old":
        return
    skin = head.skin
    path(parent, "M 108 183 Q 119 179 132 182 L 132 188 Q 116 187 108 183 Z "
                 "M 188 182 Q 201 178 214 180 Q 206 186 188 188 Z",
         skin.shade)
    path(parent, "M 128 199 Q 118 212 117 227 Q 123 226 129 216 L 133 203 Z "
                 "M 192 199 Q 202 209 207 224 Q 199 224 192 213 L 188 203 Z",
         skin.shade)
    limit = brow_top(look)
    lift = 0 if limit is None else max(0, 129 - limit)
    forehead = (
        f"M 125 {number(119 - lift)} Q 139 {number(111 - lift)} 158 {number(115 - lift)} "
        f"M 130 {number(127 - lift)} Q 150 {number(120 - lift)} 170 {number(123 - lift)} "
        f"M 166 {number(115 - lift)} Q 181 {number(113 - lift)} 194 {number(119 - lift)} "
    )
    path(parent, forehead + _temple_lines(look, head) +
                 "M 112 190 q 9 4 18 1 "
                 "M 191 191 q 10 1 18 -3 M 126 207 q -5 9 -5 16 M 195 206 q 6 8 8 15 "
                 "M 128 230 q 3 7 9 9 M 191 228 q -2 8 -8 12",
         class_="etch", opacity=".88")


def _draw_marks(parent, look, head):
    mark = _selected(look, "marks")
    pigment = _mix(head.skin.shade, "#342422", .49)
    freckles = look.get("freckle_pattern", "standard")
    if mark == "freckles" or freckles != "standard":
        for x, y, radius in _FRECKLES[freckles]:
            node(parent, "circle", cx=x, cy=y, r=radius, fill=pigment, opacity=".78")
    if mark == "mole":
        node(parent, "circle", cx=198, cy=206, r=3.1, fill=pigment)
    elif mark == "cheek_scar":
        path(parent, "M 106 191 Q 112 207 126 216 Q 116 210 111 207 Z", head.skin.light)
        path(parent, "M 106 191 Q 113 207 126 216", class_="etch", opacity=".89")
    elif mark == "brow_scar":
        path(parent, "M 205 118 Q 200 128 197 141 L 195 140 Q 196 130 205 118 Z",
             head.skin.light)
        path(parent, "M 205 118 Q 198 127 196 140", class_="etch", opacity=".88")


def draw_skin(parent, defs, look, head, *, show_ears):
    face = node(parent, "g", id="face-shape")
    if show_ears:
        _draw_ears(face, look, head)
    outline = _outline(look, head)
    clip_id = "face-shape-clip"
    clip = node(defs, "clipPath", id=clip_id)
    path(clip, outline)
    path(face, outline, head.skin.base)
    planes = node(face, "g", clip_path=f"url(#{clip_id})")
    _draw_planes(planes, look, head)
    if _selected(look, "skin_state") == "dusty":
        dust = _mix(head.skin.shade, "#58483c", .66)
        path(planes, "M 100 181 Q 107 198 122 207 L 116 209 125 221 "
                     "Q 110 217 102 209 Z M 226 185 Q 219 203 203 215 L 209 214 "
                     "218 211 216 224 Q 229 217 234 206 Z "
                     "M 143 238 Q 157 244 178 237 L 173 247 150 247 Z", dust, opacity=".62")
        path(planes, "M 99 190 L 122 210 113 217 98 207 Z M 225 196 L 214 220 204 221 Z",
             "url(#ink-lines)", opacity=".55")
    _draw_age(planes, look, head)
    _draw_marks(planes, look, head)
    path(face, outline, "none", class_="edge")
