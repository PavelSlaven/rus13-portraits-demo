from dataclasses import dataclass
from xml.etree import ElementTree as ET

SVG = "http://www.w3.org/2000/svg"
XLINK = "http://www.w3.org/1999/xlink"
ET.register_namespace("", SVG)
ET.register_namespace("xlink", XLINK)

EYE_HEIGHTS = {"standard": 0, "high": -4, "low": 5}
BROW_HEIGHTS = {"medium": 127.5, "low": 131, "high": 121.5}
BROW_WEIGHTS = {"medium": 2.7, "thin": 1.45, "thick": 4}
BROW_TAILS = {"standard": 0, "lifted": -5, "drooped": 6}
BROW_PROFILES = {
    "arched": (-.5, -4.6, -5, -5.4, -3),
    "straight": (.4, -1.1, -1.3, -1.5, -1),
    "angular": (.1, -2, -6.7, -4.4, -2.7),
}


@dataclass(frozen=True)
class Skin:
    base: str
    light: str
    shade: str
    blush: str
    lip: str


@dataclass(frozen=True)
class HeadGeometry:
    cheek_half: float
    temple_half: float
    top_y: float
    jaw_half: float
    chin_y: float
    neck_half: float
    skin: Skin


def brow_top(look):
    if all(look.get(field, "standard") == "standard"
           for field in ("eye_height", "brow_length", "brow_gap", "brow_tail")):
        return None
    baseline = BROW_HEIGHTS[look["brow_height"]] + EYE_HEIGHTS[look.get("eye_height", "standard")]
    weight = BROW_WEIGHTS[look["brow_weight"]]
    tail, arc, peak, inside, head = BROW_PROFILES[look["brow_shape"]]
    tail_offset = BROW_TAILS[look.get("brow_tail", "standard")]
    tilt = 2.7 if look["expression"] == "tense" else 0
    return baseline + min(tail + tail_offset * .55 - weight * .68,
                          arc - weight, peak - weight, inside - weight, head - weight,
                          -1 - weight * .68, 3 + tail_offset) - tilt - .6


def tag(name):
    return f"{{{SVG}}}{name}"


def number(value):
    return f"{value:.3f}".rstrip("0").rstrip(".")


def node(parent, name, **attrs):
    attributes = {
        key.rstrip("_").replace("_", "-"): number(value) if isinstance(value, float) else str(value)
        for key, value in attrs.items()
        if value is not None
    }
    return ET.SubElement(parent, tag(name), attributes)


def path(parent, d, fill=None, **attrs):
    return node(parent, "path", d=d, fill=fill, **attrs)


def use(parent, identifier, **attrs):
    element = node(parent, "use", **attrs)
    element.set(f"{{{XLINK}}}href", "#" + identifier)
    return element
