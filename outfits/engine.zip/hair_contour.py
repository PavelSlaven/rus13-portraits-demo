"""Sections of the filled SVG contours used for scalp hair and headwear."""

import re
from math import comb, copysign, sqrt


_COMMAND = re.compile(r"([A-Za-z])([^A-Za-z]*)")
_NUMBER = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)")
_ARGUMENTS = {"M": 2, "L": 2, "H": 1, "V": 1, "Q": 4, "T": 2, "C": 6, "S": 4}


def _segments(d):
    current = start = 0j
    previous = "M"
    control = current
    for letter, arguments in _COMMAND.findall(d):
        command = letter.upper()
        if command == "Z":
            yield current, start
            current = start
            previous = command
            continue
        values = [float(value) for value in _NUMBER.findall(arguments)]
        width = _ARGUMENTS[command]
        for index in range(0, len(values), width):
            relative = current if letter.islower() else 0j
            args = values[index:index + width]
            if command == "H":
                points = (complex(args[0] + relative.real, current.imag),)
            elif command == "V":
                points = (complex(current.real, args[0] + relative.imag),)
            else:
                points = tuple(complex(x, y) + relative for x, y in zip(args[::2], args[1::2]))
            if command == "M":
                yield current, start
                start = points[0]
                command = "L"
            else:
                if command in {"T", "S"}:
                    matching = {"Q", "T"} if command == "T" else {"C", "S"}
                    reflected = 2 * current - control if previous in matching else current
                    points = (reflected, *points)
                yield (current, *points)
            current = points[-1]
            if len(points) > 1:
                control = points[-2]
            previous = command
    yield current, start


def _point(points, t):
    degree = len(points) - 1
    return sum(comb(degree, index) * (1 - t) ** (degree - index) * t ** index * point
               for index, point in enumerate(points))


def _lines(d, x, radius=0, *, transpose=False):
    for segment in _segments(d):
        if transpose:
            segment = tuple(complex(point.imag, point.real) for point in segment)
        coordinates = [point.real for point in segment]
        if not min(coordinates) - radius <= x < max(coordinates) + radius:
            continue
        divisions = 1 if len(segment) == 2 else 24
        left = segment[0]
        for step in range(1, divisions + 1):
            right = _point(segment, step / divisions)
            yield left, right
            left = right


def _fill_at(d, x, *, transpose=False):
    crossings = []
    for left, right in _lines(d, x, transpose=transpose):
        if min(left.real, right.real) <= x < max(left.real, right.real):
            t = (x - left.real) / (right.real - left.real)
            winding = 1 if right.real > left.real else -1
            crossings.append((left.imag + t * (right.imag - left.imag), winding))
    winding = 0
    intervals = []
    for y, change in sorted(crossings):
        if not winding:
            start = y
        winding += change
        if not winding and y > start:
            intervals.append((start, y))
    return intervals


def vertical_fill(d, x):
    """Return filled intervals at x, using the SVG nonzero winding rule."""
    return _fill_at(d, x)


def horizontal_fill(d, y):
    """Return filled intervals at y, using the SVG nonzero winding rule."""
    return _fill_at(d, y, transpose=True)


def vertical_round_stroke(d, x, radius):
    """Yield vertical intervals of a contour's round stroke."""
    for left, right in _lines(d, x, radius):
        delta = right - left
        near = max(min(left.real, right.real) - x, -radius)
        far = min(max(left.real, right.real) - x, radius)
        if near > far:
            continue
        if not delta.real:
            padding = sqrt(max(0, radius ** 2 - near ** 2))
            yield min(left.imag, right.imag) - padding, max(left.imag, right.imag) + padding
        else:
            optimum = radius * delta.imag / abs(delta) * copysign(1, delta.real)
            bounds = []
            for side in (-1, 1):
                u = max(near, min(far, side * optimum))
                y = (x + u - left.real) / delta.real * delta.imag + left.imag
                bounds.append(y + side * sqrt(max(0, radius ** 2 - u ** 2)))
            yield tuple(bounds)
