from dataclasses import dataclass
from math import cos, radians, sin
from xml.etree.ElementTree import Element

from common import node, number, path, tag
from wardrobe_eurasian_weapons import DRAWERS
import image_arsenal_art
from wardrobe_weapon_art import LEATHER, STEEL_SHADE, draw_disc_sword_hilt, draw_polovtsian_sabre_hilt
from wardrobe_weapon_art import hatch, line, shape


@dataclass(frozen=True)
class Sheath:
    length: int
    half_width: int
    curve: int
    angle: int
    mouth: int
    leather: str
    fittings: str
    reverse_hilt: bool = False
    troitsky_chape: bool = False


_NOVGOROD = Sheath(240, 8, 0, -14, 25, "#8a4840", "#a17e57")
_SHEATHS = {
    "wp_long_knife": Sheath(153, 7, 5, -18, 20, "#7e503b", "#9b865f"),
    "sheathed_sword": _NOVGOROD,
    "sword": _NOVGOROD,
    "rus_disc_sword": Sheath(239, 8, 0, -15, 17, "#61483d", "#9a7d54", troitsky_chape=True),
    "eur_west_lobed_sword": Sheath(240, 10, 0, -15, 24, "#744637", "#9d8259"),
    "eur_west_oval_sword": Sheath(245, 8, 0, -15, 21, "#74443d", "#929586"),
    "eur_west_seax": Sheath(111, 10, 4, -22, 18, "#956346", "#a88658"),
    "eur_steppe_vienna_sabre": Sheath(219, 9, 27, -13, 25, "#673e38", "#b3935b"),
    "eur_steppe_yaroslavl_sabre": Sheath(239, 7, 18, -12, 22, "#6c5140", "#888d80", True),
    "steppe_polovtsian_sabre": Sheath(236, 8, 11, -12, 17, "#58483f", "#858175"),
    "eur_steppe_samanid_khanjar": Sheath(102, 10, 3, -18, 24, "#8b5445", "#b49156", True),
    "eur_east_japan_tachi": Sheath(223, 8, -19, -31, 25, "#524039", "#a58456"),
    "eur_east_song_crescent_sword": Sheath(195, 9, 16, -16, 23, "#7d4640", "#a98553", True),
    "eur_east_china_dragon_ring": Sheath(220, 7, -10, -17, 24, "#554037", "#a88a58"),
}
_HILT_DRAWERS = {
    "rus_disc_sword": draw_disc_sword_hilt,
    "steppe_polovtsian_sabre": draw_polovtsian_sabre_hilt,
}


@dataclass(frozen=True)
class LoopFit:
    angle: int
    scale: float
    shaft_x: int
    shaft_y: int


_LOOP_FITS = {
    "wp_flail": LoopFit(0, .75, 0, 0),
    "wp_signal_horn": LoopFit(65, .62, 9, -19),
    "axe": LoopFit(169, .78, 0, 44),
    "eur_west_francisca": LoopFit(172, .86, 3, 53),
    "eur_west_bayeux_club": LoopFit(172, .94, 0, 42),
    "eur_steppe_nefedyevo_flail": LoopFit(-5, .72, -13, -60),
    "eur_steppe_zagorye_mace": LoopFit(-8, .75, -9, -85),
    "eur_steppe_zaryadye_mace": LoopFit(-10, .74, -10, -81),
    "eur_steppe_seltso_hammer_axe": LoopFit(-8, .77, -10, -100),
    "eur_steppe_dargavs_double_axe": LoopFit(175, .69, 0, 78),
    "eur_steppe_ghaznavid_feline_mace": LoopFit(-7, .66, -8, -96),
    "eur_east_liao_guduo": LoopFit(-13, .72, -8, -94),
    "eur_east_bengal_ankusha": LoopFit(-9, .68, -6, -61),
}


@dataclass(frozen=True)
class EdgeCover:
    contour: str
    seam: str


_AXE_COVERS = {
    "axe": EdgeCover("M21 56Q27 54 30 51Q39 70 33 95Q27 93 22 87Q25 71 21 56Z",
                     "M29 54Q35 72 31 91"),
    "eur_west_francisca": EdgeCover("M26 59L32 52Q34 69 43 81Q38 88 27 91L24 84"
                                    "Q30 80 34 79Q29 70 26 59Z", "M31 56Q34 73 40 81L29 88"),
    "eur_steppe_seltso_hammer_axe": EdgeCover("M-41-131Q-36-132-31-129Q-34-120-29-110"
                                             "L-36-106Q-42-112-41-131Z", "M-38-128Q-39-117-35-110"),
    "eur_steppe_dargavs_double_axe": EdgeCover("M-42 92L-27 92L-27 103L-42 100Z"
                                              "M31 96Q39 93 41 102Q44 116 35 135Q31 142 23 139"
                                              "Q18 135 21 129Q32 119 31 96Z",
                                              "M-39 95l9 2M36 99Q42 113 32 135"),
}


_COMPACT_ITEMS = {"eur_west_taull_sling", "eur_east_chola_chakra"}


SHEATHED = frozenset(_SHEATHS)
WAIST_WEAPONS = SHEATHED | frozenset(_LOOP_FITS) | _COMPACT_ITEMS


def _engraved_stitch(parent, contour):
    path(parent, contour, "none", stroke="#d3a77b", stroke_width=.87,
         stroke_linecap="round", stroke_dasharray="1.4 2.2")


def _draw_hilt(parent, style, sheath):
    angle = 180 if sheath.reverse_hilt else 0
    offset = sheath.mouth if sheath.reverse_hilt else -sheath.mouth
    hilt_scale = "scale(1 1.08) " if style == "eur_east_japan_tachi" else ""
    hilt = node(parent, "g", data_part="scabbard-hilt",
                transform=f"rotate({angle}) {hilt_scale}translate(0 {offset})")
    hilt_drawer = _HILT_DRAWERS.get(style)
    if hilt_drawer is not None:
        hilt_drawer(hilt)
        return
    if style in {"sword", "sheathed_sword"}:
        from wardrobe_northwest_arms import _sword_hilt

        _sword_hilt(hilt)
        return

    artwork = Element(tag("g"))
    if style == "wp_long_knife":
        image_arsenal_art.WEAPON_DRAWERS[style](artwork)
        hilt.extend(artwork[:3])
        _clear_grip_marker(hilt)
        return
    DRAWERS[style](artwork)
    if style == "eur_west_seax":
        # The seax's own rotation belongs to the shared blade artwork.
        grip, grain, *_, collar = artwork[0]
        hilt.extend((grip, grain, collar))
    else:
        # Regional drawers paint the blade and its detailing before the hilt.
        start = next(i for i, item in enumerate(artwork) if item.get("data-part") == "weapon-grip")
        # The Vienna sabre adds one last line of decoration to the blade.
        stop = -1 if style == "eur_steppe_vienna_sabre" else None
        hilt.extend(artwork[start:stop])
    if style == "eur_east_japan_tachi":
        line(hilt, "M-3-23.8Q0-25.4 3.8-24.1", "#d9b878", 1.05)
    _clear_grip_marker(hilt)


def _clear_grip_marker(artwork):
    for item in artwork.iter():
        if item.get("data-part") == "weapon-grip":
            del item.attrib["data-part"]


def _draw_troitsky_chape(parent, length, color):
    # A small trefoil and unequal shoulders evoke Kainov and Avdeenko, fig. 1:5.
    chape = node(parent, "g", data_part="scabbard-chape", transform=f"translate(0 {length - 22})")
    shape(chape, "M-5 8V1Q-3 1-2 6Q0 9 2 6Q3 1 5-2V8Q5 18 1 21"
          "V24Q0 25-1 24V21Q-5 18-5 8Z", color, 1.5)
    line(chape, "M-3.2 7Q-4 17-.8 20", "#d1b182", .85)
    line(chape, "M0 18Q-3 16-3 13Q-3 10 0 10Q3 10 3 13Q3 16 0 18Z"
         "M0 16v-3m0 1q-3 1-2-1m2 1q2 .8 2-1", "#564539", .76)


def _draw_sheath_body(parent, sheath, length):
    w, c = sheath.half_width, sheath.curve
    tip_w = max(4, w - 4)
    mid, end = round(length * .53), length - 17
    contour = (f"M{-w} 0Q0-2 {w} 0C{w} {mid} {c + tip_w} {end - 19} {c + tip_w} {end}"
               f"Q{c + tip_w} {length - 4} {c} {length}Q{c - tip_w} {length} {c - tip_w} {end}"
               f"C{c - tip_w} {end - 19} {-w} {mid} {-w} 0Z")
    shadow = (f"M{w - 1} 2C{w - 1} {mid} {c + tip_w - 1} {end - 15} {c + tip_w - 1} {end}"
              f"Q{c + tip_w - 1} {length - 4} {c} {length - 1}L{c - 2} {end}"
              f"C{c - 2} {end - 15} {w - 5} {mid} {w - 5} 2Z")
    shape(parent, contour, sheath.leather, 2.45, data_part="scabbard-body")
    path(parent, shadow, "#382828", opacity=.51)
    hatch(parent, shadow, .48)
    _engraved_stitch(parent, f"M{3 - w} 9C{3 - w} {mid} {c - tip_w + 2} {end - 18} "
                    f"{c - tip_w + 2} {end - 4}")
    if sheath.troitsky_chape:
        _draw_troitsky_chape(parent, length, sheath.fittings)
    else:
        shape(parent, f"M{c - tip_w} {end}q{tip_w} 3 {2 * tip_w} 0"
              f"Q{c + tip_w} {length - 4} {c} {length}Q{c - tip_w} {length} {c - tip_w} {end}Z",
              sheath.fittings, 1.65)
        line(parent, f"M{c - tip_w + 2} {end + 3}q1 8 {tip_w - 1} 12", "#d2b284", .88)
    shape(parent, f"M{-w - 1} 0Q0-2 {w + 1} 0v6Q0 4 {-w - 1} 6Z", sheath.fittings, 1.7)
    line(parent, f"M{2 - w} 1.8Q0 .7 {w - 2} 1.8", "#debd8c", .95)


def _draw_strap(parent, start_x, end_x, end_y, *, split=False):
    sx, ex, ey = map(number, (start_x, end_x, end_y))
    weight = 2.8 if split else 2.35
    contour = (f"M{sx} 0Q{sx} -3 {number(start_x + weight)} -1"
               f"Q{sx} {number(end_y * .38)} {number(end_x + weight)} {ey}"
               f"L{number(end_x - weight)} {number(end_y + 2)}"
               f"Q{number(start_x - weight)} {number(end_y * .44)} {sx} 0Z")
    shape(parent, contour, LEATHER, 1.45, data_part="scabbard-hanger")
    line(parent, f"M{sx} 2Q{sx} {number(end_y * .39)} {ex} {ey}", "#bc906a", .9)


def _draw_scabbard(parent, style, sheath, *, along_bow_case, child, right_anchor=23):
    tachi = style == "eur_east_japan_tachi"
    age_scale = .75 if child else 1
    angle = sheath.angle + (9 if along_bow_case else 0)
    drop = (35 if tachi else 29) * age_scale
    transform = f"translate(0 {number(drop)}) rotate({angle})"
    sine, cosine = sin(radians(angle)), cos(radians(angle))
    if tachi:
        suspension = ((-22, 12), (12 if child else right_anchor, 51))
    else:
        suspension = ((-14, 12), (13, 31))
    bands = []
    w = sheath.half_width

    # The straps follow the sides of the hilt and tuck beneath the bands.
    for start_x, y in suspension:
        y = round(y * age_scale)
        edge = -w if start_x < 0 else w
        end_x = edge * cosine - y * sine
        end_y = drop + edge * sine + y * cosine
        _draw_strap(parent, start_x, end_x, end_y, split=tachi)
        bands.append((edge, y))

    hanging = node(parent, "g", transform=transform)
    _draw_sheath_body(hanging, sheath, round(sheath.length * age_scale))
    _draw_hilt(hanging, style, sheath)
    for edge, y in bands:
        shape(hanging, f"M{-w} {y - 3}q{w} 2.5 {2 * w}-.5v4.5q{-w} 3 {-2 * w} 1Z",
              sheath.fittings if tachi else "#775443", 1.55, data_part="scabbard-band")
        line(hanging, f"M{1 - w} {y - 1}q{w-1} 2 {2 * w - 2}-.45", "#cfa97c", .88)
        if tachi:
            node(hanging, "circle", cx=edge, cy=y, r=2.65, fill="none", stroke="#c6a46e", stroke_width=1.4)


def _draw_axe_cover(parent, style):
    cover = _AXE_COVERS[style]
    shape(parent, cover.contour, "#77503c", 1.9, data_part="axe-edge-cover")
    _engraved_stitch(parent, cover.seam)


def _draw_loop_item(parent, style, child):
    fit = _LOOP_FITS[style]
    scale = fit.scale * (.87 if child else 1)
    art = node(parent, "g", transform=f"translate(0 25) rotate({fit.angle}) scale({number(scale)})"
               f" translate({-fit.shaft_x} {-fit.shaft_y})")
    if style == "axe":
        from wardrobe_northwest_arms import _draw_axe

        _draw_axe(art)
    else:
        drawer = image_arsenal_art.WEAPON_DRAWERS.get(style) or DRAWERS[style]
        drawer(art)
    if style in _AXE_COVERS:
        _draw_axe_cover(art[0] if style == "eur_steppe_dargavs_double_axe" else art, style)
    _clear_grip_marker(art)
    shape(parent, "M-7 21Q0 23 7 21L7 27Q0 30-7 27Z", "#8c6247", 1.55,
          data_part="waist-weapon-loop")
    line(parent, "M-5 24q5 1.6 10-.3", "#d0a477", .9)


def _draw_sling(parent):
    loops = "M-1 16C-11 28-15 50-8 57S10 47 7 35L2 17M1 17C6 31 15 44 11 55Q7 65.5 0 65"
    line(parent, loops, "#302521", 3.3)
    line(parent, loops, "#a67753", 1.36)
    shape(parent, "M-9 50Q-1 53 5 49L8 56Q4 63-6 63Q-11 59-9 50Z", "#86604a", 1.65)
    line(parent, "M-7 53q7 2 12-1m-10 7q4 0 8-2", "#bc9467", .96)
    shape(parent, "M-5 14Q0 11 6 15L4 22Q-1 20-6 22Z", LEATHER, 1.4)


def _draw_chakra_cover(parent):
    shape(parent, "M-3 24Q6 19 15 26Q24 35 20 51Q16 67-1 69Q-17 68-21 56"
          "Q-27 45-21 34Q-17 27-12 24Q-9 27-3 24Z", "#72503e", 2,
          data_part="chakra-cover")
    _engraved_stitch(parent, "M-13 29Q-26 40-19 55Q-15 66-1 66Q14 64 19 51Q22 38 14 30")
    node(parent, "circle", cx=-1, cy=46, r=8, fill="#977951", stroke=STEEL_SHADE, stroke_width=1.65)
    line(parent, "M-6 46q1-5 6-5m-1 9q4 0 5-3", "#d5b480", 1)


def draw_waist_weapon(parent, style, body, *, along_bow_case=False, child=False):
    if style not in WAIST_WEAPONS:
        return
    if style in SHEATHED:
        position = .28 if along_bow_case else .59
        scabbard = node(parent, "g", data_part="scabbard", data_style=style,
                        transform=f"translate({number(160 + body.waist * position)} 403)")
        # Keep the outer hanger inside a narrow waist instead of fastening it
        # beyond the edge of a fitted gown's clipped belt.
        right_anchor = min(23, body.waist * (1 - position) - 5)
        _draw_scabbard(scabbard, style, _SHEATHS[style], along_bow_case=along_bow_case, child=child,
                       right_anchor=right_anchor)
        return

    position = .20 if along_bow_case else .67
    gear = node(parent, "g", data_part="waist-weapon", data_style=style,
                transform=f"translate({number(160 + body.waist * position)} 403)")
    if child and style in _COMPACT_ITEMS:
        gear = node(gear, "g", transform="scale(.85)")
    if style == "eur_steppe_zagorye_mace":
        hanger = "M-32-1Q-29-2-26-1C-21 9-15 17-5 21H4L5 25Q0 27-7 25C-18 21-27 10-32-1Z"
        highlight = "M-29 0C-23 12-14 19-6 23"
    else:
        hanger = "M-5 0Q0-2 5 .5Q3 8 5 15L7 23Q0 25-7 23Q-4 12-5 0Z"
        highlight = "M-2 2Q-3 11-3 20"
    shape(gear, hanger, LEATHER, 1.55, data_part="waist-weapon-hanger")
    line(gear, highlight, "#c89e75", .95)
    if style == "eur_west_taull_sling":
        _draw_sling(gear)
    elif style == "eur_east_chola_chakra":
        _draw_chakra_cover(gear)
    else:
        _draw_loop_item(gear, style, child)
