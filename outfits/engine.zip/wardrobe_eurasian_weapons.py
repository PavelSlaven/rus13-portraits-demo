from wardrobe_eurasian_east import WEAPONS as EAST
from wardrobe_eurasian_steppe import WEAPONS as STEPPE
from wardrobe_eurasian_west import WEAPONS as WEST


REGIONS = {
    "Европа и Балтика": WEST,
    "Русь, степь и Передняя Азия": STEPPE,
    "Китай, Япония, Индия и Ангкор": EAST,
}
OPTIONS = {style: label for weapons in REGIONS.values() for style, (label, _) in weapons.items()}
DRAWERS = {style: drawer for weapons in REGIONS.values() for style, (_, drawer) in weapons.items()}
