from dataclasses import dataclass, replace
from xml.etree.ElementTree import Element

from common import HeadGeometry, node, number, path
import wardrobe_adult_men
import wardrobe_adult_women
import wardrobe_northwest_men
import wardrobe_northwest_military
import wardrobe_northwest_women
import wardrobe_northwest_gotland
from wardrobe_child_east import DRAWERS as CHILD_EAST_OUTFITS
from wardrobe_child_west import DRAWERS as CHILD_WEST_OUTFITS
from wardrobe_eurasia import DRAWERS as EURASIAN_OUTFITS
from wardrobe_rus import DRAWERS as RUS_OUTFITS


OPTIONS = {
    "body": {
        "medium": "Среднее",
        "slim": "Худощавое",
        "full": "Полное",
        "athletic": "Атлетическое",
    },
    "outfit": {
        "shirt": "Рубаха",
        "svita": "Свита",
        "cloak": "Плащ",
        "kozukh": "Кожух",
        "armor": "Доспех",
        "izyaslav_kaftan": "Изяславский кафтан",
        "korzno": "Корзно с подкладкой",
        "ryazan_sleeves": "Рубаха с длинными рукавами",
        "rus_mantle": "Одежда с наплечной накидкой",
        "steppe_robe": "Степной халат со сборками",
        "kariginu": "Каригину",
        "tiraz_robe": "Одеяние с нарукавными полосами",
        "pellote": "Кастильское пельоте",
        "tang_jacket": "Танский жакет с высокой юбкой",
        "steppe_dress": "Степное платье с правым запахом",
        "norse_child_tunic": "Шерстяная туника с клиньями",
        "song_child_jacket": "Сунская куртка с запахом",
        "rus_child_svita": "Свита с тканой тесьмой",
        "iraq_school_robe": "Одеяние ученика из «Макам»",
        "castile_royal_pellote": "Королевское пельоте",
        "yuan_brocade_coat": "Наряд Юань с левой застёжкой",
        **wardrobe_adult_men.OPTIONS,
        **wardrobe_adult_women.OPTIONS,
        **wardrobe_northwest_men.OPTIONS,
        **wardrobe_northwest_women.OPTIONS,
        **wardrobe_northwest_gotland.OPTIONS,
        **wardrobe_northwest_military.OPTIONS,
    },
    "cloth_color": {
        "natural": "Естественный",
        "madder": "Мареновый",
        "moss": "Мшистый",
        "woad": "Вайда",
        "ochre": "Охристый",
    },
    "accessory": {
        "none": "Без украшений",
        "brooch": "Фибула",
        "pendant": "Подвеска",
        "pouch": "Поясной кошель",
    },
}

LABELS = {
    "body": "Телосложение",
    "outfit": "Одежда",
    "cloth_color": "Цвет ткани",
    "accessory": "Украшения и принадлежности",
}


@dataclass(frozen=True)
class Body:
    shoulder: int
    shoulder_y: int
    chest: int
    waist: int
    hem: int
    sleeve: int


BODIES = {
    "medium": Body(80, 290, 76, 70, 79, 119),
    "slim": Body(69, 289, 63, 55, 63, 103),
    "full": Body(86, 292, 84, 85, 94, 134),
    "athletic": Body(93, 287, 85, 65, 76, 128),
}
CHILD_BODY_SCALE = .84


@dataclass(frozen=True)
class Cloth:
    base: str
    light: str
    shade: str
    deep: str


@dataclass(frozen=True)
class OutfitArt:
    front: Element
    sleeves: tuple[Element, Element]
    outer: Element | None
    waist: Element | None
    body: Body
    neck: float
    cloth: Cloth
    look: dict[str, str]
    hem_y: int | None = None


LINEN = Cloth("#c8af81", "#ead29e", "#a28660", "#785d49")
MADDER = Cloth("#925749", "#bb7d61", "#6d3e37", "#4d2e2a")
MOSS = Cloth("#6b7357", "#929674", "#4d5541", "#363c32")
WOAD = Cloth("#526d76", "#7d9295", "#3b5059", "#2f3e49")
OCHRE = Cloth("#a8804e", "#c8a46b", "#805b37", "#60422f")
DYED = {"madder": MADDER, "moss": MOSS, "woad": WOAD, "ochre": OCHRE}
NATURAL = {
    "shirt": LINEN,
    "svita": Cloth("#586e66", "#819387", "#3e504c", "#293735"),
    "cloak": Cloth("#88513f", "#b27555", "#663e32", "#482f2b"),
    "kozukh": Cloth("#8d7358", "#b09670", "#69513f", "#4a382e"),
    "armor": MADDER,
    "izyaslav_kaftan": Cloth("#59697a", "#8192a1", "#3d4c5d", "#2a3343"),
    "korzno": Cloth("#8e5045", "#b86f57", "#66392f", "#412720"),
    "ryazan_sleeves": Cloth("#777957", "#a4a07b", "#51543f", "#373a30"),
    "rus_mantle": Cloth("#72404b", "#a56562", "#512e3b", "#38232d"),
    "steppe_robe": Cloth("#755540", "#a9825b", "#523a32", "#3b2a26"),
    "kariginu": Cloth("#7d858d", "#aeb8bc", "#515b6a", "#343d49"),
    "tiraz_robe": Cloth("#7e4e62", "#aa7684", "#57384a", "#392837"),
    "pellote": Cloth("#8a513f", "#b7825d", "#602f29", "#412620"),
    "tang_jacket": Cloth("#6e8271", "#9aaf93", "#465b52", "#2c403b"),
    "steppe_dress": Cloth("#805158", "#b3807c", "#61383e", "#432830"),
    "norse_child_tunic": Cloth("#beb096", "#dccdb2", "#948572", "#61564b"),
    "song_child_jacket": Cloth("#8d8f6b", "#adb18f", "#666b51", "#414a39"),
    "rus_child_svita": Cloth("#76545f", "#ab7980", "#573945", "#422d36"),
    "iraq_school_robe": Cloth("#587386", "#7e9aa7", "#415661", "#303e46"),
    "castile_royal_pellote": Cloth("#883d45", "#bb6366", "#612a38", "#481f29"),
    "yuan_brocade_coat": Cloth("#426f6b", "#74938b", "#33514f", "#263d3e"),
    "rus_gilt_cuff_tunic": Cloth("#596657", "#8e9676", "#424a40", "#30372e"),
    "castile_laced_saya": Cloth("#875057", "#ae7476", "#633944", "#462d35"),
    "yuan_fur_hunt_robe": Cloth("#bfb6a3", "#e1d7c1", "#8c8076", "#605550"),
    "song_round_robe": Cloth("#a25748", "#c48663", "#773e36", "#54312e"),
    "rus_gold_yoke_gown": Cloth("#98715d", "#bd947b", "#754f45", "#4c3631"),
    "rus_checked_panel": Cloth("#d6c29d", "#ead9b6", "#ad9677", "#7b6455"),
    "naumburg_clasp_mantle": Cloth("#85494f", "#ad6d70", "#64373e", "#432b34"),
    "song_pheasant_robe": Cloth("#34465a", "#566c7f", "#253547", "#192733"),
    "nw_nov_svita": Cloth("#656a53", "#8e8c6d", "#484b3f", "#33382f"),
    "nw_nov_sofia_tunic": Cloth("#855254", "#af7167", "#603e44", "#442d34"),
    "nw_karel_tunic": Cloth("#526876", "#7e8890", "#364957", "#293640"),
    "nw_baltic_mens_coat": Cloth("#7e6453", "#a5805d", "#5a493e", "#40362f"),
    "nw_nordic_gored_tunic": Cloth("#895d50", "#b37c65", "#613f3a", "#4b3031"),
    "nw_nov_womens_rubakha": Cloth("#d8c6a3", "#f2e3c0", "#b29c7a", "#786151"),
    "nw_nov_womens_fur_coat": Cloth("#633646", "#865263", "#482736", "#34222d"),
    "nw_nov_trimmed_gown": Cloth("#32675e", "#599083", "#244c49", "#1d3839"),
    "nw_karel_apron_gown": Cloth("#56664e", "#849071", "#3e4d3e", "#2e3b32"),
    "nw_baltic_spiral_kuub": Cloth("#39576f", "#66839a", "#2b4258", "#202f43"),
    "nw_nordic_pleated_gown": Cloth("#986846", "#bd9067", "#704b37", "#51382f"),
    "nw_gotland_mens_cloak": Cloth("#756a50", "#a6976d", "#514b3e", "#3b352f"),
    "nw_gotland_womens_mantle": Cloth("#8c654f", "#b8906b", "#634b3e", "#47352e"),
    "nw_mail_hauberk": Cloth("#a58c69", "#c4a67c", "#7e674d", "#574638"),
    "nw_nov_lamellar": Cloth("#744b46", "#aa695b", "#593934", "#402b28"),
    "nw_mail_surcoat": Cloth("#aa9982", "#cebda0", "#817668", "#534b44"),
}
_CHILD_DRAWERS = {**CHILD_WEST_OUTFITS, **CHILD_EAST_OUTFITS}
ADULT_CASTS = {
    **dict.fromkeys(wardrobe_adult_men.OPTIONS, "men"),
    **dict.fromkeys(wardrobe_adult_women.OPTIONS, "women"),
    **dict.fromkeys(wardrobe_northwest_men.OPTIONS, "men"),
    **dict.fromkeys(wardrobe_northwest_women.OPTIONS, "women"),
    "nw_gotland_mens_cloak": "men",
    "nw_gotland_womens_mantle": "women",
}
NORTHWEST_ARMOR = tuple(wardrobe_northwest_military.OPTIONS)
_OUTFIT_DRAWERS = {**RUS_OUTFITS, **EURASIAN_OUTFITS, **_CHILD_DRAWERS,
                   **wardrobe_adult_men.DRAWERS, **wardrobe_adult_women.DRAWERS,
                   **wardrobe_northwest_men.DRAWERS, **wardrobe_northwest_women.DRAWERS,
                   **wardrobe_northwest_gotland.DRAWERS,
                   **wardrobe_northwest_military.DRAWERS}
_CUT_PADDING = {
    "izyaslav_kaftan": {"shoulder": 4, "chest": 3, "hem": 6, "sleeve": 2},
    "korzno": {"shoulder": 6, "chest": 3, "hem": 8, "sleeve": 6},
    "ryazan_sleeves": {"shoulder": 3, "hem": 4, "sleeve": 10},
    "rus_mantle": {"shoulder": 5, "chest": 3, "waist": 3, "hem": 6},
    "steppe_robe": {"shoulder": 3, "chest": 3, "waist": -7, "hem": 8},
    "kariginu": {"shoulder": 10, "shoulder_y": -3, "chest": 6, "waist": 8, "hem": 9, "sleeve": 13},
    "tiraz_robe": {"shoulder": 4, "chest": 3, "hem": 7, "sleeve": 9},
    "pellote": {"waist": 3, "hem": 10},
    "tang_jacket": {"waist": 3, "hem": 12},
    "steppe_dress": {"shoulder": 3, "chest": 4, "waist": 3, "hem": 11, "sleeve": 4},
    "norse_child_tunic": {"shoulder_y": 3, "chest": 3, "waist": 4, "hem": 6, "sleeve": 6},
    "song_child_jacket": {"chest": 2, "waist": 2, "hem": 6, "sleeve": 4},
    "rus_child_svita": {"shoulder": 3, "chest": 2, "hem": 8, "sleeve": 4},
    "iraq_school_robe": {"shoulder": 4, "waist": 5, "hem": 8, "sleeve": 8},
    "castile_royal_pellote": {"waist": 6, "hem": 12},
    "yuan_brocade_coat": {"shoulder": 6, "chest": 4, "waist": 4, "hem": 7, "sleeve": 7},
    "rus_gilt_cuff_tunic": {"shoulder": 4, "chest": 2, "waist": 3, "hem": 4, "sleeve": 3},
    "castile_laced_saya": {"shoulder": 1, "chest": -4, "waist": -6, "hem": 4, "sleeve": -3},
    "yuan_fur_hunt_robe": {"shoulder": 10, "shoulder_y": -4, "chest": 9, "waist": 5, "hem": 13, "sleeve": 10},
    "song_round_robe": {"shoulder": 6, "chest": 5, "waist": 3, "hem": 8, "sleeve": 8},
    "rus_gold_yoke_gown": {"shoulder": -6, "waist": -4, "hem": 13, "sleeve": 2},
    "rus_checked_panel": {"shoulder": -7, "chest": -3, "waist": -3, "hem": 16},
    "naumburg_clasp_mantle": {"shoulder": 2, "chest": 1, "waist": -3, "hem": 10, "sleeve": -4},
    "song_pheasant_robe": {"shoulder": 3, "chest": 4, "waist": 5, "hem": 12, "sleeve": 5},
    "nw_nov_svita": {"shoulder": 3, "chest": 2, "hem": 5, "sleeve": 2},
    "nw_nov_sofia_tunic": {"shoulder": 1, "chest": 2, "hem": 4},
    "nw_karel_tunic": {"shoulder": 4, "chest": 3, "waist": 2, "hem": 7, "sleeve": 4},
    "nw_baltic_mens_coat": {"shoulder": 3, "chest": 2, "hem": 8, "sleeve": 2},
    "nw_nordic_gored_tunic": {"shoulder": 3, "chest": 2, "waist": -2, "hem": 11, "sleeve": 2},
    "nw_nov_womens_rubakha": {"shoulder": -5, "chest": -2, "waist": -3, "hem": 12},
    "nw_nov_womens_fur_coat": {"shoulder": 5, "shoulder_y": -2, "chest": 4, "waist": 2, "hem": 10, "sleeve": 7},
    "nw_nov_trimmed_gown": {"shoulder": -4, "waist": -3, "hem": 11},
    "nw_karel_apron_gown": {"shoulder": -3, "waist": -2, "hem": 10},
    "nw_baltic_spiral_kuub": {"shoulder": 1, "waist": -2, "hem": 8, "sleeve": 4},
    "nw_nordic_pleated_gown": {"shoulder": -4, "waist": -5, "hem": 13},
    "nw_gotland_mens_cloak": {"shoulder": 3, "chest": 2, "hem": 8, "sleeve": 2},
    "nw_gotland_womens_mantle": {"shoulder": -4, "chest": 1, "waist": 1, "hem": 10, "sleeve": -4},
    "nw_mail_hauberk": {"shoulder": 4, "chest": 4, "waist": 4, "hem": 5, "sleeve": 4},
    "nw_nov_lamellar": {"shoulder": 3, "chest": 4, "waist": 3, "hem": 5, "sleeve": 3},
    "nw_mail_surcoat": {"shoulder": 4, "chest": 4, "waist": 4, "hem": 7, "sleeve": 4},
}
_OUTER_LAYER = {"korzno", "rus_mantle", "kariginu", "tang_jacket", "yuan_fur_hunt_robe", "naumburg_clasp_mantle",
                *wardrobe_northwest_gotland.OPTIONS,
                "nw_mail_surcoat"}
_LIGHT_UNDERLAYER = {"korzno", "rus_mantle", "pellote", "castile_royal_pellote", "naumburg_clasp_mantle",
                     "nw_karel_apron_gown"}
_FABRIC_BELTS = {"ryazan_sleeves", "tiraz_robe", "steppe_dress", "rus_child_svita", "rus_gilt_cuff_tunic", "rus_gold_yoke_gown",
                 "nw_mail_hauberk", "nw_nov_lamellar", "nw_nov_womens_rubakha", *wardrobe_northwest_men.OPTIONS}
_DRAWN_BELTS = {"korzno", "rus_checked_panel", "song_round_robe", "song_pheasant_robe"}
BELTLESS_OUTFITS = frozenset(_OUTFIT_DRAWERS) - (_FABRIC_BELTS | _DRAWN_BELTS)
_WAIST_PARTS = {"izyaslav_kaftan": "waist-seam", "steppe_robe": "waist-seam", "tang_jacket": "high-waist-band",
                "song_round_robe": "belt", "rus_checked_panel": "checked-panel", "song_pheasant_robe": "belt"}
_MIRROR = "translate(320 0) scale(-1 1)"


def _body_fit(body: Body, outfit: str) -> Body:
    if outfit == "svita":
        return replace(
            body, shoulder=body.shoulder + 3, chest=body.chest + 2,
            hem=body.hem + 5, sleeve=body.sleeve + 2,
        )
    if outfit == "kozukh":
        return replace(
            body, shoulder=body.shoulder + 7, shoulder_y=body.shoulder_y - 3,
            chest=body.chest + 6, waist=body.waist + 4, hem=body.hem + 8, sleeve=body.sleeve + 9,
        )
    if outfit in _CUT_PADDING:
        return replace(body, **{key: getattr(body, key) + pad for key, pad in _CUT_PADDING[outfit].items()})
    return body


def _front_shape(body: Body, neck: float, *, hem_y: int | None = None) -> str:
    shoulder = body.shoulder
    crest = body.shoulder_y
    chest = body.chest
    waist = body.waist
    hem = body.hem
    if hem_y is None:
        lower = (f"C{159 - waist} 415 {165 - hem} 431 {160 - hem} 445 "
                 f"H{160 + hem} C{155 + hem} 431 {161 + waist} 415 {160 + waist} 400 ")
    else:
        edge = hem + 4
        lower = (f"C{159 - waist} 418 {161 - hem} 476 {160 - edge} {hem_y} "
                 f"Q160 {hem_y + 19} {160 + edge} {hem_y} "
                 f"C{159 + hem} 476 {161 + waist} 418 {160 + waist} 400 ")
    return (
        f"M{number(160 - neck)} 273 "
        f"C{number(146 - neck)} 273 {173 - shoulder} {crest - 10} {160 - shoulder} {crest} "
        f"C{157 - shoulder} {crest + 15} {162 - chest} 322 {160 - chest} 346 "
        f"C{158 - chest} 370 {161 - waist} 386 {160 - waist} 400 "
        f"{lower}"
        f"C{159 + waist} 386 {162 + chest} 370 {160 + chest} 346 "
        f"C{158 + chest} 322 {163 + shoulder} {crest + 15} {160 + shoulder} {crest} "
        f"C{147 + shoulder} {crest - 10} {number(174 + neck)} 273 {number(160 + neck)} 273 "
        f"Q160 307 {number(160 - neck)} 273Z"
    )


def _sleeve_shape(body: Body, outfit=None) -> str:
    shoulder = 160 - body.shoulder
    outer = 160 - body.sleeve
    crest = body.shoulder_y
    cuff = 160 - body.hem + 11
    upper = f"M{shoulder + 11} {crest - 6} C{shoulder - 11} {crest + 1} {outer + 13} 304 {outer + 7} 332 "
    if outfit == "ryazan_sleeves":
        lower = f"C{outer + 3} 354 {outer - 9} 380 {outer - 5} 402 Q{outer - 1} 414 {outer + 18} 424 L{outer + 24} 445"
    elif outfit in {"rus_mantle", "steppe_robe"}:
        lower = f"C{outer - 1} 358 {outer + 6} 406 {outer + 17} 445"
    else:
        lower = f"C{outer - 3} 362 {outer - 4} 415 {outer + 9} 445"
    inner = f"L{shoulder + 29} 336" if outfit is None else f"Q{max(cuff + 15, 181 - body.waist)} 406 {shoulder + 29} 336"
    return f"{upper}{lower} H{cuff} {inner}Z"


def _draw_sleeves(parent, body: Body, cloth: Cloth, *, cut=None):
    shoulder = 160 - body.shoulder
    outer = 160 - body.sleeve
    crest = body.shoulder_y
    shape = _sleeve_shape(body, cut)
    slots = []
    for right in (False, True):
        sleeve = node(parent, "g", transform=_MIRROR) if right else parent
        path(sleeve, shape, cloth.shade if right else cloth.base, class_="edge")
        if cut is not None:
            part = "sleeve-right" if right else "sleeve-left"
            sleeve = node(sleeve, "g", data_part=part, clip_path="url(#wardrobe-sleeve-mask)")
            slots.append(sleeve)
        path(
            sleeve,
            f"M{outer + 8} 337 Q{outer + 15} 308 {shoulder} {crest + 4} "
            f"Q{outer + 22} 326 {outer + 23} 351 L{outer + 12} 373 "
            f"Q{outer + 12} 421 {outer + 23} 444 H{outer + 9} Q{outer - 6} 397 {outer + 8} 337Z",
            cloth.deep if right else cloth.shade,
        )
        path(
            sleeve,
            f"M{outer + 7} 354 Q{outer + 18} 326 {outer + 27} 315 "
            f"Q{outer + 18} 342 {outer + 21} 359 L{outer + 4} 383Z",
            "url(#ink-lines)",
            opacity=".44",
        )
        if cut not in {"kariginu", "steppe_robe"} and cut not in _CHILD_DRAWERS:
            path(
                sleeve,
                f"M{outer + 12} 376 q10 -11 20 -14 m-18 27 16 -10 "
                f"M{outer + 11} 414 q4 11 13 21",
                class_="seam",
            )
            path(sleeve, f"M{outer + 13} 354 l9 -17 m-9 24 9 -14 m-6 61 10 13", class_="etch")
    return tuple(slots)


def _draw_folds(front, body: Body, cloth: Cloth) -> None:
    left = 160 - body.shoulder
    right = 160 + body.shoulder
    waist = 160 + body.waist
    path(front, f"M{left} 296 Q{left + 19} 280 120 278 Q105 303 {left + 8} 335Z", cloth.light)
    path(
        front,
        f"M184 288 Q{right - 13} 289 {right} {body.shoulder_y} L{right + 17} 444 "
        f"H{waist - 13} Q{waist - 4} 405 {waist - 16} 371 Q{right - 25} 313 184 288Z",
        cloth.shade,
    )
    path(front, f"M{left + 1} 344 Q{left + 11} 359 {left + 7} 381 L{left - 8} 402 L{left - 16} 359Z", cloth.shade)
    path(
        front,
        f"M{waist - 23} 371 Q{waist - 7} 390 {waist + 5} 386 L{waist + 4} 416 L{waist - 10} 412Z",
        "url(#ink-lines)", opacity=".42",
    )
    path(
        front,
        f"M120 307 Q103 329 {left + 18} 361 Q{left + 12} 342 114 309Z "
        "M179 302 Q209 314 216 353 Q203 321 179 302Z",
        cloth.light,
    )
    path(front, "M133 409 Q124 426 123 444 H113 Q119 423 133 409Z M174 412 Q184 426 192 445 H177Z", cloth.light)
    path(
        front,
        f"M116 311 Q101 335 {left + 15} 360 M190 312 Q207 329 {right - 15} 367 "
        "M150 338 q-3 22 3 42 m11 -31 6 35 M129 421 l-7 24 m60 -28 8 27",
        class_="seam",
    )
    path(
        front,
        f"M{left + 21} 369 l-7 16 m12 -12 -6 12 M{right - 18} 355 l6 19 m-11 -12 5 15 "
        "M143 367 l2 14 m65 44 4 13",
        class_="etch",
    )


def _draw_collar(front, neck: float, outfit: str) -> None:
    left, right = number(160 - neck), number(160 + neck)
    lower_left, lower_right = number(154 - neck), number(166 + neck)
    band = (
        f"M{left} 273 Q160 307 {right} 273 L{lower_right} 280 "
        f"Q160 319 {lower_left} 280Z"
    )
    if outfit == "svita":
        path(front, "M154 296 167 297 165 399 153 399Z", "#a58e6b", class_="edge")
        path(
            front,
            "M145 310q16 -3 33 1l-1 6-32 -1Z M147 339q17 -2 30 2l-1 6-30 -2Z "
            "M146 369q16 -1 30 2l-2 6-29 -2Z",
            "#b58e5e", class_="edge",
        )
        path(front, "M149 312h13m-12 30h14m-13 30h11", fill="none", stroke="#d3aa76", stroke_width="1.5", stroke_linecap="round")
    elif outfit in ("shirt", "cloak"):
        path(front, "M154 292h12l1 40-12 2Z", "#87483b", class_="edge")
        path(front, "M156 300l8 5-7 6 7 6-7 6 7 5", fill="none", stroke="#ddb581", stroke_width="1.4")

    colors = {"svita": "#a58e6b", "armor": "#593b31", "kozukh": "#4b3830"}
    path(front, band, colors.get(outfit, "#87483b"), class_="edge")
    path(
        front,
        f"M{left} 278 Q160 312 {right} 278",
        fill="none", stroke="#d6b585", stroke_width="1.45", stroke_dasharray="4 4", stroke_linecap="round",
    )


def _draw_belt(parent, body: Body) -> None:
    left, right = 166 - body.waist, 154 + body.waist
    belt = node(parent, "g", data_part="belt", clip_path="url(#wardrobe-torso-mask)")
    path(belt, f"M{left} 396 Q160 414 {right} 395 L{right - 1} 413 Q160 430 {left + 1} 414Z", "#574034", class_="edge")
    path(belt, f"M{left + 3} 400 Q160 417 {right - 3} 399 L{right - 3} 403 Q160 420 {left + 4} 404Z", "#916649")
    path(
        belt,
        f"M{left + 5} 410 Q160 426 {right - 5} 409",
        fill="none", stroke="#bd9369", stroke_width="1.35", stroke_dasharray="3 3", stroke_linecap="round",
    )
    path(
        belt,
        "M149 402l24 -1 5 4-1 13-5 4-24 -1-5 -4v-11Z M151 407l-1 9 20 1 1 -11Z",
        "#c69657", fill_rule="evenodd", stroke="#372621", stroke_width="2.9", stroke_linejoin="round",
    )
    path(belt, "M156 412l16 -1m-25 -4 8 -2", fill="none", stroke="#e9b97b", stroke_width="2", stroke_linecap="round")


def _draw_plate_front(front, defs, body: Body, neck: float) -> None:
    left = 169 - body.shoulder
    right = 151 + body.shoulder
    waist_left, waist_right = 163 - body.waist, 157 + body.waist
    inner_left, inner_right = number(159 - neck), number(161 + neck)
    crest = body.shoulder_y + 2
    plates = (
        f"M{left} {crest} Q{left + 22} {crest - 4} {inner_left} 280 Q160 321 {inner_right} 280 "
        f"Q{right - 22} {crest - 4} {right} {crest} "
        f"Q{155 + body.chest} 345 {waist_right} 401 Q160 415 {waist_left} 401 "
        f"Q{165 - body.chest} 345 {left} {crest}Z"
    )
    mask = node(defs, "clipPath", id="wardrobe-plates-mask")
    path(mask, plates)
    path(front, plates, "#74776b")
    path(front, plates, "url(#armor-plates)")
    tonal = node(front, "g", clip_path="url(#wardrobe-plates-mask)")
    path(
        tonal,
        f"M{left - 6} {crest - 2} L{left + 17} {crest - 6} "
        f"Q{left + 12} 340 {waist_left + 14} 405 L{waist_left - 8} 409Z "
        f"M{right - 19} {crest - 9} L{right + 7} {crest - 1} "
        f"L{waist_right + 11} 406 H{waist_right - 16} Q{right - 17} 347 {right - 19} {crest - 9}Z",
        "#302925", opacity=".32",
    )
    path(tonal, f"M{left + 15} {crest + 10} Q115 295 122 297 Q108 322 107 342 L{left + 12} 333Z", "#d0bd9d", opacity=".27")
    path(front, plates, "none", class_="edge")


def _draw_fur(front, neck: float) -> None:
    left, right = number(160 - neck), number(160 + neck)
    outer_left, outer_right = number(144 - neck), number(178 + neck)
    path(
        front,
        f"M{left} 274 Q160 306 {right} 274 Q{outer_right} 275 {outer_right} 287 "
        "Q203 301 181 308 L176 316 180 333 175 342 179 360 175 374 178 392 "
        "Q161 400 148 394 L144 382 147 364 143 352 146 332 140 318 143 309 "
        f"Q115 305 {outer_left} 287 Q{outer_left} 278 {left} 274Z",
        "#d3b58a", class_="edge",
    )
    path(
        front,
        f"M{left} 276 Q160 310 {right} 276 L{outer_right} 283 Q194 304 166 305 "
        "L170 320 164 341 168 357 163 389 148 391 145 371 149 355 144 337 147 320 143 307 "
        f"Q115 304 {outer_left} 287Z",
        "#ad8a66",
    )
    path(
        front, f"M{outer_left} 284 Q117 296 153 303 L157 320 152 339 157 360 153 390",
        "none", stroke="#e8cc9f", stroke_width="3.4", stroke_linecap="round",
    )
    path(
        front,
        "M114 287l-3 4m10 -3 -1 6m10 -1 2 5m7 -3 3 6m15 8 3 8m3 -9 3 6 "
        "m-10 16 -3 9m11 -9 -2 9m-6 9 3 7m4 5 -4 9m3 10 -2 8m24 -92 5 -5m3 2 4 -6m5 2 3 -5",
        class_="etch",
    )
    path(front, "M149 326q10 -3 25 -1m-24 37q14 -2 25 -1", class_="seam")
    path(front, "M150 326l11 -1m-10 36h11", fill="none", stroke="#f1d4a3", stroke_width="1.4", stroke_linecap="round")


def _draw_cloak(parent, defs, body: Body, cloth: Cloth, neck: float, *, ornate_clasp: bool) -> None:
    outer_left, outer_right = 149 - body.sleeve, 171 + body.sleeve
    shoulder_left, shoulder_right = 155 - body.shoulder, 165 + body.shoulder
    neck_left, neck_right = number(160 - neck), number(160 + neck)
    clasp = number(146 - neck)
    mantle = (
        f"M{neck_left} 273 C{shoulder_left + 4} 283 {outer_left + 14} 295 {outer_left + 11} 339 "
        f"Q{outer_left - 5} 388 {outer_left + 1} 445 H{147 - body.waist // 2} "
        f"Q{132 - body.waist // 2} 395 {147 - body.waist // 2} 356 Q120 307 {clasp} 293Z "
        f"M{neck_right} 273 C{shoulder_right} 283 {outer_right - 20} 291 {outer_right - 9} 333 "
        f"Q{outer_right + 5} 382 {outer_right - 1} 445 H{182 + body.waist // 2} "
        f"Q{200 + body.waist // 2} 407 202 366 Q183 327 {clasp} 293 "
        f"Q152 302 {neck_right} 273Z"
    )
    mask = node(defs, "clipPath", id="wardrobe-cloak-mask")
    path(mask, mantle)
    path(parent, mantle, cloth.base, class_="edge")
    cloth_panels = node(parent, "g", clip_path="url(#wardrobe-cloak-mask)")
    path(
        cloth_panels,
        f"M{neck_right} 273 Q{shoulder_right - 26} 301 {shoulder_right - 6} 341 "
        f"Q{outer_right - 21} 390 {outer_right - 12} 444 H{outer_right + 6} V302Z",
        cloth.shade,
    )
    path(
        cloth_panels,
        f"M{clasp} 296 Q{shoulder_left - 12} 318 {outer_left + 22} 381 "
        f"L{outer_left + 11} 445 H{outer_left - 8} Q{outer_left} 335 {clasp} 296Z",
        cloth.shade,
    )
    path(
        cloth_panels,
        f"M{clasp} 296 Q166 313 209 359 Q234 402 {211 + body.waist // 2} 445 "
        f"H{168 + body.waist // 2} Q243 388 188 342Z",
        cloth.deep,
    )
    path(
        cloth_panels,
        f"M{neck_right} 278 Q161 310 123 297 Q149 301 190 324 Q161 318 136 309 L105 296Z "
        f"M{shoulder_left - 1} 326 Q{outer_left + 26} 361 {outer_left + 22} 395 "
        f"L{outer_left + 16} 419 Q{outer_left + 14} 372 {shoulder_left - 1} 326Z",
        cloth.light,
    )
    path(
        cloth_panels,
        f"M{outer_left + 14} 344 Q{outer_left + 25} 327 {shoulder_left} 319 "
        f"L{outer_left + 23} 377 {outer_left + 11} 396Z "
        f"M{outer_right - 14} 349 Q{shoulder_right} 322 {shoulder_right - 16} 314 "
        f"Q{outer_right - 35} 356 {outer_right - 26} 383Z",
        "url(#ink-lines)", opacity=".5",
    )
    path(
        cloth_panels,
        f"M{clasp} 295 Q161 316 193 336 Q225 366 231 400 m-28 -73 q26 16 41 45 "
        f"M{shoulder_left - 7} 321 Q{outer_left + 18} 348 {outer_left + 15} 374 m17 16 -8 28",
        class_="seam",
    )
    path(cloth_panels, f"M{outer_left + 18} 382l-5 16 m11 -16 -3 14 m192 -51 13 11 m-9 -1 10 10 m-4 4 12 13", class_="etch")
    clasp_group = node(parent, "g", transform=f"translate({clasp} 294)")
    if ornate_clasp:
        path(
            clasp_group,
            "M0 -9 Q8 -8 9 0 Q8 8 0 9 Q-8 8-9 0 Q-8 -8 0 -9Z "
            "M0 -4 Q-4 -4-4 0 Q-4 4 0 4 Q4 4 4 0 Q4 -4 0 -4Z",
            "#c99f63", fill_rule="evenodd", stroke="#3e2d26", stroke_width="2", stroke_linejoin="round",
        )
        path(clasp_group, "M-8 3 8 -3", "none", stroke="#e8bf82", stroke_width="2.3", stroke_linecap="round")
        path(clasp_group, "M-4 -6l3 -1m3 13 3 -2", "none", stroke="#ecd09b", stroke_width="1.3", stroke_linecap="round")
    else:
        path(clasp_group, "M0 -7 Q7 -6 8 0 Q7 6 0 8 Q-7 6-8 0 Q-7 -7 0 -7Z", "#c69657", class_="edge")
        path(clasp_group, "M-4 2 5 -2m-7 -2 4 -1", "none", stroke="#efd19c", stroke_width="1.55", stroke_linecap="round")


def _draw_pouch(parent, body: Body) -> None:
    pouch = node(parent, "g", data_part="belt-accessory", clip_path="url(#wardrobe-torso-mask)")
    anchor = 162 - body.waist // 2
    strap = node(pouch, "g", transform=f"translate({anchor} 405)")
    path(strap, "M-4 0h7l1 16h-8Z", "#936448", class_="seam")
    path(strap, "M-9 13 Q0 10 9 14 L11 28 Q4 37-8 33 L-13 26Z", "#77523c", class_="edge")
    path(strap, "M-8 14 Q0 12 8 15 L8 22 Q0 27-11 21Z", "#a67b51", class_="seam")
    path(strap, "M-8 18q7 3 13 0", fill="none", stroke="#cfad75", stroke_width="1.35", stroke_dasharray="2 2")


def _draw_jewelry(parent, accessory: str, outfit: str, body: Body, neck: float) -> None:
    if accessory == "brooch" and outfit != "cloak":
        brooch_x = number(min(181 + neck, 147 + body.shoulder))
        brooch = node(parent, "g", transform=f"translate({brooch_x} 304) rotate(-16)")
        path(
            brooch,
            "M-3 -7 Q-12 -4-7 4 Q-4 9 3 7 Q10 4 8 -3 L4 -2 Q6 3 1 4 Q-5 5-5 0 Q-5 -4-2 -4Z",
            "#ba9a63", stroke="#3e2d26", stroke_width="2.1", stroke_linejoin="round",
        )
        path(brooch, "M-5 -2 8 3m-9 3 4 -1", fill="none", stroke="#e0bc81", stroke_width="1.5", stroke_linecap="round")
    elif accessory == "pendant":
        center = 170 if outfit == "svita" else 160
        drop = 320 if outfit == "cloak" else 312
        pendant = node(parent, "g", transform=f"translate({center} {drop})")
        path(
            pendant, "M-20 -19 Q-12 -7 0 2 Q12 -4 20 -19",
            "none", stroke="#50372a", stroke_width="2.7", stroke_linecap="round",
        )
        path(pendant, "M0 -2 7 6 5 14 0 18-5 14-7 6Z", "#ba925b", stroke="#392b25", stroke_width="2.2", stroke_linejoin="round")
        path(pendant, "M0 3 -3 7 0 11 3 7Z", "#e2b783")


def _draw_fabric_belt(parent, body: Body) -> None:
    left, right = 150 - body.waist, 170 + body.waist
    belt = node(parent, "g", data_part="belt", clip_path="url(#wardrobe-torso-mask)")
    path(belt, f"M{left} 397Q160 408 {right} 398L{right - 1} 409Q160 421 {left + 1} 410Z",
         "#735142", class_="edge")
    path(belt, f"M{left + 2} 400Q160 413 {right - 2} 401M{left + 3} 406Q160 418 {right - 3} 406",
         "none", stroke="#bb986b", stroke_width=1.55, stroke_linecap="round")
    path(belt, "M166 409Q165 416 172 420L175 414 180 429 173 435 169 422 164 428 160 424Z",
         "#967451", class_="seam")


def _draw_new_outfit(parent, defs, look, head, body, cloth, *, hem_y):
    outfit = look["outfit"]
    group = node(parent, "g", id=f"wardrobe-outfit-{outfit}", data_outfit=outfit)
    neck = head.neck_half + 6
    torso_shape = _front_shape(body, neck, hem_y=hem_y)
    sleeve_shape = _sleeve_shape(body, outfit)
    path(node(defs, "clipPath", id="wardrobe-torso-mask"), torso_shape)
    path(node(defs, "clipPath", id="wardrobe-sleeve-mask"), sleeve_shape)
    underlayer = LINEN if outfit in _LIGHT_UNDERLAYER else cloth
    sleeves = _draw_sleeves(group, body, underlayer, cut=outfit)
    path(group, torso_shape, underlayer.base)
    front = node(group, "g", data_part="torso", clip_path="url(#wardrobe-torso-mask)")
    if outfit not in _CHILD_DRAWERS:
        _draw_folds(front, body, underlayer)
    path(group, torso_shape, "none", class_="edge")

    waist = None
    if outfit in _WAIST_PARTS:
        waist = node(group, "g", data_part=_WAIST_PARTS[outfit], clip_path="url(#wardrobe-torso-mask)")
    if outfit in _FABRIC_BELTS:
        _draw_fabric_belt(group, body)
    elif outfit == "korzno":
        _draw_belt(group, body)
    if look["accessory"] == "pouch" and outfit not in BELTLESS_OUTFITS:
        _draw_pouch(group, body)

    outer = None
    if outfit in _OUTER_LAYER:
        overlay = node(defs, "clipPath", id="wardrobe-outer-mask")
        path(overlay, torso_shape)
        path(overlay, sleeve_shape)
        path(overlay, sleeve_shape, transform=_MIRROR)
        outer = node(group, "g", clip_path="url(#wardrobe-outer-mask)")
    _OUTFIT_DRAWERS[outfit](OutfitArt(front, sleeves, outer, waist, body, neck, cloth, look, hem_y=hem_y))
    if look["accessory"] == "pendant" or (look["accessory"] == "brooch" and outfit not in {"korzno", "rus_mantle"}):
        clipped = node(group, "g", clip_path="url(#wardrobe-torso-mask)")
        _draw_jewelry(clipped, look["accessory"], outfit, body, neck)


def draw_outfit(parent, defs, look: dict[str, str], head: HeadGeometry, *, full=False) -> None:
    if look["age"] == "child":
        inset = number(160 * (1 - CHILD_BODY_SCALE))
        parent = node(parent, "g", data_part="wardrobe",
                      transform=f"matrix({CHILD_BODY_SCALE} 0 0 1.08 {inset} -35.6)")
    outfit = look["outfit"]
    body = _body_fit(BODIES[look["body"]], outfit)
    cloth = DYED.get(look["cloth_color"], NATURAL[outfit])
    if outfit in _OUTFIT_DRAWERS:
        hem_y = wardrobe_northwest_military.FULL_HEMS.get(outfit) if full else None
        _draw_new_outfit(parent, defs, look, head, body, cloth, hem_y=hem_y)
        return
    accessory = look["accessory"]
    neck = head.neck_half + 6
    front_shape = _front_shape(body, neck)
    mask = node(defs, "clipPath", id="wardrobe-torso-mask")
    path(mask, front_shape)

    underlayer = LINEN if outfit == "cloak" else cloth
    _draw_sleeves(parent, body, underlayer)
    path(parent, front_shape, underlayer.base)
    front = node(parent, "g", data_part="torso", clip_path="url(#wardrobe-torso-mask)")
    _draw_folds(front, body, underlayer)
    _draw_collar(front, neck, outfit)
    if outfit == "kozukh":
        _draw_fur(front, neck)
    elif outfit == "armor":
        _draw_plate_front(front, defs, body, neck)
    path(parent, front_shape, "none", class_="edge")
    _draw_belt(parent, body)
    if accessory == "pouch":
        _draw_pouch(parent, body)
    if outfit == "cloak":
        _draw_cloak(parent, defs, body, cloth, neck, ornate_clasp=accessory == "brooch")
    _draw_jewelry(parent, accessory, outfit, body, neck)
