from dataclasses import dataclass, replace
from xml.etree.ElementTree import Element

from common import HeadGeometry, node, number, path, tag
import wardrobe_adult_men
import image_armour_art
import image_court_art
import image_daily_art
import wardrobe_adult_women
import wardrobe_bandiagara
import wardrobe_northwest_men
import wardrobe_northwest_military
import wardrobe_northwest_women
import wardrobe_northwest_gotland
import wardrobe_northwest_accessories
import wardrobe_northwest_archery
import wardrobe_northwest_arms
import wardrobe_northwest_cloaks
from wardrobe_northwest_shields import back_shield_style, draw_back_shield
from wardrobe_weapon_carry import WAIST_WEAPONS, draw_waist_weapon
from wardrobe_child_east import DRAWERS as CHILD_EAST_OUTFITS
from wardrobe_child_west import DRAWERS as CHILD_WEST_OUTFITS
from wardrobe_eurasia import DRAWERS as EURASIAN_OUTFITS
from wardrobe_rus import DRAWERS as RUS_OUTFITS


_REFERENCE_OUTFITS = {
    "rus_work_shirt": "Грубая рабочая рубаха",
    "rus_wool_tunic": "Шерстяная верхняя рубаха",
    "western_knee_tunic": "Западноевропейская туника до колен",
    "paired_pin_gown": "Плечевая одежда на парных булавках",
    "rus_work_gown": "Длинная рабочая одежда из шерсти",
    "rus_fine_gown": "Тонкая верхняя одежда знати",
    "rus_fine_coat": "Тонкая верхняя одежда зажиточного горожанина",
    "rus_child_wool_coat": "Детская шерстяная верхняя одежда",
    "rus_womens_fur_coat": "Женская меховая шуба",
    "rus_cloth_covered_fur_coat": "Шуба, крытая тканью",
    "rus_child_fur_coat": "Детская меховая одежда",
    "rus_cleric_robe": "Повседневная одежда священника",
    "rus_monk_robe": "Монашеская длинная одежда",
    "rus_sticharion": "Стихарь",
    "western_fine_coat": "Западная одежда из тонкого сукна",
    "latin_pilgrim_robe": "Одежда латинского паломника",
}

OPTIONS = {
    "body": {
        "medium": "Среднее",
        "slim": "Худощавое",
        "full": "Полное",
        "athletic": "Атлетическое",
    },
    "outfit": {
        "shirt": "Рубаха",
        "svita": "Свита",
        "cloak": "Плащ",
        "kozukh": "Кожух",
        "armor": "Доспех",
        "izyaslav_kaftan": "Изяславский кафтан",
        "korzno": "Корзно с подкладкой",
        "ryazan_sleeves": "Рубаха с длинными рукавами",
        "rus_mantle": "Одежда с наплечной накидкой",
        "steppe_robe": "Степной халат со сборками",
        "kariginu": "Каригину",
        "tiraz_robe": "Одеяние с нарукавными полосами",
        "pellote": "Кастильское пельоте",
        "tang_jacket": "Танский жакет с высокой юбкой",
        "steppe_dress": "Степное платье с правым запахом",
        "norse_child_tunic": "Шерстяная туника с клиньями",
        "song_child_jacket": "Сунская куртка с запахом",
        "rus_child_svita": "Свита с тканой тесьмой",
        "iraq_school_robe": "Одеяние ученика из «Макам»",
        "castile_royal_pellote": "Королевское пельоте",
        "yuan_brocade_coat": "Наряд Юань с левой застёжкой",
        "song_plain_jacket": "Сунская одежда с запахом",
        **wardrobe_bandiagara.OPTIONS,
        **wardrobe_adult_men.OPTIONS,
        **wardrobe_adult_women.OPTIONS,
        **wardrobe_northwest_men.OPTIONS,
        **wardrobe_northwest_women.OPTIONS,
        **wardrobe_northwest_gotland.OPTIONS,
        **wardrobe_northwest_military.OPTIONS,
        **_REFERENCE_OUTFITS,
        **image_armour_art.OUTFITS,
        **image_court_art.OUTFITS,
        **image_daily_art.OUTFITS,
    },
    "cloth_color": {
        "natural": "Естественный",
        "madder": "Мареновый",
        "moss": "Мшистый",
        "woad": "Вайда",
        "ochre": "Охристый",
        "indigo": "Индиго",
    },
    "accessory": {
        "none": "Без украшений",
        "brooch": "Фибула",
        "pendant": "Подвеска",
        "pouch": "Поясной кошель",
    },
}

LABELS = {
    "body": "Телосложение",
    "outfit": "Одежда",
    "cloth_color": "Цвет ткани",
    "accessory": "Украшения и принадлежности",
}


@dataclass(frozen=True)
class Body:
    shoulder: int
    shoulder_y: int
    chest: int
    waist: int
    hem: int
    sleeve: int
    wrist_x: int


BODIES = {
    "medium": Body(80, 290, 76, 70, 79, 119, 71),
    "slim": Body(69, 289, 63, 55, 63, 103, 87),
    "full": Body(86, 292, 84, 85, 94, 134, 56),
    "athletic": Body(93, 287, 85, 65, 76, 128, 68),
}
CHILD_BODY_SCALE = .84


@dataclass(frozen=True)
class Cloth:
    base: str
    light: str
    shade: str
    deep: str


@dataclass(frozen=True)
class OutfitArt:
    front: Element
    sleeves: tuple[Element, Element]
    outer: Element | None
    waist: Element | None
    body: Body
    neck: float
    cloth: Cloth
    look: dict[str, str]
    hem_y: int | None = None
    hem_half: int | None = None


LINEN = Cloth("#c8af81", "#ead29e", "#a28660", "#785d49")
MADDER = Cloth("#925749", "#bb7d61", "#6d3e37", "#4d2e2a")
MOSS = Cloth("#6b7357", "#929674", "#4d5541", "#363c32")
WOAD = Cloth("#526d76", "#7d9295", "#3b5059", "#2f3e49")
OCHRE = Cloth("#a8804e", "#c8a46b", "#805b37", "#60422f")
INDIGO = Cloth("#3e526b", "#708397", "#2c3e56", "#223248")
DYED = {"madder": MADDER, "moss": MOSS, "woad": WOAD, "ochre": OCHRE, "indigo": INDIGO}
NATURAL = {
    "shirt": LINEN,
    "svita": Cloth("#586e66", "#819387", "#3e504c", "#293735"),
    "cloak": Cloth("#88513f", "#b27555", "#663e32", "#482f2b"),
    "kozukh": Cloth("#8d7358", "#b09670", "#69513f", "#4a382e"),
    "armor": MADDER,
    "izyaslav_kaftan": Cloth("#59697a", "#8192a1", "#3d4c5d", "#2a3343"),
    "korzno": Cloth("#8e5045", "#b86f57", "#66392f", "#412720"),
    "ryazan_sleeves": Cloth("#777957", "#a4a07b", "#51543f", "#373a30"),
    "rus_mantle": Cloth("#72404b", "#a56562", "#512e3b", "#38232d"),
    "steppe_robe": Cloth("#755540", "#a9825b", "#523a32", "#3b2a26"),
    "kariginu": Cloth("#7d858d", "#aeb8bc", "#515b6a", "#343d49"),
    "tiraz_robe": Cloth("#7e4e62", "#aa7684", "#57384a", "#392837"),
    "pellote": Cloth("#8a513f", "#b7825d", "#602f29", "#412620"),
    "tang_jacket": Cloth("#6e8271", "#9aaf93", "#465b52", "#2c403b"),
    "steppe_dress": Cloth("#805158", "#b3807c", "#61383e", "#432830"),
    "norse_child_tunic": Cloth("#beb096", "#dccdb2", "#948572", "#61564b"),
    "song_child_jacket": Cloth("#8d8f6b", "#adb18f", "#666b51", "#414a39"),
    "song_plain_jacket": Cloth("#8d8f6b", "#adb18f", "#666b51", "#414a39"),
    "tellem_tunic": Cloth("#bfa888", "#d8c7ab", "#9b8267", "#5c4b41"),
    "tellem_wrap": Cloth("#4d6478", "#76858b", "#3c5169", "#293a52"),
    "rus_child_svita": Cloth("#76545f", "#ab7980", "#573945", "#422d36"),
    "iraq_school_robe": Cloth("#587386", "#7e9aa7", "#415661", "#303e46"),
    "castile_royal_pellote": Cloth("#883d45", "#bb6366", "#612a38", "#481f29"),
    "yuan_brocade_coat": Cloth("#426f6b", "#74938b", "#33514f", "#263d3e"),
    "rus_gilt_cuff_tunic": Cloth("#596657", "#8e9676", "#424a40", "#30372e"),
    "castile_laced_saya": Cloth("#875057", "#ae7476", "#633944", "#462d35"),
    "yuan_fur_hunt_robe": Cloth("#bfb6a3", "#e1d7c1", "#8c8076", "#605550"),
    "song_round_robe": Cloth("#a25748", "#c48663", "#773e36", "#54312e"),
    "rus_gold_yoke_gown": Cloth("#98715d", "#bd947b", "#754f45", "#4c3631"),
    "rus_checked_panel": Cloth("#d6c29d", "#ead9b6", "#ad9677", "#7b6455"),
    "naumburg_clasp_mantle": Cloth("#85494f", "#ad6d70", "#64373e", "#432b34"),
    "song_pheasant_robe": Cloth("#34465a", "#566c7f", "#253547", "#192733"),
    "nw_nov_svita": Cloth("#656a53", "#8e8c6d", "#484b3f", "#33382f"),
    "nw_nov_sofia_tunic": Cloth("#855254", "#af7167", "#603e44", "#442d34"),
    "nw_karel_tunic": Cloth("#526876", "#7e8890", "#364957", "#293640"),
    "nw_baltic_mens_coat": Cloth("#7e6453", "#a5805d", "#5a493e", "#40362f"),
    "nw_nordic_gored_tunic": Cloth("#895d50", "#b37c65", "#613f3a", "#4b3031"),
    "nw_nov_womens_rubakha": Cloth("#d8c6a3", "#f2e3c0", "#b29c7a", "#786151"),
    "nw_nov_womens_fur_coat": Cloth("#633646", "#865263", "#482736", "#34222d"),
    "nw_nov_trimmed_gown": Cloth("#32675e", "#599083", "#244c49", "#1d3839"),
    "nw_karel_apron_gown": Cloth("#56664e", "#849071", "#3e4d3e", "#2e3b32"),
    "nw_baltic_spiral_kuub": Cloth("#39576f", "#66839a", "#2b4258", "#202f43"),
    "nw_nordic_pleated_gown": Cloth("#986846", "#bd9067", "#704b37", "#51382f"),
    "nw_gotland_mens_cloak": Cloth("#756a50", "#a6976d", "#514b3e", "#3b352f"),
    "nw_gotland_womens_mantle": Cloth("#8c654f", "#b8906b", "#634b3e", "#47352e"),
    "nw_mail_hauberk": Cloth("#a58c69", "#c4a67c", "#7e674d", "#574638"),
    "nw_nov_lamellar": Cloth("#744b46", "#aa695b", "#593934", "#402b28"),
    "nw_mail_surcoat": Cloth("#aa9982", "#cebda0", "#817668", "#534b44"),
    "nw_nov_scale": Cloth("#854f41", "#ac715c", "#623e37", "#472f2b"),
    "nw_nov_copper_mail": Cloth("#45605f", "#718580", "#37494b", "#293b3b"),
    "nw_gomel_lamellar": Cloth("#786643", "#a08b57", "#514c34", "#39372a"),
    "nw_magdeburg_plate_coat": Cloth("#9c7653", "#c5a077", "#6b503c", "#49382e"),
    "rus_work_shirt": Cloth("#a78b6f", "#c2a78e", "#806751", "#5e4b3d"),
    "rus_wool_tunic": MOSS,
    "western_knee_tunic": MADDER,
    "paired_pin_gown": WOAD,
    "rus_work_gown": Cloth("#797860", "#9b9777", "#535742", "#424237"),
    "rus_fine_gown": Cloth("#675069", "#a27b91", "#49384e", "#302d3e"),
    "rus_fine_coat": WOAD,
    "rus_child_wool_coat": OCHRE,
    "rus_womens_fur_coat": Cloth("#8b796d", "#b6a79c", "#63554e", "#483c38"),
    "rus_cloth_covered_fur_coat": Cloth("#713c47", "#a35957", "#512c36", "#3b2229"),
    "rus_child_fur_coat": Cloth("#9b765d", "#c7a689", "#75533f", "#49342d"),
    "rus_cleric_robe": Cloth("#626163", "#828184", "#414149", "#34343a"),
    "rus_monk_robe": Cloth("#53504c", "#706b60", "#3b3735", "#302b29"),
    "rus_sticharion": Cloth("#c6bcac", "#efe2cc", "#958c87", "#665e60"),
    "western_fine_coat": Cloth("#6c6e53", "#939475", "#4b4f41", "#343a32"),
    "latin_pilgrim_robe": Cloth("#7b6b54", "#9d8a6c", "#564b42", "#3c342f"),
}
_CHILD_DRAWERS = {**CHILD_WEST_OUTFITS, **CHILD_EAST_OUTFITS}
NATURAL.update({key: Cloth(*colors) for key, colors in image_court_art.OUTFIT_COLORS.items()})
NATURAL.update({"index_flat_ring_mail": MADDER, "index_padded_tunic": Cloth("#ac9e7d", "#d3c4a1", "#807557", "#5a503f"),
                "image_fur_loincloth": Cloth("#8c7354", "#c2a477", "#5d4938", "#3c2d26")})
ADULT_CASTS = {
    **dict.fromkeys(wardrobe_adult_men.OPTIONS, "men"),
    **dict.fromkeys(wardrobe_adult_women.OPTIONS, "women"),
    **dict.fromkeys(wardrobe_northwest_men.OPTIONS, "men"),
    **dict.fromkeys(wardrobe_northwest_women.OPTIONS, "women"),
    "nw_gotland_mens_cloak": "men",
    "nw_gotland_womens_mantle": "women",
    **dict.fromkeys((*image_armour_art.OUTFITS, *image_court_art.OUTFITS), "men"),
    **dict.fromkeys(("paired_pin_gown", "rus_work_gown", "rus_fine_gown", "rus_womens_fur_coat"), "women"),
    **dict.fromkeys(("western_knee_tunic", "rus_fine_coat", "western_fine_coat", "rus_cleric_robe",
                    "rus_monk_robe", "rus_sticharion", "latin_pilgrim_robe"), "men"),
}
NORTHWEST_ARMOR = tuple(wardrobe_northwest_military.OPTIONS)
ARMORED_OUTFITS = frozenset(("armor", *NORTHWEST_ARMOR, "index_flat_ring_mail"))
# These metal sleeves reach the wrist; shorter mail sleeves leave a bracelet exposed.
BRACELET_COVERING_OUTFITS = frozenset(("nw_mail_surcoat", "nw_magdeburg_plate_coat"))
FULL_HEMS = {"tang_jacket": 700, **wardrobe_northwest_military.FULL_HEMS,
             **image_court_art.OUTFIT_HEMS, "index_flat_ring_mail": 570, "index_padded_tunic": 545,
             "image_fur_loincloth": 474}
_FUR_LINED_HEMS = {"kozukh", "nw_nov_womens_fur_coat"}
_LONG_TUNIC_HEMS = {"nw_nov_sofia_tunic", "nw_nordic_gored_tunic", "tellem_tunic"}
_CLOAKS_COVERING_BOTH_HANDS = ("novgorod_mantle", "gotland_open", "travel_wool_cloak", "luda",
                              "rus_monk_mantle")
HANDHELD_HIDDEN_BY = {
    "weapon": _CLOAKS_COVERING_BOTH_HANDS,
    "shield": (),
    "bow": _CLOAKS_COVERING_BOTH_HANDS,
}
_OUTFIT_DRAWERS = {**RUS_OUTFITS, **EURASIAN_OUTFITS, **_CHILD_DRAWERS,
                   **wardrobe_bandiagara.DRAWERS, "song_plain_jacket": CHILD_EAST_OUTFITS["song_child_jacket"],
                   **wardrobe_adult_men.DRAWERS, **wardrobe_adult_women.DRAWERS,
                   **wardrobe_northwest_men.DRAWERS, **wardrobe_northwest_women.DRAWERS,
                   **wardrobe_northwest_gotland.DRAWERS,
                   **wardrobe_northwest_military.DRAWERS, **image_armour_art.OUTFIT_DRAWERS,
                   **image_court_art.OUTFIT_DRAWERS, **image_daily_art.OUTFIT_DRAWERS}
_CUT_PADDING = {
    "izyaslav_kaftan": {"shoulder": 4, "chest": 3, "hem": 6, "sleeve": 2},
    "korzno": {"shoulder": 6, "chest": 3, "hem": 8, "sleeve": 6},
    "ryazan_sleeves": {"shoulder": 3, "hem": 4, "sleeve": 10},
    "rus_mantle": {"shoulder": 5, "chest": 3, "waist": 3, "hem": 6},
    "steppe_robe": {"shoulder": 3, "chest": 3, "waist": -7, "hem": 8},
    "kariginu": {"shoulder": 10, "shoulder_y": -3, "chest": 6, "waist": 8, "hem": 9, "sleeve": 13},
    "tiraz_robe": {"shoulder": 4, "chest": 3, "hem": 7, "sleeve": 9},
    "pellote": {"waist": 3, "hem": 10},
    "tang_jacket": {"waist": 3, "hem": 12},
    "steppe_dress": {"shoulder": 3, "chest": 4, "waist": 3, "hem": 11, "sleeve": 4},
    "norse_child_tunic": {"shoulder_y": 3, "chest": 3, "waist": 4, "hem": 6, "sleeve": 6},
    "song_child_jacket": {"chest": 2, "waist": 2, "hem": 6, "sleeve": 4},
    "song_plain_jacket": {"chest": 2, "waist": 2, "hem": 6, "sleeve": 4},
    "tellem_tunic": {"shoulder": 5, "chest": 6, "waist": 7, "hem": 9, "sleeve": 5},
    "tellem_wrap": {"waist": 2, "hem": 6},
    "rus_child_svita": {"shoulder": 3, "chest": 2, "hem": 8, "sleeve": 4},
    "iraq_school_robe": {"shoulder": 4, "waist": 5, "hem": 8, "sleeve": 8},
    "castile_royal_pellote": {"waist": 6, "hem": 12},
    "yuan_brocade_coat": {"shoulder": 6, "chest": 4, "waist": 4, "hem": 7, "sleeve": 7},
    "rus_gilt_cuff_tunic": {"shoulder": 4, "chest": 2, "waist": 3, "hem": 4, "sleeve": 3},
    "castile_laced_saya": {"shoulder": 1, "chest": -4, "waist": -6, "hem": 4, "sleeve": -3},
    "yuan_fur_hunt_robe": {"shoulder": 10, "shoulder_y": -4, "chest": 9, "waist": 5, "hem": 13, "sleeve": 10},
    "song_round_robe": {"shoulder": 6, "chest": 5, "waist": 3, "hem": 8, "sleeve": 8},
    "rus_gold_yoke_gown": {"shoulder": -6, "waist": -4, "hem": 13, "sleeve": 2},
    "rus_checked_panel": {"shoulder": -7, "chest": -3, "waist": -3, "hem": 16},
    "naumburg_clasp_mantle": {"shoulder": 2, "chest": 1, "waist": -3, "hem": 10, "sleeve": -4},
    "song_pheasant_robe": {"shoulder": 3, "chest": 4, "waist": 5, "hem": 12, "sleeve": 5},
    "nw_nov_svita": {"shoulder": 3, "chest": 2, "hem": 5, "sleeve": 2},
    "nw_nov_sofia_tunic": {"shoulder": 1, "chest": 2, "hem": 4},
    "nw_karel_tunic": {"shoulder": 4, "chest": 3, "waist": 2, "hem": 7, "sleeve": 4},
    "nw_baltic_mens_coat": {"shoulder": 3, "chest": 2, "hem": 8, "sleeve": 2},
    "nw_nordic_gored_tunic": {"shoulder": 3, "chest": 2, "waist": -2, "hem": 11, "sleeve": 2},
    "nw_nov_womens_rubakha": {"shoulder": -5, "chest": -2, "waist": -3, "hem": 12},
    "nw_nov_womens_fur_coat": {"shoulder": 5, "shoulder_y": -2, "chest": 4, "waist": 2, "hem": 10, "sleeve": 7},
    "nw_nov_trimmed_gown": {"shoulder": -4, "waist": -3, "hem": 11},
    "nw_karel_apron_gown": {"shoulder": -3, "waist": -2, "hem": 10},
    "nw_baltic_spiral_kuub": {"shoulder": 1, "waist": -2, "hem": 8, "sleeve": 4},
    "nw_nordic_pleated_gown": {"shoulder": -4, "waist": -5, "hem": 13},
    "nw_gotland_mens_cloak": {"shoulder": 3, "chest": 2, "hem": 8, "sleeve": 2},
    "nw_gotland_womens_mantle": {"shoulder": -4, "chest": 1, "waist": 1, "hem": 10, "sleeve": -4},
    "nw_mail_hauberk": {"shoulder": 4, "chest": 4, "waist": 4, "hem": 5, "sleeve": 4},
    "nw_nov_lamellar": {"shoulder": 3, "chest": 4, "waist": 3, "hem": 5, "sleeve": 3},
    "nw_mail_surcoat": {"shoulder": 4, "chest": 4, "waist": 4, "hem": 7, "sleeve": 4},
    "nw_nov_scale": {"shoulder": 4, "chest": 4, "waist": 2, "hem": 7, "sleeve": 4},
    "nw_nov_copper_mail": {"shoulder": 2, "chest": 3, "waist": 2, "hem": 7, "sleeve": 3},
    "nw_gomel_lamellar": {"shoulder": 6, "chest": 4, "waist": 3, "hem": 9, "sleeve": 7},
    "nw_magdeburg_plate_coat": {"shoulder": 3, "chest": 3, "waist": 1, "hem": 6, "sleeve": 3},
}
_CUT_PADDING.update({
    "rus_work_shirt": {"shoulder": -4, "sleeve": -4, "hem": -8},
    "rus_wool_tunic": {"shoulder": 3, "chest": 4, "hem": 10},
    "western_knee_tunic": {"shoulder": -4, "chest": -5, "waist": -12, "hem": 17, "sleeve": -13},
    "paired_pin_gown": {"shoulder": -5, "waist": -3, "hem": 18, "sleeve": -5},
    "rus_work_gown": {"shoulder": 4, "chest": 5, "waist": 7, "hem": 12, "sleeve": 3},
    "rus_fine_gown": {"shoulder": -6, "chest": -4, "waist": -10, "hem": 21, "sleeve": -11},
    "rus_fine_coat": {"chest": -4, "waist": -8, "hem": 10, "sleeve": -9},
    "rus_child_wool_coat": {"shoulder": 1, "chest": 3, "hem": 6, "sleeve": 6},
    "rus_womens_fur_coat": {"shoulder": 4, "chest": 5, "waist": 3, "hem": 11, "sleeve": 10},
    "rus_cloth_covered_fur_coat": {"shoulder": 9, "chest": 8, "waist": 8, "hem": 13, "sleeve": 10},
    "rus_child_fur_coat": {"shoulder": 5, "chest": 8, "waist": 4, "hem": 6, "sleeve": 10},
    "rus_cleric_robe": {"chest": 3, "waist": 4, "hem": 11, "sleeve": 3},
    "rus_monk_robe": {"chest": 5, "waist": 6, "hem": 7, "sleeve": 11},
    "rus_sticharion": {"chest": 9, "waist": 8, "hem": 22, "sleeve": 14},
    "western_fine_coat": {"shoulder": -2, "chest": -4, "waist": -10, "hem": 6, "sleeve": -8},
    "latin_pilgrim_robe": {"chest": 3, "waist": 2, "hem": 10, "sleeve": 2},
})
_REFERENCE_HEMS = {
    "rus_work_shirt": (535, 665), "rus_wool_tunic": (569, 672), "western_knee_tunic": (533, 533),
    "paired_pin_gown": (675, 686), "rus_work_gown": (683, 685), "rus_fine_gown": (689, 700),
    "rus_fine_coat": (591, 591), "rus_child_wool_coat": (572, 700), "rus_womens_fur_coat": (666, 679),
    "rus_cloth_covered_fur_coat": (620, 663), "rus_child_fur_coat": (567, 567),
    "rus_cleric_robe": (698, 698), "rus_monk_robe": (686, 686), "rus_sticharion": (706, 706),
    "western_fine_coat": (628, 628), "latin_pilgrim_robe": (649, 649),
}
_REFERENCE_BELTLESS = {
    "rus_fine_gown", "paired_pin_gown", "rus_womens_fur_coat", "rus_cloth_covered_fur_coat",
    "rus_child_fur_coat", "rus_cleric_robe", "rus_sticharion", "western_fine_coat",
}
_OUTER_LAYER = {"izyaslav_kaftan", "korzno", "rus_mantle", "kariginu", "tang_jacket", "yuan_fur_hunt_robe", "naumburg_clasp_mantle",
                *wardrobe_northwest_gotland.OPTIONS,
                "nw_mail_surcoat"}
_LIGHT_UNDERLAYER = {"korzno", "rus_mantle", "pellote", "castile_royal_pellote", "naumburg_clasp_mantle",
                     "nw_karel_apron_gown"}
_FABRIC_BELTS = {"ryazan_sleeves", "tiraz_robe", "steppe_dress", "rus_child_svita", "rus_gilt_cuff_tunic", "rus_gold_yoke_gown",
                 "nw_mail_hauberk", "nw_nov_lamellar", "nw_nov_scale", "nw_nov_copper_mail",
                 "nw_gomel_lamellar", "nw_magdeburg_plate_coat", "nw_nov_womens_rubakha",
                 *wardrobe_northwest_men.OPTIONS}
_DRAWN_BELTS = {"korzno", "rus_checked_panel", "song_round_robe", "song_pheasant_robe"}
BELTLESS_OUTFITS = (frozenset(_OUTFIT_DRAWERS) - (_FABRIC_BELTS | _DRAWN_BELTS)) | _REFERENCE_BELTLESS
_DRAPED_CLOAKS = {"korzno", "rus_mantle", "naumburg_clasp_mantle", *wardrobe_northwest_gotland.OPTIONS}
_WAIST_PARTS = {"izyaslav_kaftan": "waist-seam", "steppe_robe": "waist-seam", "tang_jacket": "high-waist-band",
                "song_round_robe": "belt", "rus_checked_panel": "checked-panel", "song_pheasant_robe": "belt"}
_WAIST_PARTS.update(dict.fromkeys(image_court_art.OUTFITS, "belt"))
_MIRROR = "translate(320 0) scale(-1 1)"


def _body_fit(body: Body, outfit: str) -> Body:
    if outfit == "svita":
        return replace(
            body, shoulder=body.shoulder + 3, chest=body.chest + 2,
            hem=body.hem + 5, sleeve=body.sleeve + 2,
        )
    if outfit == "kozukh":
        return replace(
            body, shoulder=body.shoulder + 7, shoulder_y=body.shoulder_y - 3,
            chest=body.chest + 6, waist=body.waist + 4, hem=body.hem + 8, sleeve=body.sleeve + 9,
        )
    if outfit in _CUT_PADDING:
        return replace(body, **{key: getattr(body, key) + pad for key, pad in _CUT_PADDING[outfit].items()})
    return body


def _full_hem(look, body):
    outfit = look["outfit"]
    if outfit in _REFERENCE_HEMS:
        y = _REFERENCE_HEMS[outfit][look["cast"] == "women"]
        half = min(135, body.hem + (15 if y > 600 else 4))
    elif outfit in FULL_HEMS:
        y, half = FULL_HEMS[outfit], body.hem + 4
    elif look["cast"] == "women" and outfit not in ARMORED_OUTFITS:
        y = 677 if outfit in _FUR_LINED_HEMS else 700
        half = min(137, body.hem + (30 if outfit == "nw_nordic_pleated_gown" else 24))
    elif outfit in _FUR_LINED_HEMS:
        y, half = 581, body.hem + 15
    else:
        y = 555 if outfit in _LONG_TUNIC_HEMS else 545
        half = body.hem + 5
    if look["age"] == "child":
        y = round(440 + (y - 440) * .70)
    return y, half


def _front_shape(body: Body, neck: float, *, hem_y: int | None = None, hem_half: int | None = None) -> str:
    shoulder = body.shoulder
    crest = body.shoulder_y
    chest = body.chest
    waist = body.waist
    hem = body.hem
    if hem_y is None:
        lower = (f"C{159 - waist} 415 {165 - hem} 431 {160 - hem} 445 "
                 f"H{160 + hem} C{155 + hem} 431 {161 + waist} 415 {160 + waist} 400 ")
    else:
        edge = hem + 4 if hem_half is None else hem_half
        lower = (f"C{159 - waist} 418 {161 - hem} 476 {160 - edge} {hem_y} "
                 f"Q160 {hem_y + 19} {160 + edge} {hem_y} "
                 f"C{159 + hem} 476 {161 + waist} 418 {160 + waist} 400 ")
    return (
        f"M{number(160 - neck)} 273 "
        f"C{number(146 - neck)} 273 {173 - shoulder} {crest - 10} {160 - shoulder} {crest} "
        f"C{157 - shoulder} {crest + 15} {162 - chest} 322 {160 - chest} 346 "
        f"C{158 - chest} 370 {161 - waist} 386 {160 - waist} 400 "
        f"{lower}"
        f"C{159 + waist} 386 {162 + chest} 370 {160 + chest} 346 "
        f"C{158 + chest} 322 {163 + shoulder} {crest + 15} {160 + shoulder} {crest} "
        f"C{147 + shoulder} {crest - 10} {number(174 + neck)} 273 {number(160 + neck)} 273 "
        f"Q160 307 {number(160 - neck)} 273Z"
    )


def sleeve_cuff(body: Body, outfit=None):
    outer = 160 - body.sleeve
    offset = 24 if outfit == "ryazan_sleeves" else 17 if outfit in {"rus_mantle", "steppe_robe"} else 9
    half = max(16, min(24, (171 - body.hem - outer - offset) / 2))
    return body.wrist_x - half, body.wrist_x + half


def _sleeve_curves(body: Body, outfit=None):
    shoulder = 160 - body.shoulder
    outer = 160 - body.sleeve
    crest = body.shoulder_y
    wrist, cuff = sleeve_cuff(body, outfit)
    upper = ((shoulder + 11, crest - 6), (shoulder - 11, crest + 1), (outer + 13, 304), (outer + 7, 332))
    if outfit == "ryazan_sleeves":
        lower = (
            (upper[-1], (outer + 3, 354), (outer - 9, 380), (outer - 5, 402)),
            ((outer - 5, 402), (outer - 1, 414), (outer + 18, 424)),
            ((outer + 18, 424), (wrist, 445)),
        )
    elif outfit in {"rus_mantle", "steppe_robe"}:
        lower = ((upper[-1], (outer - 1, 358), (outer + 6, 406), (wrist, 445)),)
    else:
        lower = ((upper[-1], (outer - 3, 362), (outer - 4, 415), (wrist, 445)),)
    inner = ((cuff, 445), (shoulder + 29, 336)) if outfit is None else (
        (cuff, 445), (max(cuff + 15, 181 - body.waist), 406), (shoulder + 29, 336),
    )
    return upper, lower, inner


def _curve_command(points):
    command = {2: "L", 3: "Q", 4: "C"}[len(points)]
    return command + " ".join(f"{number(x)} {number(y)}" for x, y in points[1:])


def _sleeve_shape(body: Body, outfit=None) -> str:
    upper, lower, inner = _sleeve_curves(body, outfit)
    start = f"M{number(upper[0][0])} {number(upper[0][1])}"
    outside = _curve_command(upper) + " ".join(_curve_command(curve) for curve in lower)
    return f"{start}{outside}H{number(inner[0][0])}{_curve_command(inner)}Z"


def _curve_x_at_y(points, y):
    low, high = 0.0, 1.0
    direction = 1 if points[-1][1] > points[0][1] else -1
    for _ in range(18):
        t = (low + high) / 2
        interpolated = list(points)
        while len(interpolated) > 1:
            interpolated = [(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                            for a, b in zip(interpolated, interpolated[1:])]
        if (interpolated[0][1] - y) * direction < 0:
            low = t
        else:
            high = t
    return interpolated[0][0]


def sleeve_section(body: Body, outfit, y):
    """Actual forearm edges, shared by sleeves, guards and wrist trim."""
    if outfit == "image_fur_loincloth":
        shoulder = 160 - body.shoulder
        wrist, cuff = sleeve_cuff(body, outfit)
        elbow = (shoulder + wrist) / 2
        outside = ((elbow - 10, 350), (elbow - 12, 382), (wrist, 440))
        inside = ((cuff, 440), (cuff - 3, 391), (elbow + 15, 357))
        y = max(357, min(440, y))
        return _curve_x_at_y(outside, y), _curve_x_at_y(inside, y)
    cut = outfit if outfit in _OUTFIT_DRAWERS or outfit in _REFERENCE_OUTFITS else None
    _, lower, inner = _sleeve_curves(body, cut)
    y = max(336, min(445, y))
    outside = next(curve for curve in lower if curve[0][1] <= y <= curve[-1][1])
    return _curve_x_at_y(outside, y), _curve_x_at_y(inner, y)


def _draw_sleeves(parent, body: Body, cloth: Cloth, *, cut=None, cuffs=False):
    shoulder = 160 - body.shoulder
    outer = 160 - body.sleeve
    crest = body.shoulder_y
    shape = _sleeve_shape(body, cut)
    wrist, cuff = sleeve_cuff(body, cut)
    slots = []
    for right in (False, True):
        sleeve = node(parent, "g", transform=_MIRROR) if right else parent
        path(sleeve, shape, cloth.shade if right else cloth.base, class_="edge",
             data_part="sleeve-outline", data_side="right" if right else "left")
        if cut is not None:
            part = "sleeve-right" if right else "sleeve-left"
            sleeve = node(sleeve, "g", data_part=part, clip_path="url(#wardrobe-sleeve-mask)")
            slots.append(sleeve)
        path(
            sleeve,
            f"M{outer + 8} 337 Q{outer + 15} 308 {shoulder} {crest + 4} "
            f"Q{outer + 22} 326 {outer + 23} 351 L{outer + 12} 373 "
            f"Q{outer + 12} 421 {outer + 23} 444 H{outer + 9} Q{outer - 6} 397 {outer + 8} 337Z",
            cloth.deep if right else cloth.shade,
        )
        path(
            sleeve,
            f"M{outer + 7} 354 Q{outer + 18} 326 {outer + 27} 315 "
            f"Q{outer + 18} 342 {outer + 21} 359 L{outer + 4} 383Z",
            "url(#ink-lines)",
            opacity=".44",
        )
        if cut not in {"kariginu", "steppe_robe"} and cut not in _CHILD_DRAWERS:
            path(
                sleeve,
                f"M{outer + 12} 376 q10 -11 20 -14 m-18 27 16 -10 "
                f"M{outer + 11} 414 q4 11 13 21",
                class_="seam",
            )
            path(sleeve, f"M{outer + 13} 354 l9 -17 m-9 24 9 -14 m-6 61 10 13", class_="etch")
        if cuffs:
            fabric = node(sleeve, "g", clip_path="url(#wardrobe-sleeve-mask)")
            curve = f"M{wrist - 6} 437Q{number((wrist + cuff) / 2)} 444 {cuff + 5} 437"
            path(fabric, f"{curve}V445H{wrist - 6}Z", cloth.shade)
            path(fabric, curve, "none", stroke=cloth.deep, stroke_width=2)
    return tuple(slots)


def _draw_folds(front, body: Body, cloth: Cloth, *, hem_y=None, hem_half=None) -> None:
    left = 160 - body.shoulder
    right = 160 + body.shoulder
    waist = 160 + body.waist
    bottom = 444 if hem_y is None else hem_y + 10
    shadow_right = right + 17 if hem_half is None else 165 + hem_half
    shadow_left = waist - 13 if hem_half is None else 160 + round(.51 * hem_half)
    path(front, f"M{left} 296 Q{left + 19} 280 120 278 Q105 303 {left + 8} 335Z", cloth.light)
    path(
        front,
        f"M184 288 Q{right - 13} 289 {right} {body.shoulder_y} L{shadow_right} {bottom} "
        f"H{shadow_left} Q{waist - 4} 405 {waist - 16} 371 Q{right - 25} 313 184 288Z",
        cloth.shade,
    )
    path(front, f"M{left + 1} 344 Q{left + 11} 359 {left + 7} 381 L{left - 8} 402 L{left - 16} 359Z", cloth.shade)
    path(
        front,
        f"M{waist - 23} 371 Q{waist - 7} 390 {waist + 5} 386 L{waist + 4} 416 L{waist - 10} 412Z",
        "url(#ink-lines)", opacity=".42",
    )
    path(
        front,
        f"M120 307 Q103 329 {left + 18} 361 Q{left + 12} 342 114 309Z "
        "M179 302 Q209 314 216 353 Q203 321 179 302Z",
        cloth.light,
    )
    if hem_y is None:
        path(front, "M133 409 Q124 426 123 444 H113 Q119 423 133 409Z M174 412 Q184 426 192 445 H177Z", cloth.light)
    else:
        fold_left, fold_right = 160 - round(.46 * hem_half), 160 + round(.22 * hem_half)
        path(front, f"M133 412Q124 460 {fold_left} {hem_y - 5}Q{fold_left - 13} {hem_y - 20} 133 412Z "
             f"M174 418Q185 444 {fold_right + 14} {hem_y - 3}Q{fold_right} {hem_y - 16} 174 418Z",
             cloth.light, opacity=".68")
        path(front, f"M134 423Q{fold_left + 7} 480 {fold_left} {hem_y - 12} "
             f"M158 447Q157 490 {160 - round(.10 * hem_half)} {hem_y - 10}", class_="etch")
        path(front, f"M{165 - hem_half} {hem_y - 7}Q160 {hem_y + 12} {155 + hem_half} {hem_y - 7}",
             class_="seam")
    path(
        front,
        f"M116 311 Q101 335 {left + 15} 360 M190 312 Q207 329 {right - 15} 367 "
        "M150 338 q-3 22 3 42 m11 -31 6 35"
        + (" M129 421 l-7 24 m60 -28 8 27" if hem_y is None else " M184 420q5 12 6 24"),
        class_="seam",
    )
    path(
        front,
        f"M{left + 21} 369 l-7 16 m12 -12 -6 12 M{right - 18} 355 l6 19 m-11 -12 5 15 "
        "M143 367 l2 14 m65 44 4 13",
        class_="etch",
    )


def _draw_collar(front, neck: float, outfit: str) -> None:
    left, right = number(160 - neck), number(160 + neck)
    lower_left, lower_right = number(154 - neck), number(166 + neck)
    band = (
        f"M{left} 273 Q160 307 {right} 273 L{lower_right} 280 "
        f"Q160 319 {lower_left} 280Z"
    )
    if outfit == "svita":
        path(front, "M154 296 167 297 165 399 153 399Z", "#a58e6b", class_="edge")
        path(
            front,
            "M145 310q16 -3 33 1l-1 6-32 -1Z M147 339q17 -2 30 2l-1 6-30 -2Z "
            "M146 369q16 -1 30 2l-2 6-29 -2Z",
            "#b58e5e", class_="edge",
        )
        path(front, "M149 312h13m-12 30h14m-13 30h11", fill="none", stroke="#d3aa76", stroke_width="1.5", stroke_linecap="round")
    elif outfit in ("shirt", "cloak"):
        path(front, "M154 292h12l1 40-12 2Z", "#87483b", class_="edge")
        path(front, "M156 300l8 5-7 6 7 6-7 6 7 5", fill="none", stroke="#ddb581", stroke_width="1.4")

    colors = {"svita": "#a58e6b", "armor": "#593b31", "kozukh": "#4b3830"}
    path(front, band, colors.get(outfit, "#87483b"), class_="edge")
    path(
        front,
        f"M{left} 278 Q160 312 {right} 278",
        fill="none", stroke="#d6b585", stroke_width="1.45", stroke_dasharray="4 4", stroke_linecap="round",
    )


def _draw_belt(parent, body: Body, *, full=False) -> None:
    inset = -3 if full else 6
    left, right = 160 - body.waist + inset, 160 + body.waist - inset
    belt = node(parent, "g", data_part="belt", clip_path="url(#wardrobe-torso-mask)")
    path(belt, f"M{left} 396 Q160 414 {right} 395 L{right - 1} 413 Q160 430 {left + 1} 414Z", "#574034", class_="edge")
    path(belt, f"M{left + 3} 400 Q160 417 {right - 3} 399 L{right - 3} 403 Q160 420 {left + 4} 404Z", "#916649")
    path(
        belt,
        f"M{left + 5} 410 Q160 426 {right - 5} 409",
        fill="none", stroke="#bd9369", stroke_width="1.35", stroke_dasharray="3 3", stroke_linecap="round",
    )
    path(
        belt,
        "M149 402l24 -1 5 4-1 13-5 4-24 -1-5 -4v-11Z M151 407l-1 9 20 1 1 -11Z",
        "#c69657", fill_rule="evenodd", stroke="#372621", stroke_width="2.9", stroke_linejoin="round",
    )
    path(belt, "M156 412l16 -1m-25 -4 8 -2", fill="none", stroke="#e9b97b", stroke_width="2", stroke_linecap="round")


def _draw_plate_front(front, defs, body: Body, neck: float) -> None:
    left = 169 - body.shoulder
    right = 151 + body.shoulder
    waist_left, waist_right = 163 - body.waist, 157 + body.waist
    inner_left, inner_right = number(159 - neck), number(161 + neck)
    crest = body.shoulder_y + 2
    plates = (
        f"M{left} {crest} Q{left + 22} {crest - 4} {inner_left} 280 Q160 321 {inner_right} 280 "
        f"Q{right - 22} {crest - 4} {right} {crest} "
        f"Q{155 + body.chest} 345 {waist_right} 401 Q160 415 {waist_left} 401 "
        f"Q{165 - body.chest} 345 {left} {crest}Z"
    )
    mask = node(defs, "clipPath", id="wardrobe-plates-mask")
    path(mask, plates)
    path(front, plates, "#74776b")
    path(front, plates, "url(#armor-plates)")
    tonal = node(front, "g", clip_path="url(#wardrobe-plates-mask)")
    path(
        tonal,
        f"M{left - 6} {crest - 2} L{left + 17} {crest - 6} "
        f"Q{left + 12} 340 {waist_left + 14} 405 L{waist_left - 8} 409Z "
        f"M{right - 19} {crest - 9} L{right + 7} {crest - 1} "
        f"L{waist_right + 11} 406 H{waist_right - 16} Q{right - 17} 347 {right - 19} {crest - 9}Z",
        "#302925", opacity=".32",
    )
    path(tonal, f"M{left + 15} {crest + 10} Q115 295 122 297 Q108 322 107 342 L{left + 12} 333Z", "#d0bd9d", opacity=".27")
    path(front, plates, "none", class_="edge")


def _draw_fur(front, neck: float, *, hem_y=None) -> None:
    left, right = number(160 - neck), number(160 + neck)
    outer_left, outer_right = number(144 - neck), number(178 + neck)
    path(
        front,
        f"M{left} 274 Q160 306 {right} 274 Q{outer_right} 275 {outer_right} 287 "
        "Q203 301 181 308 L176 316 180 333 175 342 179 360 175 374 178 392 "
        "Q161 400 148 394 L144 382 147 364 143 352 146 332 140 318 143 309 "
        f"Q115 305 {outer_left} 287 Q{outer_left} 278 {left} 274Z",
        "#d3b58a", class_="edge",
    )
    path(
        front,
        f"M{left} 276 Q160 310 {right} 276 L{outer_right} 283 Q194 304 166 305 "
        "L170 320 164 341 168 357 163 389 148 391 145 371 149 355 144 337 147 320 143 307 "
        f"Q115 304 {outer_left} 287Z",
        "#ad8a66",
    )
    path(
        front, f"M{outer_left} 284 Q117 296 153 303 L157 320 152 339 157 360 153 390",
        "none", stroke="#e8cc9f", stroke_width="3.4", stroke_linecap="round",
    )
    path(
        front,
        "M114 287l-3 4m10 -3 -1 6m10 -1 2 5m7 -3 3 6m15 8 3 8m3 -9 3 6 "
        "m-10 16 -3 9m11 -9 -2 9m-6 9 3 7m4 5 -4 9m3 10 -2 8m24 -92 5 -5m3 2 4 -6m5 2 3 -5",
        class_="etch",
    )
    path(front, "M149 326q10 -3 25 -1m-24 37q14 -2 25 -1", class_="seam")
    path(front, "M150 326l11 -1m-10 36h11", fill="none", stroke="#f1d4a3", stroke_width="1.4", stroke_linecap="round")
    if hem_y is not None:
        fur = f"M150 409Q157 413 173 409Q168 471 181 {hem_y + 9}Q159 {hem_y + 13} 141 {hem_y + 9}Q152 480 150 409Z"
        path(front, fur, "#bc9d76", stroke="#69513f", stroke_width=2, stroke_linejoin="round")
        path(front, f"M157 419Q160 474 155 {hem_y + 8}L164 {hem_y + 8}Q158 477 165 418Z", "#d3b58a")


def _draw_cloak(parent, defs, body: Body, cloth: Cloth, neck: float, *, ornate_clasp: bool,
                hem_y=None, hem_half=None, clasp_material=None, fabric_material=None, child=False) -> None:
    outer_left = max(8, 149 - body.sleeve)
    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    neck_left, neck_right = number(160 - neck), number(160 + neck)
    clasp = 160
    bottom = 454 if hem_y is None else min(620 if child else 711, hem_y + (30 if child else 75))
    edge = max(14, 160 - (hem_half or body.hem) - 18)
    opening = 160 - body.waist * .4
    left_panel = (
        f"M{neck_left} 273C{number(145 - neck)} 271 {shoulder + 10} {crest - 14} {shoulder - 5} {crest - 2}"
        f"C{shoulder - 28} {crest + 10} {outer_left + 6} 324 {outer_left} 362"
        f"C{outer_left - 2} 423 {edge - 7} {bottom - 62} {edge} {bottom - 11}"
        f"Q{edge + 22} {bottom + 8} {number(opening)} {bottom + 3}"
        f"C{number(opening + 7)} {bottom - 76} 132 371 {clasp} 294"
        f"Q146 292 {neck_left} 273Z"
    )
    right_panel = (
        f"M{neck_right} 273C{number(175 + neck)} 271 {310 - shoulder} {crest - 14} {325 - shoulder} {crest - 2}"
        f"C{348 - shoulder} {crest + 10} {314 - outer_left} 324 {320 - outer_left} 362"
        f"C{322 - outer_left} 423 {327 - edge} {bottom - 62} {320 - edge} {bottom - 11}"
        f"Q{298 - edge} {bottom + 8} {number(320 - opening)} {bottom + 3}"
        f"C{number(310 - opening)} {bottom - 73} 184 372 {clasp} 294"
        f"Q174 292 {neck_right} 273Z"
    )
    mantle = left_panel + right_panel
    path(node(defs, "clipPath", id="wardrobe-cloak-mask"), mantle)
    path(parent, mantle, cloth.base, class_="edge", data_part="cloak-fabric")
    panels = node(parent, "g", clip_path="url(#wardrobe-cloak-mask)")
    for mirror in (None, _MIRROR):
        folds = node(panels, "g", transform=mirror)
        path(folds, f"M{neck_left} 278Q{shoulder + 6} 302 {outer_left + 14} 365"
             f"C{outer_left + 8} 421 {edge + 6} {bottom - 65} {edge + 9} {bottom}"
             f"L{edge + 30} {bottom + 3}Q{outer_left + 37} 412 {shoulder + 24} 317Z",
             cloth.shade, opacity=".7")
        path(folds, f"M{clasp - 10} 305Q{shoulder + 36} 350 {opening + 8} 434"
             f"L{number(opening + 2)} {bottom + 4}H{number(opening - 9)}"
             f"Q{number(opening + 1)} 422 {clasp - 10} 305Z", cloth.light, opacity=".65")
        path(folds, f"M{shoulder - 6} 310Q{outer_left + 27} 355 {outer_left + 28} 405"
             f"Q{outer_left + 27} {bottom - 77} {edge + 23} {bottom - 5}", class_="seam")
        path(folds, f"M{shoulder + 12} 321Q{outer_left + 46} 377 {edge + 45} {bottom - 8}"
             f"M{number(opening + 2)} 402Q{number(opening - 9)} 468 {number(opening - 13)} {bottom - 6}",
             class_="seam", opacity=".65")
        path(folds, f"M{edge + 4} {bottom - 16}Q{edge + 28} {bottom + 1} {number(opening - 4)} {bottom - 4}",
             class_="seam")
        path(folds, f"M{outer_left + 15} 355l8 17m-3-25 9 23m-4-29 11 27", class_="etch")
    clasp_group = node(parent, "g", transform=f"translate({clasp} 294)",
                       data_material_slot="accessory" if clasp_material else None,
                       data_material_surface="fixed" if fabric_material and not clasp_material else None)
    if ornate_clasp:
        path(
            clasp_group,
            "M0 -9 Q8 -8 9 0 Q8 8 0 9 Q-8 8-9 0 Q-8 -8 0 -9Z "
            "M0 -4 Q-4 -4-4 0 Q-4 4 0 4 Q4 4 4 0 Q4 -4 0 -4Z",
            "#c99f63", fill_rule="evenodd", stroke="#3e2d26", stroke_width="2", stroke_linejoin="round",
        )
        path(clasp_group, "M-8 3 8 -3", "none", stroke="#e8bf82", stroke_width="2.3", stroke_linecap="round",
             data_material_surface="light" if clasp_material else None)
        path(clasp_group, "M-4 -6l3 -1m3 13 3 -2", "none", stroke="#ecd09b", stroke_width="1.3", stroke_linecap="round",
             data_material_surface="light" if clasp_material else None)
    else:
        path(clasp_group, "M0 -7 Q7 -6 8 0 Q7 6 0 8 Q-7 6-8 0 Q-7 -7 0 -7Z", "#c69657", class_="edge")
        path(clasp_group, "M-4 2 5 -2m-7 -2 4 -1", "none", stroke="#efd19c", stroke_width="1.55", stroke_linecap="round")


def _draw_pouch(parent, body: Body, *, material=None) -> None:
    pouch = node(parent, "g", data_part="belt-accessory", clip_path="url(#wardrobe-torso-mask)",
                 data_material_slot="accessory" if material else None)
    anchor = 162 - body.waist // 2
    strap = node(pouch, "g", transform=f"translate({anchor} 405)")
    path(strap, "M-4 0h7l1 16h-8Z", "#936448", class_="seam",
         data_material_surface="fixed" if material else None)
    path(strap, "M-9 13 Q0 10 9 14 L11 28 Q4 37-8 33 L-13 26Z", "#77523c", class_="edge",
         data_material_surface="base" if material else None)
    path(strap, "M-8 14 Q0 12 8 15 L8 22 Q0 27-11 21Z", "#a67b51", class_="seam",
         data_material_surface="light" if material else None)
    path(strap, "M-8 18q7 3 13 0", fill="none", stroke="#cfad75", stroke_width="1.35", stroke_dasharray="2 2",
         data_material_surface="fixed" if material else None)


def _draw_jewelry(parent, accessory: str, outfit: str, body: Body, neck: float, *, material=None) -> None:
    if accessory == "brooch" and outfit != "cloak":
        brooch_x = number(min(181 + neck, 147 + body.shoulder))
        brooch = node(parent, "g", transform=f"translate({brooch_x} 304) rotate(-16)",
                      data_material_slot="accessory" if material else None)
        path(
            brooch,
            "M-3 -7 Q-12 -4-7 4 Q-4 9 3 7 Q10 4 8 -3 L4 -2 Q6 3 1 4 Q-5 5-5 0 Q-5 -4-2 -4Z",
            "#ba9a63", stroke="#3e2d26", stroke_width="2.1", stroke_linejoin="round",
            data_material_surface="base" if material else None,
        )
        path(brooch, "M-5 -2 8 3m-9 3 4 -1", fill="none", stroke="#e0bc81", stroke_width="1.5",
             stroke_linecap="round", data_material_surface="light" if material else None)
    elif accessory == "pendant":
        center = 170 if outfit == "svita" else 160
        drop = 320 if outfit == "cloak" else 312
        pendant = node(parent, "g", transform=f"translate({center} {drop})",
                       data_material_slot="accessory" if material else None)
        path(
            pendant, "M-20 -19 Q-12 -7 0 2 Q12 -4 20 -19",
            "none", stroke="#50372a", stroke_width="2.7", stroke_linecap="round",
            data_material_surface="fixed" if material else None,
        )
        path(pendant, "M0 -2 7 6 5 14 0 18-5 14-7 6Z", "#ba925b", stroke="#392b25",
             stroke_width="2.2", stroke_linejoin="round", data_material_surface="base" if material else None)
        path(pendant, "M0 3 -3 7 0 11 3 7Z", "#e2b783",
             data_material_surface="light" if material else None)


def _draw_fabric_belt(parent, body: Body) -> None:
    left, right = 150 - body.waist, 170 + body.waist
    belt = node(parent, "g", data_part="belt", clip_path="url(#wardrobe-torso-mask)")
    path(belt, f"M{left} 397Q160 408 {right} 398L{right - 1} 409Q160 421 {left + 1} 410Z",
         "#735142", class_="edge")
    path(belt, f"M{left + 2} 400Q160 413 {right - 2} 401M{left + 3} 406Q160 418 {right - 3} 406",
         "none", stroke="#bb986b", stroke_width=1.55, stroke_linecap="round")
    path(belt, "M166 409Q165 416 172 420L175 414 180 429 173 435 169 422 164 428 160 424Z",
         "#967451", class_="seam")


def _remove_default_belts(parent):
    for element in tuple(parent.iter()):
        for part in list(element):
            if part.get("data-part") in {"belt", "medallion-belt"}:
                element.remove(part)


def _draw_selected_jewelry(parent, look, neck):
    style = look.get("jewelry", "none")
    if style != "none" and look["outfit"] not in ARMORED_OUTFITS:
        clipped = node(parent, "g", clip_path="url(#wardrobe-torso-mask)")
        wardrobe_northwest_accessories.draw_jewelry(clipped, style, neck, equipment=look)


def _draw_chest_ornaments(parent, look, body, neck):
    """Attach ornaments to the garment before its drape or vestment covers it."""
    if look["accessory"] == "pendant" or (look["accessory"] == "brooch" and look["outfit"] not in {"korzno", "rus_mantle"}):
        clipped = node(parent, "g", clip_path="url(#wardrobe-torso-mask)")
        _draw_jewelry(clipped, look["accessory"], look["outfit"], body, neck,
                      material=look.get("accessory_material"))
    _draw_selected_jewelry(parent, look, neck)


def carried_waist_weapon(look):
    weapon = look.get("weapon", "none")
    if weapon == "sheathed_sword" or (look.get("carry") != "held" and weapon in WAIST_WEAPONS):
        return weapon
    return "none"


def carried_bow_case(look):
    bow = look.get("bow", "none")
    bow_in_case = bow == "novgorod_composite" and look.get("carry") != "held"
    style = look.get("bow_case", "plain_leather" if bow_in_case else "none")
    return style, bow if bow_in_case and style != "none" else "none"


def _carried_at_back(look):
    if look.get("carry") == "held":
        return "none", "none"
    bow = look.get("bow", "none")
    weapon = look.get("weapon", "none")
    return (
        bow if carried_bow_case(look)[1] == "none" else "none",
        weapon if weapon in wardrobe_northwest_arms.BACK_WEAPONS else "none",
    )


def draw_back_equipment(parent, look, body):
    bow, weapon = _carried_at_back(look)
    child = look["age"] == "child"
    if bow != "none":
        wardrobe_northwest_archery.draw_back_bow(parent, bow, body, child=child)
    if weapon != "none":
        wardrobe_northwest_arms.draw_back_weapon(parent, weapon, body, child=child, other_side=bow != "none")
    shield = back_shield_style(look)
    if shield != "none":
        draw_back_shield(parent, shield, body)


def draw_shield_sling(parent, defs, look):
    shield = back_shield_style(look)
    if shield == "none":
        return
    body = _body_fit(BODIES[look["body"]], look["outfit"])
    clip_id = "shield-sling-silhouette"
    silhouette = node(defs, "clipPath", id=clip_id)
    torso = defs.find(f"./*[@id='wardrobe-torso-mask']/{tag('path')}")
    path(silhouette, torso.get("d"))
    cloak = parent.find(f".//*[@data-part='cloak']/{tag('path')}")
    if cloak is not None:
        path(silhouette, cloak.get("d"))
    elif "cloak" not in look and look["outfit"] in _DRAPED_CLOAKS | {"cloak"}:
        for mask_id in ("wardrobe-outer-mask", "wardrobe-cloak-mask"):
            for element in defs.findall(f"./*[@id='{mask_id}']/{tag('path')}"):
                path(silhouette, element.get("d"), transform=element.get("transform"))
    sling = node(parent, "g", data_part="shield-sling", data_style=shield,
                 clip_path=f"url(#{clip_id})")
    right = number(165 + body.shoulder)
    left = number(126 - body.sleeve)
    beltline = body.shoulder_y + 112
    curve = f"M{right} {body.shoulder_y - 10} C{right} {body.shoulder_y + 24} 132 {beltline - 15} {left} {beltline + 8}"
    path(sling, curve, "none", stroke="#342820", stroke_width=10, stroke_linecap="round")
    path(sling, curve, "none", stroke="#a17a55", stroke_width=6.7, stroke_linecap="round")
    path(sling, curve, "none", stroke="#d0aa7c", stroke_width=1.15, stroke_dasharray="2 4")


def draw_shoulder_straps(parent, look):
    bow, weapon = _carried_at_back(look)
    if bow == weapon == "none":
        return
    outfit = look["outfit"]
    if look.get("cloak") == "novgorod_mantle" or (
        "cloak" not in look and (outfit in _DRAPED_CLOAKS or outfit == "cloak")
    ):
        return
    body = _body_fit(BODIES[look["body"]], outfit)
    if look["age"] == "child":
        inset = number(160 * (1 - CHILD_BODY_SCALE))
        parent = node(parent, "g", transform=f"matrix({CHILD_BODY_SCALE} 0 0 1.08 {inset} -35.6)")
    x = number(160 - .84 * body.shoulder)
    y = body.shoulder_y - 14
    edge = number(160 + .83 * body.waist)
    curve = f"M{x} {y} Q141 351 {edge} 397"
    for style, mirror in ((bow, False), (weapon, bow != "none")):
        if style == "none":
            continue
        strap = node(parent, "g", data_part="shoulder-strap", data_style=style,
                     clip_path="url(#wardrobe-torso-mask)", transform=_MIRROR if mirror else None)
        path(strap, curve, "none", stroke="#322721", stroke_width=8.4, stroke_linecap="round")
        path(strap, curve, "none", stroke="#8a654b", stroke_width=5.5, stroke_linecap="round")
        path(strap, curve, "none", stroke="#bd9670", stroke_width=1.1, stroke_dasharray="2 4")


def _quiver_under_sleeve(root, waist, body):
    defs = root.find(tag("defs"))
    torso = defs.find(f"./*[@id='wardrobe-torso-mask']/{tag('path')}")
    outline = defs.find(f"./*[@id='wardrobe-sleeve-mask']/{tag('path')}")
    sleeve = outline.get("d") if outline is not None else _sleeve_shape(body)
    mask_id = "quiver-behind-sleeve"
    bounds = {"x": 0, "y": 0, "width": root.get("width"), "height": root.get("height")}
    mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse", **bounds)
    node(mask, "rect", fill="white", **bounds)
    path(mask, sleeve, "black", class_="edge", style="stroke:black")
    # Restore the cloth interior where the torso sits in front of the sleeve.
    # Keep the dark joining seam in front of the quiver as part of the arm contour.
    clip_id = "quiver-sleeve-interior"
    path(node(defs, "clipPath", id=clip_id), sleeve)
    overlap = node(mask, "g", clip_path=f"url(#{clip_id})")
    path(overlap, torso.get("d"), "white", class_="edge", style="stroke:black")
    return node(waist, "g", mask=f"url(#{mask_id})")


def draw_waist_accessories(parent, look, *, full=False):
    belt = look.get("belt")
    weapon = carried_waist_weapon(look) if full else "none"
    hangs_weapon = weapon != "none"
    bow_case, cased_bow = carried_bow_case(look) if full else ("none", "none")
    quiver = look.get("quiver", "none") if full else "none"
    archery = bow_case != "none" or quiver != "none"
    if belt is None and "belt_pouch" not in look and not (hangs_weapon or archery):
        return
    pouch = look.get("belt_pouch", "none")
    legacy_pouch = belt is not None and look["accessory"] == "pouch" and pouch == "none"
    has_pouch = legacy_pouch or pouch != "none"
    show_belt = belt not in {None, "none"}
    if not (show_belt or hangs_weapon or archery or has_pouch):
        return
    outfit = look["outfit"]
    body = _body_fit(BODIES[look["body"]], outfit)
    layer = node(parent, "g", data_part="waist-accessories")
    if look["age"] == "child":
        inset = number(160 * (1 - CHILD_BODY_SCALE))
        layer.set("transform", f"matrix({CHILD_BODY_SCALE} 0 0 1.08 {inset} -35.6)")
    if show_belt:
        wardrobe_northwest_accessories.draw_belt(layer, body, belt)
    covered_by_default = "cloak" not in look and (outfit in _DRAPED_CLOAKS or outfit == "cloak")
    hidden_belt = outfit in BELTLESS_OUTFITS or covered_by_default
    cord = belt == "none" or (belt is None and hidden_belt)
    if cord:
        if has_pouch:
            part = "pouch-cord"
        elif hangs_weapon:
            part = "scabbard-cord"
        else:
            part = "archery-cord"
        wardrobe_northwest_accessories.draw_support_cord(layer, body, part=part)
    # The checked skirt is tied higher than the standard selectable belts.
    belt_offset = -8 if belt is None and outfit == "rus_checked_panel" else 0
    if quiver != "none":
        behind_sleeve = _quiver_under_sleeve(parent, layer, body)
        wardrobe_northwest_archery.draw_quiver(behind_sleeve, quiver, body, belt_offset=belt_offset)
    if bow_case != "none":
        wardrobe_northwest_archery.draw_bow_case(layer, bow_case, body, bow=cased_bow, belt_offset=belt_offset)
    if legacy_pouch:
        _draw_pouch(layer, body, material=look.get("accessory_material"))
    elif pouch != "none":
        wardrobe_northwest_accessories.draw_pouch(layer, body, pouch, cord=False)
    if hangs_weapon:
        draw_waist_weapon(layer, weapon, body, along_bow_case=bow_case != "none", child=look["age"] == "child")
    return layer


def draw_cloak_layer(parent, look, head):
    style = look.get("cloak", "none")
    if style == "none":
        return
    body = _body_fit(BODIES[look["body"]], look["outfit"])
    if look["age"] == "child":
        # Shorten the drape around the same neckline used by the child's clothing.
        inset = number(160 * (1 - CHILD_BODY_SCALE))
        parent = node(parent, "g", transform=f"matrix({CHILD_BODY_SCALE} 0 0 .86 {inset} 24.68)")
    wardrobe_northwest_cloaks.draw_cloak(
        parent, body, head.neck_half + 6, style,
        trim_material=look.get("cloak_trim_material"),
    )


def _material_stroke(parent, contour, color, width, surface="fixed", **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linejoin="round", stroke_linecap="round",
         data_material_surface=surface, **attrs)


def _draw_paired_pin_gown(front, body, neck, cloth, hem_y, hem_half):
    top = 160 - body.shoulder
    bottom = (hem_y or 442) + 14
    left = 168 - (hem_half or body.hem)
    contour = _front_shape(body, neck, hem_y=hem_y, hem_half=hem_half)
    panel = node(front, "g", data_part="pinned-overgown")
    path(panel, contour, cloth.base, class_="edge", data_material_surface="base")
    path(panel, f"M{top + 16} 347Q125 409 {left + 13} {bottom}"
         f"H{left + 39}Q126 439 {top + 22} 347Z",
         cloth.shade, data_material_surface="shade")
    path(panel, f"M181 350Q193 429 {307 - left} {bottom}H{285 - left}"
         "Q185 438 181 350Z", cloth.light, opacity=".48", data_material_surface="light")
    _material_stroke(panel, f"M{number(160 - neck)} 277Q160 311 {number(160 + neck)} 277",
                     "#b0a17a", 2.8)
    for x, tilt in ((top + 14, -26), (306 - top, 26)):
        pin = node(panel, "g", transform=f"translate({x} {body.shoulder_y - 3}) rotate({tilt})",
                   data_part="shoulder-pin", data_material_surface="fixed")
        node(pin, "ellipse", rx=6.5, ry=9, fill="#b38a58", class_="edge")
        _material_stroke(pin, "M0-6v14m-4-10 4-3 4 3", "#e7c08a", 1.1)


def _draw_reference_cut(front, sleeves, look, body, neck, cloth, hem_y, hem_half):
    outfit = look["outfit"]
    if outfit == "paired_pin_gown":
        _draw_paired_pin_gown(front, body, neck, cloth, hem_y, hem_half)
        return
    bottom = (hem_y or 443) + 11
    left = 160 - (hem_half or body.hem)
    collar_left, collar_right = number(160 - neck), number(160 + neck)
    split_gowns = {"rus_work_shirt", "rus_wool_tunic", "western_knee_tunic", "rus_work_gown",
                   "rus_fine_gown", "rus_monk_robe", "rus_sticharion", "latin_pilgrim_robe"}
    if outfit in split_gowns:
        gores = {"rus_wool_tunic": (361, 29), "western_knee_tunic": (388, 23), "rus_work_gown": (340, 22),
                 "rus_fine_gown": (393, 26), "rus_monk_robe": (329, 18), "rus_sticharion": (345, 19)}
        if outfit in gores:
            start, inset = gores[outfit]
            gore = f"M{left + inset} {start}Q{left + 42} 433 {left + 4} {bottom}H{left + 42}Z"
            for mirror in (None, _MIRROR):
                path(front, gore, cloth.shade, transform=mirror, opacity=".55", data_material_surface="shade")
                path(front, f"M{left + inset} {start}Q{left + 44} 436 {left + 12} {bottom}",
                     class_="seam", transform=mirror)
        y = 330 if outfit in {"rus_work_shirt", "rus_monk_robe"} else 314
        opening = (f"M{collar_left} 273Q150 286 156 290L155 {y}l7 2L166 290"
                   f"Q182 285 {collar_right} 273Q160 307 {collar_left} 273Z")
        path(front, opening, cloth.shade, class_="edge", data_material_surface="shade")
        _material_stroke(front, f"M{collar_left} 278Q148 293 159 295L159 {y - 3}",
                         cloth.light, 1.45, "light", stroke_dasharray="2 2")
        if outfit == "latin_pilgrim_robe" and look.get("belt_pouch", "none") == "none":
            shoulder = 160 - body.shoulder + 13
            anchor = number(160 + body.waist * .6)
            strap = f"M{shoulder} {body.shoulder_y - 3}Q151 355 {anchor} 439"
            _material_stroke(front, strap, "#403229", 8.5)
            _material_stroke(front, strap, "#a48460", 4.7)
        if outfit in {"rus_fine_gown", "rus_sticharion"}:
            trim = "#b89969" if outfit == "rus_fine_gown" else "#9e6f58"
            line = f"M{left - 2} {bottom - 17}Q160 {bottom + 1} {322 - left} {bottom - 17}"
            _material_stroke(front, line, trim, 8.6)
            _material_stroke(front, line, "#dbc59a", 1.7, stroke_dasharray="3 3")
            if outfit == "rus_sticharion":
                _material_stroke(front, "M160 330v22m-8-15h16", trim, 3.2)
        if outfit == "rus_work_shirt":
            for x, y in ((106, 351), (199, 369), (136, 437), (191, 454)):
                path(front, f"M{x} {y}l8-5m-7 9 7-5m-5 9 5-3", class_="etch")
        return

    wrap_offset = {"rus_fine_coat": 20, "rus_child_wool_coat": 28, "rus_womens_fur_coat": -10,
                   "rus_cloth_covered_fur_coat": 25, "rus_child_fur_coat": 12,
                   "rus_cleric_robe": 5, "western_fine_coat": -5}[outfit]
    center = 160 + wrap_offset
    seam = (f"M{collar_left} 274Q152 305 {center} 328Q{center + 6} 382 {center + 2} 411"
            f"Q{center + 1} {number((bottom + 410) / 2)} {center + 4} {bottom}")
    path(front, f"{seam}H{left + 8}Q{left + 22} 450 {left + 25} 381"
         f"Q{left + 47} 301 {collar_left} 274Z", cloth.light, opacity=".31", data_material_surface="light")
    _material_stroke(front, seam, cloth.deep, 4.0, "shade")
    if outfit in {"rus_womens_fur_coat", "rus_cloth_covered_fur_coat", "rus_child_fur_coat"}:
        fur = {"rus_womens_fur_coat": "#766954", "rus_cloth_covered_fur_coat": "#aa825d",
               "rus_child_fur_coat": "#9b765d"}[outfit]
        trim = "base" if outfit == "rus_child_fur_coat" else "trim"
        collar = (f"M{number(152 - neck)} 275Q160 318 {number(167 + neck)} 275"
                  f"Q182 324 {center} 340Q139 330 {number(152 - neck)} 275Z")
        borders = node(front, "g", data_part="fur-lining")
        path(borders, collar, fur, class_="edge", data_material_surface=trim)
        _material_stroke(borders, seam, fur, 10 if outfit == "rus_womens_fur_coat" else 14, trim)
        _material_stroke(borders, seam, "#d0af85", 5,
                         "light" if trim == "base" else "trim-light", stroke_dasharray="1 4")
        for sleeve in sleeves:
            outer, inside = sleeve_cuff(body, outfit)
            cuff = f"M{outer - 8} 430Q{(outer + inside) // 2} 438 {inside + 7} 430"
            _material_stroke(sleeve, cuff, fur, 15.5, trim)
            _material_stroke(sleeve, cuff, "#c6aa83", 6,
                             "light" if trim == "base" else "trim-light", stroke_dasharray="1 3")
    else:
        width = 8 if outfit == "rus_fine_coat" else 3
        _material_stroke(front, seam, cloth.shade, width, "shade")
        _material_stroke(front, seam, cloth.light, 1.5, "light", stroke_dasharray="2 4")
        fastenings = 5 if outfit == "western_fine_coat" else 3
        for index in range(fastenings):
            y = 341 + 12 * index
            if outfit == "western_fine_coat":
                node(front, "circle", cx=center + 3, cy=y, r=2.8, fill="#ad966d", class_="edge",
                     data_material_surface="fixed")
            else:
                _material_stroke(front, f"M{center - 7} {y + 2}q8-5 17-2", "#ad936d", 2)


def _draw_pilgrim_scrip(parent, body):
    x = 160 + body.waist * .6
    bag = node(parent, "g", data_part="pilgrim-scrip",
               transform=f"translate({number(x)} 443) rotate(-7)")
    path(bag, "M-14-7Q0-11 15-7L19 28Q12 39-10 36Q-20 33-19 23Z",
         "#806349", class_="edge", data_material_surface="fixed")
    path(bag, "M-15-6Q0-11 15-6L15 8Q0 20-16 8Z",
         "#a17b55", class_="edge", data_material_surface="fixed")
    _material_stroke(bag, "M-14 26Q0 35 14 27M-15-4Q0-8 14-4", "#c1a579", 1.3)
    path(bag, "M-2 9h5v10h-5Z", "#6c4d37", class_="edge", data_material_surface="fixed")
    node(bag, "circle", cx=.5, cy=14, r=1.6, fill="#ccae76", data_material_surface="fixed")


def _draw_apron(parent, look, body, hem_y):
    style = look.get("apron", "none")
    if style == "none":
        return
    leather = style == "workshop_leather"
    half = round(.63 * body.waist)
    left, right = 160 - half, 160 + half
    bottom = 598 if hem_y is None else min(hem_y - 12, 562 if leather else 620)
    spread = round(.22 * half)
    layer = node(parent, "g", data_part="apron", data_style=style, data_material_slot="apron")
    base, light, shade = ("#865e44", "#af865c", "#654735") if leather else ("#ba9d77", "#d9c19a", "#947956")
    if leather:
        path(layer, "M140 302Q160 291 180 302L178 313Q160 303 143 313Z",
             shade, data_material_surface="shade")
        top = f"M139 307Q160 317 181 307Q181 352 {right} 405"
        lower = (f"Q{right + 10} 465 {right + spread} {bottom - 18}"
                 f"Q160 {bottom + 19} {left - spread} {bottom - 17}Q{left - 11} 466 {left} 405"
                 "Q137 358 139 307Z")
    else:
        top = f"M{left} 399Q160 405 {right} 399"
        lower = (f"Q{right + 4} 466 {right + spread} {bottom - 4}"
                 f"Q163 {bottom + 7} {left - spread} {bottom}Q{left - 6} 473 {left} 399Z")
    path(layer, top + lower, base, class_="edge", data_material_surface="base")
    for offset in (-2, 0, 2):
        x = 160 + half * offset // 3
        path(layer, f"M{x} 413Q{x - 7} 477 {x - 5} {bottom - 8}"
             f"Q{x + 4} 464 {x + 4} 416Z", shade, opacity=".62", data_material_surface="shade")
        _material_stroke(layer, f"M{x + 5} 431q-3 32 2 63", light, 1.6, "light")
    _material_stroke(layer, f"M{left - spread + 5} {bottom - 10}Q160 {bottom + 1} "
                     f"{right + spread - 5} {bottom - 12}", light, 1.5, "light", stroke_dasharray="2 3")


def _draw_vestment(parent, look, body, neck, hem_y):
    style = look.get("vestment", "none")
    if style == "none":
        return
    layer = node(parent, "g", data_part="vestment", data_style=style, data_material_slot="vestment")
    base, light, shade = "#a27a56", "#d1ac78", "#77573f"
    if style == "epimanikia":
        levels = tuple(range(405, 445, 5)) + (445,)
        sections = [(y, *sleeve_section(body, look["outfit"], y)) for y in levels]
        outside = " ".join(f"L{number(outer)} {y}" for y, outer, _ in sections[1:])
        inside = " ".join(f"L{number(inner)} {y}" for y, _, inner in reversed(sections[:-1]))
        top, outer, inner = sections[0]
        bottom, bottom_outer, bottom_inner = sections[-1]
        contour = (f"M{number(outer)} {top}{outside}H{number(bottom_inner)}{inside}"
                   f"Q{number((outer + inner) / 2)} {top + 10} {number(outer)} {top}Z")
        for transform in (None, _MIRROR):
            cuff = node(layer, "g", data_part="vestment-cuff", transform=transform,
                        clip_path="url(#wardrobe-sleeve-mask)")
            path(cuff, contour, base, class_="edge", data_material_surface="base")
            fold = (f"M{number(bottom_outer + 2)} {bottom - 5}"
                    f"Q{number((bottom_outer + bottom_inner) / 2)} {bottom - 1}"
                    f" {number(bottom_inner - 2)} {bottom - 5}")
            _material_stroke(cuff, fold, light, 3, "light", stroke_dasharray="2 2")
            _material_stroke(cuff, f"M{number(body.wrist_x)} 420v15m-5-10h10", "#e1c087", 1.8)
        return

    left, right = number(160 - neck), number(160 + neck)
    end = min(620, hem_y - 16) if hem_y is not None else 560
    designs = {
        "epitrachelion": (
            f"M{left} 273Q144 292 151 309Q147 438 143 {end}Q160 {end + 8} 177 {end}"
            f"Q173 438 169 309Q176 292 {right} 273Q160 310 {left} 273Z",
            f"M160 309Q157 427 160 {end}", (334, 377, 426, 479, 532, 581)),
        "orarion": (
            f"M{left} 277l-16 8Q103 421 95 {end}l19 4Q128 426 130 329Q132 292 {left} 277Z",
            f"M{number(151 - neck)} 287Q113 432 104 {end}", ()),
        "omophorion": (
            f"M{left} 273l-23 7Q94 327 130 353L140 {end}l29 -3L157 348"
            f"Q210 315 207 284L{right} 273Q201 305 144 326Q125 308 {left} 273Z",
            f"M{number(152 - neck)} 278Q110 318 143 341L156 {end - 4}", (369, 414, 461, 512, 564)),
    }
    if style == "phelonion":
        shoulder = 160 - body.shoulder
        outer = max(8, 151 - body.sleeve)
        base, light, shade = "#943f48", "#bf7068", "#682d3a"
        back = node(parent, "g", data_part="phelonion-back", data_material_slot="vestment")
        parent.remove(back)
        parent.insert(0, back)
        back_contour = (f"M{left} 273Q{shoulder} 279 {outer + 6} 330"
                        f"Q{outer - 4} 435 {outer + 4} {end}Q160 {end + 31} {316 - outer} {end}"
                        f"Q{324 - outer} 435 {314 - outer} 330Q{320 - shoulder} 279 {right} 273Z")
        path(back, back_contour, base, class_="edge", data_material_surface="base")
        for x in (outer + 12, 308 - outer):
            _material_stroke(back, f"M{x} 351Q{number((x + 160) / 2)} 475 {x} {end - 5}", shade, 4.5, "shade")
        _material_stroke(back, f"M{outer + 5} {end - 7}Q160 {end + 23} {315 - outer} {end - 7}", "#d7b77c", 5)
        contour = (f"M{left} 273C{number(146 - neck)} 273 {173 - body.shoulder} {body.shoulder_y - 10}"
                   f" {shoulder} {body.shoulder_y}Q{outer + 9} 310 {outer + 4} 350"
                   f"Q160 412 {316 - outer} 350Q{311 - outer} 310 {320 - shoulder} {body.shoulder_y}"
                   f"C{147 + body.shoulder} {body.shoulder_y - 10} {number(174 + neck)} 273 {right} 273"
                   f"Q160 305 {left} 273Z")
        path(layer, contour, base, class_="edge", data_part="vestment-front", data_material_surface="base")
        clip = node(layer, "clipPath", id="vestment-phelonion-clip")
        path(clip, contour)
        surface = node(layer, "g", clip_path="url(#vestment-phelonion-clip)")
        path(surface, f"M{left} 278Q120 320 {shoulder - 8} 373L{shoulder + 18} 379Q143 315 {left} 278Z",
             shade, data_material_surface="shade")
        path(surface, f"M{right} 278Q201 313 {332 - shoulder} 372L{310 - shoulder} 382Q179 319 {right} 278Z",
             light, opacity=".55", data_material_surface="light")
        _material_stroke(surface, f"M{outer + 7} 344Q160 401 {313 - outer} 344", "#d7b77c", 6)
        _material_stroke(surface, f"M{shoulder} 309Q160 350 {320 - shoulder} 309", "#d7b77c", 4)
        _material_stroke(layer, "M160 324v27m-9-19h18", "#dec18a", 3.1)
        return
    contour, fold, ornaments = designs[style]
    if style == "omophorion":
        base, light, shade = "#e5ded0", "#f5eee0", "#b4a79a"
    path(layer, contour, base, class_="edge", data_part="vestment-front", data_material_surface="base")
    _material_stroke(layer, fold, shade, 4.2, "shade")
    path(layer, f"M{number(153 - neck)} 278Q155 299 160 306Q165 298 {number(166 + neck)} 278",
         "none", stroke=light, stroke_width=2, data_material_surface="light")
    for y in ornaments:
        x = 151 + (y - 348) // 43 if style == "omophorion" else 160
        _material_stroke(layer, f"M{x} {y - 8}v16m-5-11h10",
                         "#8d5645" if style == "omophorion" else "#e6c592", 2.0)


_OUTFIT_TRIM = {
    "rus_gilt_cuff_tunic": {"#c39250": "trim", "#ecd08e": "trim-light"},
    "rus_gold_yoke_gown": {color: "trim" for color in ("#d8af73", "#edc88a", "#f0d4a1", "#d6a76c", "#e1b67d")},
    "nw_nov_sofia_tunic": {color: "trim" for color in ("#d0a163", "#cc9a5a", "#a97744", "#e0b880")},
    "nw_baltic_spiral_kuub": {"#dfb97e": "trim"},
    "nw_karel_tunic": {"#c6a375": "trim", "#e1be86": "trim-light"},
    "korzno": {"#d0a16a": "trim"},
    "kozukh": {"#d3b58a": "trim-light", "#ad8a66": "trim-shade", "#e8cc9f": "trim-light", "#bc9d76": "trim"},
}
_OUTFIT_MATERIAL_PANELS = {
    "rus_gold_yoke_gown": "embroidered-silk-yoke",
    "rus_checked_panel": "checked-wool",
    "nw_nov_womens_rubakha": "checked-waist-panel",
}


def _mark_outfit_material(parent, look, cloth):
    outfit = look["outfit"]
    base = look.get("outfit_material")
    trim = look.get("outfit_trim_material")
    if not (base or trim or outfit in _REFERENCE_OUTFITS):
        return
    colors = {
        cloth.base: "base", cloth.light: "light", cloth.shade: "shade", cloth.deep: "shade",
    }
    if outfit == "nw_karel_apron_gown":
        if base == "linen":
            colors = {LINEN.base: "base", LINEN.light: "light", LINEN.shade: "shade",
                      LINEN.deep: "shade", "#e7d1a4": "base"}
        else:
            colors.update({"#a07552": "base", "#78543e": "shade", "#c79c6c": "light"})
    trim_colors = _OUTFIT_TRIM.get(outfit, {}) if trim else {}
    for element in parent.iter():
        fill = element.get("fill")
        stroke = element.get("stroke")
        surface = trim_colors.get(fill) or trim_colors.get(stroke)
        if surface and outfit in _OUTFIT_MATERIAL_PANELS:
            element.set("data-material-slot", "outfit")
        if not surface and element.get("data-material-surface") is None:
            surface = colors.get(stroke if fill == "none" else fill)
        if surface:
            element.set("data-material-surface", surface)
            if outfit == "nw_karel_apron_gown":
                element.set("data-material-slot", "outfit")
    if trim and outfit == "yuan_fur_hunt_robe":
        edging = parent.find(".//*[@data-part='crossed-fur-edging']")
        edging.set("data-material-surface", "trim")
    if trim and outfit == "nw_nov_womens_fur_coat":
        for edging in parent.findall(".//*[@data-part='fur-edging']"):
            edging.set("data-material-surface", "trim")
    if base and outfit in _OUTFIT_MATERIAL_PANELS:
        part = _OUTFIT_MATERIAL_PANELS[outfit]
        panel = parent.find(f".//*[@data-part='{part}']")
        panel.set("data-material-slot", "outfit")
        for item in list(panel):
            if item.get("fill", "").startswith("url("):
                item.set("fill", "#98635c")
                item.set("data-material-surface", "base")
            elif item.get("stroke") in {"#53404a", "#ba9181", "#4d3c43", "#d6aa92"}:
                panel.remove(item)
            elif item.get("fill") == "#88605c":
                item.set("data-material-surface", "base")


def _draw_new_outfit(parent, defs, look, head, body, cloth, *, hem_y, hem_half=None):
    outfit = look["outfit"]
    listed = outfit in _REFERENCE_OUTFITS
    material = listed or look.get("outfit_material") or look.get("outfit_trim_material")
    broad_material = material and outfit not in _OUTFIT_MATERIAL_PANELS and outfit != "nw_karel_apron_gown"
    group = node(parent, "g", id=f"wardrobe-outfit-{outfit}", data_outfit=outfit,
                 data_material_slot="outfit" if broad_material else None)
    neck = head.neck_half + 6
    torso_shape = _front_shape(body, neck, hem_y=hem_y, hem_half=hem_half)
    sleeve_shape = _sleeve_shape(body, outfit)
    path(node(defs, "clipPath", id="wardrobe-torso-mask"), torso_shape)
    path(node(defs, "clipPath", id="wardrobe-sleeve-mask"), sleeve_shape)
    underlayer = LINEN if outfit in _LIGHT_UNDERLAYER else cloth
    sleeves = _draw_sleeves(group, body, underlayer, cut=outfit)
    path(group, torso_shape, underlayer.base)
    front = node(group, "g", data_part="torso", clip_path="url(#wardrobe-torso-mask)")
    if outfit not in _CHILD_DRAWERS and outfit != "song_plain_jacket":
        full_fabric = hem_y is not None and outfit not in FULL_HEMS
        _draw_folds(front, body, underlayer, hem_y=hem_y if full_fabric else None,
                    hem_half=hem_half if full_fabric else None)
    outline = path(group, torso_shape, "none", class_="edge")
    if broad_material and outfit in _LIGHT_UNDERLAYER:
        for element in group:
            element.set("data-material-surface", "fixed")

    waist = None
    if outfit in _WAIST_PARTS:
        waist = node(group, "g", data_part=_WAIST_PARTS[outfit], clip_path="url(#wardrobe-torso-mask)")
    if "belt" not in look:
        if outfit in _FABRIC_BELTS:
            _draw_fabric_belt(group, body)
        elif outfit == "korzno" or (listed and outfit not in _REFERENCE_BELTLESS):
            _draw_belt(group, body, full=hem_y is not None)
    if look["accessory"] == "pouch" and outfit not in BELTLESS_OUTFITS:
        _draw_pouch(group, body, material=look.get("accessory_material"))

    outer = None
    if outfit in _DRAPED_CLOAKS:
        _draw_chest_ornaments(group, look, body, neck)
    if outfit in _DRAPED_CLOAKS and "cloak" in look:
        # The bundled outfit still supplies its undergarment and sleeve details.
        outer = Element(tag("g"))
    elif outfit in _OUTER_LAYER:
        overlay = node(defs, "clipPath", id="wardrobe-outer-mask")
        path(overlay, torso_shape)
        path(overlay, sleeve_shape)
        path(overlay, sleeve_shape, transform=_MIRROR)
        outer = node(group, "g", clip_path="url(#wardrobe-outer-mask)")
    if listed:
        _draw_reference_cut(front, sleeves, look, body, neck, cloth, hem_y, hem_half)
    else:
        _OUTFIT_DRAWERS[outfit](OutfitArt(front, sleeves, outer, waist, body, neck, cloth, look,
                                        hem_y=hem_y, hem_half=hem_half))
    if outfit == "latin_pilgrim_robe" and look.get("belt_pouch", "none") == "none":
        _draw_pilgrim_scrip(group, body)
    _mark_outfit_material(group, look, cloth)
    if "belt" in look and waist is not None:
        _remove_default_belts(group)
    if outfit not in _DRAPED_CLOAKS:
        _draw_chest_ornaments(group, look, body, neck)
    _draw_vestment(group, look, body, neck, hem_y)
    if look.get("apron", "none") != "none":
        _draw_apron(group, look, body, hem_y)
        apron = group[-1]
        if waist is not None:
            group.remove(apron)
            belt = waist.find("./*[@data-part='belt']")
            if belt is None:
                waist.append(apron)
            else:
                waist.insert(list(waist).index(belt), apron)
        else:
            # Keep the apron under the first overlay, including the default belt.
            group.remove(apron)
            group.insert(list(group).index(outline) + 1, apron)


def draw_outfit(parent, defs, look: dict[str, str], head: HeadGeometry, *, full=False) -> None:
    if look["age"] == "child":
        inset = number(160 * (1 - CHILD_BODY_SCALE))
        parent = node(parent, "g", data_part="wardrobe",
                      transform=f"matrix({CHILD_BODY_SCALE} 0 0 1.08 {inset} -35.6)")
    outfit = look["outfit"]
    body = _body_fit(BODIES[look["body"]], outfit)
    cloth = DYED.get(look["cloth_color"], NATURAL[outfit])
    hem_y, hem_half = _full_hem(look, body) if full else (None, None)
    if outfit == "image_fur_loincloth":
        skin = head.skin
        group = node(parent, "g", data_part="bare-torso")
        shoulder = 160 - body.shoulder
        wrist, inner_wrist = sleeve_cuff(body, outfit)
        elbow = (shoulder + wrist) / 2
        arm = (f"M{shoulder+10} 287Q{shoulder-13} 298 {elbow-10} 350"
               f"Q{elbow-12} 382 {wrist} 440Q{(wrist+inner_wrist)/2} 446 {inner_wrist} 440"
               f"Q{inner_wrist-3} 391 {elbow+15} 357L{shoulder+30} 311Z")
        for mirrored in (False, True):
            limb = node(group, "g", transform=_MIRROR if mirrored else None)
            path(limb, arm, skin.base, class_="edge", data_part="bare-arm-outline",
                 data_side="right" if mirrored else "left")
            path(limb, f"M{shoulder+8} 300Q{elbow-5} 331 {elbow-4} 356Q{elbow-5} 394 {wrist+5} 430", "none",
                 stroke=skin.light, stroke_width=7, stroke_linecap="round")
            path(limb, f"M{elbow+1} 355q6 4 10 2", "none", stroke=skin.shade, stroke_width=1.5)
        contour = _front_shape(body, head.neck_half + 6, hem_y=470, hem_half=body.waist)
        path(group, contour, skin.base, class_="edge")
        path(group, "M139 289q-15 8-28 11m69-11q15 8 28 11M160 318v27", "none",
             stroke=skin.shade, stroke_width=1.6, stroke_linecap="round")
        path(node(defs, "clipPath", id="wardrobe-torso-mask"), contour)
        path(node(defs, "clipPath", id="wardrobe-sleeve-mask"), arm)
        garment = node(parent, "g", data_material_slot="outfit", data_part="fur-loincloth")
        art = OutfitArt(garment, (), None, None, body, head.neck_half + 6, cloth, look,
                        hem_y=hem_y, hem_half=hem_half)
        image_daily_art.draw_fur_loincloth(art)
        _draw_selected_jewelry(parent, look, head.neck_half + 6)
        return
    accessory = look["accessory"]
    replace_pouch = accessory == "pouch" and (look.get("belt_pouch", "none") != "none" or "belt" in look)
    replace_jewelry = accessory in {"brooch", "pendant"} and (
        wardrobe_northwest_accessories.is_chest_jewelry(look.get("jewelry")) or outfit in ARMORED_OUTFITS
    )
    if replace_pouch or replace_jewelry:
        accessory = "none"
        look = {**look, "accessory": accessory}
    if outfit in _OUTFIT_DRAWERS or outfit in _REFERENCE_OUTFITS:
        _draw_new_outfit(parent, defs, look, head, body, cloth, hem_y=hem_y, hem_half=hem_half)
        return
    accessory = look["accessory"]
    neck = head.neck_half + 6
    front_shape = _front_shape(body, neck, hem_y=hem_y, hem_half=hem_half)
    mask = node(defs, "clipPath", id="wardrobe-torso-mask")
    path(mask, front_shape)

    underlayer = LINEN if outfit == "cloak" else cloth
    material = look.get("outfit_material") or look.get("outfit_trim_material")
    fabric = node(parent, "g", data_material_slot="outfit") if material and outfit != "cloak" else parent
    sleeve_trim = look.get("vestment") == "epimanikia"
    if full or sleeve_trim:
        path(node(defs, "clipPath", id="wardrobe-sleeve-mask"), _sleeve_shape(body))
    _draw_sleeves(fabric, body, underlayer, cuffs=full)
    path(fabric, front_shape, underlayer.base)
    front = node(fabric, "g", data_part="torso", clip_path="url(#wardrobe-torso-mask)")
    _draw_folds(front, body, underlayer, hem_y=hem_y, hem_half=hem_half)
    _draw_collar(front, neck, outfit)
    if outfit == "kozukh":
        _draw_fur(front, neck, hem_y=hem_y)
    elif outfit == "armor":
        _draw_plate_front(front, defs, body, neck)
    path(fabric, front_shape, "none", class_="edge")
    if fabric is not parent:
        _mark_outfit_material(fabric, look, cloth)
    _draw_chest_ornaments(parent, look, body, neck)
    _draw_vestment(parent, look, body, neck, hem_y)
    _draw_apron(parent, look, body, hem_y)
    if "belt" not in look:
        _draw_belt(parent, body, full=full)
    if accessory == "pouch":
        _draw_pouch(parent, body, material=look.get("accessory_material"))
    if outfit == "cloak" and "cloak" not in look:
        cape = node(parent, "g", data_material_slot="outfit") if material else parent
        clasp_material = look.get("accessory_material") if accessory == "brooch" else None
        _draw_cloak(cape, defs, body, cloth, neck, ornate_clasp=accessory == "brooch",
                    hem_y=hem_y, hem_half=hem_half, clasp_material=clasp_material, fabric_material=material,
                    child=look["age"] == "child")
        if cape is not parent:
            _mark_outfit_material(cape, look, cloth)
