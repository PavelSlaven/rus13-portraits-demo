from common import node, path


OPTIONS = {
    "rus_wedge_cap": "Рязанская шапка с отворотом",
    "castile_biretta": "Кастильский биррет",
    "yuan_hunting_cap": "Юаньская охотничья шапка",
    "song_futou": "Сунский футоу",
}
COVERAGE = {gear: {"hair": True, "ears": True, "neck": True} for gear in OPTIONS}
HAIR_ROOT_HALF = {
    "rus_wedge_cap": 73,
    "castile_biretta": 71,
    "yuan_hunting_cap": 72,
    "song_futou": 70,
}
OPEN_CROWNS = set()


def draw_rus_wedge_cap(parent, look, fit):
    # The Solotcha stone icon records the shape. The cloth colors and stitching are reconstructed.
    crown = fit.crown(parent, minimum_y=44)
    path(crown, "M80 108 Q100 84 128 62 L151 45 Q156 42 163 47 L193 60 "
         "Q225 76 241 104 L229 115 H91 Z", "#49665b", class_="edge")
    path(crown, "M87 103 Q111 77 150 49 L161 48 Q143 67 127 97 Z", "#738476")
    path(crown, "M164 48 Q213 63 240 104 L172 104 Q177 77 164 48 Z", "#334943")
    path(crown, "M190 63 Q219 77 235 101 L206 101 Q203 82 190 63 Z",
         "url(#ink-lines)", opacity=".59")
    path(crown, "M156 49 Q144 65 137 79 Q132 88 128 98 M168 51 Q178 69 176 88",
         class_="seam")
    path(crown, "M103 93 l14-12 m-6 13 9-7 m70-13 6 6 m4 5 7 8", class_="etch", opacity=".7")

    turnup = fit.sides(parent)
    path(turnup, "M80 100 Q113 94 143 97 L160 100 L178 97 Q210 95 240 100 "
         "L237 116 Q195 111 160 114 Q123 111 83 116 Z", "#9b584b", class_="edge")
    path(turnup, "M83 101 Q117 96 143 98 L160 102 L178 99 Q210 97 238 102 "
         "L235 105 Q199 101 177 102 L160 105 L142 102 Q113 100 84 106 Z", "#c3896e")
    path(turnup, "M83 111 Q121 107 159 110 Q202 107 238 111 L237 116 "
         "Q196 111 160 114 Q122 111 83 116 Z", "#653d37")
    path(turnup, "M91 108 l5-4 5 3 5-4 5 3 5-4 5 3 5-4 5 4 5-3 5 3 5-3 6 3 "
         "M168 105 l5-3 5 3 5-3 5 3 5-4 5 4 5-3 5 4 5-3 5 4 5-3 5 4",
         "none", stroke="#d4a47a", stroke_width=1.35, stroke_linejoin="round")


def draw_castile_biretta(parent, look, fit):
    # The Las Huelgas biretta has beaded castles and lions between gilt-metal bands.
    crown = fit.crown(parent, minimum_y=40)
    path(crown, "M84 48 C113 40 208 40 236 48 L235 107 Q160 120 85 107 Z",
         "#813938", class_="edge")
    path(crown, "M84 48 C113 40 208 40 236 48 C208 57 114 57 84 48 Z",
         "#b27b50", class_="seam")
    path(crown, "M92 58 Q113 62 122 62 L121 108 Q104 106 91 104 Z", "#a34c40")
    path(crown, "M206 62 Q221 60 235 55 L235 108 L218 110 Z", "#58292d")
    path(crown, "M215 63 l17-5 v45 l-10 2 Z", "url(#ink-lines)", opacity=".53")
    path(crown, "M86 48 Q121 55 159 54 Q208 54 234 48 L235 57 "
         "Q208 64 161 64 Q120 64 85 57 Z", "#ad794b", class_="seam")
    path(crown, "M91 52 Q124 59 160 58 Q199 58 230 52",
         "none", stroke="#e9c184", stroke_width=1.4, stroke_linecap="round")

    for x, y, tilt, fill in (
        (104, 79, 8, "#cfaa6c"), (132, 83, 4, "#dcb878"), (160, 85, 0, "#e7c58a"),
        (188, 83, -4, "#dcb878"), (216, 79, -8, "#b89261"),
    ):
        panel = node(crown, "g", transform=f"translate({x} {y}) rotate({tilt})")
        path(panel, "M-13-12 H13 V8 L0 17 -13 8 Z", "none", stroke=fill, stroke_width=1.15)
        if x in (104, 160, 216):
            path(panel, "M-8 7 V-3 H-6 V-7 H-4 V-4 H-2 V-9 H2 V-4 H4 V-7 H6 V-3 H8 V7 H2 V2 H-2 V7 Z",
                 fill)
            path(panel, "M-5 0 v2 m10-2 v2", "none", stroke="#6b3433", stroke_width=1.15)
        else:
            path(panel, "M-6 8 l4-6 -3-4 -5-1 1-3 5 1 4 3 2-3 -2-1 1-3 4 1 1 3 -2 6 4 4 -2 4 -4-2 "
                 "2-2 -3-2 -4 5 Z", fill)
            path(panel, "M6 0 Q10-2 9-6 Q8-9 6-7", "none", stroke=fill,
                 stroke_width=1.45, stroke_linecap="round")

    rim = fit.sides(parent)
    path(rim, "M85 101 Q160 110 235 101 L235 112 Q160 121 85 112 Z",
         "#98623d", class_="edge")
    path(rim, "M88 104 Q159 113 232 104 M88 109 Q159 118 232 109",
         "none", stroke="#d9ad6e", stroke_width=1.4, stroke_linecap="round")
    path(rim, "M102 107 l3-2 3 3 -3 2 Z M128 110 l3-2 3 2 -3 2 Z "
         "M157 111 l3-3 3 3 -3 2 Z M186 110 l3-2 3 2 -3 2 Z M212 108 l3-3 3 2 -3 3 Z",
         "#c6abba")


def draw_yuan_hunting_cap(parent, look, fit):
    # Liu Guandao, Khubilai Khan Hunting (1280), National Palace Museum, catalogue 745.
    crown = fit.crown(parent, minimum_y=65)
    path(crown, "M82 105 Q90 87 112 76 Q134 64 161 66 Q195 65 217 79 Q233 89 239 106 "
         "L229 114 H92 Z", "#98483c", class_="edge")
    path(crown, "M89 101 Q115 72 159 70 Q141 78 134 96 Q107 97 89 101 Z", "#bc6550")
    path(crown, "M169 69 Q212 70 233 102 L194 98 Q191 82 169 69 Z", "#72372f")
    path(crown, "M199 76 Q219 85 230 100 L210 98 Z", "url(#ink-lines)", opacity=".52")
    path(crown, "M161 68 Q140 76 133 94 M175 72 Q187 80 192 94", class_="seam", opacity=".7")
    path(crown, "M106 91 l9-6 m6 1 4-3 m74 2 7 4", class_="etch", opacity=".55")

    brim = fit.sides(parent)
    path(brim, "M81 101 Q115 94 159 95 Q202 94 239 101 L237 115 "
         "Q201 108 159 110 Q116 109 83 115 Z", "#3d3233", class_="edge")
    path(brim, "M84 103 Q113 96 159 97 Q201 96 236 102 L236 106 "
         "Q199 99 159 100 Q112 99 85 107 Z", "#6f4c45")
    path(brim, "M89 109 Q116 103 159 104 Q202 102 231 109",
         "none", stroke="#9a6c57", stroke_width=1.45, stroke_linecap="round")


def draw_song_futou(parent, look, fit):
    # Seated Portrait of Emperor Ningzong, National Palace Museum, catalogue 1871.
    crown = fit.crown(parent, minimum_y=45)
    for mirror in (None, "translate(320 0) scale(-1 1)"):
        wing = node(crown, "g", transform=mirror)
        path(wing, "M95 79 H67 L64 75 H36 L34 77 V85 L36 87 H64 L67 83 H95 Z",
             "#2f2c2e", class_="edge")
        path(wing, "M37 78 H61 L66 81 H89", "none", stroke="#676063", stroke_width=1.3,
             stroke_linecap="round")

    path(crown, "M85 107 L86 78 Q88 73 94 73 H112 L113 55 Q114 49 120 48 "
         "Q160 42 199 48 Q205 49 206 55 L208 73 H226 Q233 73 234 79 L235 107 "
         "L227 115 H93 Z", "#29272b", class_="edge")
    path(crown, "M118 55 Q120 51 127 51 Q153 47 176 49 Q148 54 139 61 "
         "Q134 66 134 73 H116 Z", "#51494d")
    path(crown, "M178 49 Q200 48 204 54 L207 73 H184 Q185 61 178 49 Z", "#211f23")
    path(crown, "M90 80 Q92 76 98 76 H140 Q123 84 120 99 L90 102 Z", "#484146")
    path(crown, "M188 76 H226 Q231 77 232 81 L233 101 L198 98 Q197 86 188 76 Z", "#1e1c20")
    path(crown, "M116 72 Q160 68 205 72 M92 79 H111 M212 79 H229", "none",
         stroke="#665a60", stroke_width=1.35, stroke_linecap="round")
    path(crown, "M189 79 H223 L230 100 L211 98 Z", "url(#ink-lines)", opacity=".45")

    rim = fit.sides(parent)
    path(rim, "M85 101 Q160 93 235 101 L235 115 Q159 107 85 115 Z",
         "#383136", class_="edge")
    path(rim, "M89 104 Q159 96 231 104 M89 110 Q159 102 231 110", "none",
         stroke="#63575b", stroke_width=1.3, stroke_linecap="round")


DRAWERS = {
    "rus_wedge_cap": draw_rus_wedge_cap,
    "castile_biretta": draw_castile_biretta,
    "yuan_hunting_cap": draw_yuan_hunting_cap,
    "song_futou": draw_song_futou,
}
