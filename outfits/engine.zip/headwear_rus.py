from common import node, number, path
from face_shape import _outline_half, make_head


def draw_fur_cap(parent, look, fit):
    crown = fit.crown(parent)
    path(crown, "M79 94 C84 66 113 46 149 44 C192 40 226 60 240 93 L229 110 H90 Z",
         "#873a37", class_="edge")
    path(crown, "M87 89 C105 65 126 53 156 48 C143 58 133 69 128 87 Z", "#b65b4a")
    path(crown, "M161 46 C199 48 226 65 237 92 L191 90 C187 69 175 54 161 46 Z", "#592a2c")
    path(crown, "M194 60 Q226 70 237 92 L208 91 Q205 72 194 60 Z", "url(#ink-lines)")
    path(crown, "M157 47 C139 55 129 67 125 84 M165 47 C177 56 187 70 191 84", class_="seam")

    band = (
        "M73 98 Q71 91 79 87 Q82 81 92 84 Q99 78 110 81 Q120 76 133 80 "
        "Q154 74 168 79 Q184 76 199 81 Q210 78 219 84 Q229 81 235 88 "
        "Q248 87 247 101 Q253 106 245 113 Q246 120 233 121 Q226 122 220 115 "
        "C192 107 128 107 100 115 Q93 122 86 120 Q73 121 74 113 Q66 108 73 98 Z"
    )
    path(crown, band, "#4b322c", class_="edge")
    path(crown, "M77 101 Q81 89 108 87 Q142 81 163 85 Q186 82 208 88 Q170 87 144 95 "
         "Q120 100 103 98 Q89 97 77 109 Z", "#76523e")
    path(crown, "M81 115 Q110 100 153 101 Q198 99 221 107 Q235 106 241 100 "
         "Q248 109 236 117 Q225 120 220 113 Q177 101 100 113 Q90 120 81 115 Z", "#362624")
    path(crown, "M83 106 q5-8 12-7 m5 1 q6-8 12-6 m5 2 q5-7 11-6 m8 4 q6-8 13-6 "
         "m8 5 q5-8 12-6 m7 2 q6-4 12-1 m9 6 q6-5 13-2 m6 6 q8-4 13 0 m2 6 q6-3 9 0",
         "none", stroke="#aa8160", stroke_width=2, stroke_linecap="round", opacity=".65")
    path(crown, "M81 111 l4-3 m16-2 6-2 m14-1 5-4 m20 1 6-4 m10 4 6-4 m13 3 7-3 "
         "m10 6 8-3 m13 7 7-3 m6 11 5-3", class_="etch")


def draw_felt_cap(parent, look, fit):
    crown = fit.crown(parent, minimum_y=24)
    path(crown, "M85 104 C92 87 105 78 116 61 C126 47 129 33 145 27 "
         "C159 20 181 25 186 38 Q191 47 181 54 C190 69 215 78 234 104 L225 113 H94 Z",
         "#88774d", class_="edge")
    path(crown, "M91 103 C108 83 124 72 136 43 Q144 27 164 27 Q148 33 146 51 "
         "C141 74 132 88 129 101 Z", "#ab9763")
    path(crown, "M164 30 Q178 29 183 40 Q187 47 178 52 Q167 45 162 52 "
         "C173 76 183 86 185 105 H231 C215 81 188 72 180 54 Q173 49 175 44 "
         "Q177 35 164 30 Z", "#615539")
    path(crown, "M180 55 C190 74 213 81 227 101 L203 103 Q199 87 180 55 Z",
         "url(#ink-lines)", opacity=".62")
    path(crown, "M183 52 Q176 42 160 52 M161 56 Q168 71 182 77 Q192 83 198 91", class_="seam")
    path(crown, "M113 81 l8-10 m8-13 4-8 M177 65 q7 8 14 10 m6 9 6 5 m3-6 7 5",
         class_="etch", opacity=".8")
    path(crown, "M77 102 Q123 94 158 95 Q197 94 243 101 L240 113 "
         "Q237 121 219 115 Q160 111 101 115 Q83 121 80 113 Z", "#736342", class_="edge")
    path(crown, "M81 103 Q160 91 239 103 L238 107 Q160 98 82 108 Z", "#ac9664")
    path(crown, "M86 113 Q152 103 234 112", class_="etch", opacity=".8")


def _draw_temple_ring(parent, transform, metal, light):
    ring = node(parent, "g", transform=transform)
    wire = "M-12 5 C-16 -10 1 -16 9 -8 Q14 -4 12 5"
    path(ring, wire,
         "none", stroke="#302c31", stroke_width=7.1, stroke_linecap="round")
    path(ring, wire,
         "none", stroke=metal, stroke_width=4.5, stroke_linecap="round")
    path(ring, "M-12 2 C-13 -7 -5 -12 2 -11",
         "none", stroke=light, stroke_width=3, stroke_linecap="round")
    # A radial fan of seven lobes sits on the lower arc of the wire ring.
    path(ring, "M-11 2 L-9 4 -8 3 -6 4 -6 6 -3 7 -3 5 -1 5 -1 7 1 7 1 5 3 5 3 7 6 6 6 4 8 3 9 4 11 2 "
         "L16 5 Q18 8 15 10 L11 9 L15 13 Q16 17 12 18 L8 15 L11 21 Q10 25 6 24 L3 19 L5 26 "
         "Q3 31 0 31 Q-3 31 -5 26 L-3 19 -6 24 Q-10 25 -11 21 L-8 15 -12 18 "
         "Q-16 17 -15 13 L-11 9 -15 10 Q-18 8 -16 5 Z",
         metal, stroke="#302c31", stroke_width=2.7, stroke_linejoin="round")
    path(ring, "M-15 6 L-10 5 Q-3 10 4 8 L10 5 L13 7 L10 12 L6 11 L8 16 "
         "L4 15 L4 20 L1 17 L2 25 Q0 29 -2 26 L-1 16 L-4 18 L-6 21 L-8 20 "
         "L-5 13 L-11 15 L-13 14 L-9 9 L-15 9 Z", light)
    path(ring, "M-10 7 Q0 17 10 7 M-9 12 l3 3 m3 1 1 4 m3-2 1 5 m3-6 1-3",
         "none", stroke="#f8f8f3", stroke_width=1.55, stroke_linecap="round")


def draw_temple_rings(parent, look, fit):
    sides = fit.sides(parent)
    for transform in ("", "translate(320 0) scale(-1 1)"):
        panel = node(sides, "g", transform=transform or None)
        path(panel, "M70 108 L92 109 Q89 133 88 156 Q89 184 95 210 L98 217 "
             "Q81 217 64 227 Q59 212 63 194 Q67 174 63 156 Q60 128 70 108 Z",
             "#b8a67d", class_="edge")
        path(panel, "M70 115 Q75 145 71 168 Q72 192 66 215 L66 222 Q76 215 86 214 "
             "Q78 193 82 167 Q85 139 83 115 Z", "#d7c49a")
        path(panel, "M86 122 Q83 166 85 189 Q87 205 92 213 L98 217 Q91 185 89 155 Z",
             "#756655")
        path(panel, "M72 143 Q69 153 72 165 M70 190 Q72 177 71 171 M67 220 Q78 214 91 213",
             class_="etch")

    crown = fit.crown(parent)
    path(crown, "M66 112 C69 88 78 68 106 53 Q136 40 159 44 C204 39 243 63 254 109 "
         "L231 117 Q160 102 89 117 Z", "#69796b", class_="edge")
    path(crown, "M77 105 C84 75 111 55 145 50 Q121 64 110 87 L103 108 Z", "#9ba185")
    path(crown, "M154 46 C196 43 236 68 248 108 L193 107 Q190 70 154 46 Z", "#505e55")
    path(crown, "M186 55 Q230 67 246 106 L214 106 Q210 80 186 55 Z", "url(#ink-lines)", opacity=".6")
    path(crown, "M69 92 Q104 81 160 88 Q219 83 250 92 L256 110 Q241 120 227 114 "
         "Q160 105 93 114 Q79 121 64 111 Z", "#78534e", class_="edge")
    path(crown, "M70 96 Q111 86 160 92 Q212 86 250 96 L251 101 Q205 94 160 98 "
         "Q110 95 69 101 Z", "#a77d63")
    for x, y in ((80, 104), (100, 101), (120, 100), (140, 101), (160, 102),
                 (180, 101), (200, 100), (220, 101), (240, 104)):
        path(crown, "M-6 0 L0-3.5 6 0 0 3.5 Z", "#cdaf79", transform=f"translate({x} {y})")

    for transform in ("", "translate(320 0) scale(-1 1)"):
        jewelry = node(sides, "g", transform=transform or None)
        path(jewelry, "M76 110 Q68 133 76 151 Q68 163 71 182 M73 123 Q78 126 79 140",
             "none", stroke="#473630", stroke_width=3.2, stroke_linecap="round")
        path(jewelry, "M74 119 Q69 131 74 144 M72 165 Q69 172 72 179",
             "none", stroke="#b89f70", stroke_width=1.1, stroke_linecap="round")
        _draw_temple_ring(jewelry, "translate(68 170) rotate(-13)", "#859099", "#c9d5da")
        _draw_temple_ring(jewelry, "translate(78 140) rotate(9)", "#9eaab1", "#e4edf0")


def _draw_vyatichi_ring(parent, x, y, *, card):
    ring = node(parent, "g", data_part="seven-lobed-temple-ring",
                transform=f"translate({x} {y}) scale(.86)")
    outline, silver, light = "#38353b", "#c5d2d8" if card else "#99aab1", "#f0f1e7"
    wire = "M-14 1 C-17 -6 -11 -16 -3 -18 C5 -20 16 -12 14 0"
    path(ring, wire, "none", stroke=outline, stroke_width=5.5, stroke_linecap="round")
    path(ring, wire, "none", stroke=silver, stroke_width=3.4, stroke_linecap="round")

    # Seven broad blades and deep, rounded cuts follow the Maryino ring in plate 77, 1.
    fan = (
        "M-14 -1 Q0 7 14 -1 Q19 -3 19 6 Q18 9 14 6 C8 3 9 9 14 10 "
        "Q18 11 14 18 Q12 20 9 15 Q7 12 6 14 Q5 16 9 21 Q11 24 7 27 "
        "Q5 28 5 25 L3.5 18 Q2.7 15 1.6 18 C.6 22 3 27 5 31 Q0 35 -5 31 "
        "C-3 27 -.6 22 -1.6 18 Q-2.7 15 -3.5 18 L-5 25 Q-5 28 -7 27 "
        "Q-11 24 -9 21 Q-5 16 -6 14 Q-7 12 -9 15 Q-12 20 -14 18 "
        "Q-18 11 -14 10 C-9 9 -8 3 -14 6 Q-18 9 -19 6 Q-19 -3 -14 -1Z"
    )
    path(ring, fan, silver, stroke=outline, stroke_width=1.6, stroke_linejoin="round")
    path(ring, "M-15 2 Q0 12 15 2", "none", stroke=light, stroke_width=2.3, stroke_linecap="round")
    if not card:
        path(ring, "M-13 6 Q0 16 13 6", "none", stroke="#52646b", stroke_width=.9)
        path(ring, "M-11 11 l-2 3 M-7 20 l-1 3 M7 20 l1 3 M11 11 l2 3",
             "none", stroke=light, stroke_width=1, stroke_linecap="round")


def draw_vyatichi_lobed_band(parent, look, fit):
    # Saburova, plates 76, 3 and 77, 1. A wool ribbon carries the rings beside loose hair.
    attachments = node(parent, "g", data_part="headband-attachments")
    band = fit.forehead_band(parent, look, height=18)
    wool = "#ad4259" if band.card else "#8c4b40"
    light = "#ee9bb9" if band.card else "#c98c70"
    for side in (-1, 1):
        x, y = band.point(side)
        attach_x, attach_y = band.point(.9 * side, .62)
        temple = node(attachments, "g",
                      transform=f"translate({number(x)} {number(y)}) scale({side} 1)")
        start_x = number(side * (attach_x - x))
        start_y = number(attach_y - y)
        start_bottom = number(attach_y - y + 5)
        path(temple, f"M{start_x} {start_y} Q12 -2 17 14 C21 27 14 41 20 54 "
             f"L21 68 L13 72 Q7 53 10 35 C13 23 9 9 {start_x} {start_bottom}Z",
             wool, stroke="#57323a", stroke_width=1.7, stroke_linejoin="round")
        path(temple, f"M{start_x} {start_y} Q15 2 15 26 Q10 50 16 63",
             "none", stroke=light, stroke_width=1.6, stroke_linecap="round")
        for ring_x, ring_y in ((17, 68), (15, 40), (15, 15)):
            _draw_vyatichi_ring(temple, ring_x, ring_y, card=band.card)

    path(band.group, band.strip(), wool)
    path(band.group, band.strip(bottom=.42 if band.card else .27), light)
    path(band.group, band.strip(top=.73 if band.card else .81), "#a02049" if band.card else "#633731")
    if not band.card:
        path(band.group, band.line(.68), "none", stroke="#d49a7d", opacity=".66",
             stroke_width=1.25, stroke_dasharray="1 1.9")


def _draw_veil_lining(parent, look, fit):
    head = make_head(look)
    left_forehead, *left = _outline_half(look, head, -1)
    right_forehead, *right = _outline_half(look, head, 1)

    def point(side, coordinates):
        x, y = coordinates
        return f"{number(160 + side * x)} {number(y)}"

    outer = 94 * fit.x_scale
    # The cloth beneath the fold meets the forehead at its actual contour.
    temple = 81 * fit.x_scale
    lining_top = min(head.top_y - 12, fit.brim_y - 17)
    left_corner = point(-1, (temple, left_forehead[-1][1]))
    right_corner = point(1, (temple, right_forehead[-1][1]))
    top = point(1, (0, lining_top))
    path(parent, f"M{left_corner} L{point(-1, left_forehead[-1])} "
         f"C{point(-1, left_forehead[1])} {point(-1, left_forehead[0])} {point(1, (0, head.top_y))} "
         f"C{' '.join(point(1, coordinates) for coordinates in right_forehead)} L{right_corner} "
         f"Q{point(1, (temple, lining_top))} {top} Q{point(-1, (temple, lining_top))} {left_corner} Z",
         "#69404a", id="headgear-veil-upper-lining")

    # Follow the lower face to keep the backdrop out of the folds on narrow jaws.
    commands = [f"M {point(-1, (outer, left[0][-1][1]))} L {point(-1, left[0][-1])}"]
    for curve in left[1:]:
        commands.append("C " + " ".join(point(-1, coordinates) for coordinates in curve))
    for previous, (first, second, _) in reversed(list(zip(right, right[1:]))):
        commands.append("C " + " ".join(point(1, coordinates) for coordinates in (second, first, previous[-1])))
    commands.append(f"L {point(1, (outer, right[0][-1][1]))} "
                    f"L {point(1, (60 * fit.x_scale, fit.chin_y + 22))} "
                    f"L {point(-1, (60 * fit.x_scale, fit.chin_y + 22))} Z")
    path(parent, " ".join(commands), "#69404a")


def draw_shoulder_veil(parent, look, fit):
    _draw_veil_lining(parent, look, fit)
    neck = fit.chin(parent)
    path(neck, "M81 216 C110 223 118 243 135 247 Q158 254 181 247 C195 244 210 232 232 217 "
         "L251 291 Q237 308 222 316 Q179 325 158 320 Q124 315 108 322 L70 295 Z",
         "#713e46", class_="edge")
    path(neck, "M94 236 C125 252 138 256 159 255 Q189 256 229 233 Q193 269 166 277 "
         "Q136 275 94 250 Z", "#8d4f54")
    path(neck, "M105 265 Q152 294 227 252 Q216 300 160 306 Q120 296 93 289 Z", "#562f39")
    path(neck, "M112 273 Q146 292 168 281 M132 303 Q157 313 181 309 M163 267 Q188 262 210 247",
         class_="seam")

    sides = fit.sides(parent)
    path(sides, "M68 108 L90 110 C89 131 87 150 88 170 Q89 198 108 221 "
         "C120 249 111 277 147 308 Q132 307 119 316 Q98 328 85 318 Q60 314 42 326 "
         "C50 293 59 278 61 249 Q70 206 62 171 C56 143 59 122 68 108 Z", "#79434c", class_="edge")
    path(sides, "M68 116 Q65 152 70 176 C77 212 67 247 63 272 Q57 297 50 316 "
         "Q65 307 79 308 Q83 282 88 265 C95 232 76 205 77 179 Q72 142 79 116 Z", "#a05b5f")
    path(sides, "M84 119 Q79 155 83 181 Q84 205 98 222 Q108 236 105 258 "
         "Q104 289 127 309 L142 308 Q119 285 119 255 Q118 237 106 221 Q92 199 89 174 Z", "#54313c")
    path(sides, "M92 222 Q103 239 98 272 Q95 289 117 313 L107 317 Q86 305 89 279 Q96 250 92 222 Z",
         "url(#ink-lines)", opacity=".64")
    path(sides, "M72 142 Q70 163 74 179 M71 224 Q75 245 64 275 Q57 300 55 312 "
         "M93 231 Q100 245 95 268 Q90 285 97 302 M94 309 Q101 313 112 313", class_="seam")

    path(sides, "M230 110 L252 108 C264 130 261 153 256 180 C253 205 260 231 266 253 "
         "Q273 291 284 322 Q263 318 236 327 Q221 332 209 321 Q197 309 183 310 "
         "C202 285 202 250 216 218 Q231 194 233 171 Q234 141 230 110 Z", "#673945", class_="edge")
    path(sides, "M232 119 Q237 154 235 176 C233 205 225 223 216 248 Q210 273 196 305 "
         "Q209 309 213 315 Q230 295 235 262 C241 236 235 216 243 190 Q250 157 246 120 Z", "#8d5057")
    path(sides, "M251 129 Q258 146 252 181 Q248 214 262 256 Q270 289 279 317 "
         "Q265 315 250 321 C247 295 238 286 240 255 C244 219 239 215 245 186 Q250 163 251 129 Z",
         "#492e38")
    path(sides, "M249 219 Q248 235 257 259 Q265 288 276 315 L258 318 Q254 289 248 271 Q242 244 249 219 Z",
         "url(#ink-lines)", opacity=".62")
    path(sides, "M247 144 Q250 166 243 186 M243 226 Q238 253 235 273 Q231 297 220 313 "
         "M251 247 Q258 263 262 281 M249 303 l6 14", class_="seam")

    crown = fit.crown(parent)
    path(crown, "M66 112 C68 77 103 43 145 40 C184 36 225 51 247 85 Q254 98 255 112 "
         "L231 116 Q211 102 189 100 Q152 94 122 104 Q103 113 89 117 Z", "#79434c", class_="edge")
    path(crown, "M70 109 C78 76 109 49 147 44 Q124 53 111 71 Q99 89 91 113 Z", "#a05b5f")
    path(crown, "M154 42 C197 41 240 64 253 111 L232 112 Q221 102 204 102 "
         "Q195 64 154 42 Z", "#572f3b")
    path(crown, "M190 46 Q235 61 250 109 L235 110 Q224 97 215 95 Q208 59 190 46 Z",
         "url(#ink-lines)", opacity=".54")
    path(crown, "M95 112 Q119 92 156 92 Q205 88 230 110", "none",
         stroke="#b2726c", stroke_width=3.1, stroke_linecap="round")
    path(crown, "M80 98 Q92 70 114 57 M218 67 Q231 80 236 93", class_="etch")


DRAWERS = {
    "fur_cap": draw_fur_cap,
    "felt_cap": draw_felt_cap,
    "temple_rings": draw_temple_rings,
    "rus_vyatichi_lobed_band": draw_vyatichi_lobed_band,
    "shoulder_veil": draw_shoulder_veil,
}
