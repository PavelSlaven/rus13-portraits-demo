"""Six Eurasian headwear forms drawn in the shared head fitting coordinates."""

from common import path


def _draw_linen_coif(parent, look, fit):
    crown = fit.crown(parent)
    path(crown, "M77 115 C79 83 110 58 159 57 C203 56 235 79 243 115 "
                "H230 Q160 107 90 115Z", "#ece2c6", class_="edge")
    path(crown, "M127 109 Q136 78 159 58 Q153 84 151 108Z", "#cabb9d")
    path(crown, "M164 58 Q190 77 195 109 M93 105 Q113 67 145 62", class_="seam", opacity=".62")

    sides = fit.sides(parent)
    path(sides, "M78 112 Q160 100 242 112 Q249 145 244 177 Q242 204 225 220 "
                "L214 208 Q227 187 230 165 Q233 136 228 116 Q159 110 92 116 "
                "Q88 139 91 166 Q93 190 107 207 L96 221 Q80 208 76 183 Q70 150 78 112Z",
         "#e9dec1", class_="edge")
    path(sides, "M81 123 Q75 162 85 191 Q90 207 98 211 L89 191 Q83 157 88 120Z "
                "M239 121 Q247 162 235 193 L224 211 Q241 174 237 123Z", "url(#ink-lines)", opacity=".55")
    path(sides, "M84 119 Q78 159 88 189 M236 120 Q242 158 232 192", class_="etch")

    ties = fit.chin(parent)
    path(ties, "M91 197 C94 224 116 245 157 249 L153 257 C112 253 92 230 85 204Z "
               "M229 197 C226 224 204 245 163 249 L167 257 C208 253 228 230 235 204Z",
         "#eadfc2", class_="edge")
    path(ties, "M155 252 Q144 252 138 262 L143 271 Q148 261 159 258 "
               "Q163 266 174 268 L178 263 Q168 258 165 253Z", "#d3c2a1", class_="edge")
    path(ties, "M151 251 Q159 245 167 251 L166 258 Q158 262 152 257Z", "#f3e9cf", class_="edge")


def draw_wimple_lining(parent, fit):
    lining = fit.chin(parent)
    path(lining, "M88 171Q98 210 102 228Q113 264 160 273"
         "Q209 264 218 228Q226 202 232 171Z", "#666b5c", id="wimple-inner-cloth")


def _draw_wimple(parent, look, fit):
    throat = fit.chin(parent)
    path(throat, "M80 166 Q88 195 106 221 Q124 245 160 247 Q196 245 214 221 "
                 "Q230 187 239 168 Q241 224 227 271 Q208 293 164 299 Q123 297 93 275 "
                 "Q79 239 80 166Z", "#b9bda7")
    path(throat, "M84 231 Q86 255 93 275 Q123 297 164 299 Q208 293 227 271 Q234 247 236 231",
         "none", class_="edge")
    path(throat, "M90 226 Q117 255 165 263 Q198 264 232 228 Q214 269 166 275 "
                 "Q114 267 90 242Z M99 261 Q137 285 183 282 Q170 289 147 290 Q121 285 99 269Z",
         "#8b9785")
    path(throat, "M93 230 Q120 256 159 259 Q199 260 227 232 M104 260 Q129 277 168 279 "
                 "Q196 279 223 260", class_="seam", opacity=".72")
    path(throat, "M113 273 Q144 291 169 287 M185 268 Q201 263 213 253", class_="etch")

    crown = fit.crown(parent)
    path(crown, "M69 115 C73 81 112 54 163 54 C207 55 242 81 251 115 "
                "H229 Q160 100 91 115Z", "#dfddbf", class_="edge")
    path(crown, "M74 109 Q113 68 164 62 Q212 63 243 110 Q205 76 163 77 "
                "Q110 80 83 111Z", "#eee8c9")
    path(crown, "M89 110 Q117 74 165 73 Q207 75 230 109", class_="seam", opacity=".62")

    veil = fit.sides(parent)
    path(veil, "M72 112 Q160 100 248 112 Q253 137 256 173 Q257 210 246 253 "
               "Q229 245 220 228 Q231 199 233 164 Q234 136 228 116 Q158 110 92 116 "
               "Q87 138 88 165 Q90 199 100 231 Q89 249 74 255 Q62 215 63 174 Q64 142 72 112Z",
         "#dfddbf", class_="edge")
    path(veil, "M75 122 Q66 192 82 238 Q77 185 83 120Z M242 123 Q255 189 241 238 "
               "Q245 182 236 120Z", "#a2a685")
    path(veil, "M74 148 Q67 195 81 239 M246 147 Q255 194 242 235", class_="seam", opacity=".62")
    path(veil, "M69 200 Q72 225 78 241 M251 199 Q250 220 244 242", class_="etch")


TURBAN_CROWN_TOP = 32


def _draw_wrapped_turban(parent, look, fit):
    cloth = fit.crown(parent, minimum_y=TURBAN_CROWN_TOP)
    path(cloth, "M85 114 Q70 104 75 86 Q67 77 77 65 Q88 44 113 42 "
                "Q136 27 159 36 Q181 27 202 40 Q234 42 246 62 Q255 77 248 86 "
                "Q252 104 239 113 Q163 117 85 114Z", "#eee7d3", class_="edge")
    path(cloth, "M80 82 Q107 64 136 60 Q164 55 206 43 Q172 61 145 71 "
                "Q113 82 79 92Z M87 101 Q138 86 168 72 Q210 54 241 59 "
                "Q210 63 180 80 Q148 97 115 108Z", "#b6ab96")
    path(cloth, "M82 73 Q102 57 142 51 L184 39 M78 87 Q117 76 153 63 Q185 52 201 42 "
                "M85 100 Q124 92 163 73 Q211 52 238 58", class_="seam", opacity=".75")
    path(cloth, "M91 96 Q124 89 150 77 M121 47 Q136 44 150 43 M215 67 Q229 64 236 65",
         class_="etch")
    path(cloth, "M83 98 Q113 105 151 100 Q200 91 240 73 Q251 82 244 93 "
                "Q218 109 188 112 Q124 118 87 114 Q79 108 83 98Z", "#eee8d7", class_="edge")
    path(cloth, "M92 109 Q144 114 180 105 Q221 97 240 84 M189 106 Q218 101 237 93",
         class_="etch", opacity=".82")


def _draw_bocca(parent, look, fit):
    crown = fit.crown(parent, minimum_y=18)
    path(crown, "M75 115 Q83 83 112 81 Q130 80 141 86 Q159 79 183 84 Q216 80 231 95 "
                "Q239 103 243 115 Q164 110 75 115Z", "#51423a", class_="edge")
    path(crown, "M88 105 Q111 88 137 94 Q157 85 186 92 Q211 86 230 104 "
                "Q185 95 170 100 Q118 94 88 105Z", "#82705b")

    path(crown, "M170 42 Q171 28 184 18 Q190 20 185 30 L178 44Z", "#7e5348", class_="edge")
    path(crown, "M132 94 L127 74 L116 49 L111 30 L193 30 L211 42 L201 54 L188 58 "
                "L181 92 Q158 99 132 94Z",
         "#a03e31", class_="edge")
    path(crown, "M178 45 L211 42 L201 54 L188 58 L181 92 L166 95 L170 69Z", "#662b29")
    path(crown, "M111 30 L193 30 L211 42 L127 45Z", "#c07b57", class_="edge")
    path(crown, "M124 49 L169 47 L157 83 L142 85Z", "#b2503a")
    path(crown, "M176 49 L199 47 L186 56 L179 92 L168 94Z", "url(#ink-lines)", opacity=".65")
    path(crown, "M130 50 Q141 65 145 91 M135 50 Q145 66 149 85 M181 58 L174 88",
         class_="etch", opacity=".8")

    hood = fit.sides(parent)
    path(hood, "M77 112 Q159 99 242 112 Q250 148 246 174 Q244 204 231 223 L216 214 "
               "Q227 190 230 167 Q233 139 228 116 Q160 110 92 116 Q88 140 91 166 "
               "Q93 192 104 213 L90 222 Q77 205 74 176 Q70 146 77 112Z",
         "#645347", class_="edge")
    path(hood, "M82 123 Q76 162 87 193 L94 208 Q87 168 89 126Z "
               "M239 123 Q247 162 233 196 L225 208 Q234 167 232 125Z", "url(#ink-lines)")
    path(hood, "M81 134 L84 130 M81 150 L85 146 M82 168 L86 162 M85 183 L89 179 "
               "M239 134 L236 130 M240 150 L236 146 M239 168 L235 162 M236 183 L232 179",
         "none", stroke="#9b8366", stroke_width=1.6, stroke_linecap="round")

    fastening = fit.chin(parent)
    path(fastening, "M87 202 C101 226 122 243 160 248 C198 243 219 226 233 202 L237 210 "
                     "C220 237 197 254 160 258 C123 254 100 237 83 210Z", "#824839", class_="edge")
    path(fastening, "M98 219 Q126 246 153 251 M167 251 Q194 246 222 219", class_="etch")
    path(fastening, "M154 249 Q160 244 167 249 L165 256 Q159 261 153 256Z", "#b77454", class_="edge")


def _draw_eboshi(parent, look, fit):
    crown = fit.crown(parent, minimum_y=18)
    path(crown, "M91 114 Q94 97 108 88 Q120 76 123 56 Q128 30 140 18 "
                "Q155 21 163 35 Q168 48 186 63 Q198 73 210 83 Q226 92 229 114Z",
         "#28272c", class_="edge")
    path(crown, "M115 91 Q130 67 133 45 Q136 32 141 24 Q152 29 156 44 "
                "Q145 53 144 67 L137 93Z", "#49454a")
    path(crown, "M170 56 Q188 74 204 84 L216 99 L180 102 Q179 79 170 56Z", "#1d1c22")
    path(crown, "M141 26 Q134 44 132 63 Q129 78 122 86 M151 36 Q148 54 149 68 "
                "M187 69 Q202 82 207 88", "none", stroke="#75696b", stroke_width=1.6,
         stroke_linecap="round")
    path(crown, "M94 101 Q159 94 225 100 L229 114 Q159 111 91 114Z", "#393139", class_="edge")
    path(crown, "M101 105 Q156 99 218 104", "none", stroke="#87797c", stroke_width=1.55,
         stroke_linecap="round")


def _draw_weimao(parent, look, fit):
    curtain = fit.sides(parent)
    path(curtain, "M35 105 Q56 105 83 109 Q77 168 80 206 Q82 237 102 273 "
                  "Q83 266 63 277 Q40 248 34 201 Q28 151 35 105Z "
                  "M285 105 Q264 105 237 109 Q243 168 240 206 Q238 237 218 273 "
                  "Q237 266 257 277 Q280 248 286 201 Q292 151 285 105Z",
         "#ddc7a3", fill_opacity=".61", stroke="#5f4941", stroke_width=2,
         stroke_linejoin="round")
    path(curtain, "M43 114 Q38 170 49 222 Q55 248 68 269 M54 115 Q47 168 60 225 "
                  "Q65 249 79 269 M70 116 Q65 168 71 214 Q76 247 88 268 "
                  "M277 114 Q282 170 271 222 Q265 248 252 269 M266 115 Q273 168 260 225 "
                  "Q255 249 241 269 M250 116 Q255 168 249 214 Q244 247 232 268",
         class_="etch", opacity=".56")

    hat = fit.crown(parent)
    path(hat, "M49 101 Q78 88 95 77 Q101 62 117 55 Q158 42 201 55 "
              "Q220 62 225 77 Q248 91 272 101 L285 113 "
              "Q232 116 160 114 Q86 117 35 113Z", "#ab774c", class_="edge")
    path(hat, "M98 76 Q124 55 160 55 Q195 55 222 76 Q158 69 98 76Z", "#cfab72")
    path(hat, "M55 101 Q78 88 96 79 Q158 70 224 79 Q244 90 266 102 "
              "Q210 91 160 92 Q105 92 55 101Z", "#c79a60")
    path(hat, "M98 77 Q158 68 223 77 M74 93 Q157 78 245 94", class_="seam")
    path(hat, "M50 104 Q156 87 271 104 L285 113 Q227 116 160 114 "
              "Q90 116 35 113Z", "#5e4839", class_="edge")
    path(hat, "M43 111 Q157 94 278 111", "none", stroke="#d4b180", stroke_width=2.05,
         stroke_linecap="round")


DRAWERS = {
    "linen_coif": _draw_linen_coif,
    "wimple": _draw_wimple,
    "wrapped_turban": _draw_wrapped_turban,
    "bocca": _draw_bocca,
    "eboshi": _draw_eboshi,
    "weimao": _draw_weimao,
}
