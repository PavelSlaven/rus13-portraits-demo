"""Selectable belt equipment and ornaments from the clothing list."""

from clothing_reference_types import ClothingReference


def _belt(item, *materials, **options):
    return ClothingReference("belt", item, materials, **options)


def _pouch(item, *materials, **options):
    return ClothingReference("belt_pouch", item, materials, equipment={"belt": "leather"}, **options)


def _jewel(item, *materials, **options):
    return ClothingReference("jewelry", item, materials, **options)


# A material used for the illustration can be selectable even when the source leaves it open.
REFERENCES: dict[int, tuple[ClothingReference, ...]] = {
    113: (_belt("leather", "leather"), _belt("gold_plaques", "leather", trim_materials=("gold",))),
    114: (_belt("woven", "wool"),),
    115: (_belt("child_braid", "wool", age="child"),),
    116: (_belt("plaque_set", "leather", trim_materials=("gold",)),),
    117: (
        _pouch("drawstring", "leather"),
        _pouch("pleated", "leather"),
        ClothingReference("accessory", "pouch", ("leather",)),
    ),
    118: (_pouch("novgorod_flap", "leather"),),
    119: (_pouch("cloth_drawstring", "plain_weave"),),
    120: (_pouch("small_bag", "linen"),),
    121: (_pouch("sheathed_belt_knife", "leather"),),
    122: (_pouch("knife_sheath", "leather"),),
    123: (_pouch("fire_kit_bag", "plain_weave", trim_materials=("flint",)),),
    137: (
        ClothingReference("accessory", "brooch", ("bronze",)),
        _jewel("ring_fibula", "bronze"),
    ),
    138: (_jewel("penannular_fibula", "bronze"),),
    139: (ClothingReference("accessory", "pendant", ("bronze",)),),
    140: (_jewel("amulet_cluster", "bronze"),),
    141: (_jewel("lunula", "silver", cast="women"),),
    142: (_jewel("noisy_horse", "bronze", cast="women"),),
    143: (_jewel("riasna", "silver", cast="women", equipment={"headgear": "rus_diamond_band"}),),
    144: (_jewel("quadrifoil", "gold", trim_materials=("enamel",)),),
    145: (_jewel("cross", "copper", "stone"),),
    146: (_jewel("encolpion", "copper", "bronze"),),
    147: (_jewel("stone_icon", "stone", "bone"),),
    148: (_jewel("zmeevik", "copper"),),
    149: (_jewel("glass_beads", "glass", "amber", "carnelian", cast="women"),),
    150: (_jewel("amber_drops", "amber", "carnelian", "crystal", "amethyst"),),
    151: (_jewel("ear_hoops", "silver", cast="women"),),
    152: (_jewel("shield_temple_ring", "silver", cast="women"),),
    153: (_jewel("hair_spiral", "bronze"),),
    154: (_jewel("bracelet", "bronze", "glass", cast="women", detail=True),),
    155: (_jewel("glass_bracelet", "glass", cast="women", detail=True),),
    156: (_jewel("plate_bracelet", "bronze", detail=True),),
    157: (_jewel("signet_ring", "silver", detail=True),),
    158: (_jewel("kolt", "gold", "silver", "tin_lead", cast="women", equipment={"headgear": "rus_diamond_band"}),),
    159: (_jewel("chained_pins", "bronze", cast="women"),),
    160: (_jewel("neck_torc", "bronze"),),
    161: (_jewel("bone_collar_button", "bone"), _jewel("bronze_collar_button", "bronze")),
    162: (_jewel("pilgrim_badge", "tin_lead"),),
    289: (_belt("leather", "leather"),),
    290: (_belt("saaremaa", "leather"),),
    291: (_belt("woven", "wool"),),
    292: (_pouch("drawstring", "leather"),),
    293: (_pouch("pleated", "leather"),),
    294: (
        ClothingReference("accessory", "brooch", ("silver",)),
        _jewel("ring_fibula", "silver"),
    ),
    295: (
        ClothingReference("accessory", "pendant", ("silver",)),
        _jewel("leaf_pendant", "silver"),
    ),
    296: (ClothingReference("accessory", "pouch", ("leather",)),),
    297: (_jewel("cross", "bronze"),),
    298: (_jewel("glass_beads", "glass"),),
    299: (_jewel("noisy_horse", "bronze"),),
    300: (_jewel("quadrifoil", "gold", trim_materials=("enamel",)),),
}
