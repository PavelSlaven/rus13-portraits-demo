from common import node, number, path


def _song_jacket(art):
    body, cloth = art.body, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    side = 160 - body.chest
    tie = 160 - body.waist + 8

    path(art.front, f"M{side} 307 Q107 282 {left} 273 Q127 320 116 349 Q107 377 {tie} 404 "
         f"L{side - 15} 430Z", cloth.light, opacity=".72")
    path(art.front, f"M{right} 273 Q{150 + body.shoulder} 289 {162 + body.chest} 347 "
         f"L{185 + body.hem} 440 L186 438 Q201 370 {right} 273Z", cloth.shade)
    path(art.front, f"M{left} 273 Q160 304 {right} 273 Q183 313 159 337 Q130 313 {left} 273Z",
         "#d7c5a3")
    path(art.front, f"M{right} 273 Q184 316 151 338 Q{tie + 24} 363 {tie} 385 "
         f"L{tie - 2} 397 Q{tie + 37} 375 162 347 Q196 313 {number(167 + art.neck)} 277Z",
         cloth.deep, class_="edge")
    path(art.front, f"M{number(164 + art.neck)} 277 Q187 314 157 343 Q{tie + 29} 368 {tie + 4} 390",
         "none", stroke="#bdb28d", stroke_width="2.7", stroke_linecap="round")
    path(art.front, f"M{tie + 5} 386 Q{tie + 16} 381 {tie + 18} 387 Q{tie + 18} 393 {tie + 8} 390 "
         f"Q{tie + 16} 397 {tie + 14} 404 M{tie + 8} 390 Q{tie + 2} 396 {tie} 403",
         "none", stroke="#5b4c3d", stroke_width="2.3", stroke_linecap="round")
    path(art.front, "M58 414 Q158 423 259 409 L270 449 H47Z", "#766653", class_="edge")
    path(art.front, "M95 424 Q105 431 99 443 M118 426 Q126 433 122 445 "
         "M185 426 Q190 436 188 445 M219 423 Q217 433 223 445", class_="seam")
    path(art.front, f"M{side + 16} 329 q-9 11 -9 29 M204 327 q9 16 7 34 M194 385 q-1 13 -7 22",
         class_="seam", opacity=".78")
    outer = 160 - body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{outer - 5} 423 Q{outer + 22} 426 {176 - body.waist} 414 H131V448H{outer - 5}Z",
             "#c8b58d", class_="edge")
        path(sleeve, f"M{outer + 11} 386 q5 -11 13 -17", class_="seam")


def _school_robe(art):
    body, cloth = art.body, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    side = 160 - body.chest
    outer = 160 - body.sleeve

    path(art.front, f"M65 303 Q{side + 24} 282 {left} 273 Q115 310 123 367 Q128 414 117 448 H65Z",
         cloth.light, opacity=".68")
    path(art.front, f"M186 281 Q{148 + body.shoulder} 281 {165 + body.chest} 323 "
         "L273 448H200 Q210 404 199 358Z", cloth.shade)
    path(art.front, f"M{left} 273 Q160 307 {right} 273 L{number(164 + art.neck)} 281 "
         f"Q180 297 166 304 L166 327H154V304 Q138 296 {number(156 - art.neck)} 281Z",
         "#d8bc8f", class_="edge")
    path(art.front, "M159 303V321", "none", stroke="#92705c", stroke_width="1.7", stroke_linecap="round")
    path(art.front, f"M{side + 16} 322 Q{side + 24} 374 {side + 18} 428 M142 340 Q152 371 144 418 "
         "M179 337 Q174 358 183 384 M207 359 Q215 387 205 420",
         class_="seam", opacity=".76")
    for sleeve in art.sleeves:
        upper = 160 - body.shoulder
        path(sleeve, f"M{outer} 328 Q{upper - 1} 321 {upper + 16} 310 "
             f"L{upper + 20} 327 Q{upper + 3} 339 {outer} 345Z", "#a27d54", class_="edge")
        path(sleeve, f"M{outer} 332 Q{upper + 3} 326 {upper + 18} 317 "
             f"M{outer} 340 Q{upper + 5} 333 {upper + 20} 324",
             "none", stroke="#ddbc87", stroke_width="1.7")
        path(sleeve, f"M{outer + 10} 381 q5 -12 15 -19 m-9 37 10 20", class_="seam")


def _yuan_coat(art):
    body, cloth = art.body, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    shoulder = 160 - body.shoulder
    edge = 160 + body.waist - 6
    hem = 160 + body.hem - 4

    path(art.front, f"M{shoulder} 293 Q110 278 {left} 273 Q129 319 132 372 Q132 418 119 448 "
         f"H{shoulder - 15}Z", cloth.light, opacity=".66")
    path(art.front, f"M{right} 273 Q{154 + body.shoulder} 285 {165 + body.chest} 338 "
         f"L{hem} 448 H169 Q180 388 169 347Z", cloth.shade)
    path(art.front, f"M{left} 273 Q160 305 {right} 273 Q181 312 164 335 Q141 315 {left} 273Z",
         "#9c554d")
    path(art.front, f"M{left} 273 Q131 311 166 339 Q{edge - 8} 360 {edge} 380 "
         f"Q{edge - 6} 422 {hem} 445 H{hem - 12} Q{edge - 18} 425 {edge - 13} 382 "
         f"Q{edge - 25} 359 155 345 Q125 322 {number(153 - art.neck)} 278Z",
         "#514030", class_="edge")
    path(art.front, f"M{number(157 - art.neck)} 277 Q129 314 161 342 Q{edge - 18} 361 {edge - 7} 382 "
         f"Q{edge - 13} 423 {hem - 6} 443",
         "none", stroke="#e1b36f", stroke_width="4", stroke_linecap="round")
    for offset in (0, 16, 32):
        x = edge - 16 + offset * .07
        y = 382 + offset
        path(art.front, f"M{number(x - 11)} {y} h16", "none", stroke="#be874b",
             stroke_width="2", stroke_linecap="round")
        node(art.front, "circle", cx=x + 4, cy=y, r=2.0, fill="#edd192")
    for x, y in ((115, 350), (150, 377), (111, 403), (159, 427)):
        path(art.front, f"M{x} {y - 7} q2 5 7 7 q-5 2 -7 7 q-2 -5 -7 -7 q5 -2 7 -7Z",
             "#dab77b", opacity=".74")
        node(art.front, "circle", cx=x, cy=y, r=1.8, fill="#654d4b")
    path(art.front, f"M{shoulder + 19} 328 q5 -13 16 -22 M123 370 q-6 9 -6 17 "
         "M174 405 q4 14 1 28", class_="seam", opacity=".76")
    outer = 160 - body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{outer - 3} 423 Q{outer + 24} 429 {176 - body.waist} 415 L134 446H{outer - 3}Z",
             "#825c3c", class_="edge")
        path(sleeve, f"M{outer} 430 Q{outer + 26} 434 {174 - body.waist} 423 "
             f"M{outer + 3} 437 Q{outer + 25} 441 {176 - body.waist} 430",
             "none", stroke="#e1b36f", stroke_width="2")


DRAWERS = {
    "song_child_jacket": _song_jacket,
    "iraq_school_robe": _school_robe,
    "yuan_brocade_coat": _yuan_coat,
}
