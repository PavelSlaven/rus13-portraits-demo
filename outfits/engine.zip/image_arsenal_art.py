"""Предметные рисунки из INDEX: оружие и отдельные детали.

WEAPON_DRAWERS используют хват (0, 0). DETAIL_DRAWERS рисуют в 320×260.
Источник подтверждает только показанную форму; оговорки дат и аналогов в META.
"""

from functools import partial

from common import node, path
from wardrobe_weapon_art import INK, LEATHER, STEEL, STEEL_LIGHT, STEEL_SHADE, hatch, line, shape


WOOD = "#916c4c"
WOOD_LIGHT = "#c5a071"
BONE = "#c9b590"
BRONZE = "#a18452"


def _wood(parent, top, bottom, half=3.2):
    shape(parent, f"M{-half} {top}Q0 {top-3} {half} {top}L{half+1} {bottom}"
          f"Q0 {bottom+4} {-half} {bottom}Z", WOOD, 1.8, data_part="weapon-grip")
    line(parent, f"M{-half+1.4} {top+6}L-1 {bottom-7}", WOOD_LIGHT, 1.05)


def _metal(parent, contour, ridge=None, fill=STEEL):
    shape(parent, contour, fill, 2)
    if ridge:
        line(parent, ridge, STEEL_LIGHT, 1.25)


def draw_wooden_flail(parent):
    """Две деревянные части, соединённые короткой гибкой связкой."""
    _wood(parent, -246, 136)
    shape(parent, "M-7-247Q0-252 7-247L6-237Q0-233-6-237Z", LEATHER, 1.7)
    line(parent, "M0-245Q-14-271-29-247", INK, 5)
    line(parent, "M0-245Q-14-271-29-247", "#ad8861", 2.1)
    shape(parent, "M-35-249Q-30-254-24-249L-14-93Q-22-87-30-92Z", WOOD, 2.2)
    line(parent, "M-31-241L-24-101M-25-222l5 98", WOOD_LIGHT, 1.1)
    line(parent, "M-34-240l10-.7m-9 5 10-.7", "#674b37", 1.4)


def draw_broom(parent):
    _wood(parent, -250, 50, 2.8)
    outline = "M-8 39Q-22 66-30 128L-23 136-15 131-8 139 1 134 9 140 17 130 25 135Q22 78 9 39Z"
    shape(parent, outline, "#9b8157", 2)
    hatch(parent, "M7 43Q22 78 25 135L12 132Q10 86 2 45Z", .45)
    for x in range(-20, 23, 5):
        line(parent, f"M{x/4} 46Q{x*.7} 84 {x} {130+(x%3)*2}", "#5c4a31", .9)
    shape(parent, "M-10 40L10 40 13 57Q0 62-14 57Z", "#78533b", 1.5)
    line(parent, "M-10 44l20 1m-22 5 23 .5m-24 4 25 .5", "#d1aa75", 1)


def draw_cudgel(parent):
    shape(parent, "M-3-112Q0-115 4-112L5 96Q2 101-3 98L-5-24Z", WOOD, 2,
          data_part="weapon-grip")
    line(parent, "M-.8-107L.3 91M2-61l.4 35", WOOD_LIGHT, 1)


def draw_staff(parent):
    _wood(parent, -247, 152)
    shape(parent, "M-3-244Q-5-261-17-264Q-34-267-38-250Q-40-242-35-235"
          "Q-32-232-30-236Q-38-251-26-256Q-13-261-10-246L-5-227 3-229Z", WOOD, 2)
    line(parent, "M-1-245Q-7-263-23-262Q-35-260-36-249", WOOD_LIGHT, 1.05)


def draw_bronze_flail(parent):
    _wood(parent, -108, 40, 3.7)
    line(parent, "M0-109Q-29-92-30-52Q-33-12-25 33", INK, 4)
    line(parent, "M0-109Q-29-92-30-52Q-33-12-25 33", "#ae865c", 1.7)
    node(parent, "ellipse", cx=-25, cy=40, rx=6, ry=8, fill="none", stroke=INK, stroke_width=3.8)
    node(parent, "circle", cx=-25, cy=66, r=22, fill=BRONZE, stroke=INK, stroke_width=2.2)
    shape(parent, "M-31 47L-31 43-19 43-19 48Z", BRONZE, 1.3)
    path(parent, "M-14 48Q2 62-11 80Q-22 93-38 82Q-18 83-15 68Z", "#77603c")
    for x, y in ((-35, 55), (-24, 53), (-14, 58), (-39, 67), (-27, 65), (-14, 71), (-32, 78), (-22, 82)):
        node(parent, "circle", cx=x, cy=y, r=2.3, fill="#d3af70", stroke="#665134", stroke_width=.8)


def _leaf_spear(parent, *, broad=False, length=-282):
    _wood(parent, length+48, 145, 3.3)
    half = 15 if broad else 7
    shoulder = length-31 if broad else length-12
    tip = length-115 if broad else length-62
    contour = (f"M-4 {length+49}L-4 {length+12}Q{-half} {shoulder} 0 {tip}"
               f"Q{half} {shoulder} 4 {length+12}L5 {length+49}Z")
    _metal(parent, contour, f"M0 {tip+5}L0 {length+47}")
    path(parent, f"M0 {tip+5}Q{half-2} {shoulder} 3 {length+12}L4 {length+47}H0Z", STEEL_SHADE)
    line(parent, f"M-3 {length+41}l7 1", STEEL_LIGHT, .9)


def draw_sulitsa(parent):
    _leaf_spear(parent, length=-201)


def draw_rogatina(parent):
    _leaf_spear(parent, broad=True, length=-217)


def draw_lance(parent):
    _leaf_spear(parent, length=-340)


def draw_long_knife(parent):
    shape(parent, "M-4-24Q0-27 5-24L6 20Q1 24-5 21Z", BONE, 2,
          data_part="weapon-grip")
    for y in (-15, 6):
        node(parent, "circle", cx=0, cy=y, r=1.5, fill="#665a44")
    contour = "M-5 20L6 20L8 123Q7 149-4 167Q-3 132-5 114Z"
    _metal(parent, contour, "M5 28L6 122Q5 144-2 159")
    path(parent, "M-4 24L0 24 1 125-3 158Q-2 129-4 113Z", STEEL_SHADE)


def draw_knife(parent):
    drawing = node(parent, "g", transform="scale(.8 .65)")
    draw_long_knife(drawing)


def draw_bolt(parent):
    _wood(parent, -87, 77, 2.4)
    _metal(parent, "M-4-66L-5-89-7-102 0-126 7-102 5-89 4-66Z", "M0-120V-70")
    for sign in (-1, 1):
        shape(parent, f"M{sign*2} 43L{sign*11} 55L{sign*10} 78L{sign*2} 70Z", "#b8a688", 1.2)
    line(parent, "M-2 75h5", "#5e4430", 1)


def draw_horn(parent):
    contour = "M-14-34Q7-7 28 6Q58 25 103 20L108 66Q56 78 16 49Q-9 31-22-28Z"
    shape(parent, contour, "#c8ad79", 2.2, data_part="weapon-grip")
    path(parent, "M-19-26Q-4 33 21 48Q58 73 105 63L104 52Q52 63 20 35Q-3 14-19-26Z", "#9d7c4e")
    line(parent, "M-11-26Q13 15 39 26Q63 36 99 32", "#e2c796", 1.7)
    for x, y, angle in ((9, 20, -35), (72, 42, -2)):
        band = node(parent, "g", transform=f"translate({x} {y}) rotate({angle})")
        shape(band, "M-4-16L5-17 7 23-4 23Z", "#887347", 1.4)
        line(band, "M-1-14L1 21", "#d8bb76", 1)
        node(band, "circle", cx=1, cy=-19, r=3, fill="none", stroke=INK, stroke_width=1.5)
    line(parent, "M13 3Q34-11 72 22", "#6a5136", 2.2)
    for x, y in ((35, 32), (51, 41), (88, 44)):
        line(parent, f"M{x-5} {y}q4-9 9-2q3 7-5 8q-7-1-2-5", "#786039", 1.1)
    shape(parent, "M100 20Q109 17 111 42Q113 61 108 66L104 65Q109 47 100 20Z", "#7d603b", 1.7)


WEAPONS = {
    "2h_flail_wood": "Деревянный цеп", "broom": "Метла с пучком прутьев",
    "cudgel": "Дубинка", "wp_flail": "Бронзовый шаровой кистень",
    "wp_sulitsa": "Листовидная сулица", "wp_rogatina": "Рогатина с широким пером",
    "wp_lance": "Длинное конное копьё", "wp_staff": "Пастуший посох",
    "wp_long_knife": "Длинный однолезвийный нож", "wp_crossbow_bolt": "Самострельный болт",
    "wp_signal_horn": "Резной сигнальный олифант",
}
WEAPON_DRAWERS = {
    "2h_flail_wood": draw_wooden_flail, "broom": draw_broom, "cudgel": draw_cudgel,
    "wp_flail": draw_bronze_flail, "wp_sulitsa": draw_sulitsa, "wp_rogatina": draw_rogatina,
    "wp_lance": draw_lance, "wp_staff": draw_staff, "wp_long_knife": draw_long_knife,
    "wp_crossbow_bolt": draw_bolt, "wp_signal_horn": draw_horn,
}
# Все новые предметы по умолчанию закрепляются за спиной; свободные руки рисует генератор.
BACK_WEAPONS = {
    "2h_flail_wood": (-62, 400, .17, 1.08), "broom": (-65, 400, .16, 1.10),
    "cudgel": (-65, 365, .16, 1.08), "wp_flail": (-70, 360, .10, 1),
    "wp_sulitsa": (-49, 398, .17, 1.10), "wp_rogatina": (-49, 399, .17, 1.08),
    "wp_lance": (-42, 411, .16, .95), "wp_staff": (-49, 400, .17, 1.08),
    "wp_long_knife": (-71, 357, .12, 1), "wp_crossbow_bolt": (-62, 352, .10, 1),
    "wp_signal_horn": (-70, 337, .03, 1),
}


def _on_card(drawer, parent, transform):
    drawer(node(parent, "g", transform=transform))


def _arrowhead(parent, kind):
    """Формы снимков INDEX, включая их ограничения и повреждения."""
    g = node(parent, "g", transform="translate(160 25)")
    if kind == "blunt":
        shape(g, "M-22 156Q-29 129-33 99Q-35 57-25 37Q-9 14 15 25Q34 39 32 77"
              "Q31 117 21 153Q0 166-22 156Z", "#b09870", 2.5)
        node(g, "ellipse", cx=1, cy=143, rx=13, ry=8, fill="#423b2c", stroke=INK, stroke_width=1.8)
        line(g, "M-28 81Q0 94 31 80M-27 88Q0 103 29 89", "#796044", 1.7)
        for x in (-20, -9, 3, 15, 25):
            node(g, "circle", cx=x, cy=77+(25-abs(x))*.15, r=2.2, fill="none", stroke="#755f44", stroke_width=1.2)
    elif kind == "bone":
        shape(g, "M-7 193Q-10 168-19 141Q-26 125-21 116L-27 108Q-20 99-19 84"
              "Q-11 40 0 9Q15 46 22 99Q26 122 14 147Q7 167 5 193Z", BONE, 2.3)
        path(g, "M0 12Q15 50 20 99Q25 122 13 146L4 190H0Q6 147 7 110Z", "#a58f6e")
        line(g, "M-4 29Q-15 72-15 96m-2 28 8 23m3 7 1 18", "#e8d5b0", 1.4)
    else:
        contours = {
            "barbed": "M-4 198L-10 174-6 132-3 101-19 108-18 84-10 67-9 38-1 8 7 11 16 72 18 103 8 100 6 144 10 191Z",
            "broad_hunting": "M-3 204L-5 160-13 147-18 62-23 34-20 16 21 17 21 34 16 65 11 145 4 160 3 204Z",
            "leaf": "M-3 205L-6 168-17 149-29 112-27 88-18 65-13 36-6 24 0 7 8 31 11 56 21 79 26 110 12 152 5 170 3 205Z",
            "rhomboid": "M-3 205L-5 143-10 137-11 124-18 114-27 45 0 10 27 46 17 113 9 124 9 137 4 143 3 205Z",
            "socketed_ap": "M-10 200L-7 158-11 132-15 113-13 89-6 44 0 9 5 42 12 90 14 114 9 136 6 159 10 200Z",
            "tanged_ap": "M-3 205L-5 144-10 137-10 101-16 86-13 63 0 9 15 63 16 85 9 100 9 137 4 143 3 205Z",
        }
        contour = contours[kind]
        _metal(g, contour, "M0 16L0 197")
        if kind in {"socketed_ap", "barbed"}:
            line(g, "M-7 196Q0 190 8 196M-3 169L-5 190", "#4e534a", 1.5)
        if kind == "rhomboid":
            line(g, "M-25 46L0 55 25 46M0 55V117", "#52594e", 1.3)


def draw_arrow(parent):
    g = node(parent, "g", transform="translate(160 132) rotate(72) scale(.49)")
    _wood(g, -188, 193, 2.2)
    _metal(g, "M-4-178L-7-197 0-224 7-197 4-178Z", "M0-219V-180")
    for sign in (-1, 1):
        shape(g, f"M{sign*2} 126L{sign*16} 142L{sign*15} 182L{sign*2} 172Z", "#bfa98a", 1.6)
        line(g, f"M{sign*4} 137L{sign*13} 148m{-sign*9} 0 {sign*9} 9m{-sign*9} 0 {sign*9} 10", "#e2d2ad", .9)
    line(g, "M-2 189h4", INK, 1.1)


def draw_shaft(parent):
    g = node(parent, "g", transform="translate(160 130) rotate(73) scale(.52)")
    _wood(g, -230, 230, 4)
    node(g, "ellipse", cx=0, cy=230, rx=4, ry=2, fill="#624a34", stroke=INK, stroke_width=1)


def draw_spear_butt(parent):
    g = node(parent, "g", transform="translate(160 31)")
    shape(g, "M-11 2Q0-4 11 2L9 59-9 59Z", WOOD, 2)
    line(g, "M-7 9L-5 49", WOOD_LIGHT, 1.3)
    _metal(g, "M-14 50L14 50 10 105 4 180 0 205-4 181-11 106Z", "M-8 56L-5 104-1 185")
    line(g, "M-12 59Q0 65 12 59M4 62L2 101", "#4c5349", 1.25)


def draw_bowstring(parent):
    for color, width in ((INK, 3.8), ("#bd9a70", 1.7)):
        line(parent, "M79 62Q32 117 96 178C142 229 248 196 247 127Q246 71 184 57"
             "Q133 42 105 72Q74 102 106 143Q137 182 189 157Q223 139 209 105Q201 88 181 87", color, width)
        line(parent, "M79 62Q85 43 98 50Q112 62 97 71Q81 80 79 62M181 87Q163 80 157 91Q152 107 170 110Q188 107 181 87", color, width)


def _ring(parent, x, y, radius=9, *, riveted=True):
    node(parent, "circle", cx=x, cy=y, r=radius, fill="none", stroke=INK, stroke_width=4.4)
    node(parent, "circle", cx=x, cy=y, r=radius, fill="none", stroke=STEEL, stroke_width=2.5)
    line(parent, f"M{x-radius*.72} {y-radius*.55}q3-4 7-3", STEEL_LIGHT, .8)
    if riveted:
        node(parent, "circle", cx=x+radius*.7, cy=y+radius*.7, r=1.7, fill="#d5ccb0", stroke=INK, stroke_width=.6)


def draw_rings(parent):
    for row in range(5):
        for col in range(8):
            _ring(parent, 57+col*26+(row%2)*12, 58+row*27, 13, riveted=(row+col)%2==0)
    _ring(parent, 105, 221, 16)
    _ring(parent, 172, 221, 16, riveted=False)
    _metal(parent, "M225 213h29v5h-10v16h-8v-16h-11Z", "M229 214h20")


def draw_repair(parent):
    for row in range(4):
        for col in range(6):
            _ring(parent, 61+col*22+(row%2)*10, 48+row*23, 11)
    for x, y in ((224, 70), (246, 95), (219, 121)):
        _ring(parent, x, y, 14)
    for x in (63, 89, 116):
        _metal(parent, f"M{x} 183h12v5h-4v26h-4v-26h-4Z")
    shape(parent, "M169 174Q207 156 256 168L256 184Q208 172 170 190Z", LEATHER, 2)
    line(parent, "M177 182Q210 168 248 176", "#c69a6f", 1.1)
    for x in (200, 212, 224, 236):
        node(parent, "circle", cx=x, cy=177, r=1.3, fill=INK)


def draw_finial(parent):
    shape(parent, "M112 85Q160 65 208 85L201 173Q160 194 119 174Z", STEEL, 2.7)
    path(parent, "M176 84Q194 79 207 86L201 174Q186 183 172 182Z", STEEL_SHADE)
    node(parent, "ellipse", cx=160, cy=84, rx=48, ry=15, fill="#454b43", stroke=INK, stroke_width=2.7)
    node(parent, "ellipse", cx=160, cy=84, rx=37, ry=9, fill="#282b27", stroke=STEEL_LIGHT, stroke_width=2)
    line(parent, "M127 104L130 165M123 174Q159 191 198 174", STEEL_LIGHT, 1.7)


def draw_horse_mask(parent):
    """Только лицевая маска из Ромашек, без придуманного полного конского доспеха."""
    contour = ("M120 28Q160 14 200 29L208 46Q232 44 237 74L228 123 211 158"
               "L194 207Q185 239 160 239Q134 239 126 207L111 160 93 127 84 76"
               "Q89 45 113 46Z M111 76Q92 91 106 127Q120 117 120 96Z"
               "M208 75Q226 91 213 126Q200 116 199 96Z")
    shape(parent, contour, "#777b6e", 2.7, fill_rule="evenodd")
    path(parent, "M160 25Q186 23 198 31L202 65 189 116 180 206Q174 233 160 237Z", "#555d53")
    line(parent, "M122 47Q160 34 201 48M129 55Q119 112 137 186Q144 214 148 226"
         "M160 56L159 224M202 138L189 183", "#b3b19b", 1.4)
    for x, y in ((119, 52), (160, 45), (201, 53), (107, 141), (211, 142)):
        node(parent, "circle", cx=x, cy=y, r=2.6, fill="#c4b696", stroke=INK, stroke_width=.9)


def draw_stone(parent):
    contour = "M71 84Q80 37 133 31Q190 18 229 62Q265 101 251 160Q241 215 182 230Q125 247 83 207Q50 174 57 124Z"
    shape(parent, contour, "#aaa995", 2.5)
    path(parent, "M181 30Q229 45 247 94Q267 142 241 187Q219 227 176 231Q220 196 215 143Q213 76 181 30Z", "#7d8274")
    line(parent, "M79 106Q83 67 117 54M87 183l12 14M118 222l19 6M151 47l17-3", "#d7d0b6", 2.4)
    for x, y, radius in ((99, 91, 3), (142, 73, 2), (190, 115, 4), (119, 165, 3), (178, 190, 2), (218, 147, 2), (81, 139, 2)):
        node(parent, "circle", cx=x, cy=y, r=radius, fill="#747b6e", opacity=.75)


def draw_shield_boss(parent):
    from wardrobe_northwest_shields import _boss
    _boss(node(parent, "g", transform="translate(160 130) scale(3.3)"), x=0, y=0, size=1)


def draw_shield_parts(parent):
    boards = node(parent, "g", transform="translate(110 124)")
    node(boards, "circle", r=83, fill="#a38760", stroke=INK, stroke_width=3)
    # Линии досок ограничены окружностью; ремни и рукоять вынесены рядом.
    for x in (-52, -26, 0, 26, 52):
        from math import sqrt
        half = sqrt(79**2-x**2)
        line(boards, f"M{x} {-half}V{half}", "#6c533c", 1.8)
    node(boards, "circle", r=24, fill="#3d332b", stroke="#71533d", stroke_width=3)
    shape(parent, "M225 51Q242 39 260 53L262 65Q243 55 227 68Z", LEATHER, 2)
    shape(parent, "M222 94Q257 76 282 110L277 120Q253 91 228 107Z", LEATHER, 2)
    line(parent, "M231 132C283 128 284 218 241 224Q215 223 226 194", INK, 6)
    line(parent, "M231 132C283 128 284 218 241 224Q215 223 226 194", "#ad8057", 3)


def draw_hilt(parent):
    from wardrobe_northwest_arms import _sword_hilt
    _sword_hilt(node(parent, "g", transform="translate(160 143) scale(3.3)"))


def _existing(parent, *, module, symbol, transform):
    # Импорт только при рисовании: канонический реестр оружия может импортировать этот модуль.
    from importlib import import_module
    getattr(import_module(module), symbol)(node(parent, "g", transform=transform))


def draw_baldric(parent):
    shape(parent, "M62 42Q80 30 91 43L256 211Q261 224 245 228L76 62Z", LEATHER, 2.5)
    line(parent, "M78 43L249 217", "#c99c6a", 1.3)
    shape(parent, "M170 137l23-21 17 19-23 21Z M178 137l14-12 10 11-14 12Z",
          BRONZE, 1.6, fill_rule="evenodd")
    line(parent, "M187 127l10 12", INK, 1.2)


def draw_sword_belt(parent):
    from wardrobe_weapon_carry import _draw_scabbard, _NOVGOROD
    shape(parent, "M48 35Q160 12 271 35L271 51Q160 30 48 51Z", LEATHER, 2.2)
    line(parent, "M56 39Q159 21 263 39", "#c59a70", 1)
    _draw_scabbard(node(parent, "g", transform="translate(182 42) scale(.72)"),
                   "sheathed_sword", _NOVGOROD, along_bow_case=False, child=False)


DETAIL_DRAWERS = {
    **{f"wp_ah_{kind}": partial(_arrowhead, kind=kind) for kind in
       ("barbed", "blunt", "bone", "broad_hunting", "leaf", "rhomboid", "socketed_ap", "tanged_ap")},
    "wp_arrow": draw_arrow, "wp_spear_shaft": draw_shaft, "wp_spear_butt": draw_spear_butt,
    "wp_bowstring": draw_bowstring, "wp_mail_rings": draw_rings, "wp_armour_repair": draw_repair,
    "wp_helmet_finial": draw_finial, "wp_horse_armour": draw_horse_mask,
    "wp_siege_stone": draw_stone, "wp_shield_umbo": draw_shield_boss,
    "wp_shield_parts": draw_shield_parts, "wp_sword_hilt_parts": draw_hilt,
    "wp_baldric": draw_baldric, "wp_sword_belt": draw_sword_belt,
    "wp_knife": partial(_on_card, draw_knife, transform="translate(160 66) scale(1.5)"),
}
_CARD_TRANSFORMS = {
    "2h_flail_wood": "translate(172 162) scale(.55)", "broom": "translate(160 162) scale(.53)",
    "cudgel": "translate(160 137) scale(.95)", "wp_flail": "translate(175 143) scale(1.15)",
    "wp_sulitsa": "translate(160 153) scale(.51)", "wp_rogatina": "translate(160 167) scale(.43)",
    "wp_lance": "translate(160 183) scale(.39)", "wp_staff": "translate(174 166) scale(.48)",
    "wp_long_knife": "translate(160 60) scale(.98)", "wp_crossbow_bolt": "translate(160 150) scale(.95)",
    "wp_signal_horn": "translate(62 101) scale(1.65)",
}
DETAIL_DRAWERS.update({key: partial(_on_card, drawer, transform=_CARD_TRANSFORMS[key])
                       for key, drawer in WEAPON_DRAWERS.items()})
_EXISTING_DETAILS = {
    "wp_sword": ("wardrobe_northwest_arms", "_draw_sword", "translate(160 57) scale(.78)"),
    "wp_battle_axe": ("wardrobe_northwest_arms", "_draw_axe", "translate(145 83) scale(1.3)"),
    "wp_spear": ("wardrobe_northwest_arms", "_draw_spear", "translate(160 164) scale(.43)"),
    "club_wooden": ("wardrobe_eurasian_west", "_draw_bayeux_club", "translate(145 81) scale(1.7)"),
    "wp_club": ("wardrobe_eurasian_west", "_draw_bayeux_club", "translate(145 81) scale(1.7)"),
    "wp_crossbow": ("wardrobe_eurasian_west", "_draw_drosten_crossbow", "translate(157 100) scale(1.25)"),
    "wp_sling": ("wardrobe_eurasian_west", "_draw_taull_sling", "translate(170 42) scale(1.45)"),
    "wp_mace": ("wardrobe_eurasian_steppe", "_draw_zaryadye_mace", "translate(160 166) scale(1)"),
    "wp_sabre": ("wardrobe_eurasian_steppe", "_draw_yaroslavl_sabre", "translate(170 228) scale(.7)"),
    "wp_bow_composite": ("wardrobe_northwest_archery", "_draw_composite_bow", "translate(173 135) scale(.7)"),
    "wp_bow_self": ("wardrobe_northwest_archery", "_draw_northern_bow", "translate(174 130) scale(.58)"),
    "wp_shield_round": ("wardrobe_northwest_shields", "_draw_george", "translate(197 91) scale(1.45)"),
    "wp_shield_almond": ("wardrobe_northwest_arms", "_draw_kite", "translate(173 49) scale(.9)"),
    "wp_shield_triangular": ("wardrobe_northwest_arms", "_draw_triangular", "translate(176 52) scale(.98)"),
    "wp_shield_facing": ("wardrobe_northwest_arms", "_draw_kite", "translate(173 49) scale(.9)"),
}
DETAIL_DRAWERS.update({key: partial(_existing, module=module, symbol=symbol, transform=transform)
                       for key, (module, symbol, transform) in _EXISTING_DETAILS.items()})


META = {'wp_ah_barbed': {'label': 'наконечник стрелы двушипный (гарпунный)',
                  'selection': {'detail': 'wp_ah_barbed'},
                  'kind': 'detail',
                  'sources': [{'image': 'оружие/wp_ah_barbed/1.jpg',
                               'url': 'https://www.londonmuseum.org.uk/collections/v/object-36394/arrow-arrowhead/',
                               'date': 'XIII–XIV века',
                               'accuracy': 'аналог',
                               'limits': 'Лондон, XIII–XIV века; западноевропейская втульчатая головка с '
                                         'обломанными зазубринами не подтверждает русский черешковый '
                                         'гарпунный вариант.'}],
                  'limits': 'Сохранены обломанные шипы и втульчатое основание лондонского аналога; это не '
                            'подтверждённый русский черешковый вариант.',
                  'detail_id': 'wp_ah_barbed',
                  'prior_audit': 'Отдельного двушипного гарпунного наконечника стрелы нет. Колчан показывает '
                                 'только оперение и короткие участки древок, без металлических головок. При '
                                 'дорисовке сохранить оговорки INDEX о датировке и точности типа.',
                  'note': 'Лондон, XIII–XIV века; западноевропейская втульчатая головка с обломанными '
                          'зазубринами не подтверждает русский черешковый гарпунный вариант.'},
 'wp_ah_blunt': {'label': 'тупой наконечник стрелы (томар) костяной или деревянный',
                 'selection': {'detail': 'wp_ah_blunt'},
                 'kind': 'detail',
                 'sources': [{'image': 'оружие/wp_ah_blunt/1.png',
                              'url': 'https://archaeolog.ru/online-museum/onlayn-vystavka-svideteli-proshlogo-iskusstvo-i-remeslo-v-arkheologicheskikh-nakhodkakh/nakonechnik-strely-tomar',
                              'date': 'XV – начало XVI века',
                              'accuracy': 'находка',
                              'limits': 'XV – начало XVI века, Городок под Нижним Новгородом; предмет '
                                        'позднее целевого периода, хотя томары в Новгороде известны с X до '
                                        'начала XVI века.'}],
                 'detail_id': 'wp_ah_blunt',
                 'prior_audit': 'Отдельного тупого костяного томара наконечника стрелы нет. Колчан '
                                'показывает только оперение и короткие участки древок, без металлических '
                                'головок. При дорисовке сохранить оговорки INDEX о датировке и точности '
                                'типа.',
                 'note': 'XV – начало XVI века, Городок под Нижним Новгородом; предмет позднее целевого '
                         'периода, хотя томары в Новгороде известны с X до начала XVI века.'},
 'wp_ah_bone': {'label': 'костяной наконечник стрелы',
                'selection': {'detail': 'wp_ah_bone'},
                'kind': 'detail',
                'sources': [{'image': 'оружие/wp_ah_bone/1.jpg',
                             'url': 'https://asia-archive.si.edu/object/FSC-O-17/',
                             'date': 'не указан',
                             'accuracy': 'аналог',
                             'limits': 'Китай; датировка в доступной карточке не указана, изображено '
                                       'костяное острие с небольшим выступом, а не предмет новгородского '
                                       'происхождения.'}],
                'detail_id': 'wp_ah_bone',
                'prior_audit': 'Отдельного костяного острия наконечника стрелы нет. Колчан показывает только '
                               'оперение и короткие участки древок, без металлических головок. При дорисовке '
                               'сохранить оговорки INDEX о датировке и точности типа.',
                'note': 'Китай; датировка в доступной карточке не указана, изображено костяное острие с '
                        'небольшим выступом, а не предмет новгородского происхождения.'},
 'wp_ah_broad_hunting': {'label': 'наконечник стрелы широколезвийный охотничий, срезень',
                         'selection': {'detail': 'wp_ah_broad_hunting'},
                         'kind': 'detail',
                         'sources': [{'image': 'оружие/wp_ah_broad_hunting/1.jpg',
                                      'url': 'https://cris.uniyar.ac.ru/items/f3689a16-9625-49fb-9d3a-7ad3c3bcaff8',
                                      'date': 'XIII–XIV века',
                                      'accuracy': 'аналог',
                                      'limits': 'XIII–XIV века, селище Яковлевское-3 в Ярославской области; '
                                                'на фото узкий вытянутый срезень, а не широкий профиль из '
                                                'названия вещи.'}],
                         'detail_id': 'wp_ah_broad_hunting',
                         'prior_audit': 'Отдельного плоского срезня наконечника стрелы нет. Колчан '
                                        'показывает только оперение и короткие участки древок, без '
                                        'металлических головок. При дорисовке сохранить оговорки INDEX о '
                                        'датировке и точности типа.',
                         'note': 'XIII–XIV века, селище Яковлевское-3 в Ярославской области; на фото узкий '
                                 'вытянутый срезень, а не широкий профиль из названия вещи.'},
 'wp_ah_leaf': {'label': 'наконечник стрелы листовидный',
                'selection': {'detail': 'wp_ah_leaf'},
                'kind': 'detail',
                'sources': [{'image': 'оружие/wp_ah_leaf/1.jpg',
                             'url': 'https://archaeolog.ru/press/exhibitions/gorodische-gorodok-zagadka-nizhnego-novgoroda-xv-veka',
                             'date': 'XV век',
                             'accuracy': 'аналог',
                             'limits': 'XV век, городище Городок в Нижнем Новгороде; снимок показывает набор '
                                       'разных форм и относится к более позднему времени.'}],
                'detail_id': 'wp_ah_leaf',
                'prior_audit': 'Отдельного листовидного наконечника стрелы нет. Колчан показывает только '
                               'оперение и короткие участки древок, без металлических головок. При дорисовке '
                               'сохранить оговорки INDEX о датировке и точности типа.',
                'note': 'XV век, городище Городок в Нижнем Новгороде; снимок показывает набор разных форм и '
                        'относится к более позднему времени.'},
 'wp_ah_rhomboid': {'label': 'наконечник стрелы черешковый ромбический',
                    'selection': {'detail': 'wp_ah_rhomboid'},
                    'kind': 'detail',
                    'sources': [{'image': 'оружие/wp_ah_rhomboid/1.jpg',
                                 'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/258044',
                                 'date': 'X–XII века',
                                 'accuracy': 'находка',
                                 'limits': 'X–XII века, Рюриково городище; находка старше игрового периода, '
                                           'но форма черешкового ромбовидного пера совпадает.'}],
                    'detail_id': 'wp_ah_rhomboid',
                    'prior_audit': 'Отдельного черешкового ромбического наконечника стрелы нет. Колчан '
                                   'показывает только оперение и короткие участки древок, без металлических '
                                   'головок. При дорисовке сохранить оговорки INDEX о датировке и точности '
                                   'типа.',
                    'note': 'X–XII века, Рюриково городище; находка старше игрового периода, но форма '
                            'черешкового ромбовидного пера совпадает.'},
 'wp_ah_socketed_ap': {'label': 'наконечник стрелы втульчатый бронебойный',
                       'selection': {'detail': 'wp_ah_socketed_ap'},
                       'kind': 'detail',
                       'sources': [{'image': 'оружие/wp_ah_socketed_ap/1.jpg',
                                    'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/273948',
                                    'date': 'XIII в.',
                                    'accuracy': 'аналог',
                                    'limits': 'Новгород, XIII в.; музейный предмет втульчатый, но '
                                              'бронебойность и гранёная форма источником не установлены.'}],
                       'detail_id': 'wp_ah_socketed_ap',
                       'prior_audit': 'Отдельного втульчатого узкого наконечника стрелы нет. Колчан '
                                      'показывает только оперение и короткие участки древок, без '
                                      'металлических головок. При дорисовке сохранить оговорки INDEX о '
                                      'датировке и точности типа.',
                       'note': 'Новгород, XIII в.; музейный предмет втульчатый, но бронебойность и гранёная '
                               'форма источником не установлены.'},
 'wp_ah_tanged_ap': {'label': 'наконечник стрелы черешковый узкий бронебойный (гранёный)',
                     'selection': {'detail': 'wp_ah_tanged_ap'},
                     'kind': 'detail',
                     'sources': [{'image': 'оружие/wp_ah_tanged_ap/1.jpg',
                                  'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/511742',
                                  'date': 'X–XII вв.',
                                  'accuracy': 'аналог',
                                  'limits': 'Рюриково городище, X–XII вв.; находка ранняя, а точное '
                                            'соответствие узкому гранёному типу 1230 года не установлено.'}],
                     'detail_id': 'wp_ah_tanged_ap',
                     'prior_audit': 'Отдельного черешкового бронебойного наконечника стрелы нет. Колчан '
                                    'показывает только оперение и короткие участки древок, без металлических '
                                    'головок. При дорисовке сохранить оговорки INDEX о датировке и точности '
                                    'типа.',
                     'note': 'Рюриково городище, X–XII вв.; находка ранняя, а точное соответствие узкому '
                             'гранёному типу 1230 года не установлено.'},
 'wp_arrow': {'label': 'стрела',
              'selection': {'quiver': 'birchbark'},
              'kind': 'detail',
              'sources': [{'image': 'оружие/wp_arrow/1.jpg',
                           'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/587529',
                           'date': 'XII в., середина – первая треть XIII в.',
                           'accuracy': 'аналог',
                           'limits': 'Новгород, XII в. — первая треть XIII в.; сохранилась деревянная часть, '
                                     'а перья и железный или костяной наконечник в карточке не указаны.'}],
              'detail_id': 'wp_arrow',
              'prior_audit': 'Видны три оперённых хвоста и короткие участки древок в устье колчана. Полной '
                             'извлечённой стрелы, её острия и правильной общей длины нет; нужен '
                             'самостоятельный рисунок.',
              'note': 'Новгород, XII в. — первая треть XIII в.; сохранилась деревянная часть, а перья и '
                      'железный или костяной наконечник в карточке не указаны.'},
 'wp_spear_shaft': {'label': 'копейное древко',
                    'selection': {'weapon': 'spear'},
                    'kind': 'detail',
                    'sources': [{'image': 'оружие/wp_spear_shaft/1.jpg',
                                 'url': 'https://www.icon-art.info/masterpiece.php?mst_id=432; '
                                        'https://commons.wikimedia.org/wiki/File:Novgorod_George.jpg',
                                 'date': 'XII век (ок. 1130)',
                                 'accuracy': 'изображение эпохи',
                                 'limits': 'Новгородская икона, ок. 1130; древко показано частью копья, а не '
                                           'отдельной вещью.'}],
                    'detail_id': 'wp_spear_shaft',
                    'prior_audit': 'Длинное деревянное древко уже полностью нарисовано внутри копья; '
                                   'отдельного предмета без наконечника нет.',
                    'note': 'Новгородская икона, ок. 1130; древко показано частью копья, а не отдельной '
                            'вещью.'},
 'wp_spear_butt': {'label': 'подток копья',
                   'selection': {'detail': 'wp_spear_butt'},
                   'kind': 'detail',
                   'sources': [{'image': 'оружие/wp_spear_butt/1.jpg',
                                'url': 'https://collections.maa.cam.ac.uk/objects/595743/?page=17633',
                                'date': 'Средневековье; век не указан',
                                'accuracy': 'аналог',
                                'limits': 'Кембриджшир, Англия, средневековая дата не уточнена; конкретная '
                                          'форма не привязана к Новгороду.'}],
                   'detail_id': 'wp_spear_butt',
                   'prior_audit': 'В _draw_spear нижний конец деревянный, обозначен короткой тёмной линией; '
                                  'длинный железный втульчатый шип с фото не изображён.',
                   'note': 'Кембриджшир, Англия, средневековая дата не уточнена; конкретная форма не '
                           'привязана к Новгороду.'},
 'wp_bowstring': {'label': 'тетива',
                  'selection': {'bow': 'novgorod_composite'},
                  'kind': 'detail',
                  'sources': [{'image': 'оружие/wp_bowstring/1.jpg',
                               'url': 'https://commons.wikimedia.org/wiki/File:Composite_bow,_sword_-_11-12c_-_Novgorod_Kremlin_Museum.jpg',
                               'date': 'Современная реконструкция по материалам XII в.',
                               'accuracy': 'аналог',
                               'limits': 'Новгород, современная реконструкция по материалам XII в.; тетива '
                                         'показана на собранном луке, а не как отдельная археологическая '
                                         'находка.'}],
                  'detail_id': 'wp_bowstring',
                  'prior_audit': 'Тетива уже видна прямой тонкой линией между концами натянутого лука. '
                                 'Отдельной снятой или свёрнутой тетивы нет.',
                  'note': 'Новгород, современная реконструкция по материалам XII в.; тетива показана на '
                          'собранном луке, а не как отдельная археологическая находка.'},
 'wp_mail_rings': {'label': 'кольца кольчуги (клёпаные и цельносечёные)',
                   'selection': {'outfit': 'nw_mail_hauberk'},
                   'kind': 'detail',
                   'sources': [{'image': 'одежда/wp_mail_rings/1.jpg',
                                'url': 'https://combatarchaeology.org/artefact-of-the-month-the-mail-chausses-of-molledalen-buskerud/',
                                'date': 'Дата не установлена, возможно XV в.',
                                'accuracy': 'аналог',
                                'limits': 'Контекст и дата не установлены, Мёлледален, Норвегия; фрагмент '
                                          'чулка показывает кольчатое полотно, а не отдельные кольца из '
                                          'Новгорода.'}],
                   'detail_id': 'wp_mail_rings',
                   'prior_audit': 'Кольца видны повторяющимся узором mail-rings на рукавах и корпусе. '
                                  'Отдельных клёпаных и цельносечёных колец с читаемыми соединениями нет; '
                                  'текстура не заменяет крупную деталь.',
                   'note': 'Контекст и дата не установлены, Мёлледален, Норвегия; фрагмент чулка показывает '
                           'кольчатое полотно, а не отдельные кольца из Новгорода.'},
 'wp_armour_repair': {'label': 'ремонт доспеха: заплата кольчуги, связка колец и заклёпок, ремни обвязки',
                      'selection': {'detail': 'wp_armour_repair'},
                      'kind': 'detail',
                      'sources': [{'image': 'одежда/wp_armour_repair/1.png',
                                   'url': 'https://www.cambridge.org/core/journals/antiquity/article/recycling-and-repair-on-the-roman-frontier-a-hoard-of-mail-armour-from-bonn/2C901AE3F014C020B338E7D9EAA6CA20',
                                   'date': 'XV',
                                   'accuracy': 'аналог',
                                   'limits': 'XV в., Европа; изображён готовый ремонт кольчуги, а не '
                                             'переносимый набор колец, заклёпок и ремней Руси 1230 года.'}],
                      'detail_id': 'wp_armour_repair',
                      'prior_audit': 'Узоры колец на кольчуге уже есть, но переносимого набора колец, '
                                     'заклёпок и ремней либо отдельного ремонтного фрагмента нет. Источник '
                                     'показывает ремонт XV века, не набор Руси 1230 года.',
                      'note': 'XV в., Европа; изображён готовый ремонт кольчуги, а не переносимый набор '
                              'колец, заклёпок и ремней Руси 1230 года.'},
 'wp_helmet_finial': {'label': 'навершие-втулка шлема (для еловца)',
                      'selection': {'detail': 'wp_helmet_finial'},
                      'kind': 'detail',
                      'sources': [{'image': 'головной убор/wp_helmet_finial/1.jpg',
                                   'url': 'https://history.org.ua/LiberUA/978-966-1530-30-9/978-966-1530-30-9.pdf#page=59',
                                   'date': 'XII',
                                   'accuracy': 'реконструкция',
                                   'limits': 'Деталь показана установленной на полном шлеме, а не '
                                             'отдельно.'}],
                      'detail_id': 'wp_helmet_finial',
                      'prior_audit': 'Есть округлые и конические навершия готовых шлемов, но открытая '
                                     'цилиндрическая втулка для еловца с фото не нарисована. Нужна отдельная '
                                     'деталь.',
                      'note': 'Деталь показана установленной на полном шлеме, а не отдельно.'},
 'wp_horse_armour': {'label': 'Конская лицевая маска из Ромашек',
                     'selection': {'detail': 'wp_horse_armour'},
                     'kind': 'detail',
                     'sources': [{'image': 'одежда/wp_horse_armour/1.png',
                                  'url': 'https://publications.hse.ru/pubs/share/direct/345296514.pdf',
                                  'date': 'XIII (1200–1240)',
                                  'accuracy': 'находка',
                                  'limits': 'Изображена только лицевая маска головы; источник не '
                                            'подтверждает полный конский доспех или покрытие всего коня.'}],
                     'research_only': True,
                     'limits': 'Показана только лицевая маска; полного доспеха коня нет.',
                     'detail_id': 'wp_horse_armour',
                     'prior_audit': 'Конь и конская защита не нарисованы. Фактический источник показывает '
                                    'только железную лицевую маску лошади; нужно рисовать её, а не '
                                    'выдумывать полный бард.',
                     'note': 'Изображена только лицевая маска головы; источник не подтверждает полный '
                             'конский доспех или покрытие всего коня.'},
 'wp_siege_stone': {'label': 'каменное ядро метательной машины',
                    'selection': {'detail': 'wp_siege_stone'},
                    'kind': 'detail',
                    'sources': [{'image': 'оружие/wp_siege_stone/1.jpg',
                                 'url': 'https://www.metmuseum.org/art/collection/search/651123',
                                 'date': 'XIII век (ок. 1250)',
                                 'accuracy': 'аналог',
                                 'limits': 'Монфор, Иерусалимское королевство, ок. 1250; каменный снаряд '
                                           'осадной машины из другого региона.'}],
                    'detail_id': 'wp_siege_stone',
                    'prior_audit': 'Каменного снаряда метательной машины нет; нужен самостоятельный крупный '
                                   'округлый камень.',
                    'note': 'Монфор, Иерусалимское королевство, ок. 1250; каменный снаряд осадной машины из '
                            'другого региона.'},
 'wp_shield_umbo': {'label': 'умбон щита',
                    'selection': {'shield': 'novgorod_george'},
                    'kind': 'detail',
                    'sources': [{'image': 'оружие/wp_shield_umbo/1.png',
                                 'url': 'https://nav.shm.ru/exhibits/4435/',
                                 'date': 'X век',
                                 'accuracy': 'аналог',
                                 'limits': 'Русь, X век; курганные умбоны на несколько веков старше целевого '
                                           'периода.'}],
                    'detail_id': 'wp_shield_umbo',
                    'prior_audit': 'Полусферический металлический умбон с фланцем и заклёпками уже виден в '
                                   'центре круглого щита. Отдельной крупной выкладки нет.',
                    'note': 'Русь, X век; курганные умбоны на несколько веков старше целевого периода.'},
 'wp_shield_parts': {'label': 'части щита: дощатая основа, окантовка, рукоять и плечевой ремень',
                     'selection': {'shield': 'gokstad'},
                     'kind': 'detail',
                     'sources': [{'image': 'оружие/wp_shield_parts/1.jpg',
                                  'url': 'https://ica.themorgan.org/manuscript/page/53/158530',
                                  'date': 'XIII',
                                  'accuracy': 'аналог',
                                  'limits': 'Париж, Франция, 1244–1254 гг.; миниатюра показывает плечевой '
                                            'ремень, но не раскрывает деревянную основу, внутреннюю рукоять '
                                            'и окантовку'}],
                     'detail_id': 'wp_shield_parts',
                     'prior_audit': 'На обороте показаны стыки деревянных досок и обод; draw_shield создаёт '
                                    'рукоять data-part=shield-grip, wardrobe.draw_shield_sling — плечевой '
                                    'ремень. Единой разобранной предметной выкладки этих деталей нет.',
                     'note': 'Париж, Франция, 1244–1254 гг.; миниатюра показывает плечевой ремень, но не '
                             'раскрывает деревянную основу, внутреннюю рукоять и окантовку'},
 'wp_sword_hilt_parts': {'label': 'части рукояти меча (перекрестье, навершие, основа рукояти)',
                         'selection': {'weapon': 'sword'},
                         'kind': 'detail',
                         'sources': [{'image': 'оружие/wp_sword_hilt_parts/1.png',
                                      'url': 'https://swordmaster.org/2012/09/21/o-neizvestnoy-nakhodke-srednevekovogo-mecha-iz-novgoroda.html',
                                      'date': 'X–XII',
                                      'accuracy': 'находка',
                                      'limits': ''}],
                         'detail_id': 'wp_sword_hilt_parts',
                         'prior_audit': 'Рукоять, навершие и перекрестье уже нарисованы отдельной функцией, '
                                        'их можно переиспользовать в крупной выкладке. Перекрестье '
                                        'отличается от прямой крестовины конкретной находки INDEX.',
                         'note': ''},
 'wp_baldric': {'label': 'перевязь оружия через плечо',
                'selection': {'weapon': 'spear'},
                'kind': 'detail',
                'sources': [{'image': 'нет картинки',
                             'url': 'https://ica.themorgan.org/manuscript/page/20/158530',
                             'date': 'XIII век (ближайший просмотренный, не использован)',
                             'accuracy': '—',
                             'limits': 'Ближайшая проверенная миниатюра показывает мечи в ножнах у пояса, но '
                                       'лямка через плечо не различима; для неё не использована.'}],
                'detail_id': 'wp_baldric',
                'prior_audit': 'При carry=carried копьё за спиной удерживается диагональным кожаным плечевым '
                               'ремнём data-part=shoulder-strap. Отдельного слота перевязи нет; это ремень '
                               'переноски, а не доказанная мечeвая перевязь.',
                'note': 'Ближайшая проверенная миниатюра показывает мечи в ножнах у пояса, но лямка через '
                        'плечо не различима; для неё не использована.'},
 'wp_sword_belt': {'label': 'мечевой пояс с подвесом ножен',
                   'selection': {'weapon': 'sheathed_sword'},
                   'kind': 'detail',
                   'sources': [{'image': 'пояс и кошель/wp_sword_belt/1.jpg',
                                'url': 'https://ica.themorgan.org/manuscript/page/20/158530',
                                'date': 'XIII век (около 1244–1254)',
                                'accuracy': 'аналог',
                                'limits': 'Это западноевропейская сцена середины XIII века, а не '
                                          'новгородский образец; ремни и точный способ подвеса ножен на '
                                          'миниатюре не прорисованы.'}],
                   'detail_id': 'wp_sword_belt',
                   'prior_audit': 'Ножны подвешены двумя ремнями _draw_strap к поясу; само полотно пояса '
                                  'рисует wardrobe_northwest_accessories. Отдельного цельного мечевого пояса '
                                  'с фурнитурой нет.',
                   'note': 'Это западноевропейская сцена середины XIII века, а не новгородский образец; '
                           'ремни и точный способ подвеса ножен на миниатюре не прорисованы.'},
 'wp_knife': {'label': 'нож (боевой и хозяйственный)',
              'selection': {'belt_pouch': 'sheathed_belt_knife'},
              'kind': 'detail',
              'sources': [{'image': 'оружие/wp_knife/1.jpg',
                           'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/170387',
                           'date': 'XIII',
                           'accuracy': 'находка',
                           'limits': ''}],
              'detail_id': 'wp_knife',
              'prior_audit': 'Поясной нож в ножнах есть целиком в походном ношении: видна рукоять, клинок '
                             'скрыт. Для самостоятельного обнажённого ножа с костяной рукоятью из INDEX '
                             'нужна новая геометрия клинка.',
              'note': ''},
 '2h_flail_wood': {'label': 'Деревянный цеп',
                   'selection': {'weapon': '2h_flail_wood'},
                   'kind': 'weapon',
                   'sources': [{'image': 'оружие/2h_flail_wood/1.jpg',
                                'url': 'https://commons.wikimedia.org/wiki/File:Battage_%C3%A0_fl%C3%A9au_%28original%29.jpg',
                                'date': 'XIII (около 1270)',
                                'accuracy': 'аналог',
                                'limits': 'Париж, Франция, около 1270; изображён сельскохозяйственный цеп, '
                                          'тогда как игровой вариант отнесён к двуручному боевому оружию.'}],
                   'detail_id': '2h_flail_wood',
                   'prior_audit': 'Длинного сельскохозяйственного цепа с шарнирной колотушкой нет. Кистень '
                                  'Нефедьева устроен иначе; нужен новый рисунок цепа по французской '
                                  'миниатюре, с оговоркой её даты около 1270.',
                   'note': 'Париж, Франция, около 1270; изображён сельскохозяйственный цеп, тогда как '
                           'игровой вариант отнесён к двуручному боевому оружию.'},
 'broom': {'label': 'Метла с пучком прутьев',
           'selection': {'weapon': 'broom'},
           'kind': 'weapon',
           'sources': [{'image': 'оружие/broom/1.jpg',
                        'url': 'https://digital.bodleian.ox.ac.uk/inquire/p/4a0c575c-0cad-4dd2-8fd4-a6689c0ae1e8',
                        'date': 'XIV (около 1320–1330)',
                        'accuracy': 'аналог',
                        'limits': 'Гент, Фландрия, около 1320–1330 годов; метла показана в хозяйственном '
                                  'деле, а игровой предмет используется как оружие.'}],
           'detail_id': 'broom',
           'prior_audit': 'Древка с пучком прутьев нет; нужен новый хозяйственный предмет по миниатюре XIV '
                          'века, без утверждения о точном новгородском образце 1230 года.',
           'note': 'Гент, Фландрия, около 1320–1330 годов; метла показана в хозяйственном деле, а игровой '
                   'предмет используется как оружие.'},
 'cudgel': {'label': 'Дубинка',
            'selection': {'weapon': 'cudgel'},
            'kind': 'weapon',
            'sources': [{'image': 'оружие/cudgel/1.jpg',
                         'url': 'https://ica.themorgan.org/manuscript/page/58/108938',
                         'date': 'XIV (1348)',
                         'accuracy': 'аналог',
                         'limits': 'Франция, 1348 год; миниатюра показывает клуб с утолщением у конца, тогда '
                                   'как игровой cudgel — лёгкий деревянный учебный прут длиной около 60 '
                                   'см.'}],
            'detail_id': 'cudgel',
            'prior_audit': 'Лёгкого учебного прута нет. Готовая eur_west_bayeux_club имеет выраженное '
                           'утолщение и не покрывает описанный игровой прут.',
            'note': 'Франция, 1348 год; миниатюра показывает клуб с утолщением у конца, тогда как игровой '
                    'cudgel — лёгкий деревянный учебный прут длиной около 60 см.'},
 'wp_flail': {'label': 'Бронзовый шаровой кистень',
              'selection': {'weapon': 'wp_flail'},
              'kind': 'weapon',
              'sources': [{'image': 'оружие/wp_flail/1.png',
                           'url': 'https://nav.shm.ru/exhibits/1590/',
                           'date': 'XII–XIII',
                           'accuracy': 'находка',
                           'limits': ''}],
              'detail_id': 'wp_flail',
              'prior_audit': 'Имеющийся eur_steppe_nefedyevo_flail имеет длинную роговую гирьку. На фото '
                             'wp_flail бронзовый шар с ушком и мелкими выступами; этот вариант отсутствует.',
              'note': ''},
 'wp_sulitsa': {'label': 'Листовидная сулица',
                'selection': {'weapon': 'wp_sulitsa'},
                'kind': 'weapon',
                'sources': [{'image': 'оружие/wp_sulitsa/1.jpg',
                             'url': 'https://collection.kulpole.ru/entity/OBJECT/33771?index=6&topoex=8622167',
                             'date': 'XII–XIV',
                             'accuracy': 'находка',
                             'limits': ''}],
                'detail_id': 'wp_sulitsa',
                'prior_audit': 'Готовая eur_steppe_grigorovo_dart имеет два обратных шипа. На фото '
                               'wp_sulitsa вытянутый узкий листовидный наконечник без них; этот вариант '
                               'отсутствует.',
                'note': ''},
 'wp_rogatina': {'label': 'Рогатина с широким пером',
                 'selection': {'weapon': 'wp_rogatina'},
                 'kind': 'weapon',
                 'sources': [{'image': 'оружие/wp_rogatina/1.png',
                              'url': 'https://rusdarpa.ru/?p=1162',
                              'date': 'XII–XIII',
                              'accuracy': 'находка',
                              'limits': ''}],
                 'detail_id': 'wp_rogatina',
                 'prior_audit': 'Готовые spear и eur_west_scalvian_spear не имеют нужного широкого '
                                'лавролистного пера рогатины. Нужен новый профиль наконечника по чертежу, '
                                'без произвольной поперечной перекладины.',
                 'note': ''},
 'wp_lance': {'label': 'Длинное конное копьё',
              'selection': {'weapon': 'wp_lance'},
              'kind': 'weapon',
              'sources': [{'image': 'оружие/wp_lance/1.jpg',
                           'url': 'https://ica.themorgan.org/manuscript/page/47/158530',
                           'date': 'XIII',
                           'accuracy': 'аналог',
                           'limits': 'Париж, Франция, 1244–1254 гг.; западноевропейская миниатюра показывает '
                                     'конный бой, но не русское копьё и не точный профиль наконечника'}],
              'limits': 'Обобщённый полный предмет по миниатюре; русская форма наконечника не установлена.',
              'detail_id': 'wp_lance',
              'prior_audit': 'Пешее spear уже есть, но отдельного длинного конного копья и позы всадника '
                             'нет. Полное копьё можно использовать как основу, но специфический предмет не '
                             'представлен.',
              'note': 'Париж, Франция, 1244–1254 гг.; западноевропейская миниатюра показывает конный бой, но '
                      'не русское копьё и не точный профиль наконечника'},
 'wp_staff': {'label': 'Пастуший посох',
              'selection': {'weapon': 'wp_staff'},
              'kind': 'weapon',
              'sources': [{'image': 'оружие/wp_staff/1.jpg',
                           'url': 'https://ica.themorgan.org/manuscript/page/56/158530',
                           'date': 'XIII век (ок. 1244–1254)',
                           'accuracy': 'изображение эпохи',
                           'limits': 'Франция, ок. 1244–1254; показан пастуший посох, а не русское боевое '
                                     'оружие.'}],
              'detail_id': 'wp_staff',
              'prior_audit': 'Простой посох, включая загнутую пастушью вершину на фактической миниатюре, '
                             'отсутствует. Копейное древко можно использовать лишь как основу новой '
                             'геометрии.',
              'note': 'Франция, ок. 1244–1254; показан пастуший посох, а не русское боевое оружие.'},
 'wp_long_knife': {'label': 'Длинный однолезвийный нож',
                   'selection': {'weapon': 'wp_long_knife'},
                   'kind': 'weapon',
                   'sources': [{'image': 'оружие/wp_long_knife/1.jpg',
                                'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/170387',
                                'date': 'XIII',
                                'accuracy': 'аналог',
                                'limits': 'Новгород, XIII век; музейный нож длиной 16 см с костяной рукоятью '
                                          'не подтверждает игровую удлинённую разновидность'}],
                   'detail_id': 'wp_long_knife',
                   'prior_audit': 'Полного русского длинного однолезвийного ножа нет. Англосаксонский '
                                  'eur_west_seax — отдельный инокультурный образец, а фото в INDEX вообще '
                                  'показывает обычный нож 16 см.',
                   'note': 'Новгород, XIII век; музейный нож длиной 16 см с костяной рукоятью не '
                           'подтверждает игровую удлинённую разновидность'},
 'wp_crossbow_bolt': {'label': 'Самострельный болт',
                      'selection': {'weapon': 'wp_crossbow_bolt'},
                      'kind': 'weapon',
                      'sources': [{'image': 'оружие/wp_crossbow_bolt/1.jpg',
                                   'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/189430',
                                   'date': 'XIII–XV вв.',
                                   'accuracy': 'находка',
                                   'limits': 'Новгородская археологическая коллекция, XIII–XV вв.; '
                                             'сохранился железный наконечник, а не болт с коротким '
                                             'древком.'}],
                      'detail_id': 'wp_crossbow_bolt',
                      'prior_audit': 'У готового раннего арбалета нет болта; нужен отдельный короткий болт '
                                     'и/или его втульчатый массивный наконечник по фото. На фото сохранена '
                                     'только металлическая головка.',
                      'note': 'Новгородская археологическая коллекция, XIII–XV вв.; сохранился железный '
                              'наконечник, а не болт с коротким древком.'},
 'wp_signal_horn': {'label': 'Резной сигнальный олифант',
                    'selection': {'weapon': 'wp_signal_horn'},
                    'kind': 'weapon',
                    'sources': [{'image': 'оружие/wp_signal_horn/1.jpg',
                                 'url': 'https://www.metmuseum.org/art/collection/search/21967',
                                 'date': 'ок. 1200',
                                 'accuracy': 'аналог',
                                 'limits': 'Южная Италия, ок. 1200; резной слоновый бивень с металлическими '
                                           'креплениями вместо простого рога животного.'}],
                    'detail_id': 'wp_signal_horn',
                    'prior_audit': 'Сигнального рога нет. Фото показывает резной олифант около 1200 года из '
                                   'возможной Южной Италии; не следует выдавать его за простой русский рог.',
                    'note': 'Южная Италия, ок. 1200; резной слоновый бивень с металлическими креплениями '
                            'вместо простого рога животного.'},
 'wp_sword': {'label': 'меч',
              'selection': {'weapon': 'sword'},
              'kind': 'detail',
              'sources': [{'image': 'оружие/wp_sword/1.jpg',
                           'url': 'https://swordmaster.org/2012/09/21/o-neizvestnoy-nahodke-srednevekovogo-mecha-iz-novgoroda.html',
                           'date': 'X–XII',
                           'accuracy': 'находка',
                           'limits': ''}],
              'detail_id': 'wp_sword',
              'prior_audit': 'Есть полный прямой двулезвийный меч с навершием и перекрестьем, также '
                             'sheathed_sword. Его сложное перекрестье основано на другой новгородской '
                             'находке; меч с прямой крестовиной 1987 года из INDEX не скопирован.',
              'note': ''},
 'wp_battle_axe': {'label': 'боевой топор',
                   'selection': {'weapon': 'axe'},
                   'kind': 'detail',
                   'sources': [{'image': 'оружие/wp_battle_axe/1.jpg',
                                'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/862383',
                                'date': 'XIII в.',
                                'accuracy': 'находка',
                                'limits': ''}],
                   'detail_id': 'wp_battle_axe',
                   'prior_audit': 'Есть полный топор: деревянное топорище, проушина и асимметричное '
                                  'металлическое лезвие. Предмет виден на оружейном листе; фото подтверждает '
                                  'ту же конструкцию.',
                   'note': ''},
 'wp_spear': {'label': 'копьё пешее',
              'selection': {'weapon': 'spear'},
              'kind': 'detail',
              'sources': [{'image': 'оружие/wp_spear/1.jpg',
                           'url': 'https://www.icon-art.info/masterpiece.php?mst_id=432; '
                                  'https://commons.wikimedia.org/wiki/File:Novgorod_George.jpg',
                           'date': 'XII век (ок. 1130)',
                           'accuracy': 'изображение эпохи',
                           'limits': 'Новгородская икона, ок. 1130; религиозное изображение, а не '
                                     'археологическая находка оружия.'}],
              'detail_id': 'wp_spear',
              'prior_audit': 'Есть полное пешее копьё: длинное прямое древко и узкий ромбовидно-листовидный '
                             'втульчатый наконечник. Готовы позиции в руке и за плечом.',
              'note': 'Новгородская икона, ок. 1130; религиозное изображение, а не археологическая находка '
                      'оружия.'},
 'club_wooden': {'label': 'дубина',
                 'selection': {'weapon': 'eur_west_bayeux_club'},
                 'kind': 'detail',
                 'sources': [{'image': 'оружие/club_wooden/1.jpg',
                              'url': 'https://commons.wikimedia.org/wiki/File:OdoBayeux.jpg',
                              'date': 'XI (около 1070-х)',
                              'accuracy': 'аналог',
                              'limits': 'Англия и Нормандия, около 1070-х годов; это клуб епископа-всадника, '
                                        'а игровой предмет описан как грубо выструганная из доски дубина '
                                        'длиной 65 см.'}],
                 'detail_id': 'club_wooden',
                 'prior_audit': 'На фото Байё гладкая деревянная палица с утолщённым концом; этот силуэт уже '
                                'нарисован. Он покрывает фактический аналог, но не доказывает игровую '
                                'дубину, выструганную из доски.',
                 'note': 'Англия и Нормандия, около 1070-х годов; это клуб епископа-всадника, а игровой '
                         'предмет описан как грубо выструганная из доски дубина длиной 65 см.'},
 'wp_club': {'label': 'дубина',
             'selection': {'weapon': 'eur_west_bayeux_club'},
             'kind': 'detail',
             'sources': [{'image': 'нет картинки',
                          'url': 'inputs/ITEMS.md:412',
                          'date': 'не установлено',
                          'accuracy': '',
                          'limits': ''}],
             'detail_id': 'wp_club',
             'prior_audit': 'Имеется цельная деревянная палица с утолщённым концом. Для wp_club в INDEX '
                            'картинки нет; это повторное использование готового общего предмета, без '
                            'заявления об археологическом русском образце.',
             'note': ''},
 'wp_crossbow': {'label': 'самострел (ранний арбалет)',
                 'selection': {'weapon': 'eur_west_drosten_crossbow'},
                 'kind': 'detail',
                 'sources': [{'image': 'оружие/wp_crossbow/1.webp',
                              'url': 'https://manuscriptminiatures.com/4107/12181',
                              'date': '1225–1250 гг.',
                              'accuracy': 'аналог',
                              'limits': 'Париж, 1225–1250; французская библейская миниатюра показывает '
                                        'западноевропейский самострел, а не установленную новгородскую '
                                        'модель 1230 года.'}],
                 'detail_id': 'wp_crossbow',
                 'prior_audit': 'Есть ранний арбалет с деревянным ложем, дугой и тетивой. Он основан на '
                                'камне Дростена; иной референс из INDEX не доказывает совпадение механизма, '
                                'но сам класс предмета уже представлен.',
                 'note': 'Париж, 1225–1250; французская библейская миниатюра показывает западноевропейский '
                         'самострел, а не установленную новгородскую модель 1230 года.'},
 'wp_sling': {'label': 'праща',
              'selection': {'weapon': 'eur_west_taull_sling'},
              'kind': 'detail',
              'sources': [{'image': 'оружие/wp_sling/1.jpg',
                           'url': 'https://ica.themorgan.org/manuscript/page/56/158530',
                           'date': 'XIII век (ок. 1244–1254)',
                           'accuracy': 'изображение эпохи',
                           'limits': 'Франция, ок. 1244–1254; библейская миниатюра показывает пращу в '
                                     'западноевропейской сцене.'}],
              'detail_id': 'wp_sling',
              'prior_audit': 'Есть кожаная ложка и две гибкие ветви пращи; походный свёрнутый вариант '
                             'wardrobe_weapon_carry._draw_sling. Французская миниатюра INDEX является другим '
                             'изображением того же типа.',
              'note': 'Франция, ок. 1244–1254; библейская миниатюра показывает пращу в западноевропейской '
                      'сцене.'},
 'wp_mace': {'label': 'булава',
             'selection': {'weapon': 'eur_steppe_zaryadye_mace'},
             'kind': 'detail',
             'sources': [{'image': 'оружие/wp_mace/1.png',
                          'url': 'https://nav.shm.ru/exhibits/4552/',
                          'date': 'XII–XIV',
                          'accuracy': 'находка',
                          'limits': ''}],
             'detail_id': 'wp_mace',
             'prior_audit': 'Есть деревянная рукоять с многогранным металлическим навершием, также '
                            'четырёхшипный вариант eur_steppe_zagorye_mace. Покрыт общий класс булавы; '
                            'ребристое навершие фото INDEX не является точной копией этих головок.',
             'note': ''},
 'wp_sabre': {'label': 'сабля',
              'selection': {'weapon': 'eur_steppe_yaroslavl_sabre'},
              'kind': 'detail',
              'sources': [{'image': 'оружие/wp_sabre/1.jpg',
                           'url': 'https://collection.kulpole.ru/entity/OBJECT/64653',
                           'date': 'XIII–XIV',
                           'accuracy': 'аналог',
                           'limits': 'Куликово поле, XIII–XIV вв.; находка может быть позднее новгородского '
                                     '1230 г. и имеет лишь слабый изгиб клинка'}],
              'detail_id': 'wp_sabre',
              'prior_audit': 'Есть полный изогнутый однолезвийный клинок, рукоять и перекрестье, а также '
                             'изогнутые ножны. Дополнительный вариант eur_steppe_vienna_sabre.',
              'note': 'Куликово поле, XIII–XIV вв.; находка может быть позднее новгородского 1230 г. и имеет '
                      'лишь слабый изгиб клинка'},
 'wp_bow_composite': {'label': 'лук сложный (составной)',
                      'selection': {'bow': 'novgorod_composite'},
                      'kind': 'detail',
                      'sources': [{'image': 'оружие/wp_bow_composite/1.jpg',
                                   'url': 'https://commons.wikimedia.org/wiki/File:Composite_bow,_sword_-_11-12c_-_Novgorod_Kremlin_Museum.jpg',
                                   'date': 'XII в. (современная реконструкция)',
                                   'accuracy': 'реконструкция',
                                   'limits': 'Современная музейная реконструкция по археологическим '
                                             'материалам и письменным источникам; точные породы дерева и '
                                             'материал тетивы здесь не указаны.'}],
                      'detail_id': 'wp_bow_composite',
                      'prior_audit': 'Есть полный изогнутый составной лук с рукоятью, окончаниями плеч и '
                                     'тетивой; также походный вариант _draw_composite_back_bow. Это общий '
                                     'тип, не точная копия музейной реконструкции.',
                      'note': 'Современная музейная реконструкция по археологическим материалам и письменным '
                              'источникам; точные породы дерева и материал тетивы здесь не указаны.'},
 'wp_bow_self': {'label': 'лук простой деревянный',
                 'selection': {'bow': 'northern_wood'},
                 'kind': 'detail',
                 'sources': [{'image': 'оружие/wp_bow_self/1.jpg',
                              'url': 'https://novgorod-iss.kamiscloud.ru/entity/OBJECT/817846',
                              'date': 'XII в., вторая половина – рубеж XII–XIII вв.',
                              'accuracy': 'аналог',
                              'limits': 'Троицкий раскоп, Великий Новгород, вторая половина XII в. – рубеж '
                                        'XIII; предмет короткий, детский, а не подтверждённый боевой '
                                        'образец.'}],
                 'detail_id': 'wp_bow_self',
                 'prior_audit': 'Есть простой длинный деревянный лук с тетивой; геометрия отлична от '
                                'составного. Фото INDEX — короткий детский лук, поэтому готовый рисунок '
                                'покрывает тип, но не точный найденный экземпляр.',
                 'note': 'Троицкий раскоп, Великий Новгород, вторая половина XII в. – рубеж XIII; предмет '
                         'короткий, детский, а не подтверждённый боевой образец.'},
 'wp_shield_round': {'label': 'щит круглый',
                     'selection': {'shield': 'novgorod_george'},
                     'kind': 'detail',
                     'sources': [{'image': 'оружие/wp_shield_round/1.jpg',
                                  'url': 'https://www.icon-art.info/masterpiece.php?mst_id=432; '
                                         'https://commons.wikimedia.org/wiki/File:Novgorod_George.jpg',
                                  'date': 'XII век (ок. 1130)',
                                  'accuracy': 'изображение эпохи',
                                  'limits': ''}],
                     'detail_id': 'wp_shield_round',
                     'prior_audit': 'Уже изображён круглый щит с новгородской иконы Георгия: круглая '
                                    'плоскость, обод и центральный умбон.',
                     'note': ''},
 'wp_shield_almond': {'label': 'щит миндалевидный (каплевидный)',
                      'selection': {'shield': 'kite'},
                      'kind': 'detail',
                      'sources': [{'image': 'оружие/wp_shield_almond/1.jpg',
                                   'url': 'https://ica.themorgan.org/manuscript/page/77/158530',
                                   'date': 'XIII',
                                   'accuracy': 'аналог',
                                   'limits': 'Париж, Франция, 1244–1254 гг.; показаны западные рыцарские '
                                             'щиты с гербовыми рисунками, а не новгородский щит'}],
                      'detail_id': 'wp_shield_almond',
                      'prior_audit': 'Есть длинный миндалевидный щит со скруглённым верхом и вытянутым '
                                     'остриём; также novgorod_dish по местному изображению. Западная '
                                     'миниатюра INDEX — лишь аналог.',
                      'note': 'Париж, Франция, 1244–1254 гг.; показаны западные рыцарские щиты с гербовыми '
                              'рисунками, а не новгородский щит'},
 'wp_shield_triangular': {'label': 'щит треугольный (ранний, со скруглённым верхом)',
                          'selection': {'shield': 'triangular'},
                          'kind': 'detail',
                          'sources': [{'image': 'оружие/wp_shield_triangular/1.webp',
                                       'url': 'https://www.shieldwright.eu/articles/how-were-medieval-shield-wooden-cores-constructed',
                                       'date': 'XIII век (ок. 1230–1240)',
                                       'accuracy': 'аналог',
                                       'limits': 'Марбург, Германия, ок. 1230–1240; рельефный лев и '
                                                 'заострённый контур отличаются от раннего новгородского '
                                                 'варианта.'}],
                          'detail_id': 'wp_shield_triangular',
                          'prior_audit': 'Есть треугольный щит со слабо округлённым верхом и заострённым '
                                         'низом. Рельефный лев конкретного немецкого предмета INDEX не '
                                         'воспроизведён.',
                          'note': 'Марбург, Германия, ок. 1230–1240; рельефный лев и заострённый контур '
                                  'отличаются от раннего новгородского варианта.'},
 'wp_shield_facing': {'label': 'обтяжка и окраска щита',
                      'selection': {'shield': 'kite'},
                      'kind': 'detail',
                      'sources': [{'image': 'оружие/wp_shield_facing/1.jpg',
                                   'url': 'https://eletsmuseum.ru/istoriya-odnogo-eksponata-shhit/',
                                   'date': 'XII–XIV',
                                   'accuracy': 'аналог',
                                   'limits': 'Елец, XII–XIV вв.; музей показывает копию монгольского '
                                             'круглого щита с металлическими накладками, а не древнерусскую '
                                             'миндалевидную обтяжку и окраску'}],
                      'detail_id': 'wp_shield_facing',
                      'prior_audit': 'Окрашенная плоскость и кожаный обод уже видны у щитов. Отдельной '
                                     'снятой обтяжки нет; монгольский круглый щит с накладками из INDEX не '
                                     'воспроизведён.',
                      'note': 'Елец, XII–XIV вв.; музей показывает копию монгольского круглого щита с '
                              'металлическими накладками, а не древнерусскую миндалевидную обтяжку и '
                              'окраску'}}
