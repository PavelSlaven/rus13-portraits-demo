import re

from adult_hair_men import PARTED_STRAIGHT_CROWN, PARTED_STRAIGHT_LOCK
from adult_hair_women import WRAPPED_BRAID_TIE, WRAPPED_SINGLE_BRAID
from clothing_headwear_art import draw_scarf_pin
import facial_hair_shapes
from facial_hair_growth import MOUSTACHE_STUBBLE, visible_facial_hair
import hairstyle_shapes
import headwear
import headwear_northwest_military
from common import HeadGeometry, brow_top, node, number, path
from face_features import eye_layout
from face_shape import ear_fit, face_outline, forehead_curve
from hair_length import SCALP_STYLES, SHAVED_STYLE, STUBBLE_STYLE
from nose_mouth import facial_hair_mouth_opening, moustache_band
from wardrobe import CHILD_BODY_SCALE


OPTIONS = {
    "hair_style": {
        "short": "Короткие",
        "ear_length": "До ушей",
        "long": "Длинные распущенные",
        "tied": "Собранные",
        "braided": "Плетёные",
    },
    "hair_texture": {
        "straight": "Прямые",
        "wavy": "Волнистые",
        "curly": "Кудрявые",
        "coiled": "С мелкими завитками",
    },
    "hairline": {
        "rounded": "Плавная",
        "straight": "Прямая",
        "receding": "С височными углами",
    },
    "hair_density": {
        "thick": "Густые",
        "thinning": "Редеющие",
        "open_crown": "С открытым теменем",
    },
    "part": {"none": "Без пробора", "center": "Центральный", "side": "Боковой"},
    "hair_color": {
        "dark_chestnut": "Тёмно-каштановые",
        "black": "Чёрные",
        "chestnut": "Каштановые",
        "light_brown": "Русые",
        "blond": "Светлые",
        "red": "Рыжие",
    },
    "graying": {
        "none": "Без седины",
        "temples": "Седина на висках",
        "mixed": "Смешанная седина",
        "full": "Сплошная седина",
    },
    "beard": {
        "none": "Без бороды",
        "stubble": "Щетина",
        "short": "Короткая округлая",
        "broad": "Широкая",
        "long": "Длинная клином",
    },
    "moustache": {
        "none": "Без усов",
        "short": "Короткие",
        "broad": "Широкие",
        "drooping": "Опущенные",
    },
    "headgear": {
        "none": "Без головного убора",
        "cap": "Шапка",
        "wrap": "Платок",
        "helmet": "Шлем с бармицей",
        "tall_helmet": "Высокий шлем с бармицей",
    },
}

LEGACY_STYLE_IDS = {field: tuple(OPTIONS[field]) for field in ("hair_style", "beard", "moustache")}
OPTIONS["hair_style"].update(hairstyle_shapes.OPTIONS)
OPTIONS["hair_style"].update(hairstyle_shapes.FITTED_OPTIONS)
OPTIONS["hair_style"].update(SCALP_STYLES)
OPTIONS["beard"].update(facial_hair_shapes.BEARD_OPTIONS)
OPTIONS["moustache"].update(facial_hair_shapes.MOUSTACHE_OPTIONS)
OPTIONS["headgear"].update(headwear.OPTIONS)
OPTIONS["headgear"].update(headwear_northwest_military.OPTIONS)

LABELS = {
    "hair_style": "Причёска",
    "hair_texture": "Фактура волос",
    "hairline": "Линия роста волос",
    "hair_density": "Густота волос",
    "part": "Пробор",
    "hair_color": "Цвет волос",
    "graying": "Седина",
    "beard": "Борода",
    "moustache": "Усы",
    "headgear": "Головной убор",
}

COVERAGE = {
    "none": {"ears": True, "neck": True, "hair": True},
    "cap": {"ears": True, "neck": True, "hair": True},
    "wrap": {"ears": False, "neck": True, "hair": True},
    "helmet": {"ears": False, "neck": False, "hair": False},
    "tall_helmet": {"ears": False, "neck": False, "hair": False},
    **headwear.COVERAGE,
    **dict.fromkeys(headwear_northwest_military.OPTIONS, {"ears": False, "neck": False, "hair": False}),
    "nw_pakalniskiai_helm": {"ears": False, "neck": True, "hair": False},
}

AVENTAIL_COVERAGE = {
    "nw_duboshin_helm": "Бармица закрывает уши, затылок, шею и верх плеч. Лицо открыто.",
    "nw_lykovo_helm": "Бармица закрывает уши, затылок, шею и верх плеч. Наносник прикрывает переносицу.",
    "nw_gjermundbu_helm": "Бармица закрывает уши, затылок, шею и края плеч. Очковина обрамляет глаза, рот открыт.",
    "nw_pakalniskiai_helm": "Бармица закрывает уши, затылок, бока шеи и края плеч. Лицо и горло открыты.",
}

_COLORS = {
    "dark_chestnut": ("#362827", "#63493d", "#241c1d", "#967661"),
    "black": ("#252527", "#4b4846", "#1e1b20", "#85817b"),
    "chestnut": ("#613c2f", "#8b5a41", "#3d2927", "#b68361"),
    "light_brown": ("#77604a", "#9a8160", "#4d3d33", "#bea57d"),
    "blond": ("#a18054", "#c8a774", "#67513b", "#e4ca93"),
    "red": ("#864831", "#b06d48", "#523125", "#d49567"),
}
_SILVER = ("#80776e", "#b3a99a", "#514946", "#e0d0b6")
_MIXED = ("#62534d", "#938374", "#403432", "#c3b19c")
NORTHWEST_HELMETS = tuple(headwear_northwest_military.OPTIONS)
_HELMETS = {"helmet", "tall_helmet", *NORTHWEST_HELMETS}

_CROWNS = {
    "short": (
        "M93 176c-9-10-10-19-10-34-9-12-6-32 1-46l-10 3q9-22 36-32"
        "-8-8-18-8 22-8 48-3 32 10 49-19 10 16 5 27 20-4 27-18 9 20-2 32"
        " 16 4 26 17-13-5-24 1 11 14 15 32 3 14-.5 31l-8 15"
    ),
    "ear_length": (
        "M97 198q-16 13-23 2 5-19 1-38-7-29 2-52 9-36 38-49 25-14 48-9"
        " 28-6 54 12 28 18 29 53 2 21-3 45-4 20 4 35-12 11-24 1"
    ),
    "long": (
        "M93 176Q77 157 78 130C78 99 96 74 117 61Q137 48 160 52"
        "Q192 48 215 65C236 80 247 103 244 131Q245 155 226.5 174"
    ),
    "tied": (
        "M94 172q-12-15-11-43-5-36 15-58 22-27 61-26 36-4 60 20 25 24 18 67"
        " 1 22-12 40"
    ),
    "braided": (
        "M94 173q-13-14-11-40-6-33 15-61 19-26 60-26 39-2 66 25 16 19 16 48"
        " 3 33-14 56"
    ),
}

_THIN_CROWN = (
    "M93 176q-13-14-12-40-2-28 18-50 19-26 59-31"
    " 37-4 59 19 24 22 24 53Q243 150 227.5 174"
)

_HAIRLINES = {
    "rounded": (
        "Q224 151 217 125Q199 129 182 116Q166 106 155 98"
        "Q142 112 118 121Q108 125 101 125Q99 148 93 176"
    ),
    "straight": "Q221 155 217 119Q164 104 108 120Q106 154 93 176",
    "receding": (
        "Q223 156 218 145Q219 116 205 112Q194 126 180 121"
        "Q153 101 139 106Q125 115 114 110Q103 117 103 144L93 176"
    ),
}
_RECEDED_LINE = (
    "Q222 156 217 140Q217 117 202 111Q187 112 178 103"
    "Q166 94 148 100Q134 108 118 109Q105 117 105 140L93 176"
)
_OPEN_CROWN = {
    "rounded": (
        "M93 174q-13-13-12-37 1-23 18-38 8-8 18-12"
        "-9 11-13 29-1 30-11 58Z"
        " M227 174q-8-18-9-43-1-22-14-42 18 8 29 29 11 32-6 56Z"
    ),
    "straight": (
        "M93 174q-13-13-12-37 1-22 22-39l11-6-6 27q-2 27-15 55Z"
        " M227 174q-11-19-11-46l-7-35 12 9q26 22 15 58Z"
    ),
    "receding": (
        "M93 174q-13-13-12-37 1-21 18-35l7-4q-6 20-5 37-1 22-8 39Z"
        " M227 174q-8-18-9-43-2-22-9-31 18 5 25 25 11 27-7 49Z"
    ),
}

_BACKS = {
    "ear_length": (
        "M104 96q-25 16-27 45-7 21 0 42l-6 24 19-6-3 12q35 11 69-6"
        " 59 12 82-1l-4-12 15 10q-9-29-4-52 4-39-23-58Z"
    ),
    "long": (
        "M108 98q-36 17-39 70-2 41-16 75-10 23-3 58l11-12 4 26 13-6"
        " 12 8q36-1 65-34 39 24 73 28l21-7 12 11 1-18 13 7q-2-22-11-42"
        "-14-34-16-86-2-51-33-79Z"
    ),
    "tied": (
        "M179 84q23-25 54-18 30 6 32 33 0 29-22 41-23 8-46-5Z"
    ),
    "braided": (
        "M105 98Q72 132 85 180C88 189 94 195 107 198"
        "Q122 202 138 205L184 204 212 217Q244 198 243 165Q246 127 218 99Z"
    ),
}

_LONG_ENDS = {
    "straight": (
        "M75 143q-12 24-10 47 3 46-12 95l11-12-2 21 16-10q18-8 20-38"
        " 3-47-4-85Z M225 152q-4 49 4 88 3 30 22 44l-1-14 13 12"
        "q-10-38-12-72-1-33-12-64Z"
    ),
    "wavy": (
        "M78 143q-18 31-9 53 10 25-5 55-9 15-8 36 5-8 12-11l-2 18"
        "q28-13 31-37 4-23-4-44-7-22 2-52Z M225 151q-7 28 2 53"
        " 10 31 7 53-3 19 16 29l-1-14 16 12q-9-20-8-41 0-31-12-56l-5-38Z"
    ),
    "curly": (
        "M77 143q-13 18-10 31-15 12-5 25-6 12 1 23-11 12-6 27"
        "-12 22 1 31l10-1q0 16 13 12 13-6 10-22 15-12 6-31 8-12 1-26 3-40-6-55Z"
        " M223 151q-6 27 1 41-7 15 3 25-3 16 6 28-6 17 7 27-4 16 10 20"
        " 15 4 17-12-10-10-6-25 5-14-6-25 6-34-10-47 3-14-9-29Z"
    ),
    "coiled": (
        "M76 143q-10 8-7 17-11 4-7 14-10 7-5 17-7 6 0 16-9 9-3 17"
        "-11 9-4 18-7 7-3 15-10 13 4 18 0 11 12 10 4 13 15 4 13 1 13-12"
        " 12-4 8-15 10-10 4-18 6-8 0-16 6-15-1-23 6-12 0-22 2-16-11-26Z"
        " M224 151q-8 8-5 21-6 9 1 17-6 12 2 18-4 11 3 17-7 9 2 16"
        "-5 10 4 17-4 11 8 16-2 12 10 13 7 11 17 0 11-4 4-15 3-12-7-17"
        " 5-10-3-17 5-12-4-19 4-13-5-20 4-13-4-20 2-12-10-21Z"
    ),
}

_TEXTURE_STROKES = {
    "straight": (
        "M87 112q10-23 40-31m-31 31q11-17 43-24m-27 19q10-8 31-13"
        "m-10 10q11-5 19-13m-42 26 15-7m-23 10 8-3m28-43q28 2 43-6"
        "m0 8q15-3 21-10m-26 20 19-5m-12 13q14 8 24 7m-10 5 9 4"
        "m-71-51 10 2m36-3 5-6m33 80 4 12"
    ),
    "wavy": (
        "M83 122q-3-14 18-24t25-16q10-10 31-9t40-12"
        "M91 131q-2-13 21-23 17-7 26-18 10-10 29-6t41-9"
        "M99 135q1-12 21-18t27-14q12-10 32-10 17-1 38-11"
        "M184 106q22-5 36 8t9 36M86 135q-4 14 2 27"
    ),
    "curly": (
        "M83 122q-4-16 11-23 10-4 15 3 3 7-5 10-7 2-8-4"
        "M111 97q-1-17 17-20 17-2 18 12-1 9-11 8-7-2-5-7"
        "M150 78q4-15 19-14 12 1 12 10-1 8-11 7"
        "M183 86q11-12 22-7 7 2 5 10-2 6-8 6"
        "M213 99q17 3 16 16-3 9-10 6M229 128q11 11 1 19"
        "M109 119q12-13 23-11M97 143q-8 9-5 20"
    ),
    "coiled": (
        "M90 115q-9-10 1-16 7-4 10 2m3-7q-3-10 6-13 9-2 12 6"
        "m2-9q-1-10 10-11 8-1 11 6m3-5q1-10 12-9 7 1 8 7"
        "m2 3q8-11 17-4 3 3 1 8m8 1q7-9 14-3 4 4 0 9"
        "m7 3q9-3 12 4 2 6-4 11m1 3q10 0 10 8 0 5-5 8"
        "M93 128q-10-1-7-10m13 9q6-10 15-6m-4-7q1-8 13-8"
        "m-3-6q8-10 16-3m4-8q8-10 15-2m6-1q8-10 19-6"
        "m5 13q10-7 15 1m3 6q9-7 14 4m6 20q9 0 9 8-1 6-7 8"
        "M89 150q-9-6-1-14"
    ),
}

_TEXTURE_EDGES = {
    "wavy": (
        "M93 176Q78 162 82 138Q65 105 90 85Q98 77 107 77Q104 63 123 55"
        "Q145 46 161 54Q178 54 189 40Q197 52 196 62Q216 62 224 51"
        "Q234 69 225 80Q238 80 247 97Q238 95 229 97Q250 122 238 142Q239 160 227.5 174"
    ),
    "curly": (
        "M93 176Q78 168 82 146Q67 135 73 112Q66 94 84 83Q78 66 98 58"
        "Q107 54 117 60Q122 42 144 43Q157 43 164 53Q173 34 194 39"
        "Q209 42 209 56Q228 51 236 67Q241 77 236 83Q253 88 252 106"
        "Q249 115 240 118Q248 130 239 145Q240 168 227.5 174"
    ),
    "coiled": (
        "M93 176Q82 175 82 163Q74 158 78 146Q67 142 71 129Q61 121 69 109"
        "Q63 97 73 91Q69 79 80 74Q79 61 93 60Q98 47 110 52Q118 42 131 48"
        "Q140 36 152 45Q164 36 175 44Q189 34 199 47Q212 42 220 53"
        "Q235 51 237 65Q252 70 247 82Q258 91 251 104Q259 116 250 125"
        "Q253 139 242 143Q245 154 236 158Q237 171 227.5 174"
    ),
}


def hair_palette(look):
    if look["graying"] == "full":
        return _SILVER
    if look["graying"] == "mixed":
        base, light, shade, stroke = _COLORS[look["hair_color"]]
        return _mix_color(base, _MIXED[0]), _mix_color(light, _MIXED[1]), shade, _mix_color(stroke, _MIXED[3])
    return _COLORS[look["hair_color"]]


def _mix_color(first, second):
    return "#" + "".join(
        f"{(int(first[index:index + 2], 16) + int(second[index:index + 2], 16)) // 2:02x}"
        for index in (1, 3, 5)
    )


def _hair_transform(head: HeadGeometry):
    x_scale = head.temple_half / 68
    y_scale = (160 - head.top_y) / 85
    return f"matrix({number(x_scale)} 0 0 {number(y_scale)} {number(160 * (1 - x_scale))} {number(160 * (1 - y_scale))})"


def _temple_transform(head: HeadGeometry):
    x_scale = head.temple_half / 68
    return f"matrix({number(x_scale)} 0 0 1 {number(160 * (1 - x_scale))} 0)"


def _stroke(parent, d, color, width=1.45, **attrs):
    path(parent, d, "none", stroke=color, stroke_width=width, stroke_linecap="round",
         stroke_linejoin="round", **attrs)


def _clip_group(parent, defs, clip_id, d):
    clip = node(defs, "clipPath", id=clip_id)
    path(clip, d)
    return node(parent, "g", clip_path=f"url(#{clip_id})")


def _brow_safe_hairline(look, head):
    scale = (160 - head.top_y) / 85
    edge = min(121, round(160 + (brow_top(look, include_standard=True) - 4 - 160) / scale, 1))
    line = look["hairline"]
    if line == "straight":
        fringe = f"Q164 {edge - 8} 106 {edge}"
    elif line == "receding" or look["hair_density"] == "thinning":
        fringe = f"Q196 {edge - 13} 177 {edge - 2} Q157 {edge + 5} 141 {edge - 6} Q123 {edge - 13} 106 {edge}"
    else:
        fringe = (f"Q199 {edge} 182 {edge - 8} Q166 {edge - 16} 155 {edge - 19} "
                  f"Q132 {edge - 5} 106 {edge}")
    return f"Q223 151 214 {edge}{fringe}Q101 145 93 176"


def _hairline(look, head):
    line = look["hairline"]
    if (look.get("hair_length") or look["age"] == "child" or look["hair_style"] == "shoulder_locks"
            or look["brow_shape"] in {"heavy_ridge", "soft_arch"}):
        return _brow_safe_hairline(look, head)
    if look["hair_density"] == "thick":
        if line == "receding" and look["skull"] == "long" and look["eye_spacing"] == "wide":
            return (
                "Q228 156 223 145Q219 116 205 112Q194 126 180 121"
                "Q153 101 139 106Q125 115 114 110Q98 117 98 144L91 176"
            )
        return _HAIRLINES[line]
    if line == "straight":
        return "Q222 154 218 140Q162 120 106 140Q103 159 93 176"
    if line == "receding":
        return (
            "Q223 156 220 148Q222 126 204 120Q188 133 177 124"
            "Q159 108 143 114Q130 126 115 118Q103 127 103 149L93 176"
        )
    return _RECEDED_LINE


def _crown_path(look, head):
    style = look["hair_style"]
    density = look["hair_density"]
    if style == "steppe_braids":
        return hairstyle_shapes.STEPPE_CROWN
    if density == "open_crown":
        return _OPEN_CROWN[look["hairline"]]
    if density == "thinning" and style in {"short", "tied", "braided"}:
        crown = _THIN_CROWN
    elif style == "short" and look["hair_texture"] != "straight":
        crown = _TEXTURE_EDGES[look["hair_texture"]]
    else:
        crown = _CROWNS.get(style) or hairstyle_shapes.CROWNS[style]
    if style == "ear_length":
        crown += "Q226 172 226.5 174"
    crown += _hairline(look, head)
    if style == "ear_length":
        crown += "Q94 185 97 198"
    return crown + "Z"


def _braids_behind_face(look):
    gear, style = look["headgear"], look["hair_style"]
    if style not in {"braided", "double_braids", "steppe_braids"}:
        return False
    return gear in headwear.SIDE_BRAID_GEAR or (
        COVERAGE[gear]["hair"] and (style != "steppe_braids" or gear != "wrap")
    )


def draw_back_hair(parent, defs, look, head):
    style = look["hair_style"]
    shape = _BACKS.get(style) or hairstyle_shapes.BACKS.get(style)
    gear = look["headgear"]
    if gear in _HELMETS | {"wrap"} or shape is None or (look["age"] == "child" and _braids_behind_face(look)):
        return
    covered_crown = gear == "cap" or (gear in headwear.COVERAGE and gear not in headwear.OPEN_CROWNS)
    if style in {"tied", "high_knot"} and covered_crown:
        return
    transform = _temple_transform(head) if style == "shoulder_locks" else _hair_transform(head)
    if covered_crown:
        back = node(parent, "g", id="hair-back")
        if gear == "cap":
            back = _clip_group(back, defs, "hair-cap-back-reveal", _cap_hair_reveal(look, head))
        else:
            fit = headwear.HeadwearFit.for_head(look, head)
            back = _clip_group(back, defs, "headgear-hair-back-reveal", fit.hair_reveal(gear))
        group = node(back, "g", transform=transform)
    else:
        group = node(parent, "g", id="hair-back", transform=transform)
    base, light, shade, stroke = hair_palette(look)
    path(group, shape, shade, class_="edge")
    if style == "tied":
        path(group, "M208 77q27-12 45 3 10 8 7 23-8-14-26-15-17-3-31 8Z", light)
        _stroke(group, "M227 76q22 0 29 17m-21-7q17 5 22 16m-27-5q19 5 22 17", stroke)
    elif style == "long":
        path(group, "M66 193q5 52-10 96l12-13-4 17 16-15 14-49Zm179 41q4 28 22 63l-16-9 2 12-22-18Z", base)
        _stroke(group, "M69 234q-1 21-10 38m183-26q5 20 16 35", stroke)
    elif style in hairstyle_shapes.BUNCH_DETAIL:
        highlight, texture = hairstyle_shapes.BUNCH_DETAIL[style]
        art = _clip_group(group, defs, "hair-bunch-clip", shape)
        path(art, highlight, light)
        _stroke(art, texture, stroke, 1.7)


def _long_panels(parent, defs, look, clip_id):
    base, light, shade, stroke = hair_palette(look)
    form = _LONG_ENDS[look["hair_texture"]]
    path(parent, form, base, class_="edge")
    art = _clip_group(parent, defs, clip_id, form)
    path(art, "M73 156q3 38 10 60 9 34-12 71 21-14 21-38 0-16-10-55l-1-36Z"
         " M231 180q9 31 8 60-1 24 18 45-6-18-6-38 1-42-20-67Z", light)
    path(art, "M56 280q27-20 29-72 9 51-16 78Zm177-57q7 47 26 66l-24-11Z", shade)
    texture = {
        "straight": "M76 170q-2 42 1 53 6 24-6 46M82 180q-1 34 4 55m151-55q7 37 7 54 1 24 9 38",
        "wavy": "M75 179q-5 20 3 40t-7 46m11-54q12 23 1 42m149-69q-2 18 7 42t6 44",
        "curly": "M71 195q16 5 11 15-3 4-7 2m3 15q14 7 3 15m-6 9q13 7 4 17m162-60q-10 9 2 18m0 9q-8 13 6 22",
        "coiled": "M67 196q9-6 12 2m-7 9q10-5 14 5m-7 6q9 4 4 11m-10 9q9-4 12 5m-11 5q8 6 4 12m157-52q8-5 12 3m-10 8q9-4 13 5m-9 7q9-3 13 6m-10 6q11-2 11 8",
    }[look["hair_texture"]]
    _stroke(art, texture, stroke, 1.6)


def _braid(parent, look, *, gathered=False):
    base, light, shade, stroke = hair_palette(look)
    weave = ("10 16 3 30 7 12-1 25l-4 13-2 13-12-1 1-16"
             "q-10-12-5-23-10-16-4-27-10-12-5-24")
    if gathered:
        form = f"M220 155C232 169 227 181 238 193Q251 207 243 218q{weave}C218 181 208 169 220 155Z"
    else:
        form = f"M222 163q18-3 19 20 11 21 2 35 {weave}-10-13-3-27Z"
    path(parent, form, base, class_="edge")
    path(parent, ("M229 184Q235 188 237 192" if gathered else "M227 173q13 5 10 19")
         + "l-15 9 15 9q4 7 2 15l-12 8"
         " 12 8q4 8 0 14l-8 4 9 12-5 13-5-6q-8-9-5-19-7-13-3-24"
         "-9-12-4-25-7-15 0-24Z", shade)
    path(parent, "M215 192q9 1 20 9l-5 6q-12-8-16-11Zm6 23q9 2 20 10l-4 7"
         "q-12-9-17-11Zm5 24q7 4 15 12l-5 6-11-10Zm2 23 13 9-4 5-10-8Z", light)
    _stroke(parent, "M218 202q10-8 20-11m-16 34q8-10 19-13m-16 34q7-8 16-11"
            "m-12 34q3-6 13-9", "#382927", 2)
    _stroke(parent, "M218 194l8 4m-2 21 10 5m-7 18 10 7m-8 16 8 5", stroke, 1.6)
    path(parent, "M228 282q7 2 14-1l-1 8q-7 3-14 0Z", "#925b45", class_="edge")
    path(parent, "M229 291q5 1 11-1 1 12-6 18l-4-5-4 2Z", shade, class_="seam")


def _draw_hair_lock(parent, defs, look, identifier, drawing, *, accents=(), adult_crown=False):
    base, light, shade, stroke = hair_palette(look)
    form, shadow, highlight, flow = drawing
    path(parent, form, base, class_="edge")
    art = _clip_group(parent, defs, identifier, form)
    path(art, shadow, shade)
    path(art, highlight, light)
    _stroke(art, flow, stroke, 1.65)
    if adult_crown and look["hair_texture"] in {"curly", "coiled"}:
        _stroke(art, _TEXTURE_STROKES[look["hair_texture"]], stroke, 1.4)
    if adult_crown and look["graying"] == "temples":
        path(art, "M81 133Q90 136 105 130L104 150Q96 161 94 174L83 169Z"
             " M215 130Q226 136 238 129L238 169 225 175Q222 159 215 150Z", _SILVER[0])
        _stroke(art, "M92 140q2 11 1 20m7-24q-1 10-3 14m125-15q4 10 5 21m2-22q4 9 4 19", _SILVER[3])
    for color, accent in accents:
        path(art, accent, color)


def _draw_scalp_stubble(parent, defs, look, head):
    base, light, shade, _ = hair_palette(look)
    clipped = node(parent, "g", id="hair-scalp-stubble", clip_path="url(#face-shape-clip)")
    group = node(clipped, "g", transform=_hair_transform(head))
    density = look["hair_density"]
    if density == "open_crown":
        scalp = _OPEN_CROWN[look["hairline"]]
    else:
        scalp = f"M50 45H270V174H226.5{_brow_safe_hairline(look, head)}H50Z"
    grain = node(defs, "pattern", id="hair-scalp-grain", width=11, height=11, pattern_units="userSpaceOnUse")
    _stroke(grain, "M1.6 3l.6-1.2m5 1.5.2-1.1M5 7.9l.4-1.1m3.7 3.2.8-1.4", shade, 1.25)
    _stroke(grain, "M3.2 4.4l.4-.7m3.7 2.8.6-.8", light, .8)
    path(group, scalp, base, opacity=".49" if density == "thinning" else ".62")
    path(group, scalp, "url(#hair-scalp-grain)", opacity=".8")


def draw_hair(parent, defs, look, head):
    hat = look["headgear"]
    style = look["hair_style"]
    if not COVERAGE[hat]["hair"] or style == SHAVED_STYLE:
        return
    fitted_crown = hairstyle_shapes.FITTED_CROWNS.get(style)
    crown_exposed = hat == "none" or hat in headwear.OPEN_CROWNS
    if not crown_exposed and style in hairstyle_shapes.FITTED_SHAVED:
        return
    if hat == "wrap":
        if wrap_shows_hairline(look):
            foreground = node(parent, "g", id="hair-front", clip_path="url(#face-shape-clip)")
            fringe = _clip_group(foreground, defs, "hair-wrap-fringe",
                                 _cap_face_opening(look, expose_crown=True))
            if style == STUBBLE_STYLE:
                _draw_scalp_stubble(fringe, defs, look, head)
            else:
                crown = node(fringe, "g", transform=_hair_transform(head))
                _draw_hair_crown(crown, defs, look, head, exposed=False)
        return
    foreground = node(parent, "g", id="hair-front")
    if hat == "cap":
        foreground = _clip_group(foreground, defs, "hair-cap-reveal", _cap_hair_reveal(look, head))
        foreground = _clip_group(foreground, defs, "hair-cap-face", _cap_face_opening(look))
    elif hat in headwear.COVERAGE and hat not in headwear.OPEN_CROWNS:
        fit = headwear.HeadwearFit.for_head(look, head)
        foreground = _clip_group(foreground, defs, "headgear-hair-front-reveal", fit.hair_reveal(hat))
    safe_forehead = fitted_crown is not None or look.get("hair_length") or style == "shoulder_locks"
    if hat in headwear.OPEN_CROWNS or (hat == "none" and safe_forehead):
        clip = "hair-shoulder-face" if style == "shoulder_locks" and hat == "none" else "headgear-hair-face"
        foreground = _clip_group(foreground, defs, clip, _cap_face_opening(look, expose_crown=True))
    elif hat in headwear.COVERAGE:
        foreground = _clip_group(foreground, defs, "headgear-hair-face", _cap_face_opening(look))
    if style == STUBBLE_STYLE:
        _draw_scalp_stubble(foreground, defs, look, head)
        return
    group = node(foreground, "g", transform=_hair_transform(head))
    _draw_hair_crown(group, defs, look, head, exposed=crown_exposed)


def _draw_hair_crown(group, defs, look, head, *, exposed):
    style = look["hair_style"]
    fitted_crown = hairstyle_shapes.FITTED_CROWNS.get(style)
    if fitted_crown is not None:
        adult_style = style in hairstyle_shapes.ADULT_CASTS
        drawing = fitted_crown
        if not exposed:
            drawing = hairstyle_shapes.FITTED_COVERED_CROWNS.get(
                style, fitted_crown if adult_style else hairstyle_shapes.COVERED_CROWN,
            )
        if style == "adult_rus_parted_waves" and look["hair_texture"] == "straight":
            drawing = PARTED_STRAIGHT_CROWN
        accents = hairstyle_shapes.FITTED_ACCENTS.get(style, ()) if exposed else ()
        _draw_hair_lock(group, defs, look, "hair-crown-clip", drawing, accents=accents, adult_crown=adult_style)
        return

    base, light, shade, stroke = hair_palette(look)
    crown = _crown_path(look, head)
    texture = look["hair_texture"]
    density = look["hair_density"]
    if style == "high_knot" and density == "open_crown":
        path(group, hairstyle_shapes.OPEN_KNOT_TIE, base)
        _stroke(group, "M104 104Q126 78 151 72", stroke, 1.7)
    path(group, crown, base, class_="edge")
    detail = _clip_group(group, defs, "hair-crown-clip", crown)
    path(detail, "M91 112q6-26 41-35 19-3 37-2 15-4 25-16-6 21-26 26"
         "-13 15-39 25l-28 11-7 14 3-19Zm76-20q22-1 37-12-3 9-9 12"
         " 13 4 21 14-25-5-38-11Z", light)
    path(detail, "M79 128q8 12 17 21l1 26-14-12Zm123-38 26-13 13 25Z"
         " M210 121q22 7 27 39l-11 21Z", shade)
    if look["graying"] in {"temples", "mixed"}:
        path(detail, "M80 124q14 7 24 0l-3 18-9 28-11-8 6-10Z"
             " M213 120q20 8 25 26l-10 27-5-10-1-17Z", _SILVER[0])
        _stroke(detail, "M88 136q4 10 3 22m7-24-3 16m128-19 4 21m3-12 2 11", _SILVER[3])
    flow = hairstyle_shapes.FLOW.get(style)
    if flow:
        _stroke(detail, flow, stroke, 2.2)
    if not flow or (style != "steppe_braids" and texture in {"curly", "coiled"}):
        _stroke(detail, _TEXTURE_STROKES[texture], stroke, 1.45 if texture == "straight" else 1.8)
    if look["graying"] == "mixed":
        _stroke(detail, "M95 111q14-17 36-25m-16 24 16-7m12-21q22 0 33-9"
                "m-7 25q22 4 38 17m-4-16 14 11", _SILVER[3], 2.2)
    part = look["part"]
    if part != "none" and density != "open_crown" and style != "steppe_braids":
        divide = {
            "center": "M157 111q7-14 5-33-1-10 3-22",
            "side": "M124 120q-11-5-12-20 0-12 6-25",
        }[part]
        _stroke(detail, divide, shade, 5)
        _stroke(detail, divide, head.skin.shade, 2.15)
    if density == "thinning":
        _stroke(detail, "M105 102q11-16 28-24m-2 11 15-10m8-2q21-4 43 3m-13 4 19 5",
                head.skin.shade, 2.6)


def _jaw_transform(head: HeadGeometry):
    width = 0.74 + (head.jaw_half - 32) * (0.41 / 33)
    return f"translate(160 {number(head.chin_y)}) scale({number(width)} 1) translate(-160 -254)"


def _facial_hair_layer(parent, defs, look, kind, clearance, *, compact_mouth=False, **attrs):
    identifier = f"hair-{kind}"
    clip_id = f"{identifier}-mouth-reveal"
    clip = node(defs, "clipPath", id=clip_id)
    opening = facial_hair_mouth_opening(look, clearance, compact_mouth=compact_mouth)
    path(clip, "M0 0H320V440H0Z " + opening, clip_rule="evenodd")
    return node(parent, "g", id=identifier, clip_path=f"url(#{clip_id})", **attrs)


def _moustache_lip_clearance(defs, look, padding, *, compact_mouth):
    # A round stroke around the actual lip shape leaves space at the corners too.
    mask_id = "hair-moustache-lip-clearance"
    bounds = {"x": 0, "y": 0, "width": 320, "height": 440}
    mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse", **bounds)
    node(mask, "rect", fill="white", **bounds)
    lip = facial_hair_mouth_opening(look, 0, compact_mouth=compact_mouth)
    path(mask, lip, "black", stroke="black", stroke_width=2 * padding,
         stroke_linejoin="round")
    return f"url(#{mask_id})"


def _draw_beard(parent, defs, look, head, *, compact_mouth=False):
    style = look["beard"]
    if style == "none":
        return
    layer = _facial_hair_layer(parent, defs, look, "beard", 5.8 if compact_mouth else 2.5,
                               compact_mouth=compact_mouth)
    if style == "stubble":
        layer = node(layer, "g", clip_path="url(#face-shape-clip)")
    group = node(layer, "g", transform=_jaw_transform(head))
    if style in facial_hair_shapes.BEARDS:
        _draw_shaped_beard(group, defs, look)
        return
    base, light, shade, stroke = hair_palette(look)
    form = {
        "stubble": "M101 201q12 17 24 22l10 12q25 13 50-1l10-13q15-7 23-20"
        "l-6 23q-13 22-33 28-27 9-48-2-20-10-27-35Z",
        "short": "M96 192q8 19 27 30l9 13q12 11 28 10 16 0 27-11l8-12q17-9 29-30"
        "-2 29-17 48-20 25-47 25-26-1-46-22-16-17-18-51Z",
        "broad": "M97 192q11 23 27 31l7 11q14 11 29 10 18 1 29-11l7-12q16-9 28-30"
        "Q225 222 217 248l-4-2q2 9-4 15l-6-3q-4 11-13 13l-3-3q-11 9-22 8l-5-3"
        "q-11 8-21 2l-7-5q-11 4-17-7l-4 1q-7-8-6-17l-4 2Q94 224 97 192Z",
        "long": "M97 192q9 20 26 30l8 12q13 11 29 10 17 0 29-12l7-11q18-9 28-29"
        " 0 38-16 58-11 20-23 29l-9 13-4-4-14 16-6-11-6 1-11-17-7-1"
        "-8-15q-26-31-23-69Z",
    }[style]
    if style == "stubble":
        path(group, form, base, opacity=".42")
        path(group, form, "url(#ink-lines)", opacity=".74")
        _stroke(group, "M113 220l2 4m7 9 2 3m12 8 2 4m9-2 1 4m12-2 1 4"
                "m12-7 1 4m12-9-1 4m10-10-1 4m10-14-2 4", shade, 1.9, opacity=".7")
        return
    path(group, form, base, class_="edge")
    detail = _clip_group(group, defs, "hair-beard-clip", form)
    path(detail, "M103 213q12 30 33 36 7 3 20 2-4 13-13 28-28-15-40-38Z"
         " M224 203q-10 20-19 28-12 17-26 21l10 36q29-31 35-60Z", shade)
    path(detail, "M125 231q19 13 35 12 17-1 33-14-13 19-23 27l-5 22-12 16"
         " 2-28-7-8q-15-10-23-27Z", light)
    _stroke(detail, "M110 223q5 11 12 17m4 4 6 8m7-1 4 8m10-7 3 13m7-13-1 11"
            "m8-12 7 11m4-15-1 10m9-11-3 9m13-22-3 10m-43 21 1 12"
            "m10-11-3 16m17-17-5 14", stroke, 1.85)
    if look["graying"] in {"temples", "mixed"}:
        _stroke(detail, "M105 208q4 14 11 20m2 3 4 7m89-22-8 14m-2 1-6 10", _SILVER[1], 3.6)
    if look["graying"] == "mixed":
        _stroke(detail, "M130 241q13 8 18 19m7-14 3 10m10 4-2 15m12-29 7-9", _SILVER[3], 2.1)


def _draw_shaped_beard(group, defs, look):
    base, light, shade, stroke = hair_palette(look)
    form, shadow, highlight, flow = facial_hair_shapes.BEARDS[look["beard"]]
    path(group, form, base, class_="edge")
    detail = _clip_group(group, defs, "hair-beard-clip", form)
    path(detail, shadow, shade)
    path(detail, highlight, light)
    _stroke(detail, flow, stroke, 1.85)
    if look["graying"] in {"temples", "mixed"}:
        _stroke(detail, "M104 209q5 19 18 29m7 4 7 12M213 210q-4 16-17 26", _SILVER[1], 3.3)
    if look["graying"] == "mixed":
        _stroke(detail, "M139 250q6 4 8 12m8-11 2 15m11-16-3 18m20-19-5 13", _SILVER[3], 2.1)


_MOUSTACHES = {
    "short": "M156 208q-5-2-12 0-9 1-13 8 8-2 13-2 7 0 12-3Z",
    "broad": "M157 209q-8-4-18-1-14 1-20 13 10-5 18-4 10 0 19-5Z",
}
_MOUSTACHE_HEIGHTS = {"short": (205, 218), "broad": (204, 223)}
_MOUSTACHE_POINT = re.compile(r"(\d+(?:\.\d+)?) (\d+(?:\.\d+)?)")


def _draw_growing_moustache(parent, look, head, style, *, card, compact_mouth):
    full = look.get("moustache_growth", "full") == "full"
    nose, lip, mouth_half, corner = moustache_band(look, compact_mouth=compact_mouth)
    top = nose + 1.9
    band = max(3, lip - top + (1.1 if full else -.7))
    half_width = min(mouth_half + 12, head.temple_half - 16, head.cheek_half - 13, head.jaw_half - 9)
    width_scale = half_width / 46 * (1 if full else .86)
    if card and style == "forked_ends":
        width_scale = min(width_scale, head.jaw_half / 64)
    tail_scale = .5
    tip_scale = width_scale
    bend_start, bend_length = 0, 22
    outline, strands = facial_hair_shapes.GROWING_MOUSTACHES[style]
    if compact_mouth:
        # The bulk of the moustache stays above the card's light separator row.
        top = max(top, lip - 22)
        band = max(4, min(11.5, 218.6 - top, lip - top - 8))
        band *= 1 if full else .92
        outline = facial_hair_shapes.DENSE_CARD_MOUSTACHES[style]
        if style == "solid_chevron":
            tail_scale = .82 if full else .76
    if style in facial_hair_shapes.DROOPING_MOUSTACHES:
        tip_scale = min(half_width * .80, head.jaw_half - 14) / 51
        bend_start = max(0, corner - (top + band))
        tail_depth, medium_tail = 30, .45
        if style == "long_split":
            # Leave room for the chin to narrow below the mouth.
            chin_margin = 14
            if head.jaw_half < 50:
                chin_margin = 17
            elif head.jaw_half >= 65:
                chin_margin = 8
            if card:
                chin_margin += 5
            tail_depth, medium_tail = 40, .55
            full_tail = min(.92, max(.12, (head.chin_y - (top + band) - chin_margin) / tail_depth))
            tip_width = .63 if card and head.jaw_half < 65 else .77
            tip_scale = min(half_width * tip_width, head.jaw_half - 16) / 51
            bend_length = 12
            if not full:
                width_scale = half_width / 46 * .96
        else:
            full_tail = min(.83, max(.12, (head.chin_y - lip - 10) / tail_depth))
        if head.jaw_half - mouth_half <= (18 if card else 15):
            # With little room beside the mouth, end the strands above its corners.
            full_tail = min(full_tail, max(.10, (corner - 1.7 - (top + band)) / tail_depth))
        tail_scale = full_tail * (1 if full else medium_tail)
    rise_scale = min(.60, max(.52, band / 20)) if full else min(.46, max(.38, band / 20))

    def fit(point):
        x, y = map(float, point.groups())
        tail = max(0, y - 220) * tail_scale
        # Follow the jaw inwards as longer ends drop below the mouth.
        bend = min(1, max(0, tail - bend_start) / bend_length)
        x = 160 + (x - 160) * (width_scale + (tip_scale - width_scale) * bend)
        height = (min(y, 220) - 200) * band / 20
        if y < 200 and style in facial_hair_shapes.RAISED_MOUSTACHES:
            height = (y - 200) * rise_scale
        y = top + height + tail
        return f"{number(x)} {number(y)}"

    base, light, shade, stroke = hair_palette(look)
    path(parent, _MOUSTACHE_POINT.sub(fit, outline), base,
         stroke=shade, stroke_width=1.85, stroke_linejoin="round")
    if not card:
        _stroke(parent, _MOUSTACHE_POINT.sub(fit, strands), stroke if look["graying"] == "mixed" else light, 1.35)


def has_dense_card_moustache(look):
    return (look["headgear"] != "nw_great_helm"
            and visible_facial_hair(look)[1] in facial_hair_shapes.DENSE_CARD_MOUSTACHES)


def draw_facial_hair(parent, defs, look, head, *, card=False):
    gear = look["headgear"]
    if gear == "nw_great_helm":
        return
    beard, style = visible_facial_hair(look)
    if (beard, style) == ("none", "none"):
        return
    if gear in _HELMETS:
        parent = _facial_hair_under_mail(parent, defs, look, head)
    compact_mouth = card and style in facial_hair_shapes.DENSE_CARD_MOUSTACHES
    _draw_beard(parent, defs, {**look, "beard": beard}, head, compact_mouth=compact_mouth)
    if style == "none":
        return
    growing = style in facial_hair_shapes.GROWING_MOUSTACHES
    clearance = 6.1 if compact_mouth else 4.1 if card and growing else 1.8
    if not card and style in facial_hair_shapes.MOUSTACHE_CONTOURS:
        clearance = 3.2
    padding = 6.8 if card else 4.6
    if card and style in facial_hair_shapes.RAISED_MOUSTACHES:
        padding = 8.2
    lip_mask = _moustache_lip_clearance(defs, look, padding, compact_mouth=compact_mouth)
    visible = _facial_hair_layer(parent, defs, look, "moustache", clearance, compact_mouth=compact_mouth,
                                 mask=lip_mask)
    visible = node(visible, "g", clip_path="url(#face-shape-clip)")
    if growing:
        _draw_growing_moustache(visible, look, head, style, card=card, compact_mouth=compact_mouth)
        return
    base, light, shade, stroke = hair_palette(look)
    shapes = facial_hair_shapes.CARD_MOUSTACHES if card else facial_hair_shapes.MOUSTACHES
    new_shape = MOUSTACHE_STUBBLE if style == "stubble" else shapes.get(style)
    if new_shape:
        outline, highlight, (start, end), thickness = new_shape
    else:
        start, end = _MOUSTACHE_HEIGHTS[style]
        thickness = 1.9 if style == "short" else 2.3
        outline = _MOUSTACHES[style]
        highlight = "M151 209.5q-7 1-12 3"
        if style == "broad" and look["lip_volume"] == "full":
            outline = "M157 209q-8-4-18-1-14 1-20 13 10-8 18-7 10-2 19-4Z"
    top, bottom, _, _ = moustache_band(look)
    available = max(1, bottom - top)
    # With a low nose and high lips, keep some volume at the ends beside the mouth.
    height = min(end - start, max(6, available * .82))
    y_scale = height / (end - start)
    y = top + max(.75, (available - height) / 2) - start * y_scale
    x_scale = 1
    if style in facial_hair_shapes.FITTED_MOUSTACHES:
        # Reserve space between the moustache ends and the side locks.
        half_width = min(head.temple_half - 17, (head.cheek_half + head.jaw_half) / 2 - 11)
        x_scale = min(1, half_width / 64)
    position = f"matrix({number(x_scale)} 0 0 {number(y_scale)} {number(160 * (1 - x_scale))} {number(y)})"
    group = node(visible, "g", transform=position)
    offset = {"narrow": 2, "medium": 0, "wide": -3}[look["nose_width"]] if new_shape and card else 0
    for transform in (None, "translate(320 0) scale(-1 1)"):
        wing = group if transform is None else node(group, "g", transform=transform)
        if offset:
            wing = node(wing, "g", transform=f"translate({offset} 0)")
        path(wing, outline, base, stroke=shade, stroke_width=thickness, stroke_linejoin="round")
        _stroke(wing, highlight, stroke if look["graying"] == "mixed" else light, 1.35)


_MAIL_SHOULDER_HALF = {"slim": 96, "medium": 111, "full": 126, "athletic": 129}
_WRAP_HEMS = {"right": ((242, 233), (218, 245)), "left": ((78, 231), (102, 242))}
# Slide the root inward under the cloth and leave the end at shoulder level.
_COVERED_LOCK_SLOPE = {
    "adult_steppe_long_braids": (.30, 314),
    "adult_iran_two_braids": (.115, 356),
    "child_rus_nape_braid": (.24, 308),
    "adult_japan_long_hair": (.075, 330),
    "adult_castile_shoulder_waves": (.14, 350),
    "child_rus_swept_loose": (.17, 305),
}
_LOOSE_UNDER_WRAP = {
    "straight": ((.20, .17), 318),
    "wavy": ((.13, .22), 318),
    "curly": ((.28, .23), 318),
    "coiled": ((.38, .27), 318),
    "shoulder_locks": ((.17, .25), 310),
}
(_WRAP_RIGHT_OUT, _WRAP_RIGHT_IN), (_WRAP_LEFT_OUT, _WRAP_LEFT_IN) = (
    tuple(f"{x} {y}" for x, y in _WRAP_HEMS[side]) for side in ("right", "left")
)
_WRAP_OUTSIDE = (
    "M67 175Q62 144 76 104Q90 68 122 54Q152 39 185 52Q220 55 238 88"
    f"Q255 117 252 159Q251 210 {_WRAP_RIGHT_OUT}L{_WRAP_RIGHT_IN}"
)
_CHILD_WRAP = _WRAP_OUTSIDE + (
    "Q231 216 231 173Q230 132 220 111Q184 90 155 93"
    f"Q124 94 105 106Q91 122 89 173Q87 208 {_WRAP_LEFT_IN}L{_WRAP_LEFT_OUT}Q69 202 67 175Z"
)
_WRAP_FOREHEAD_LIFT = {"stubble": 0, "short": 4, "medium": 14, "long": 17}


def wrap_shows_hairline(look):
    return (look["age"] != "child" and look.get("hair_length") in _WRAP_FOREHEAD_LIFT
            and look["hair_style"] not in hairstyle_shapes.FITTED_SHAVED)


def _wrap_shape(look, head):
    if look["age"] == "child":
        return _CHILD_WRAP
    band = min(93, brow_top(look, include_standard=True) - 23)
    top, corners = band, band + 15
    if wrap_shows_hairline(look):
        top = max(head.top_y + 5, band - _WRAP_FOREHEAD_LIFT[look["hair_length"]])
        corners = max(band + 11, top + 15)
    clearance = {"close": 58, "balanced": 60, "wide": 65}[look["eye_spacing"]]
    half = max(69, (clearance + 3) * 68 / head.temple_half)
    left, right = 160 - half, 160 + half
    return _WRAP_OUTSIDE + (
        f"Q233 214 {number(right)} 173Q{number(right - 1)} 133 {number(right - 13)} {number(corners)}"
        f"Q190 {number(top - 2)} 155 {number(top)}Q124 {number(top + 1)} {number(left + 13)} {number(corners)}"
        f"Q{number(left + 1)} 133 {number(left)} 173Q87 208 {_WRAP_LEFT_IN}"
        f"L{_WRAP_LEFT_OUT}Q69 202 67 175Z"
    )


def _hem_opening(side, hem, bottom, *, curved=False):
    (outer_x, outer_y), (inner_x, inner_y) = hem
    outside = 320 if side == "right" else 0
    # The hair below the inner corner of the scarf turns toward the shoulder.
    inside = f"Q{inner_x} {inner_y + 18} 160 {inner_y + 34}" if curved else "H160"
    return f"M{outside} {outer_y}H{outer_x}L{inner_x} {inner_y}{inside}V{bottom}H{outside}Z"


def _tuck_under_hem(parent, slope, end):
    return node(parent, "g", transform=f"matrix(1 0 {number(slope)} 1 {number(-slope * end)} 0)")


def _draw_hair_sides(parent, defs, look, head):
    gear, style = look["headgear"], look["hair_style"]
    custom = hairstyle_shapes.FITTED_LOCKS.get(style)
    if style == "adult_rus_parted_waves" and look["hair_texture"] == "straight":
        custom = PARTED_STRAIGHT_LOCK
    age = "adult" if style in hairstyle_shapes.ADULT_CASTS else "child"
    identifier = f"hair-{age}-locks" if custom is not None else "hair-braid"
    hem_limit = 440 if age == "adult" else 337
    braids = node(parent, "g", id=identifier, transform=_temple_transform(head))
    wrapped = gear == "wrap"
    new_hem = headwear.BRAID_HEMS.get(gear)
    paired = style in hairstyle_shapes.FITTED_PAIRED_LOCKS if custom is not None else style != "braided"
    for side in (("right", "left") if paired else ("right",)):
        braid = braids
        hem = _WRAP_HEMS[side] if wrapped else new_hem
        if hem is not None:
            if new_hem is not None and side == "left":
                hem = tuple((320 - x, y) for x, y in hem)
            clip_id = f"hair-wrap-braid-{side}" if wrapped else f"hair-headgear-braid-{side}"
            braid = _clip_group(braids, defs, clip_id, _hem_opening(side, hem, hem_limit, curved=wrapped))
        if side == "left":
            braid = node(braid, "g", transform="translate(320 0) scale(-1 1)")
        if wrapped and style == "adult_rus_single_braid":
            _draw_hair_lock(braid, defs, look, "hair-wrap-single-braid", WRAPPED_SINGLE_BRAID,
                            accents=WRAPPED_BRAID_TIE)
        elif custom is not None:
            if hem is not None and style in _COVERED_LOCK_SLOPE:
                braid = _tuck_under_hem(braid, *_COVERED_LOCK_SLOPE[style])
            elif style == "adult_steppe_folded_braids" and look["ear_size"] == "large":
                braid = node(braid, "g", transform="translate(0 150) scale(1 1.13) translate(0 -150)")
            _draw_hair_lock(braid, defs, look, f"hair-{age}-lock-{side}", custom,
                            accents=hairstyle_shapes.FITTED_ACCENTS.get(style, ()))
        elif style == "steppe_braids":
            _draw_hair_lock(braid, defs, look, f"hair-steppe-braid-{side}", hairstyle_shapes.STEPPE_BRAID)
        else:
            offset = (-3 if wrapped else 0) + (0 if paired else -2)
            shift = 10 if paired else 3
            _braid(node(braid, "g", transform=f"translate({offset} {shift})"), look, gathered=not wrapped)


def _helmet_rise(look):
    return max(0, 128 - brow_top(look, include_standard=True))


def _draw_mail_base(parent, defs, look, head):
    x_scale = 0.88 + (head.temple_half - 61) / 62.5
    transform = f"matrix({number(x_scale)} 0 0 1 {number(160 * (1 - x_scale))} 0)"
    half = _MAIL_SHOULDER_HALF[look.get("body", "medium")] / x_scale
    if look["age"] == "child":
        half *= CHILD_BODY_SCALE
    left, right = 160 - half, 160 + half
    top = number(112 - _helmet_rise(look))
    shape = (
        f"M83 {top}Q76 168 64 209C55 244 {number(left + 19)} 274 {number(left)} 294"
        f"Q{number(left + 59)} 317 160 317Q{number(right - 59)} 317 {number(right)} 292"
        f"C{number(right - 19)} 274 262 245 253 209L237 {top}Z"
    )
    clip = node(defs, "clipPath", id="hair-mail-outline")
    path(clip, shape, transform=transform)
    mail = node(parent, "g", id="hair-mail-base")
    art = node(mail, "g", clip_path="url(#hair-mail-outline)")
    folds = node(art, "g", transform=transform)
    path(folds, shape, "#5b5b51")
    path(folds, shape, "url(#mail-rings)", opacity=".76")
    path(folds, "M93 136q-1 70-19 116l-22 50 65 10q-21-44-11-108Z"
         " M227 136q-3 64-22 120l-4 59 67-12q-27-43-26-102Z", "#302b2b", opacity=".56")
    path(folds, "M69 213q-6 48-37 77l16 8q25-34 30-74Z"
         " M234 229q13 34 14 70l18-6Z", "#a7a592", opacity=".28")
    path(folds, f"M{number(left + 12)} 294Q{number(left + 66)} 312 160 313"
         f"Q{number(right - 66)} 313 {number(right - 12)} 293", class_="seam")
    path(mail, shape, "none", class_="edge", transform=transform)


_FITTED_AVENTAILS = {
    "nw_duboshin_helm": (0, 295),
    "nw_lykovo_helm": (1, 301),
    "nw_gjermundbu_helm": (-7, 286),
    "nw_pakalniskiai_helm": (-4, 291),
}


def _open_throat_edge(head, hem, inset=0):
    half = head.neck_half - inset
    nl, nr = 160 - half, 160 + half
    shoulder = number(227 + inset)
    return (
        f"{number(nr + 15)} {hem - 1} Q{number(nr + 5)} 270 {number(nr - 2)} 248 "
        f"Q{number(nr - 3)} {shoulder} 160 {number(229 + inset)} "
        f"Q{number(nl + 3)} {shoulder} {number(nl + 2)} 248 "
        f"Q{number(nl - 5)} 270 {number(nl - 15)} {hem - 1}"
    )


def _facial_hair_under_mail(parent, defs, look, head):
    gear = look["headgear"]
    identifier = "hair-helmet-beard-reveal"
    if gear not in _FITTED_AVENTAILS:
        return _clip_group(parent, defs, identifier, _mail_face_opening(look, head) + "Z")
    if not COVERAGE[gear]["neck"]:
        return node(parent, "g", clip_path="url(#face-shape-clip)")
    hem = _FITTED_AVENTAILS[gear][1]
    # Leave the dark edge of the mail visible around the opening at the throat.
    inset = 2.5
    right = 175 + head.neck_half - inset
    clip = node(defs, "clipPath", id=identifier)
    path(clip, face_outline(look, head))
    path(clip, f"M{_open_throat_edge(head, hem, inset)}V440H{number(right)}V{hem - 1}Z")
    return node(parent, "g", clip_path=f"url(#{identifier})")


def _draw_fitted_aventail(parent, defs, look, head):
    gear = look["headgear"]
    width_delta, hem = _FITTED_AVENTAILS[gear]
    rim_half, rim_y = headwear_northwest_military.helmet_rim(look, head)
    shoulders = _MAIL_SHOULDER_HALF[look["body"]] + width_delta
    left, right = 160 - shoulders, 160 + shoulders
    rim_left, rim_right = 160 - rim_half + 2, 160 + rim_half - 2
    ear_width, ear_height, ear_y = ear_fit(look)
    side = max(head.cheek_half - 6 + 34 * ear_width, rim_half + 16)
    side_left, side_right = 160 - side, 160 + side
    ear_top = number(ear_y - 13 * ear_height)
    ear_bottom = number(ear_y + 28 * ear_height)
    rise = number(ear_y - 28 * ear_height)
    top = number(rim_y - 3)
    if COVERAGE[gear]["neck"]:
        nl, nr = 160 - head.neck_half, 160 + head.neck_half
        edge = (
            f"Q{right - 24} {hem + 11} {_open_throat_edge(head, hem)} "
            f"Q{left + 24} {hem + 11} {left} {hem}"
        )
    else:
        edge = f"Q160 {hem + 29} {left} {hem}"
    outline = (
        f"M{number(rim_left)} {top}H{number(rim_right)} "
        f"C{number(rim_right + 4)} {number(rim_y + 10)} {number(side_right - 4)} {rise} {number(side_right)} {ear_top} "
        f"Q{number(side_right + 2)} {number(ear_y + 8)} {number(side_right + 1)} {ear_bottom} "
        f"Q{number((side_right + right) / 2)} 249 {right} {hem} {edge} "
        f"Q{number((side_left + left) / 2)} 249 {number(side_left - 1)} {ear_bottom} "
        f"Q{number(side_left - 2)} {number(ear_y + 8)} {number(side_left)} {ear_top} "
        f"C{number(side_left + 4)} {rise} {number(rim_left - 4)} {number(rim_y + 10)} {number(rim_left)} {top}Z"
    )
    mail = node(parent, "g", id="hair-mail-base", data_part="aventail", data_style=gear)
    path(mail, outline, "#5d5e54", class_="edge")
    mesh = _clip_group(mail, defs, "fitted-aventail-outline", outline)
    path(mesh, f"M{number(rim_left + 13)} {top}Q{number(side_left + 7)} 202 {left + 14} {hem + 2} "
         f"L{left + 36} {hem + 6}Q{number(183 - rim_half)} 207 {number(rim_left + 22)} {top}Z",
         "#a19c88", opacity=".37")
    path(mesh, f"M{number(rim_right - 13)} {top}Q{number(side_right - 25)} 236 {right - 33} {hem + 10} "
         f"L{right + 8} {hem + 10}Q{number(side_right + 6)} 199 {number(rim_right)} {top}Z",
         "#393532", opacity=".62")
    path(mesh, outline, "url(#mail-rings)", opacity=".82")
    if COVERAGE[gear]["neck"]:
        _stroke(mail, f"M{number(nr + 15)} {hem - 1}Q{number(nr + 5)} 270 {number(nr - 2)} 248 "
                f"M{number(nl - 15)} {hem - 1}Q{number(nl - 5)} 270 {number(nl + 2)} 248", "#8b8372", 1.05)
    else:
        _stroke(mesh, f"M{left + 7} {hem - 6}Q160 {hem + 21} {right - 7} {hem - 6}", "#aaa18c", 1.25)


def _draw_loose_fall(parent, defs, look, head):
    gear = look["headgear"]
    shoulder = look["hair_style"] == "shoulder_locks"
    stem = "hair-shoulder" if shoulder else "hair-long"
    identifier = f"{stem}-fall"
    hair = node(parent, "g", id=identifier)
    if gear == "wrap":
        shape = "shoulder_locks" if shoulder else look["hair_texture"]
        slopes, end = _LOOSE_UNDER_WRAP[shape]
        scaled = node(hair, "g", transform=_temple_transform(head))
        for side, slope in zip(("left", "right"), slopes):
            reveal = _hem_opening(side, _WRAP_HEMS[side], 440, curved=True)
            clip_id = f"{identifier}-wrap-{side}"
            side_layer = _clip_group(scaled, defs, clip_id, reveal)
            locks = _tuck_under_hem(side_layer, -slope if side == "left" else slope, end)
            if shoulder:
                _draw_hair_lock(locks, defs, look, f"{clip_id}-detail", hairstyle_shapes.SHOULDER_FALL)
            else:
                _long_panels(locks, defs, look, f"{clip_id}-detail")
        return
    if gear == "cap":
        hair = _clip_group(hair, defs, f"{stem}-cap", _cap_hair_reveal(look, head))
    elif gear in headwear.COVERAGE and gear not in headwear.OPEN_CROWNS:
        fit = headwear.HeadwearFit.for_head(look, head)
        hair = _clip_group(hair, defs, f"{stem}-hat", fit.hair_reveal(gear))
    if shoulder:
        locks = node(hair, "g", transform=_temple_transform(head))
        _draw_hair_lock(locks, defs, look, f"{identifier}-clip", hairstyle_shapes.SHOULDER_FALL)
    else:
        locks = node(hair, "g", transform=_hair_transform(head))
        _long_panels(locks, defs, look, f"{identifier}-clip")


def draw_headgear_base(parent, defs, look, head):
    gear = look["headgear"]
    if gear in _FITTED_AVENTAILS:
        _draw_fitted_aventail(parent, defs, look, head)
    elif gear in _HELMETS:
        _draw_mail_base(parent, defs, look, head)
    elif gear == "wrap":
        lining = node(parent, "g", transform=_temple_transform(head),
                      data_material_slot="headgear" if look.get("headgear_material") else None)
        path(lining, _wrap_shape(look, head), "#574941", class_="edge")
    if look["hair_style"] in {"shoulder_locks", "long"} and COVERAGE[gear]["hair"]:
        _draw_loose_fall(parent, defs, look, head)
    if _braids_behind_face(look):
        _draw_hair_sides(parent, defs, look, head)
    elif look["hair_style"] in hairstyle_shapes.FITTED_LOCKS:
        covered_roots = gear == "wrap" or gear in headwear.BRAID_HEMS
        reveal = (look["hair_style"] in hairstyle_shapes.FITTED_LOCKS_UNDER_CLOTH
                  if covered_roots else COVERAGE[gear]["hair"])
        if reveal:
            _draw_hair_sides(parent, defs, look, head)


def _cap_curve_segment(curve, end_y):
    # Split the crown cubic at the height of the band to keep the forehead's curvature.
    start, first, second, end = curve
    low, high = 0, 1
    for _ in range(12):
        t = (low + high) / 2
        a = tuple(p + (q - p) * t for p, q in zip(start, first))
        b = tuple(p + (q - p) * t for p, q in zip(first, second))
        c = tuple(p + (q - p) * t for p, q in zip(second, end))
        d = tuple(p + (q - p) * t for p, q in zip(a, b))
        e = tuple(p + (q - p) * t for p, q in zip(b, c))
        tip = tuple(p + (q - p) * t for p, q in zip(d, e))
        if tip[1] < end_y:
            low = t
        else:
            high = t
    return a, d, (tip[0], end_y)


def _cap_band(look, forehead):
    center_y = min(119, brow_top(look, include_standard=True) - 3.5)
    side_y = center_y - 5
    _, _, (half_width, _) = _cap_curve_segment(forehead, side_y)
    return half_width + 4, center_y, side_y


def _cap_hair_reveal(look, head):
    forehead = ((0, head.top_y), *forehead_curve(look, head))
    half, center_y, side_y = _cap_band(look, forehead)
    left, right = 160 - half, 160 + half
    temple_left, temple_right = 160 - head.temple_half, 160 + head.temple_half
    return (
        f"M{number(left)} {number(side_y - 1)}Q160 {number(center_y + 4)}"
        f" {number(right)} {number(side_y - 1)}"
        f"Q{number(right + 9)} {number(side_y + 7)} {number(temple_right + 20)} 154"
        "L320 205V440H0V205"
        f"L{number(temple_left - 20)} 154Q{number(left - 9)} {number(side_y + 7)}"
        f" {number(left)} {number(side_y - 1)}Z"
    )


def _cap_face_opening(look, *, expose_crown=False):
    opening = {"close": 58, "balanced": 60, "wide": 65}[look["eye_spacing"]]
    left, right = 160 - opening, 160 + opening
    if expose_crown:
        top = brow_top(look, include_standard=True) - 3
        return (
            "M25 0H295V337H25Z"
            f"M{left + 10} {number(top)}Q{left} {number(top + 2)} {left} {number(top + 14)}"
            f"V164Q{left} 178 {left - 4} 186Q160 177 {right + 4} 186"
            f"Q{right} 178 {right} 164V{number(top + 14)}Q{right} {number(top + 2)} {right - 10} {number(top)}Z"
        )
    return (
        f"M25 0H{left}V164Q{left} 178 {left - 4} 186"
        f"Q160 177 {right + 4} 186Q{right} 178 {right} 164V0H295V337H25Z"
    )


def _draw_cap(parent, defs, look, head):
    forehead = ((0, head.top_y), *forehead_curve(look, head))
    half, center_y, side_y = _cap_band(look, forehead)
    top = head.top_y - 12
    upper_y = side_y - min(11, (side_y - top) * .48)
    skin_first, skin_second, skin_end = forehead[1:]
    cloth = ((0, top), (skin_first[0], top), (skin_second[0] + 3, skin_second[1] - 8),
             (skin_end[0] + 4, skin_end[1]))
    first, second, (upper_half, _) = _cap_curve_segment(cloth, upper_y)
    left, right = number(160 - half), number(160 + half)
    upper_left, upper_right = number(160 - upper_half), number(160 + upper_half)
    cuff_top = f"Q160 {number(upper_y + 8)} {upper_right} {number(upper_y)}"
    cuff_bottom = f"Q160 {number(center_y + 5)} {left} {number(side_y)}"
    crown = (
        f"M{upper_left} {number(upper_y)}"
        f"C{number(160 - second[0])} {number(second[1])}"
        f" {number(160 - first[0])} {number(first[1])} 160 {number(top)}"
        f"C{number(160 + first[0])} {number(first[1])}"
        f" {number(160 + second[0])} {number(second[1])} {upper_right} {number(upper_y)}"
        f"L{right} {number(side_y)}{cuff_bottom}Z"
    )
    cuff = f"M{upper_left} {number(upper_y)}{cuff_top}L{right} {number(side_y)}{cuff_bottom}Z"

    group = node(parent, "g", id="hair-cap", data_material_slot="headgear" if look.get("headgear_material") else None)
    path(group, crown, "#866451")
    art = _clip_group(group, defs, "hair-cap-cloth-clip", crown)
    x_scale = half / 83
    y_scale = (center_y - top) / 100
    art = node(art, "g", transform=(
        f"matrix({number(x_scale)} 0 0 {number(y_scale)} "
        f"{number(160 * (1 - x_scale))} {number(top - 46 * y_scale)})"
    ))
    path(art, "M86 121q2-33 24-52 23-18 50-18 19 .5 30 9-29-6-57 9"
         "-24 12-39 49Z", "#a78068")
    path(art, "M183 54q39 11 52 49l4 21-30 6q-1-47-26-76Z", "#64453f")
    path(art, "M180 56q40 10 58 64l-31 5q-4-48-27-69Z", "url(#ink-lines)", opacity=".46")
    path(art, "M116 69q-20 17-23 43m16-28q-6 7-9 18m116-19 10 19m-8-9 8 17"
         "m-38-48 12 12", class_="etch")
    path(group, crown, "none", class_="edge")
    path(group, cuff, "#714b40", class_="edge")
    _stroke(group, f"M{number(164 - upper_half)} {number(upper_y + 4.5)}"
            f"Q160 {number(upper_y + 12)} {number(156 + upper_half)} {number(upper_y + 4.5)}",
            "#bb866c", 1.65)


def _draw_wrap(parent, defs, look, head):
    material_slot = "headgear" if look.get("headgear_material") or look.get("headgear_trim_material") else None
    group = node(parent, "g", id="hair-wrap", transform=_temple_transform(head), data_material_slot=material_slot)
    shape = _wrap_shape(look, head)
    path(group, shape, "#a79775", class_="edge")
    group = _clip_group(group, defs, "hair-wrap-shape", shape)
    path(group, "M72 162Q68 126 87 96Q101 72 131 61Q161 48 185 58"
         "Q142 62 109 94Q82 117 72 162Z", "#ceb68d")
    path(group, "M157 81Q176 73 194 76Q236 99 247 144Q249 193 239 223"
         "L224 234Q237 190 231 163Q222 122 201 107Z", "#67574a")
    path(group, "M204 91Q237 100 248 143Q251 189 240 223L230 229"
         "Q244 176 229 136Z", "url(#ink-lines)", opacity=".5")
    path(group, "M79 182Q82 155 91 133Q102 109 119 102Q151 84 192 78"
         "Q180 70 168 66Q116 73 88 104Q73 127 73 151Z", "#8c7961")
    path(group, "M76 193Q86 171 93 130Q111 101 154 90Q175 82 188 80"
         " M85 213Q85 188 90 181M195 85Q232 107 240 148"
         " M235 197Q242 177 241 163", class_="seam")
    _stroke(group, "M91 91q18-17 39-24m-9 19q15-8 34-14M76 141q4-14 10-23"
            "m141-10q12 18 15 32m-6 56-6 19", "#d6bc92", 1.6)
    if trim := look.get("headgear_trim_material"):
        draw_scarf_pin(group, x=237, y=168, metal=trim)


def _mail_face_opening(look, head):
    left_cheek = 160 - head.cheek_half
    right_cheek = 160 + head.cheek_half
    baseline = {"close": 58, "balanced": 60, "wide": 65}[look.get("eye_spacing", "balanced")]
    eyes = eye_layout(look, head)
    # Include the stroke of the eyelid and the dark binding at the edge of the mail.
    eye_clearance = max(baseline, eyes.spacing + eyes.outer + 5.5)
    left_opening, right_opening = number(160 - eye_clearance), number(160 + eye_clearance)
    rise = _helmet_rise(look)
    inner_top = number(106 - rise)
    return (
        f"M{left_opening} {inner_top}V163Q{left_opening} 174 {number(left_cheek + 3)} 180"
        f"Q{number(left_cheek + 1)} 222 {number(160 - head.jaw_half - 3)} {number(head.chin_y - 15)}"
        f"Q160 {number(head.chin_y + 39)} {number(160 + head.jaw_half + 3)} {number(head.chin_y - 15)}"
        f"Q{number(right_cheek - 1)} 220 {number(right_cheek - 3)} 180"
        f"Q{right_opening} 174 {right_opening} 163V{inner_top}"
    )


def _draw_mail_hood(parent, look, head):
    parent = node(parent, "g", clip_path="url(#hair-mail-outline)")
    left_temple, right_temple = 160 - head.temple_half, 160 + head.temple_half
    left_cheek, right_cheek = 160 - head.cheek_half, 160 + head.cheek_half
    outer_top = number(102 - _helmet_rise(look))
    opening = _mail_face_opening(look, head)
    return_lane = (
        f"L{number(right_temple + 14)} {outer_top}Q{number(right_cheek + 16)} 197 264 257"
        "Q218 286 160 291Q102 286 56 257"
        f"Q{number(left_cheek - 16)} 197 {number(left_temple - 14)} {outer_top}Z"
    )
    hood = opening + return_lane
    path(parent, hood, "#5b5b51")
    path(parent, hood, "url(#mail-rings)", opacity=".76")
    _stroke(parent, opening, "#332c29", 3.2)


def _draw_helmet(parent, head, tall, rise):
    x_scale = (head.temple_half + 11) / 79
    pivot = 17 if tall else 34
    inset = rise / (139 - pivot)
    y_scale = number(.89 - inset) if rise else ".89"
    y_offset = number(2.1 + inset * pivot)
    group = node(parent, "g", id="hair-helmet", transform=(
        f"matrix({number(x_scale)} 0 0 {y_scale} {number(160 * (1 - x_scale))} {y_offset})"
    ))
    if tall:
        path(group, "M78 123q4-31 37-57 28-20 45-48 17 28 45 48 33 24 38 56l-4 13Z",
             "#969b8e", class_="edge")
        path(group, "M88 122q8-31 32-51 21-18 37-43-10 29-37 57-12 15-17 38Z", "#c5beaa")
        path(group, "M161 22q18 30 45 49 29 23 34 52l-52 6q-2-36-16-60Z", "#697168")
        path(group, "M185 57q42 26 54 63l-23 6q-6-34-31-69Z", "url(#ink-lines)", opacity=".54")
        path(group, "M160 24q-9 37-21 58-12 20-14 44m35-102q7 25 17 47 12 24 12 55", class_="seam")
        path(group, "M99 110q6-13 18-25m5-10 11-10m57 5 13 16m5 4 14 19m-75-40-5 13", class_="etch")
        path(group, "M155 24q-5-4-4-8 3-5 9-4 8 0 9 5 1 5-7 8Z", "#9b9e8e", class_="edge")
        _stroke(group, "M155 17q4-2 8-1", "#decdb0", 1.5)
    else:
        path(group, "M78 124q9-31 43-55 28-19 39-40 14 21 40 39 32 23 43 55l-3 12Z",
             "#969b8e", class_="edge")
        path(group, "M87 122q12-30 38-47 21-14 32-35-8 26-30 47-15 17-17 37Z", "#c5beaa")
        path(group, "M162 41q9 15 36 33 31 24 41 49l-57 5q4-26-6-51Z", "#6c736a")
        path(group, "M189 72q35 14 49 46l-24 5q-6-28-25-51Z", "url(#ink-lines)", opacity=".49")
        path(group, "M159 38q-9 33-20 52-8 15-9 36m30-87q6 21 14 42 8 21 8 45", class_="seam")
        path(group, "M96 115q5-12 15-23m10-9 10-11m53 4 9 12m13 6 14 18m-75-28-5 9", class_="etch")
        path(group, "M155 35q-6-4-3-9 4-6 11-4 7 4 4 9-3 6-12 4Z", "#9b9e8e", class_="edge")
        _stroke(group, "M155 27q4-4 8-1", "#decdb0", 1.5)
    path(group, "M76 116q77 14 168 0l2 14q-85 14-172 0Z", "#777d73", class_="edge")
    path(group, "M79 119q76 13 162 0v3q-84 14-162 0Z", "#b6b29e")
    for x, y in ((89, 124), (111, 127), (135, 129), (160, 130), (184, 129), (208, 127), (231, 124)):
        node(group, "circle", cx=x, cy=y, r="2.25", fill="#c8bea3", stroke="#4b453d", stroke_width="1")


def draw_headgear_top(parent, defs, look, head):
    gear = look["headgear"]
    if gear in headwear.COVERAGE:
        headwear.draw(parent, look, head)
    elif gear == "cap":
        _draw_cap(parent, defs, look, head)
    elif gear == "wrap":
        _draw_wrap(parent, defs, look, head)
    elif gear in _HELMETS:
        if gear not in _FITTED_AVENTAILS:
            _draw_mail_hood(parent, look, head)
        if gear in NORTHWEST_HELMETS:
            shell = node(parent, "g", id=f"headgear-{gear}")
            headwear_northwest_military.DRAWERS[gear](shell, look, head)
        else:
            _draw_helmet(parent, head, gear == "tall_helmet", _helmet_rise(look))
