from common import node, number, path
from wardrobe_eurasian_weapons import DRAWERS as EURASIAN_DRAWERS, OPTIONS as EURASIAN_OPTIONS, REGIONS
from wardrobe_weapon_art import INK as _INK, LEATHER as _LEATHER, STEEL as _STEEL
from wardrobe_weapon_art import STEEL_LIGHT as _STEEL_LIGHT, STEEL_SHADE as _STEEL_SHADE
from wardrobe_weapon_art import hatch as _hatch, line as _line, shape as _shape


OPTIONS = {
    "weapon": {
        "none": "Без оружия",
        "sheathed_sword": "Меч в ножнах",
        "sword": "Меч в руке",
        "axe": "Топор в руке",
        "spear": "Копьё в руке",
        **EURASIAN_OPTIONS,
    },
    "shield": {
        "none": "Без щита",
        "round": "Круглый щит",
        "kite": "Миндалевидный щит",
        "triangular": "Треугольный щит",
    },
}
LABELS = {"weapon": "Оружие", "shield": "Щит"}
WEAPON_GROUPS = {
    "Новгородский набор": ["sheathed_sword", "sword", "axe", "spear"],
    **{region: list(weapons) for region, weapons in REGIONS.items()},
}


def _sword_hilt(parent, *, grip_part=None):
    _shape(parent, "M-4-22Q0-24 4-22L5 18H-5Z", "#624237", 1.9, data_part=grip_part)
    _line(parent, "M-3-18l6 2m-6 4 7 2m-7 4 7 2m-8 4 8 2m-8 4 8 2m-8 4 8 2",
          "#a47b5a", 1)
    _shape(parent, "M-8-23C-11-26-8-34-2-35Q5-36 8-30Q11-25 6-22Q0-20-8-23Z",
           "#897754", 2.2)
    _line(parent, "M-6-27Q-5-33 1-33Q4-32 6-30M-4-24q3-2 7-.7", "#d3b78a", .9)

    # Rounded ends and beads flank the oval of the Bolshaya Moskovskaya crossguard.
    _shape(parent,
           "M-22 19Q-23 15-20 14Q-17 13-16 17L-12 17Q-9 13-6 16"
           "Q0 10 6 16Q10 13 12 17L16 17Q17 13 20 14Q23 15 22 20"
           "Q21 24 17 22L13 21Q10 24 6 22Q0 28-6 22Q-10 24-13 21"
           "L-17 22Q-21 24-22 19Z", "#a68b5a", 2)
    _line(parent, "M-20 18l3 1 8-1m18 0 8 1 3-1M-3 20q-3-4 1-4Q0 17 0 22"
          "Q0 17 2 16q4 0 1 4", "#e3c795", .9)


def _draw_sword(parent):
    _shape(parent, "M-7 21Q-7 87-5 161Q-4 204 0 222Q6 202 6 160L8 22Z", _STEEL, 2.8)
    path(parent, "M2 24H7L5 160Q5 196 0 217Q3 160 2 24Z", _STEEL_SHADE)
    _hatch(parent, "M3 25H7L5 159Q5 193 1 212Z", .38)
    _line(parent, "M-5 26Q-5 93-3 159Q-3 194-.5 209", _STEEL_LIGHT, 1.25)
    _line(parent, "M-1 28Q-1.4 107 0 166M3.2 61l-.3 23", "#66685e", 1.25)
    _sword_hilt(parent, grip_part="weapon-grip")


def _draw_axe(parent):
    _shape(parent, "M-4-25Q-1-28 3-25Q2 30 4 59L6 113Q4 117-2 116"
           "L-4 62Q-6 20-4-25Z", "#87674c", 2, data_part="weapon-grip")
    _line(parent, "M-1-21Q-3 19 0 55L2 110M2 76l1 18", "#bf9969", 1)
    _shape(parent, "M-5 50L6 51Q6 57 10 59Q22 61 29 54"
           "Q36 70 31 92Q18 86 13 75Q9 67 5 67L-4 68Z", _STEEL)
    path(parent, "M-3 52L5 54Q6 61 14 63Q21 64 26 60Q21 69 23 78"
         "Q18 74 13 67Q9 64 5 64L-3 65Z", _STEEL_SHADE)
    _hatch(parent, "M-3 53L5 54Q5 63 14 63L21 63Q17 68 22 75Q12 67 5 64L-3 65Z", .63)
    _line(parent, "M29 58Q33 69 30 87Q23 84 19 79M-1 55q4 0 5 4", _STEEL_LIGHT, 1.4)


def _draw_spear(parent):
    _shape(parent, "M-2.6-275L2.6-275Q4-77 3.2 36L2.5 142Q0 145-2.5 142"
           "L-3.3 34Q-4-85-2.6-275Z", "#87684e", 1.85, data_part="weapon-grip")
    _line(parent, "M-.9-266L-1.6-82M-.6-54L-1 40l.7 89M1.8 84v30", "#bf9a6d", 1)
    _shape(parent, "M-3.8-267L-3.2-285L-10-301L0-331L10-301L3.2-285L3.8-267"
           "Q0-265-3.8-267Z", _STEEL, 2.35)
    path(parent, "M0-328L8.6-301 1.8-285 2.5-268 0-267Z", _STEEL_SHADE)
    _hatch(parent, "M.8-326L8.6-301 1.8-285V-269H.8Z", .49)
    _line(parent, "M-8-301l7-25L-1-285l-1 15M-2.5-273l5 1", _STEEL_LIGHT, 1.05)
    _line(parent, "M-2 137h4", "#54453a", 1.3)


def draw_grip_fingers(parent, skin):
    # An open outline at the right joins this fragment to the existing hand.
    fingers = "M6-7Q1-10-4-7Q-7-5-6-2Q-8 0-6 3Q-6 8-2 9Q1 10 6 8"
    path(parent, f"{fingers}Z", skin.base, data_part="grip-fingers")
    _line(parent, fingers, "#493129", 1.45)
    _line(parent, "M-6-2Q-2-3 1-2M-6 3Q-3 2 0 3", "#563932", .9)


def draw_held_weapon(parent, style, *, x, y, skin):
    if style in {"none", "sheathed_sword"}:
        return
    weapon = node(parent, "g", data_part="weapon", data_style=style,
                  data_grip_x=x, data_grip_y=y, transform=f"translate({number(x)} {number(y)})")
    drawer, angle = _HELD_WEAPONS[style]
    artwork = node(weapon, "g", transform=f"rotate({angle})") if angle else weapon
    drawer(artwork)
    draw_grip_fingers(weapon, skin)


def _shield_face(parent, outline, fill, inner, border):
    _shape(parent, outline, border, 3.55)
    _shape(parent, inner, fill, 1.4)


def _draw_round(parent):
    outline = ("M-19-30C17-32 44-5 44 30C45 64 19 93-16 94"
               "C-51 95-80 68-80 34C-81-2-54-29-19-30Z")
    inner = ("M-19-24C13-26 38-2 38 30C39 61 15 87-16 88"
             "C-48 89-74 65-74 34C-75 2-50-23-19-24Z")
    _shield_face(parent, outline, "#8b8261", inner, "#685446")
    path(parent, "M22-10C53 21 39 70 1 85Q-47 97-68 57Q-43 79-13 71Q27 65 22-10Z", "#68684d")
    _hatch(parent, "M24-7C49 21 42 64 8 82Q-22 94-48 79Q18 76 24-7Z", .72)
    path(parent, "M-19-21Q-48-21-69 13Q-55-3-34-5Q-4-11 24 2Q10-19-19-21Z", "#b0a17b", opacity=".74")
    _line(parent, "M-68 10Q-60-9-41-18M17 82l9-8M-62 44l8-3m4 2 10-3m57 13 12-5M-34 74l12-4",
          "#b5a47b", 1)
    _line(parent, "M-68 17l22-6m43-15 16-5M-67 56l22-5M5 56l27-8M-12 74l14-4", "#60543f", 1.1)
    node(parent, "ellipse", cx=-19, cy=32, rx=22, ry=20, fill="#777b71", stroke=_INK, stroke_width=2.1)
    for cx, cy in ((-19, 16), (-37, 32), (-19, 48), (-1, 32)):
        node(parent, "circle", cx=cx, cy=cy, r=1.25, fill="#352e2a")
    _shape(parent, "M-32 32Q-30 21-19 21Q-8 21-6 32Q-7 42-19 43Q-30 43-32 32Z",
           _STEEL_SHADE, 1.9)
    path(parent, "M-30 32Q-28 23-19 23Q-10 23-9 31Q-13 28-18 30Q-23 32-27 36Z", _STEEL)
    _line(parent, "M-27 30q2-5 8-5", _STEEL_LIGHT, 1.15)


def _draw_kite(parent):
    outline = ("M-12-34C16-33 41-19 44 9C47 50 20 142-15 204"
               "C-52 164-78 89-76 33C-74-6-49-34-12-34Z")
    inner = ("M-12-28C13-27 35-15 38 10C42 50 17 132-16 193"
             "C-49 153-73 86-70 33C-68-3-46-28-12-28Z")
    _shield_face(parent, outline, "#986355", inner, "#715241")
    path(parent, "M20-19Q44-7 38 29C28 103 1 159-16 192Q-20 178-24 170"
         "C0 124 21 50 20-19Z", "#754640")
    _hatch(parent, "M29-12Q49 11 29 68Q11 145-16 191L-20 182Q9 121 21 58Q31 12 29-12Z", .59)
    path(parent, "M-56 9Q-42-20-10-22Q-58 8-56 64Q-56 87-46 121Q-74 75-56 9Z", "#b87a64", opacity=".68")
    _line(parent, "M-60 31Q-56 9-46-3m-12 54v14m78-64 3 12M-38 134l10 22M-16 173l5-12",
          "#cc9479", 1.2)
    _line(parent, "M-56 89l6 10m-4-16 3 7M15 59q-5 23-13 40m6-9-4 11m-34 36 7 14",
          "#673e37", 1.05)


def _draw_triangular(parent):
    outline = ("M-75-27Q-21-36 44-24Q41 89-14 179"
               "Q-65 108-75-27Z")
    inner = ("M-68-21Q-21-29 37-18Q33 86-14 167"
             "Q-59 102-68-21Z")
    _shield_face(parent, outline, "#6f7d73", inner, "#8b6c4d")
    path(parent, "M18-21L37-17Q32 91-14 166L-23 153Q12 87 18-21Z", "#525f56")
    _hatch(parent, "M25-20l11 2Q34 86-14 166l-4-5Q19 84 25-20Z", .55)
    path(parent, "M-67-19Q-50-24-26-23Q-51-14-52 7Q-51 48-42 87Q-59 55-67-19Z", "#9ba091", opacity=".67")
    _line(parent, "M-62-14Q-48-18-39-18m-21 34 2 16m7 22 2 13M-23 140q4 10 8 15",
          "#b8b9a6", 1.15)
    _line(parent, "M-42 82q7 17 13 27m-8-22 7 15M16 50l-4 21m0-8-5 24",
          "#464f47", 1.25)


def draw_shield(parent, style, *, x, y):
    if style == "none":
        return
    shield = node(parent, "g", data_part="shield", data_style=style,
                  data_grip_x=x, data_grip_y=y, transform=f"translate({number(x)} {number(y)})")
    _shape(shield, "M-12-8Q-2-13 11-7L11 7Q-2 12-12 7Z", _LEATHER, 2, data_part="shield-grip")
    _SHIELDS[style](shield)


def draw_scabbard(parent, body):
    anchor = number(160 + .60 * body.waist)
    scabbard = node(parent, "g", data_part="scabbard", data_style="sheathed_sword",
                    transform=f"translate({anchor} 403)")
    _shape(scabbard, "M-20 2l6-1Q-10 28 7 59l-4 5Q-14 41-20 2Z", _LEATHER, 1.55,
           data_part="scabbard-hanger")
    _shape(scabbard, "M7-1l4-1Q15 18 28 51l-5 6Q12 26 7-1Z", _LEATHER, 1.55,
           data_part="scabbard-hanger")
    _line(scabbard, "M-17 4q3 22 10 37M10 2q6 25 14 42", "#c89e75", 1.15)

    hanging = node(scabbard, "g", transform="translate(0 25) rotate(-17)")
    _shape(hanging, "M-10 26Q.5 23 10 26Q9 108 6 169Q6 190 1 201"
           "Q-4 203-6 195Q-9 187-9 169Q-10 100-10 26Z", "#8f473a", 3)
    shade = "M4 28l4-1Q7 107 4 169Q5 192 1 199L-2 197Q1 183 0 170Q3 102 4 28Z"
    path(hanging, shade, "#66362e")
    _hatch(hanging, shade, .54)
    _line(hanging, "M-6 30Q-7 97-5 165M-5 172l1 13", "#c88162", 1.55)
    _line(hanging, "M-3 38l-.2 21m.2-13v22M3 80l-.4 15M-3 145l.4 23", "#65362f", .95)
    _shape(hanging, "M-7 185q7 1 12-1Q4 198 1 201q-5 2-8-16Z", "#947652", 2)
    _line(hanging, "M-4 188q1 8 4 10", "#d4ad78", 1)
    _shape(hanging, "M-10 24Q0 22 10 24l.3 7Q0 28-10 31Z", "#a67955", 1.8)
    _line(hanging, "M-7 26q6-2 14 0", "#d8ac7b", .88)
    _shape(hanging, "M-10 42q10 1 19-2l.1 6Q0 49-10 47Z", "#73513c", 1.7)
    _line(hanging, "M-7 44q6 0 13-2", "#b18b63", .88)
    _sword_hilt(hanging)


_HELD_WEAPONS = {
    "sword": (_draw_sword, 8), "axe": (_draw_axe, 11), "spear": (_draw_spear, -6),
    **{style: (drawer, 0) for style, drawer in EURASIAN_DRAWERS.items()},
}
_SHIELDS = {"round": _draw_round, "kite": _draw_kite, "triangular": _draw_triangular}
