from common import node, number, path
import image_arsenal_art
from wardrobe_eurasian_weapons import DRAWERS as EURASIAN_DRAWERS, OPTIONS as EURASIAN_OPTIONS, REGIONS
from wardrobe_northwest_shields import DRAWERS as NEW_SHIELDS, LABELS as SHIELD_LABELS, OUTLINES
from wardrobe_weapon_art import INK as _INK, LEATHER as _LEATHER, STEEL as _STEEL
from wardrobe_weapon_art import STEEL_LIGHT as _STEEL_LIGHT, STEEL_SHADE as _STEEL_SHADE
from wardrobe_weapon_art import draw_disc_sword, draw_polovtsian_sabre
from wardrobe_weapon_art import hatch as _hatch, line as _line, shape as _shape


OPTIONS = {
    "weapon": {
        "none": "Без оружия",
        "sheathed_sword": "Меч в ножнах",
        "sword": "Новгородский меч",
        "rus_disc_sword": "Романский меч с дисковидным навершием",
        "axe": "Новгородский топор",
        "spear": "Новгородское копьё",
        "steppe_polovtsian_sabre": "Сабля из кургана Новый I",
        "steppe_lance": "Степное копьё",
        **EURASIAN_OPTIONS,
        **image_arsenal_art.WEAPONS,
    },
    "carry": {
        "carried": "В походном положении",
        "held": "В руках",
    },
    "shield": {
        "none": "Без щита",
        "round": "Круглый щит",
        "kite": "Миндалевидный щит",
        "triangular": "Треугольный щит",
        **SHIELD_LABELS,
    },
    "shield_carry": {
        "held": "В руке",
        "back": "За спиной",
    },
}
LABELS = {"weapon": "Оружие", "carry": "Положение оружия и лука", "shield": "Щит",
          "shield_carry": "Положение щита"}
WEAPON_GROUPS = {
    "Новгородский набор": ["sheathed_sword", "sword", "rus_disc_sword", "axe", "spear"],
    "Дополнения по INDEX": list(image_arsenal_art.WEAPONS),
    **{region: list(weapons) for region, weapons in REGIONS.items()},
}
WEAPON_GROUPS["Русь, степь и Передняя Азия"].extend(("steppe_polovtsian_sabre", "steppe_lance"))

# Image-space projections around the resting figure, in the original artwork's units.
# Each entry gives the offset from the centre, the height, the shaft's tilt,
# and the vertical scale. A negative vertical scale turns a lowered head up.
BACK_WEAPONS = {
    **{style: pose for style, pose in image_arsenal_art.BACK_WEAPONS.items()
       if style not in {"wp_long_knife", "wp_flail", "wp_signal_horn"}},
    "broom": (-100, 400, .16, 1.1),
    "spear": (-1, 407, .37, 1.12),
    "steppe_lance": (-7, 408, .37, 1.14),
    "eur_west_broad_axe": (-75, 372, -.19, -1.45),
    "eur_west_winged_spear": (-43, 396, .17, 1.15),
    "eur_west_scalvian_spear": (-41, 405, .18, 1.14),
    "eur_west_drosten_crossbow": (-102, 334, -.51, 1.28),
    "eur_steppe_grigorovo_dart": (-43, 370, .18, 1.08),
    "eur_east_punjab_gada": (-70, 330, .19, 1.14),
    "eur_east_chola_trishula": (-49, 388, .18, 1.15),
    "eur_east_angkor_spear": (-44, 399, .14, 1.14),
    "eur_east_angkor_phkak": (-53, 332, .17, 1.17),
}
_HELD_LENGTH = {
    "sword": 1.17, "rus_disc_sword": 1.05, "axe": 1.13, "spear": 1.12,
    "eur_west_lobed_sword": 1.23, "eur_west_oval_sword": 1.21,
    "eur_west_broad_axe": 1.24, "eur_west_winged_spear": 1.10, "eur_west_scalvian_spear": 1.10,
    "eur_west_seax": .88, "eur_steppe_vienna_sabre": 1.19, "eur_steppe_yaroslavl_sabre": 1.09,
    "steppe_polovtsian_sabre": 1.06, "steppe_lance": 1.17,
    "eur_steppe_samanid_khanjar": .74, "eur_east_japan_tachi": 1.22,
    "eur_east_song_crescent_sword": 1.18, "eur_east_china_dragon_ring": 1.19,
    "eur_east_angkor_spear": 1.10,
}
_LOWERED_BLADES = {"eur_west_lobed_sword", "eur_west_oval_sword", "eur_steppe_vienna_sabre"}


def _sword_hilt(parent, *, grip_part=None):
    _shape(parent, "M-4-22Q0-24 4-22L5 18H-5Z", "#624237", 1.9, data_part=grip_part)
    _line(parent, "M-3-18l6 2m-6 4 7 2m-7 4 7 2m-8 4 8 2m-8 4 8 2m-8 4 8 2",
          "#a47b5a", 1)
    _shape(parent, "M-8-23C-11-26-8-34-2-35Q5-36 8-30Q11-25 6-22Q0-20-8-23Z",
           "#897754", 2.2)
    _line(parent, "M-6-27Q-5-33 1-33Q4-32 6-30M-4-24q3-2 7-.7", "#d3b78a", .9)

    # Rounded ends and beads flank the oval of the Bolshaya Moskovskaya crossguard.
    _shape(parent,
           "M-22 19Q-23 15-20 14Q-17 13-16 17L-12 17Q-9 13-6 16"
           "Q0 10 6 16Q10 13 12 17L16 17Q17 13 20 14Q23 15 22 20"
           "Q21 24 17 22L13 21Q10 24 6 22Q0 28-6 22Q-10 24-13 21"
           "L-17 22Q-21 24-22 19Z", "#a68b5a", 2)
    _line(parent, "M-20 18l3 1 8-1m18 0 8 1 3-1M-3 20q-3-4 1-4Q0 17 0 22"
          "Q0 17 2 16q4 0 1 4", "#e3c795", .9)


def _draw_sword(parent):
    _shape(parent, "M-7 21Q-7 87-5 161Q-4 204 0 222Q6 202 6 160L8 22Z", _STEEL, 2.8)
    path(parent, "M2 24H7L5 160Q5 196 0 217Q3 160 2 24Z", _STEEL_SHADE)
    _hatch(parent, "M3 25H7L5 159Q5 193 1 212Z", .38)
    _line(parent, "M-5 26Q-5 93-3 159Q-3 194-.5 209", _STEEL_LIGHT, 1.25)
    _line(parent, "M-1 28Q-1.4 107 0 166M3.2 61l-.3 23", "#66685e", 1.25)
    _sword_hilt(parent, grip_part="weapon-grip")


def _draw_axe(parent):
    _shape(parent, "M-4-25Q-1-28 3-25Q2 30 4 59L6 113Q4 117-2 116"
           "L-4 62Q-6 20-4-25Z", "#87674c", 2, data_part="weapon-grip")
    _line(parent, "M-1-21Q-3 19 0 55L2 110M2 76l1 18", "#bf9969", 1)
    _shape(parent, "M-5 49Q1 48 6 50Q8 58 17 60Q28 61 37 53"
           "Q44 69 39 92Q25 87 14 76Q9 69 5 68L-4 68Z", _STEEL)
    path(parent, "M-3 51L5 53Q8 62 17 64Q24 66 32 60Q27 70 29 82"
         "Q21 77 15 69Q9 64 4 65L-3 65Z", _STEEL_SHADE)
    _hatch(parent, "M-3 53L5 54Q8 62 17 65L26 64Q23 70 27 77Q16 68 5 64L-3 65Z", .63)
    _line(parent, "M37 58Q41 71 38 88Q30 86 22 79M-1 55q4 0 5 4", _STEEL_LIGHT, 1.4)


def _draw_spear_shaft(parent, wood, highlight):
    _shape(parent, "M-2.6-275L2.6-275Q4-77 3.2 36L2.5 142Q0 145-2.5 142"
           "L-3.3 34Q-4-85-2.6-275Z", wood, 1.85, data_part="weapon-grip")
    _line(parent, "M-.9-266L-1.6-82M-.6-54L-1 40l.7 89M1.8 84v30", highlight, 1)


def _draw_spear(parent):
    _draw_spear_shaft(parent, "#87684e", "#bf9a6d")
    _shape(parent, "M-3.8-267L-3.2-285L-10-301L0-331L10-301L3.2-285L3.8-267"
           "Q0-265-3.8-267Z", _STEEL, 2.35)
    path(parent, "M0-328L8.6-301 1.8-285 2.5-268 0-267Z", _STEEL_SHADE)
    _hatch(parent, "M.8-326L8.6-301 1.8-285V-269H.8Z", .49)
    _line(parent, "M-8-301l7-25L-1-285l-1 15M-2.5-273l5 1", _STEEL_LIGHT, 1.05)
    _line(parent, "M-2 137h4", "#54453a", 1.3)


def _draw_steppe_lance(parent):
    _draw_spear_shaft(parent, "#785c41", "#c1a075")
    _shape(parent, "M-3.6-267L-2.8-286Q-6-294-5.5-305Q-3-321 0-338"
           "Q3-321 5.5-305Q6-294 2.8-286L3.6-267Q0-265-3.6-267Z", _STEEL, 2.2)
    shade = "M0-334Q3-318 4.6-305Q5.2-296 1.7-286L2.5-268 0-267Z"
    path(parent, shade, _STEEL_SHADE)
    _hatch(parent, shade, .38)
    _line(parent, "M-3.9-304Q-1.8-320-.7-330L-1.2-287l-.7 15m.2 1 3.4-.5", _STEEL_LIGHT, 1.05)
    _line(parent, "M-2 137h4", "#55483b", 1.3)


def draw_grip_fingers(parent, skin, half_width):
    hand = node(parent, "g", data_part="hand")
    outer, inner = 3 - half_width, half_width - 2
    fingers = (f"M{outer} -14Q{outer - 1} -9 {outer - 2} -5"
               f"Q{outer - 3} 1 {outer - 1} 6Q{outer} 11 -5 12"
               f"Q0 15 5 11Q{inner + 1} 11 {inner + 1} 5"
               f"Q{inner + 1} 0 {inner - 1} -2Q{inner - 2} -7 {inner} -13")
    path(hand, f"{fingers}Q0 -10 {outer} -14Z", skin.base, data_part="grip-fingers")
    path(hand, f"M{outer + 1}-7Q{outer - 1} 4 -6 9Q-2 12 5 9"
         f"Q{inner + 1} 9 {inner - 1} 2Q{inner - 3} 11 -3 7Q{outer + 1} 4 {outer + 1}-7Z",
         skin.shade, opacity=".45", data_part="grip-shade")
    _line(hand, fingers, "#342525", 2.15)
    _line(hand, f"M{inner - 1} -2Q6 -8 .5 -4Q-2 -2 .5 .3L4 1"
          "M-7 2q2.8 -1.4 5.5 -.5m-5 5q2.6 -1.3 5.1 -.5",
          "#6b483a", 1.02)


def draw_held_weapon(parent, style, *, x, y, skin, half_width, child=False):
    if style in {"none", "sheathed_sword"}:
        return
    weapon = node(parent, "g", data_part="weapon", data_style=style,
                  data_grip_x=x, data_grip_y=y, transform=f"translate({number(x)} {number(y)})")
    drawer, angle = _HELD_WEAPONS[style]
    length = _HELD_LENGTH.get(style, 1)
    width = .85 if child else 1
    if style in _LOWERED_BLADES:
        angle = min(12, max(4, .22 * (x - 20)))
    elif style == "steppe_lance":
        # Keep the upper shaft outside the face as the hand moves closer to the torso.
        angle = min(angle, -.14 * (x - 22))
    elif child and style == "spear":
        angle -= min(3, max(0, .10 * (x - 68)))
    elif child and style == "eur_west_winged_spear":
        angle = -3
    artwork = node(weapon, "g", transform=f"rotate({number(angle)}) scale({width} {length})")
    drawer(artwork)
    draw_grip_fingers(weapon, skin, half_width)


def draw_back_weapon(parent, style, body, *, child, other_side=False):
    offset, y, shear, length = BACK_WEAPONS[style]
    x = 160 + offset - .22 * (body.shoulder - 80)
    drawing = node(parent, "g", data_part="back-weapon", data_style=style,
                   transform="translate(320 0) scale(-1 1)" if other_side else None)
    if child:
        drawing = node(drawing, "g", transform="matrix(.88 0 0 .84 19.2 43)")
    art = node(drawing, "g", transform=f"matrix(1 0 {shear} {length} {number(x)} {y})")
    _HELD_WEAPONS[style][0](art)
    if style == "eur_west_broad_axe":
        _shape(art, "M-37 70Q-45 106-36 151L-30 146Q-37 108-31 79Z",
               "#79503e", 2.1)
        _line(art, "M-37 81Q-42 105-34 145", "#bb8b68", 1.1)
    for part in art.iter():
        if part.get("data-part") == "weapon-grip":
            part.set("data-part", "back-shaft")


def _shield_face(parent, outline, fill, inner, border):
    _shape(parent, outline, border, 3.55)
    _shape(parent, inner, fill, 1.4)


def _draw_round(parent):
    outline = OUTLINES["round"]
    inner = ("M-19-24C13-26 38-2 38 30C39 61 15 87-16 88"
             "C-48 89-74 65-74 34C-75 2-50-23-19-24Z")
    _shield_face(parent, outline, "#8b8261", inner, "#685446")
    path(parent, "M22-10C53 21 39 70 1 85Q-47 97-68 57Q-43 79-13 71Q27 65 22-10Z", "#68684d")
    _hatch(parent, "M24-7C49 21 42 64 8 82Q-22 94-48 79Q18 76 24-7Z", .72)
    path(parent, "M-19-21Q-48-21-69 13Q-55-3-34-5Q-4-11 24 2Q10-19-19-21Z", "#b0a17b", opacity=".74")
    _line(parent, "M-68 10Q-60-9-41-18M17 82l9-8M-62 44l8-3m4 2 10-3m57 13 12-5M-34 74l12-4",
          "#b5a47b", 1)
    _line(parent, "M-68 17l22-6m43-15 16-5M-67 56l22-5M5 56l27-8M-12 74l14-4", "#60543f", 1.1)
    node(parent, "ellipse", cx=-19, cy=32, rx=22, ry=20, fill="#777b71", stroke=_INK, stroke_width=2.1)
    for cx, cy in ((-19, 16), (-37, 32), (-19, 48), (-1, 32)):
        node(parent, "circle", cx=cx, cy=cy, r=1.25, fill="#352e2a")
    _shape(parent, "M-32 32Q-30 21-19 21Q-8 21-6 32Q-7 42-19 43Q-30 43-32 32Z",
           _STEEL_SHADE, 1.9)
    path(parent, "M-30 32Q-28 23-19 23Q-10 23-9 31Q-13 28-18 30Q-23 32-27 36Z", _STEEL)
    _line(parent, "M-27 30q2-5 8-5", _STEEL_LIGHT, 1.15)


def _draw_kite(parent):
    outline = OUTLINES["kite"]
    inner = ("M-12-28C13-27 35-15 38 10C42 50 17 132-16 193"
             "C-49 153-73 86-70 33C-68-3-46-28-12-28Z")
    _shield_face(parent, outline, "#986355", inner, "#715241")
    path(parent, "M20-19Q44-7 38 29C28 103 1 159-16 192Q-20 178-24 170"
         "C0 124 21 50 20-19Z", "#754640")
    _hatch(parent, "M29-12Q49 11 29 68Q11 145-16 191L-20 182Q9 121 21 58Q31 12 29-12Z", .59)
    path(parent, "M-56 9Q-42-20-10-22Q-58 8-56 64Q-56 87-46 121Q-74 75-56 9Z", "#b87a64", opacity=".68")
    _line(parent, "M-60 31Q-56 9-46-3m-12 54v14m78-64 3 12M-38 134l10 22M-16 173l5-12",
          "#cc9479", 1.2)
    _line(parent, "M-56 89l6 10m-4-16 3 7M15 59q-5 23-13 40m6-9-4 11m-34 36 7 14",
          "#673e37", 1.05)


def _draw_triangular(parent):
    outline = OUTLINES["triangular"]
    inner = ("M-68-21Q-21-29 37-18Q33 86-14 167"
             "Q-59 102-68-21Z")
    _shield_face(parent, outline, "#6f7d73", inner, "#8b6c4d")
    path(parent, "M18-21L37-17Q32 91-14 166L-23 153Q12 87 18-21Z", "#525f56")
    _hatch(parent, "M25-20l11 2Q34 86-14 166l-4-5Q19 84 25-20Z", .55)
    path(parent, "M-67-19Q-50-24-26-23Q-51-14-52 7Q-51 48-42 87Q-59 55-67-19Z", "#9ba091", opacity=".67")
    _line(parent, "M-62-14Q-48-18-39-18m-21 34 2 16m7 22 2 13M-23 140q4 10 8 15",
          "#b8b9a6", 1.15)
    _line(parent, "M-42 82q7 17 13 27m-8-22 7 15M16 50l-4 21m0-8-5 24",
          "#464f47", 1.25)


def draw_shield(parent, style, *, x, y):
    if style == "none":
        return
    shield = node(parent, "g", data_part="shield", data_style=style,
                  data_grip_x=x, data_grip_y=y, transform=f"translate({number(x)} {number(y)})")
    _shape(shield, "M-12-8Q-2-13 11-7L11 7Q-2 12-12 7Z", _LEATHER, 2, data_part="shield-grip")
    _SHIELDS[style](shield)


_HELD_WEAPONS = {
    "sword": (_draw_sword, 8), "axe": (_draw_axe, 11), "spear": (_draw_spear, -6),
    "rus_disc_sword": (draw_disc_sword, 8),
    "steppe_polovtsian_sabre": (draw_polovtsian_sabre, 8),
    "steppe_lance": (_draw_steppe_lance, -4),
    **{style: (drawer, 0) for style, drawer in EURASIAN_DRAWERS.items()},
    **{style: (drawer, 0) for style, drawer in image_arsenal_art.WEAPON_DRAWERS.items()},
}
_SHIELDS = {"round": _draw_round, "kite": _draw_kite, "triangular": _draw_triangular, **NEW_SHIELDS}
