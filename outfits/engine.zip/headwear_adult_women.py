from common import node, number, path


OPTIONS = {
    "rus_diamond_band": "Шерстяное очелье с ромбами",
    "naumburg_linen_cap": "Наумбургская шапочка с подбородочной лентой",
    "castile_pleated_tocado": "Кастильский плиссированный токадо",
    "song_pearl_crown": "Сунский венец с жемчугом",
}
COVERAGE = {
    "rus_diamond_band": {"ears": True, "neck": True, "hair": True},
    "naumburg_linen_cap": {"ears": False, "neck": True, "hair": True},
    "castile_pleated_tocado": {"ears": False, "neck": True, "hair": True},
    "song_pearl_crown": {"ears": True, "neck": True, "hair": True},
}
HAIR_ROOT_HALF = {"naumburg_linen_cap": 72, "castile_pleated_tocado": 72, "song_pearl_crown": 70}
OPEN_CROWNS = {"rus_diamond_band"}


def draw_rus_diamond_band(parent, look, fit):
    # The Grigoryevo textile is documented. The open arrangement is reconstructed.
    band = fit.sides(parent)
    jewelry = node(band, "g", transform="translate(4 30) scale(1 .75)")
    ring = "M228 124 C234 124 237 129 235 135 C233 141 225 141 222 136 C219 131 223 125 227 126"
    path(jewelry, ring, "none", stroke="#45322a", stroke_width=4.4, stroke_linecap="round")
    path(jewelry, ring, "none", stroke="#c6a377", stroke_width=2.3, stroke_linecap="round")
    path(jewelry, "M223 132 Q223 137 229 138 M232 126 l2 2", "none", stroke="#f0d6ac",
         stroke_width=.95, stroke_linecap="round")
    # Lower the front of the band when the space between scalp and brows is shallow.
    dip = min(13, max(0, 22 - (fit.brim_y - fit.top_y)))
    path(band, f"M94 109 C105 96 132 {number(94 + dip)} 160 {number(94 + dip)} "
         f"C188 {number(94 + dip)} 214 97 226 107 Q232 112 231 117 "
         f"C218 111 192 {number(106 + dip)} 162 {number(107 + dip)} "
         f"C133 {number(107 + dip)} 109 108 91 118 Q90 114 94 109 Z",
         "#9b413c", class_="edge")
    path(band, f"M94 113 C110 100 136 {number(97 + dip)} 160 {number(97 + dip)} "
         f"C189 {number(97 + dip)} 215 101 228 111 M95 116 "
         f"C113 105 139 {number(104 + dip)} 160 {number(104 + dip)} "
         f"C184 {number(104 + dip)} 212 107 227 114",
         "none", stroke="#d88a6c", stroke_width=1.1, stroke_linecap="round")
    path(band, "M224 106 Q229 107 232 111 C236 116 237 121 234.5 124.5 Q232 128 229 125 "
         "Q231 118 223 111 Z", "#b45146", stroke="#623834", stroke_width=1.25, stroke_linejoin="round")
    path(band, "M225.5 109 L228 110.5 M228.5 112.5 Q234 117 232.5 124",
         "none", stroke="#e39a77", stroke_width=1.25, stroke_linecap="round")
    for x, y, tilt in ((101, 108.5, -28), (115, 104, -17), (130, 102, -8), (145, 101, -4),
                       (160, 100.5, 0), (175, 101, 4), (190, 102, 8), (205, 104, 14), (220, 108, 26)):
        ridge = 1 - (abs(x - 160) / 66) ** 2
        weave = node(band, "g", transform=f"translate({x} {number(y + dip * ridge)}) rotate({tilt})")
        path(weave, "M-6 0 L0-3.5 6 0 0 3.5 Z", "#3d6b6d", stroke="#653d3d", stroke_width=.55)
        path(weave, "M-4 0 L0-2.6 4 0 0 1 Z", "#78948a")
        path(weave, "M-1.7 0 L0-1.2 1.7 0 0 1.2 Z", "#b8a27e")


def draw_naumburg_linen_cap(parent, look, fit):
    # The low flared cap and the separately worn chin band follow the Naumburg donor figures.
    ties = fit.temples(parent)
    brim = fit.brim_y
    chin = fit.chin_y
    strap = (
        f"M92 {number(brim - 5)} C88 139 90 176 96 203 C100 225 121 {number(chin + 2)} "
        f"155 {number(chin + 2)} C185 {number(chin + 2)} 212 232 222 205 C231 182 231 148 "
        f"227 {number(brim - 5)}"
    )
    path(ties, strap, "none", stroke="#5d5046", stroke_width=9.1, stroke_linecap="round")
    path(ties, strap, "none", stroke="#d0c0a6", stroke_width=6.3, stroke_linecap="round")
    path(ties, f"M91 {number(brim + 4)} C88 140 91 188 96 203 Q105 {number(chin - 5)} "
         f"146 {number(chin + 3)} M162 {number(chin + 3)} Q193 {number(chin + 1)} 213 222",
         "none", stroke="#f1e2c7", stroke_width=1.55, stroke_linecap="round")
    path(ties, "M227 133 Q233 177 224 200 M98 209 Q105 227 115 235", class_="etch", opacity=".58")

    crown = fit.crown(parent, minimum_y=65)
    path(crown, "M69 78 C91 70 121 65 159 65 C196 65 227 70 250 78 "
         "C245 88 237 104 230 115 Q160 107 90 115 C82 100 75 87 69 78 Z",
         "#e1d1b7", class_="edge")
    path(crown, "M70 78 C92 70 127 66 159 66 C192 66 227 70 249 78 "
         "C222 84 197 87 159 87 C128 87 98 85 70 78 Z", "#c1b197", class_="seam")
    path(crown, "M81 78 Q117 68 166 69 Q210 69 238 78 Q221 80 208 80 "
         "Q157 73 116 80 Q101 82 81 78 Z", "#ede0c7")
    path(crown, "M79 84 Q109 92 142 90 Q121 97 119 108 L92 111 Z", "#f2e5cf")
    path(crown, "M186 87 Q217 87 244 82 L231 112 L200 109 Q201 98 186 87 Z", "#b0a18b")
    path(crown, "M216 88 Q230 86 242 84 L231 111 L218 111 Q220 98 216 88 Z",
         "url(#ink-lines)", opacity=".45")
    path(crown, "M90 99 Q120 105 147 101 M175 103 Q207 103 235 95 M97 91 l12 3 m99 1 12-2",
         class_="etch", opacity=".67")

    rim = fit.sides(parent)
    path(rim, "M87 105 C114 100 136 100 160 101 C185 100 208 101 233 105 "
         "L230 115 C205 113 184 115 160 115 C139 115 114 113 90 115 Z",
         "#c7b69b", class_="edge")
    path(rim, "M90 107 Q158 98 230 107 L229 109 Q158 102 91 110 Z", "#f1e1c8")
    path(rim, "M94 112 Q158 104 226 112", "none", stroke="#897b67", stroke_width=1.05,
         stroke_dasharray="2 2.4")


def draw_castile_pleated_tocado(parent, look, fit):
    # The attendant at Escorial T-I-6, fol. 54v, supplies the rising fold and pleated face edge.
    sides = fit.sides(parent)
    path(sides, "M80 101 Q93 107 92 119 C85 146 86 169 91 187 Q96 204 105 214 "
         "Q96 214 91 220 Q74 204 72 182 C67 154 69 122 80 101 Z", "#c9ae91", class_="edge")
    path(sides, "M76 131 Q68 162 77 189 Q86 206 91 212 Q83 182 83 161 Q82 148 87 126 Z", "#e8d1b2")
    path(sides, "M77 143 Q74 160 78 180 Q80 195 94 210 M84 155 Q83 175 88 193",
         class_="etch")
    path(sides, "M230 97 Q248 101 250 128 C247 160 248 185 255 207 "
         "Q258 219 265 229 Q258 229 252 237 Q245 233 238 234 C226 214 227 191 230 166 "
         "C231 143 230 123 230 97 Z", "#c7ab91", class_="edge")
    path(sides, "M234 119 Q239 143 235 165 C232 193 234 213 244 230 L251 232 "
         "Q241 206 241 179 Q242 153 245 125 Z", "#edd6b5")
    path(sides, "M244 144 Q239 200 254 233 L263 229 Q248 205 249 180 Z",
         "url(#ink-lines)", opacity=".56")
    path(sides, "M246 132 Q242 155 243 178 Q245 211 255 230 M231 171 Q229 201 237 218 "
         "M231 193 Q234 212 244 226", class_="etch")

    crown = fit.crown(parent, minimum_y=30)
    path(crown, "M76 109 C78 95 79 77 89 66 C101 54 122 57 148 49 "
         "C170 44 175 32 189 31 C206 34 211 52 226 64 Q244 78 245 106 "
         "L231 115 Q158 117 89 115 Z", "#ddc2a3", class_="edge")
    path(crown, "M88 69 Q100 58 134 56 C165 49 175 44 185 35 "
         "Q177 52 158 63 Q120 73 90 79 Z", "#f1dbc0")
    path(crown, "M188 33 Q199 36 205 47 Q221 73 235 76 Q243 91 243 106 "
         "L225 110 Q224 85 210 69 Q195 50 188 33 Z", "#ab856f")
    path(crown, "M195 42 Q206 59 225 74 Q236 79 241 101 L228 102 Q220 77 206 64 Z",
         "url(#ink-lines)", opacity=".54")
    path(crown, "M92 68 Q115 64 138 59 Q174 50 185 36 M101 73 Q147 71 177 51 "
         "M151 68 Q183 63 195 48 M207 59 Q224 80 232 85 M211 77 Q221 84 224 93",
         "none", stroke="#a27565", stroke_width=1.3, stroke_linecap="round")

    path(crown, "M86 75 C100 74 112 76 136 74 Q177 72 213 63 L225 72 "
         "C191 80 172 83 142 84 Q110 87 83 85 Z", "#ead1b1", class_="seam")
    path(crown, "M82 85 C103 87 124 86 145 84 Q192 82 225 73 L232 82 "
         "C197 91 174 91 148 93 Q110 95 80 93 Z", "#d9b698", class_="seam")
    path(crown, "M80 93 C106 95 130 95 152 92 Q191 90 233 82 L238 91 "
         "C201 99 173 100 151 101 Q111 104 78 102 Z", "#e9cfac", class_="seam")
    path(crown, "M78 103 Q114 105 152 101 Q197 99 239 91 L244 104 "
         "L232 115 C185 117 135 117 90 115 L76 108 Z", "#d6b294", class_="seam")
    path(crown, "M87 79 Q113 82 138 79 Q181 76 219 69 M85 89 Q112 92 147 88 Q194 86 228 78 "
         "M83 97 Q123 98 150 96 Q196 94 234 87 M83 106 Q116 108 149 105 Q193 104 240 98",
         "none", stroke="#fae7c9", stroke_width=2.15, stroke_linecap="round")
    path(crown, "M88 82 l12 1 m27 9 16-1 m39-14 14-2 m-8 15 15-2 m-105 13 17 0 m77 8 14 0",
         "none", stroke="#a16f61", stroke_width=1.05, stroke_linecap="round")


def _flower_pin(parent, x, y, size, tilt, center):
    flower = node(parent, "g", transform=f"translate({x} {y}) rotate({tilt}) scale({size})")
    path(flower, "M0 3 Q-1 13 7 20 L10 21 M3 12 Q10 7 14 10 Q12 15 5 15 "
         "M3 13 Q-5 14-9 7 Q-2 6 3 13 Z", "#a77b4f", stroke="#e0b476", stroke_width=1.1,
         stroke_linejoin="round", stroke_linecap="round")
    path(flower, "M0-2 C-6-6-5-12 0-12 Q5-12 4-6 Q11-10 13-5 Q15 0 8 2 "
         "Q13 7 8 10 Q4 12 1 6 Q-4 12-8 8 Q-11 4-6 1 Q-13 0-11-5 Q-9-9-4-6 Z",
         "#c29154", stroke="#493330", stroke_width=1.1, stroke_linejoin="round")
    path(flower, "M-1-10 Q-3-9-1-5 M10-5 L6-2 M7 7 L4 4 M-7 7 L-4 4 M-9-4 L-5-2",
         "none", stroke="#f5d497", stroke_width=1.42, stroke_linecap="round")
    node(flower, "circle", cx=0, cy=0, r=3.25, fill=center, stroke="#624636", stroke_width=.9)
    node(flower, "circle", cx=-.8, cy=-1.1, r=.95, fill="#fff1cb")


def _pearl(parent, x, y, size):
    node(parent, "circle", cx=x, cy=y, r=size, fill="#e2d5c0", stroke="#6f5247", stroke_width=.8)
    node(parent, "circle", cx=x - .28 * size, cy=y - .32 * size, r=.39 * size, fill="#fff4d9")


def draw_song_pearl_crown(parent, look, fit):
    # Seated Portrait of Ningzong's Empress, National Palace Museum, catalogue 1844.
    crown = fit.crown(parent, minimum_y=26)
    path(crown, "M85 108 C84 79 99 50 123 38 C141 28 159 26 179 32 "
         "C215 38 237 66 237 108 L225 115 Q161 109 94 115 Z", "#38373c", class_="edge")
    path(crown, "M94 101 Q99 65 125 46 Q151 32 173 34 C135 45 126 76 127 99 Z", "#544b4c")
    path(crown, "M181 35 Q214 41 230 74 Q234 88 234 105 L194 104 Q202 63 181 35 Z", "#25252b")
    path(crown, "M206 48 Q229 67 233 103 L214 103 Q215 69 206 48 Z", "url(#ink-lines)", opacity=".62")
    path(crown, "M90 100 Q108 79 122 69 Q137 58 147 41 M225 99 "
         "Q209 82 198 73 Q181 56 174 43 M133 99 Q149 86 160 71 Q168 84 184 98",
         "none", stroke="#9c7959", stroke_width=1.38, stroke_linecap="round")
    for x, y, size, tilt, center in (
        (160, 41, .94, 1, "#889a8c"), (128, 53, .82, -26, "#a76657"), (191, 53, .83, 24, "#859688"),
        (104, 75, .80, -35, "#829589"), (138, 77, .90, -14, "#849589"),
        (181, 77, .85, 15, "#a46054"), (217, 75, .81, 36, "#ad6a56"), (160, 63, .83, 4, "#ba7960"),
    ):
        _flower_pin(crown, x, y, size, tilt, center)
    for x, y, size in ((112, 56, 2.1), (143, 45, 1.9), (177, 45, 2), (208, 58, 2.2),
                       (117, 87, 2), (151, 94, 2.15), (169, 93, 2.25), (205, 88, 2.2)):
        _pearl(crown, x, y, size)

    rim = fit.sides(parent)
    path(rim, "M84 103 Q114 92 160 92 Q207 92 236 103 L232 116 Q159 114 88 116 Z",
         "#4e4141", class_="edge")
    path(rim, "M87 104 Q115 95 160 95 Q209 95 233 104 M89 113 Q159 111 231 113",
         "none", stroke="#b18d64", stroke_width=1.25, stroke_linecap="round")
    for x, y, size in ((92, 107.7, 2.9), (102, 105.1, 3.2), (113, 103, 3.4), (124, 101.2, 3.8),
                       (136, 100.3, 3.6), (148, 99.7, 3.75), (160, 99.6, 4.2), (172, 99.7, 3.75),
                       (184, 100.3, 3.6), (196, 101.2, 3.8), (207, 103, 3.4), (218, 105.1, 3.2),
                       (228, 107.7, 2.9)):
        _pearl(rim, x, y, size)
    for mirror in (None, "translate(320 0) scale(-1 1)"):
        pendant = node(rim, "g", transform=mirror)
        path(pendant, "M91 111 Q84 119 85 128", "none", stroke="#a58159", stroke_width=1.6)
        for x, y, size in ((88, 116, 2.35), (86, 121, 2.5), (85, 126.5, 2.6), (85, 132, 3.2)):
            _pearl(pendant, x, y, size)


DRAWERS = {
    "rus_diamond_band": draw_rus_diamond_band,
    "naumburg_linen_cap": draw_naumburg_linen_cap,
    "castile_pleated_tocado": draw_castile_pleated_tocado,
    "song_pearl_crown": draw_song_pearl_crown,
}
