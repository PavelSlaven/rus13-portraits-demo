from common import node, number, path


OPTIONS = {
    "nw_nov_womens_rubakha": "Новгородская рубаха с клетчатым полотнищем",
    "nw_nov_womens_fur_coat": "Новгородский женский кожух",
    "nw_nov_trimmed_gown": "Новгородское платье с узорными лентами",
    "nw_karel_apron_gown": "Карельский наряд с передником и парными фибулами",
    "nw_baltic_spiral_kuub": "Синий кууб с бронзовыми спиралями",
    "nw_nordic_pleated_gown": "Норвежское шерстяное платье со складками",
}


def _neck_band(art, fill, outline, lower=319):
    left, right = round(160 - art.neck, 3), round(160 + art.neck, 3)
    return path(
        art.front,
        f"M{left} 273 Q160 307 {right} 273 l3 8 Q160 {lower} {left - 3} 281Z",
        fill, stroke=outline, stroke_width=2.15, stroke_linejoin="round",
    )


def _wool_check(parent, name, contour, base, stripe, thread, step, rotation=0):
    group = node(parent, "g", data_part=name)
    pattern_id = f"wardrobe-nw-{name}-weave"
    pattern = node(node(group, "defs"), "pattern", id=pattern_id, width=step, height=step,
                   patternUnits="userSpaceOnUse", patternTransform=f"rotate({rotation})")
    node(pattern, "rect", width=step, height=step, fill=base)
    path(pattern, f"M4 0V{step}", "none", stroke=stripe, stroke_width=6, opacity=.84)
    path(pattern, f"M0 5H{step}", "none", stroke=stripe, stroke_width=6.5, opacity=.72)
    path(pattern, f"M10 0V{step} M0 11H{step}", "none", stroke=thread, stroke_width=1.1, opacity=.78)
    path(group, contour, f"url(#{pattern_id})", stroke="#473331", stroke_width=2.45,
         stroke_linejoin="round")
    return group


def draw_rubakha(art):
    front, cloth, body = art.front, art.cloth, art.body
    _neck_band(art, "#ad8b6f", "#594538", 317)
    path(front, "M154 294Q157 304 154 325l5 4 6-5-3-28", cloth.light,
         stroke="#6d5042", stroke_width=1.7, stroke_linejoin="round")
    path(front, "M155 305l8 4m-8 1 8 4m-8 1 7 4", "none", stroke="#885d4b", stroke_width=1.35)
    path(front, "M156 323Q155 330 151 334 M160 325Q163 330 161 334", class_="etch")

    for index in (-2, -1, 1, 2):
        x = 160 + round(index * body.waist / 4)
        path(front, f"M{x + index * 5} {345 - abs(index) * 5} Q{x + index} 375 {x} 401 "
             f"L{x + 4} 401 Q{x + index * 4} 374 {x + index * 5} {345 - abs(index) * 5}Z",
             cloth.shade, opacity=.66)

    half = round(.69 * body.waist)
    bottom = f"L{166 + half} 447 H{154 - half}"
    fold_y = 446
    if art.hem_y is not None:
        fold_y = art.hem_y - 54
        flare = min(half + 16, art.hem_half - 18)
        bottom = (f"Q{167 + half} 452 {160 + flare} {fold_y} "
                  f"Q160 {fold_y + 9} {160 - flare} {fold_y} Q{153 - half} 452 {160 - half} 403")
    # Checked wool is attested at Novgorod. Its use as a waist panel is conjectural.
    checked = _wool_check(
        front, "checked-waist-panel",
        f"M{160 - half} 403 Q160 413 {160 + half} 403 {bottom}Z",
        "#98635c", "#564550", "#d5a186", 20, -5,
    )
    fold = 160 + round(.66 * half)
    fold_mid = (412 + fold_y) // 2
    path(checked, f"M{fold} 411Q{fold + 1} {fold_mid} {fold - 5} {fold_y}h6Q{fold + 7} {fold_mid + 1} {fold + 4} 410Z",
         "#4f3540", opacity=.54)
    path(checked, f"M{fold - 1} 415Q{fold} {fold_mid + 1} {fold - 5} {fold_y}", "none",
         stroke="#e0ab8c", stroke_width=1.2, opacity=.53)

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        cuff = f"M{outside - 2} 421 Q{outside + 20} 428 {170 - body.waist} 420"
        path(sleeve, cuff, "none", stroke="#806352", stroke_width=5)
        path(sleeve, cuff, "none", stroke="#d0af86", stroke_width=1.55, stroke_dasharray="2 2.5")


def draw_fur_coat(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = round(160 - art.neck, 3), round(160 + art.neck, 3)
    opening_bottom = "L149 447 H171 L169 390"
    underlayer = "M157 305Q155 379 156 447h8q2-68 0-142Z"
    shadow_bottom = "Q121 404 113 446h15Q134 418 134 386"
    light_bottom = "Q122 414 115 445"
    fur_bottom = "L151 385 153 399 150 416 152 429 150 447 H136 L139 431 137 416"
    if art.hem_y is not None:
        low = art.hem_y + 11
        bend = round((390 + low) / 2)
        drift = round(.16 * (art.hem_half - 55))
        opening_bottom = f"Q151 {bend} 145 {low} H175 Q169 {bend} 169 390"
        underlayer = f"M157 305Q159 {bend} 152 {low}h16Q161 {bend} 164 305Z"
        shadow_bottom = (f"Q119 {bend} {113 - drift} {low}h15 "
                         f"Q135 {bend} 134 386")
        light_bottom = f"Q125 {bend} {112 - drift} {low - 9}"
        fur_bottom = ("L151 385 153 399 150 416 152 429 "
                      f"Q150 {bend} 145 {low}H131 Q139 {bend} 137 416")
    opening = f"M{left} 273 Q139 292 151 293 Q149 349 151 390 {opening_bottom} "
    opening += f"Q171 349 169 293 Q181 292 {right} 273 Q160 307 {left} 273Z"
    path(front, opening, "#413032", class_="edge", data_part="coat-opening")
    path(front, underlayer, "#b59a77", opacity=.83)

    for side, transform in (("left", None), ("right", "translate(320 0) scale(-1 1)")):
        panel = node(front, "g", transform=transform, data_part=f"fur-coat-panel-{side}")
        path(panel, f"M134 309Q121 339 121 373 {shadow_bottom} Q127 347 134 309Z", cloth.shade)
        path(panel, f"M128 317Q116 353 121 386 {light_bottom}", "none",
             stroke=cloth.light, stroke_width=2.05, opacity=.7)
        path(panel, "M128 410q-1 17-5 35", class_="etch")
        fur = (
            f"M{left} 273 Q142 291 155 296 L153 315 155 326 152 346 154 361 "
            f"{fur_bottom} "
            f"L140 399 138 384 141 362 139 345 142 324 140 307 Q128 299 {left - 4} 281Z"
        )
        path(panel, fur, "#ae9072" if side == "left" else "#9d7d64",
             stroke="#5f463b", stroke_width=2, stroke_linejoin="round", data_part="fur-edging")
        stitches = [(133, 296), (145, 314), (145, 332), (144, 351), (144, 370),
                    (143, 389), (143, 408), (142, 426), (143, 443)]
        if art.hem_y is not None:
            stitches.extend((143 - round(5 * ((y - 443) / (low - 443)) ** 2), y)
                            for y in range(462, low, 19))
        for x, y in stitches:
            path(panel, f"M{x - 3} {y - 6}q4 1 6 7 m-9 0q4 1 6 5", "none",
                 stroke="#654b40", stroke_width=1.35, stroke_linecap="round")
            path(panel, f"M{x} {y - 3}q2 0 4 4", "none", stroke="#d8ba91", stroke_width=1.25)

    for y in (323, 346):
        path(front, f"M150 {y + 1}q11 5 21-1", "none", stroke="#57403a",
             stroke_width=2.8, stroke_linecap="round")
        node(front, "circle", cx=170, cy=y, r=2.25, fill="#b29168", stroke="#593e35", stroke_width=1.05)

    outside = 160 - body.sleeve
    inner = 179 - body.waist
    for sleeve in art.sleeves:
        path(sleeve, f"M{outside - 5} 413Q{outside + 20} 422 {inner} 411 L{inner + 2} 426 "
             f"Q{outside + 25} 439 {outside - 4} 429Z", "#a88b70",
             stroke="#5b433a", stroke_width=2, stroke_linejoin="round")
        for x in range(outside + 2, inner, 7):
            path(sleeve, f"M{x} 421q2 4 1 8m4-10 1 6", "none", stroke="#6f5346", stroke_width=1.15)


def draw_trimmed_gown(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = round(160 - art.neck, 3), round(160 + art.neck, 3)
    ribbon = node(front, "g", data_part="sewn-patterned-ribbon")
    collar = f"M{left} 273Q160 307 {right} 273l5 9Q160 332 {left - 5} 282Z"
    path(ribbon, collar, "#6d433e", stroke="#51313a", stroke_width=2.1)
    path(ribbon, f"M{left - 1} 279Q160 315 {right + 1} 279", "none",
         stroke="#d5a66e", stroke_width=1.35, stroke_dasharray="2.4 2.2")
    for index in range(-2, 3):
        x = number(160 + index * art.neck * .34)
        y = 302 - index * index * 1.35
        path(ribbon, f"M{x} {number(y - 4)}l4 4-4 4-4-4Z", "#daa774")

    for side, transform in (("left", None), ("right", "translate(320 0) scale(-1 1)")):
        strip = node(ribbon, "g", transform=transform, data_part=f"vertical-gown-ribbon-{side}")
        outer = 160 - round(body.waist * .46)
        bottom = 447
        left_edge, right_edge = f"Q{outer - 1} 376 {outer - 7} 447", f"Q{outer + 10} 380 {outer + 6} 326"
        outer_stitch = f"Q{outer + 2} 387 {outer - 5} 447"
        inner_stitch = f"Q{outer + 8} 383 {outer + 3} 447"
        flare = 0
        if art.hem_y is not None:
            bottom = art.hem_y - 4
            flare = round(.52 * (art.hem_half - body.waist))
            bend = round((447 + bottom) / 2)
            left_edge += f" Q{outer - 8} {bend} {outer - 7 - flare} {bottom}"
            right_edge = f"Q{outer + 5} {bend} {outer + 6} 447 {right_edge}"
            outer_stitch += f" Q{outer - 6} {bend} {outer - 5 - flare} {bottom}"
            inner_stitch += f" Q{outer + 2} {bend} {outer + 3 - flare} {bottom}"
        path(strip, f"M{outer - 5} 320 {left_edge}H{outer + 6 - flare} {right_edge}Z", "#794944",
             stroke="#553538", stroke_width=1.9, stroke_linejoin="round")
        path(strip, f"M{outer - 3} 330{outer_stitch} M{outer + 4} 331{inner_stitch}", "none",
             stroke="#c69067", stroke_width=1.05)
        for y in range(335, bottom, 11):
            x = outer + (2 if y < 401 else 1)
            if y > 447:
                x -= round(flare * ((y - 447) / (bottom - 447)) ** 2)
            path(strip, f"M{x} {y - 4}l2.5 4-2.5 4-2.5-4Z", "#e2b781")
        path(strip, f"M{outer - 11} 339Q{outer - 16} 363 {outer - 10} 397 "
             f"Q{outer - 11} 424 {outer - 14} 443", "none", stroke=cloth.light, stroke_width=1.75, opacity=.7)

    if art.hem_y is not None:
        half, hem = art.hem_half - 5, art.hem_y
        path(ribbon, f"M{160 - half} {hem - 13}Q160 {hem + 6} {160 + half} {hem - 13} "
             f"L{160 + half} {hem - 7}Q160 {hem + 12} {160 - half} {hem - 7}Z", "#ae845c")

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        cuff = f"M{outside - 4} 418 Q{outside + 22} 427 {173 - body.waist} 416"
        path(sleeve, cuff, "none", stroke="#4f3638", stroke_width=11)
        path(sleeve, cuff, "none", stroke="#9d5b50", stroke_width=8)
        path(sleeve, cuff, "none", stroke="#e0ae77", stroke_width=2.4, stroke_dasharray="3 2.8")


def draw_karel_apron_gown(art):
    front, cloth, body = art.front, art.cloth, art.body
    _neck_band(art, "#e7d1a4", "#79634f", 319)
    shoulder = 160 - body.shoulder
    pin = shoulder + round(body.shoulder * .45)
    edge = 150 - body.waist
    wool_bottom = f"L{173 + body.hem} 447 H{147 - body.hem} L{edge} 404"
    if art.hem_y is not None:
        half, hem = art.hem_half + 8, art.hem_y
        wool_bottom = (f"Q{168 + body.hem} 482 {160 + half} {hem + 2} "
                       f"Q160 {hem + 24} {160 - half} {hem + 2} Q{152 - body.hem} 482 {edge} 404")
    wool = (
        f"M{shoulder + 8} 283 Q{shoulder + 25} 276 {pin + 10} 288 "
        f"Q{pin + 4} 315 160 332 Q{316 - pin} 315 {310 - pin} 288 "
        f"Q{295 - shoulder} 276 {312 - shoulder} 283 "
        f"Q{306 - shoulder} 309 {167 + body.chest} 339 L{320 - edge} 404 "
        f"{wool_bottom} "
        f"L{153 - body.chest} 339 Q{shoulder + 14} 309 {shoulder + 8} 283Z"
    )
    path(front, wool, cloth.base, stroke=cloth.deep, stroke_width=3.05, stroke_linejoin="round",
         data_part="wool-overgown")
    if art.hem_y is not None:
        for side in (-1, 1):
            waist_fold = 160 + side * round(.83 * body.waist)
            bottom_fold = 160 + side * round(.71 * art.hem_half)
            path(front, f"M{waist_fold} 388Q{waist_fold - 7 * side} 470 {bottom_fold} {hem + 6} "
                 f"h{side * 13}Q{waist_fold + 4 * side} 473 {waist_fold} 388Z", cloth.shade, opacity=.71)
            path(front, f"M{waist_fold - 4 * side} 420Q{waist_fold - 9 * side} 493 {bottom_fold - 6 * side} {hem - 8}",
                 "none", stroke=cloth.light, stroke_width=1.65, opacity=.8)
        path(front, f"M{173 - half} {hem - 7}Q160 {hem + 12} {147 + half} {hem - 7}", class_="seam")
    path(front, f"M{shoulder + 15} 294Q{shoulder + 18} 324 {164 - body.chest} 346 "
         f"Q{159 - body.waist} 378 {166 - body.waist} 398 "
         f"M{pin + 9} 311Q{pin + 19} 328 160 339Q{301 - pin} 328 {311 - pin} 311",
         "none", stroke=cloth.light, stroke_width=2.15, opacity=.73)

    for x, direction in ((pin, 1), (320 - pin, -1)):
        path(front, f"M{x + 5 * direction} 310q{9 * direction} 20 {20 * direction} 29 "
             f"q{-13 * direction} 17 {-19 * direction} 59", "none", stroke=cloth.shade, stroke_width=2.5)

    fastenings = node(front, "g", data_part="karel-fasteners")
    ring = node(fastenings, "g", data_part="shirt-ring-brooch")
    node(ring, "circle", cx=160, cy=306, r=5.2, fill="none", stroke="#55463e", stroke_width=3.25)
    node(ring, "circle", cx=160, cy=306, r=5.2, fill="none", stroke="#d8cec0", stroke_width=1.4)
    path(ring, "M157 303l6 6", "none", stroke="#c0b8a8", stroke_width=1.25)

    chain = f"M{pin} 312 Q160 368 {320 - pin} 312"
    path(fastenings, chain, "none", stroke="#3c332c", stroke_width=4.25)
    path(fastenings, chain, "none", stroke="#c5a570", stroke_width=2.05, stroke_dasharray="2.9 1.5",
         data_part="chest-chain")
    for x, tilt in ((pin, -19), (320 - pin, 19)):
        fibula = node(fastenings, "g", transform=f"translate({x} 302) rotate({tilt})", data_part="oval-fibula")
        node(fibula, "ellipse", rx=10.2, ry=15, fill="#94724d", stroke="#46362d", stroke_width=2.3)
        node(fibula, "ellipse", rx=7.1, ry=11.7, fill="#bfa16a", stroke="#e0bd81", stroke_width=1.2)
        path(fibula, "M0-8Q6-5 0 0Q-6 5 0 9 Q6 5 0 0 Q-6-5 0-8Z", "none",
             stroke="#76593f", stroke_width=1.3)
        path(fibula, "M0-9v2m0 14v2m-5-9h1m8 0h1", "none", stroke="#f0cf98", stroke_width=1.65)

    half = round(.54 * body.waist)
    apron = node(front, "g", data_part="wool-apron")
    bottom = f"L{167 + half} 447H{153 - half}"
    low, flare = 447, half + 7
    if art.hem_y is not None:
        low = art.hem_y - 37
        flare = min(half + 16, art.hem_half - 18)
        bottom = (f"Q{164 + half} 430 {160 + flare} {low} "
                  f"Q160 {low + 9} {160 - flare} {low} Q{156 - half} 430 {161 - half} 396")
    path(apron, f"M{161 - half} 396Q160 405 {159 + half} 396 {bottom}Z",
         "#a07552", stroke="#533a33", stroke_width=2.7, stroke_linejoin="round")
    path(apron, f"M{161 - half} 398Q160 407 {159 + half} 398 l2 6Q160 414 {159 - half} 404Z",
         "#78543e")
    path(apron, f"M{164 - half} 403Q160 412 {156 + half} 403", "none",
         stroke="#c79c6c", stroke_width=1.6, stroke_dasharray="2 2.8")
    for x, direction in ((166 - half, -1), (150 + half, 1)):
        bend = round((409 + low) / 2)
        spread = direction * (flare - half - 7)
        path(apron, f"M{x} 409Q{x + 4} {bend - 1} {x + 2 + spread} {low}", "none",
             stroke="#76523d", stroke_width=2.1)
    if art.hem_y is not None:
        path(apron, f"M{163 - flare} {low - 23}Q160 {low - 16} {157 + flare} {low - 23} "
             f"L{157 + flare} {low - 4}Q160 {low + 4} {163 - flare} {low - 4}Z", "#78543e")
        for x in range(176 - flare, 155 + flare, 16):
            y = low - 11 + round(2 * (1 - ((x - 160) / flare) ** 2))
            path(apron, f"M{x - 5} {y - 5}h10v10h-10Z m3 6q0 -5 5 -4q5 2 1 5q-4 1 -3 -2",
                 "none", stroke="#c59863", stroke_width=1.3)


def _spiral_braid(sleeve, left, right, y, cloth):
    braid = node(sleeve, "g", data_part="bronze-spiral-braid")
    band = f"M{left - 8} {y - 3}Q{(left + right) // 2} {y + 8} {right + 5} {y - 3}"
    path(braid, band, "none", stroke=cloth.deep, stroke_width=9.8)
    path(braid, band, "none", stroke="#785f49", stroke_width=6.15)
    count = (right - left) // 7 + 1
    for index in range(count):
        position = index / (count - 1)
        x = number(left + (right - left) * position)
        cy = number(y - 2 + 19 * position * (1 - position))
        coil = node(braid, "g", transform=f"translate({x} {cy}) rotate({number(18 - 36 * position)})")
        path(coil, "M-3 1q0-3 3-3t3 3q0 2-2 2t-2-2q0-1 1-1t1 1",
             "none", stroke="#dfb97e", stroke_width=1.14, stroke_linecap="round")


def draw_baltic_kuub(art):
    front, cloth, body = art.front, art.cloth, art.body
    _neck_band(art, "#d7bd92", cloth.deep, 317)
    left, right = round(160 - art.neck, 3), round(160 + art.neck, 3)
    necklace = node(front, "g", data_part="cowrie-necklace")
    path(necklace, f"M{left} 285 Q160 325 {right} 285 M{left - 3} 293 Q160 337 {right + 3} 293",
         "none", stroke="#443b35", stroke_width=1.5)
    for y in (305, 315):
        for index in range(-3, 4):
            x = number(160 + index * art.neck * .26)
            cy = round(y - index * index * .76, 3)
            node(necklace, "ellipse", cx=x, cy=cy, rx=2.1, ry=3.12, fill="#e1c598",
                 stroke="#685645", stroke_width=.95, transform=f"rotate({-index * 8} {x} {cy})")
            path(necklace, f"M{x} {cy - 1.25}l-.35 2.4", "none", stroke="#7d5a46", stroke_width=.85)

    shoulder = 160 - body.shoulder
    if "cloak" not in art.look:
        shawl = _wool_check(
            front, "checked-shoulder-wrap",
            f"M{shoulder - 3} {body.shoulder_y - 3} Q{shoulder + 13} 274 {left - 5} 274 "
            f"Q{left - 13} 296 {left - 5} 309 Q{shoulder + 28} 325 {shoulder + 25} 353 "
            f"Q{shoulder + 8} 350 {shoulder - 3} 342 Q{shoulder + 9} 306 {shoulder - 3} {body.shoulder_y - 3}Z",
            "#8d7869", "#4a4950", "#d5b28a", 15, -19,
        )
        path(shawl, f"M{shoulder + 4} 342Q{shoulder + 13} 347 {shoulder + 24} 350", "none",
             stroke="#e0bb8a", stroke_width=1.6, stroke_dasharray="2 2.3")

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        _spiral_braid(sleeve, outside + 11, shoulder + 10, 325, cloth)
        _spiral_braid(sleeve, outside + 8, 164 - body.waist, 412, cloth)
        path(sleeve, f"M{outside - 4} 436Q{outside + 17} 441 {179 - body.waist} 433V447H{outside - 4}Z",
             "#d4bd95", stroke=cloth.deep, stroke_width=2.15)
        path(sleeve, f"M{outside - 3} 440Q{outside + 18} 445 {179 - body.waist} 437", "none",
             stroke="#805b4d", stroke_width=1.7, stroke_dasharray="2 2.2")


def draw_nordic_pleated_gown(art):
    front, cloth, body = art.front, art.cloth, art.body
    _neck_band(art, "#d8c49e", cloth.deep, 324)
    left, right = round(160 - art.neck, 3), round(160 + art.neck, 3)
    path(front, f"M{left - 3} 282Q160 326 {right + 3} 282", "none", stroke=cloth.light, stroke_width=1.75)
    seam_left, seam_right = 151 - body.waist, 169 + body.waist
    skirt = node(front, "g", data_part="gathered-wool-skirt")
    hem_half, low = body.hem + 14, 448
    skirt_bottom = f"L{160 + hem_half} 448H{160 - hem_half}"
    if art.hem_y is not None:
        hem_half, low = art.hem_half + 8, art.hem_y + 11
        skirt_bottom = (f"Q{175 + body.hem} 484 {160 + hem_half} {low} "
                        f"H{160 - hem_half} Q{145 - body.hem} 484 {seam_left} 391")
    path(skirt, f"M{seam_left} 391Q160 405 {seam_right} 391{skirt_bottom}Z",
         cloth.base)
    for index in range(-4, 5):
        x = 160 + round(index * .17 * body.waist)
        start = x + index * 2
        y = 397 - round(.31 * index * index)
        spread = x + round(index * body.hem * .044)
        fold_end = low
        bend = 419
        if art.hem_y is not None:
            spread = 160 + round(.19 * index * art.hem_half)
            fold_end -= round(11 * ((spread - 160) / art.hem_half) ** 2)
            bend = round((y + fold_end) / 2) - 13
        path(front, f"M{start} {315 + abs(index) * 4} Q{x - 4} 352 {x} {y - 2}",
             "none", stroke=cloth.shade, stroke_width=2.1, opacity=.88)
        path(skirt, f"M{x} {y}Q{x - 3} {bend} {spread - 4} {fold_end}h7Q{spread + 2} {bend + 2} {x + 3} {y}Z",
             cloth.shade)
        path(skirt, f"M{x + 5} {y + 4}Q{x + 4} {bend + 1} {spread + 5} {fold_end - 2}", "none",
             stroke=cloth.light, stroke_width=2.0, opacity=.86)
    seam = node(front, "g", data_part="pleated-waist-seam")
    path(seam, f"M{seam_left} 391Q160 405 {seam_right} 391", class_="seam")
    path(seam, f"M{seam_left} 394Q160 408 {seam_right} 394", "none", stroke=cloth.light,
         stroke_width=1.2, stroke_dasharray="1.6 2.6")
    if art.hem_y is not None:
        hem, half = art.hem_y, art.hem_half
        path(skirt, f"M{165 - half} {hem - 7}Q160 {hem + 12} {155 + half} {hem - 7}", class_="seam")

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{outside - 4} 433Q{outside + 21} 443 {175 - body.waist} 432 V448H{outside - 4}Z",
             "#d8c49e", stroke=cloth.deep, stroke_width=2.3)
        path(sleeve, f"M{outside - 3} 439Q{outside + 21} 448 {175 - body.waist} 438",
             "none", stroke="#9e8262", stroke_width=1.25)


DRAWERS = {
    "nw_nov_womens_rubakha": draw_rubakha,
    "nw_nov_womens_fur_coat": draw_fur_coat,
    "nw_nov_trimmed_gown": draw_trimmed_gown,
    "nw_karel_apron_gown": draw_karel_apron_gown,
    "nw_baltic_spiral_kuub": draw_baltic_kuub,
    "nw_nordic_pleated_gown": draw_nordic_pleated_gown,
}
