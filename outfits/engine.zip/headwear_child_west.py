from common import node, number, path
from face_shape import forehead_curve, forehead_curve_segment, make_head


OPTIONS = {
    "child_felt_turnup": "Войлочная шапка с отворотом",
    "child_rus_browband": "Очелье с кольцами",
    "child_castile_cofia": "Кастильский шёлковый чепец",
}
COVERAGE = {
    "child_felt_turnup": {"ears": True, "neck": True, "hair": True},
    "child_rus_browband": {"ears": True, "neck": True, "hair": True},
    "child_castile_cofia": {"ears": False, "neck": True, "hair": False},
}
HAIR_ROOT_HALF = {"child_felt_turnup": 69}
OPEN_CROWNS = {"child_rus_browband"}
BRAID_HEMS = {"child_castile_cofia": ((249, 219), (211, 227))}


def draw_felt_turnup(parent, look, fit):
    crown = fit.crown(parent, minimum_y=61)
    path(crown,
         "M80 106 C83 87 99 72 118 66 C134 61 147 63 158 62 "
         "C181 59 199 66 216 75 Q234 85 241 109 L229 115 Q153 106 92 114 Z",
         "#777756", class_="edge")
    path(crown, "M87 105 Q99 77 124 70 Q139 66 157 66 Q142 75 135 90 "
         "L132 103 Q108 104 87 105 Z", "#929171")
    path(crown, "M169 64 C199 64 229 82 239 106 L197 104 Q190 77 169 64 Z", "#545741")
    path(crown, "M195 71 Q223 78 235 103 L216 101 Q212 86 195 71 Z", "url(#ink-lines)", opacity=".67")
    path(crown, "M160 65 Q149 70 144 78 Q139 85 137 95 M181 69 Q194 79 200 94", class_="seam")
    path(crown, "M103 89 l7-8 m7 3 3-3 m60 1 3 4 m21-1 4 5 m5-2 7 8", class_="etch", opacity=".58")

    roll = fit.sides(parent)
    path(roll, "M81 97 C107 96 131 92 155 93 Q176 92 189 94 Q215 94 239 98 "
         "Q244 100 242 106 L239 116 Q233 121 225 118 C182 112 131 113 94 118 "
         "Q83 121 79 115 L77 103 Q77 99 81 97 Z", "#888467", class_="edge")
    path(roll, "M81 102 C111 98 133 95 154 96 Q174 94 195 98 Q217 97 237 102 "
         "L236 106 C192 100 147 99 117 104 Q94 106 82 107 Z", "#b2aa82")
    path(roll, "M82 113 Q103 106 143 108 C182 107 213 110 239 112 L238 116 "
         "Q234 119 226 115 Q163 108 95 116 Q87 118 82 113 Z", "#64644b")
    path(roll, "M88 112 l6-2 m7 0 7-2 m9 0 6-2 m8 1 4-2 m49 1 6 1 m8 0 6 1 m10 0 5 2 m8 0 6 2",
         class_="etch", opacity=".68")


def draw_rus_browband(parent, look, fit):
    sides = fit.sides(parent)
    for mirror in (None, "translate(320 0) scale(-1 1)"):
        temple = node(sides, "g", transform=mirror)
        path(temple, "M236 110 C241 108 247 112 246 117 L244 124 Q241 127 237 123 L235 117 Z",
             "#b87653", class_="edge")
        path(temple, "M238 113 Q243 111 243 117 L241 121", "none",
             stroke="#deb58a", stroke_width=1.5, stroke_linecap="round")
        ring = "M243 125 C244 119 237 118 232 123 C226 129 231 139 238 138 C244 138 247 131 245 127"
        path(temple, ring, "none", stroke="#322821", stroke_width=4.2, stroke_linecap="round")
        path(temple, ring, "none", stroke="#d0b58a", stroke_width=2.1, stroke_linecap="round")
        path(temple, "M235 123 Q229 126 232 132 M236 136 q3 2 6-2", "none",
             stroke="#f1d8ae", stroke_width=.9, stroke_linecap="round")

    path(sides, "M78 110 Q78 104 85 103 C110 97 137 96 158 97 C181 96 213 97 237 103 "
         "Q243 105 241 111 L238 121 Q216 116 192 115 Q160 113 134 115 Q104 115 82 121 Z",
         "#834745", class_="edge")
    path(sides, "M83 107 Q110 101 136 101 Q169 99 188 101 Q213 101 238 106", "none",
         stroke="#d2a477", stroke_width=2.3, stroke_linecap="round")
    path(sides, "M85 117 Q113 111 136 111 Q168 109 191 111 Q217 111 235 117", "none",
         stroke="#512d35", stroke_width=2.2, stroke_linecap="round")
    path(sides, "M92 111 l8-5 8 2 -8 5 Z M121 107 l7-5 9 3 -8 5 Z "
         "M152 105 l8-5 9 5 -9 5 Z M183 105 l8-3 8 5 -8 3 Z M212 108 l8-3 9 6 -9 2 Z", "#d5a879")
    path(sides, "M98 110 l3-1 m26-3 3-1 m29 0 3 0 m27 0 3 1 m27 3 3 1", "none",
         stroke="#713b3a", stroke_width=1.3, stroke_linecap="round")


def _cauldron(parent, transform, color):
    # The bowed handle, projecting lugs, and striped bowl follow the Las Huelgas textile.
    motif = node(parent, "g", transform=transform)
    path(motif, "M-10 0 C-9-10 8-12 10-1 M-7-1 C-6-8 7-8 8-1", "none",
         stroke=color, stroke_width=1.15, stroke_linecap="round")
    path(motif, "M-13-1 l3 1 Q-1-2 10-1 l3-2 -1 4 -2 1 Q6 8 0 8 Q-7 7-10 2 l-2-1 Z", color)
    path(motif, "M-8 1 l5 5 M-4 0 l7 7 M0 0 l6 5 M4 0 l4 3", "none",
         stroke="#d9ab69", stroke_width=.8, stroke_linecap="round", opacity=".74")


def draw_castile_cofia(parent, look, fit):
    silk = fit.temples(parent)
    top = fit.top_y - 13
    brim = fit.brim_y
    # Follow the scalp up to the temples, including on a low, wide forehead.
    arch = max(brim - 17, fit.top_y + 1)
    temple_y = 121
    arch_scale = (temple_y - arch) / (temple_y - fit.top_y)
    forehead = ((0, fit.top_y), *forehead_curve(look, make_head(look)))
    first, second, temple = forehead_curve_segment(forehead, temple_y)

    def point(coordinate, side):
        offset, y = coordinate
        x = 160 + side * offset / fit.x_scale
        return f"{number(x)} {number(temple_y + (y - temple_y) * arch_scale)}"

    temple_left = point(temple, -1)
    temple_right = point(temple, 1)
    (outer_x, outer_y), (inner_x, inner_y) = BRAID_HEMS["child_castile_cofia"]
    left_outer = f"{320 - outer_x} {outer_y}"
    left_hem = f"{left_outer} L{320 - inner_x} {inner_y}"
    opening = (
        f"M{left_hem} C95 204 87 182 88 160 Q95 140 {temple_left} "
        f"C{point(second, -1)} {point(first, -1)} 160 {number(arch)} "
        f"C{point(first, 1)} {point(second, 1)} {temple_right} C229 133 225 145 233 169 "
        f"Q231 204 {inner_x} {inner_y} L{outer_x} {outer_y}"
    )
    outline = (
        f"{opening} C259 188 261 145 248 {number(brim - 15)} "
        f"C232 {number(top + 12)} 194 {number(top - 2)} 159 {number(top)} "
        f"C114 {number(top - 1)} 82 {number(top + 15)} 70 {number(brim - 10)} "
        f"C60 137 58 189 {left_outer} Z"
    )
    path(silk, outline, "#b58a51", class_="edge")
    clip = node(node(silk, "defs"), "clipPath", id="child-castile-cofia-silk")
    path(clip, outline)
    weave = node(silk, "g", clip_path="url(#child-castile-cofia-silk)")

    path(weave, f"M72 {number(brim - 4)} C85 {number(top + 20)} 118 {number(top + 3)} 158 {number(top + 4)} "
         f"Q183 {number(top + 4)} 199 {number(top + 9)} C162 {number(top + 6)} 135 {number(top + 20)} "
         f"114 {number(brim - 21)} C88 132 81 176 81 213 L74 215 Q61 158 72 {number(brim - 4)} Z", "#cfa66a")
    path(weave, f"M199 {number(top + 8)} Q235 {number(top + 16)} 247 {number(brim - 11)} "
         f"C259 145 260 188 247 216 L229 220 Q249 163 232 123 Q224 {number(brim - 3)} "
         f"213 {number(brim - 11)} Q223 {number(brim - 26)} 199 {number(top + 8)} Z", "#92613e")
    path(weave, "M249 134 Q261 181 246 216 L235 219 Q250 175 246 155 Z", "url(#ink-lines)", opacity=".58")
    path(weave, f"M91 {number(brim - 23)} Q134 {number(brim - 42)} 165 {number(brim - 37)} "
         f"Q202 {number(brim - 38)} 231 {number(brim - 22)}", "none",
         stroke="#d8ab69", stroke_width=5.1, stroke_linecap="round", opacity=".45")

    space = brim - top - 17
    for x, row, size, tilt, color in (
        (125, .38, .81, -14, "#724232"), (159, .36, .92, 2, "#6b3c31"),
        (194, .41, .82, 10, "#734231"),
        (103, .68, .72, -18, "#724232"), (143, .74, .89, -7, "#723d31"),
        (178, .73, .93, 6, "#6b3c31"), (214, .81, .75, 17, "#653a2e"),
    ):
        _cauldron(weave, f"translate({x} {number(top + space * row)}) rotate({tilt}) scale({size})", color)
    for x, y, tilt, color in (
        (79, 136, -16, "#80513a"), (76, 165, -4, "#734232"), (82, 194, 9, "#754934"),
        (243, 138, 21, "#633a2b"), (245, 169, 6, "#59372b"), (237, 199, -13, "#654030"),
    ):
        _cauldron(weave, f"translate({x} {y}) rotate({tilt}) scale(.64 .81)", color)

    path(silk, opening, "none", stroke="#654133", stroke_width=4.9, stroke_linejoin="round", stroke_linecap="round")
    path(silk, opening, "none", stroke="#d6a468", stroke_width=2.25, stroke_linejoin="round", stroke_linecap="round")
    path(silk, f"M{outer_x} {outer_y} L{inner_x} {inner_y} M{left_hem}", "none",
         stroke="#6a4333", stroke_width=1.15, stroke_dasharray="2 3")
    path(silk, f"M117 {number(top + 11)} Q130 {number(top + 6)} 145 {number(top + 6)} "
         "M72 151 q-4 20-2 33 m1 6 2 9 M235 182 q-2 5-2 7 m8 6-3 8", class_="etch", opacity=".68")

    # The short loose ties are sewn into the inside corners of the lower edge.
    for mirror in (None, "translate(320 0) scale(-1 1)"):
        tie = node(silk, "g", transform=mirror)
        path(tie, "M215 224 Q212 232 204 235 L202 242 Q213 239 219 225 Z",
             "#9e704b", stroke="#493329", stroke_width=1.7, stroke_linejoin="round")
        path(tie, "M216 227 Q210 237 204 239", "none", stroke="#dab071", stroke_width=1.3, stroke_linecap="round")


DRAWERS = {
    "child_felt_turnup": draw_felt_turnup,
    "child_rus_browband": draw_rus_browband,
    "child_castile_cofia": draw_castile_cofia,
}
