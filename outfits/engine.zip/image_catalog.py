"""Portable catalogue and normal rendering entry point for the illustrated INDEX."""

from copy import deepcopy
from functools import lru_cache
import json
import re
from pathlib import Path
from xml.etree import ElementTree as ET

from common import node, tag
import image_equipment


@lru_cache(maxsize=1)
def _items():
    records = json.loads(Path(__file__).with_name("image-inventory.json").read_text(encoding="utf-8"))
    return {record["id"]: record for record in records}


def catalogue():
    return deepcopy(list(_items().values()))


def research_items(equipment):
    return [{key: deepcopy(item[key]) for key in ("id", "label", "integration_status", "integration_flags", "note")
             if key in item}
            for item in _items().values() if item.get("integration_status") == "research_only"
            and item["selection"] and all(equipment.get(field) == value for field, value in item["selection"].items())]


def annotate_research(svg, equipment):
    items = research_items(equipment)
    if not items:
        return svg
    root = ET.fromstring(svg)
    root.set("data-integration-status", "research_only")
    root.set("data-integration-flags", " ".join(dict.fromkeys(flag for item in items for flag in item.get("integration_flags", []))))
    root.set("data-research-items", " ".join(item["id"] for item in items))
    title = root.find(tag("title"))
    if title is not None:
        title.text = (title.text or "Rus13") + " · Исследовательский просмотр"
    description = root.find(tag("desc"))
    if description is None:
        description = node(root, "desc")
    description.text = "Исследовательский предмет. " + " ".join(item["note"] for item in items)
    return ET.tostring(root, encoding="unicode")


def _transformed_camera(camera, transforms):
    x, y, width, height = map(float, camera.split())
    corners = [(x, y), (x + width, y + height)]
    for transform in transforms:
        for kind, arguments in reversed(re.findall(r"(matrix|translate|scale)\(([^)]+)\)", transform)):
            values = [float(value) for value in re.split(r"[ ,]+", arguments.strip())]
            if kind == "matrix":
                a, b, c, d, e, f = values
            elif kind == "translate":
                a, b, c, d, e, f = 1, 0, 0, 1, values[0], values[1] if len(values) > 1 else 0
            else:
                a, b, c, d, e, f = values[0], 0, 0, values[-1], 0, 0
            corners = [(a * px + c * py + e, b * px + d * py + f) for px, py in corners]
    (left, top), (right, bottom) = corners
    return " ".join(f"{value:g}" for value in (left, top, right - left, bottom - top))


def _detail(result, item):
    from wardrobe_northwest_accessories import jewelry_detail_svg

    equipment = result["recipe"]["equipment"]
    hand_detail = jewelry_detail_svg(equipment) if "jewelry" in item["selection"] else None
    # An insole or boot selected alongside a necklace must not replace the
    # necklace's item card with the unrelated footwear detail.
    fallback_detail = None if {"jewelry", "accessory"} & item["selection"].keys() else result.get("detail")
    svg = image_equipment.detail_svg(item["id"], item["label"]) or hand_detail or fallback_detail
    if svg:
        from clothing_materials import apply_materials
        from clothing_catalog import default_materials
        from generate import _MANUAL_CLOTHING

        root = ET.fromstring(svg)
        slot = next((field for field in item["selection"] if not field.endswith("_material")), None)
        subject = root.find(".//*[@data-part='catalog-item']")
        if subject is not None and slot is not None:
            subject.set("data-material-slot", slot)
        apply_materials(root, default_materials(equipment, _MANUAL_CLOTHING))
        root.set("data-catalog-item", item["id"])
        title = root.find(tag("title"))
        if title is None:
            title = node(root, "title")
        title.text = item["label"]
        return ET.tostring(root, encoding="unicode")
    slot = next((field for field in item["selection"] if not field.endswith("_material")), "outfit")
    camera = {
        "headgear": "35 15 250 300", "footwear": "55 626 210 117", "shoe_accessory": "55 675 210 68",
        "leg_wraps": "65 565 190 170", "foot_lining": "55 640 210 101", "trousers": "60 450 200 267",
        "belt": "30 370 260 100", "belt_pouch": "25 335 270 220", "jewelry": "35 245 250 210",
        "accessory": "35 245 250 235", "gloves": "0 370 320 117", "arm_protection": "0 345 320 120",
        "leg_protection": "60 470 200 250", "neck_protection": "65 210 190 145",
    }.get(slot, "25 245 270 480")
    if slot == "jewelry" and equipment.get("jewelry") in {
        "ear_hoops", "shield_temple_ring", "hair_spiral", "riasna", "kolt",
    }:
        camera = "35 45 250 255"
    root = ET.fromstring(result["full"])
    child = root.find(".//*[@data-part='child-figure']")
    if child is not None:
        transforms = []
        if slot in {"trousers", "footwear", "shoe_accessory", "leg_wraps", "foot_lining", "leg_protection"}:
            lower = child.find(".//*[@data-part='full-costume']/" + tag("g"))
            if lower is not None:
                transforms.append(lower.get("transform", ""))
        transforms.append(child.get("transform", ""))
        camera = _transformed_camera(camera, transforms)
    root.attrib.update(width="320", height="260", viewBox=camera)
    title = root.find(tag("title"))
    if title is None:
        title = node(root, "title")
    title.text = item["label"]
    root.set("data-catalog-item", item["id"])
    return ET.tostring(root, encoding="unicode")


def render_catalog_payload(payload):
    identifier = payload.get("catalog_item")
    if not isinstance(identifier, str) or identifier not in _items():
        raise ValueError("Выберите вещь из каталога INDEX.")
    for name in ("appearance", "equipment"):
        if not isinstance(payload.get(name, {}), dict):
            raise ValueError(f"Поле {name} должно содержать объект с параметрами.")
    item = _items()[identifier]
    culture = item["cultures"][0]
    from editor import render_payload
    from generate import VERSION, resolve_appearance
    from costume_cultures import CULTURES

    skin = {"rus": "fair", "nordic": "fair", "baltic": "fair", "karelia": "fair", "western": "fair",
            "castile": "olive", "caucasus": "olive", "iraq_iran": "olive", "south_asia": "brown",
            "angkor": "brown", "song": "fair", "tang": "fair", "japan": "fair", "steppe": "olive",
            "bandiagara": "deep"}.get(culture, "fair")
    profile = "east_eurasia" if culture in {"song", "tang", "japan", "steppe"} else "free"
    if culture in {"rus", "baltic", "nordic", "karelia", "western", "castile"}:
        profile = "novgorod"
    if culture == "bandiagara":
        profile = "sub_saharan"
    appearance = {"skin": skin, **item["appearance"], **payload.get("appearance", {})}
    appearance = resolve_appearance(payload.get("seed"), appearance, profile=payload.get("profile", profile),
                                    extended=True, expanded_hair=True, distinct_bases=True)
    gear = {"outfit": "shirt", "headgear": "none", "accessory": "none", "background": "parchment",
            "cloth_color": "natural", "trousers": "straight", "footwear": "novgorod_shoes",
            "belt": "leather", "carry": "carried", "shield_carry": "back"}
    if appearance["age"] == "child":
        gear["outfit"] = "rus_child_svita"
    if culture in {"song", "tang", "japan", "south_asia", "angkor"}:
        gear["footwear"] = "cloth_shoes"
    if appearance["age"] != "child" and "outfit" not in item["selection"] and (
            identifier.startswith("wp_") or "protection" in " ".join(item["selection"])):
        gear["outfit"] = "nw_mail_hauberk"
    if identifier == "loincloth_fur":
        gear.update(trousers="none", footwear="barefoot", belt="none")
    gear.update(item["selection"])
    gear.update(payload.get("equipment", {}))
    request = {"version": VERSION, "seed": payload.get("seed"), "profile": payload.get("profile", profile),
               "generate": False, "appearance": appearance, "equipment": gear}
    if culture in CULTURES:
        request["culture"] = culture
    if payload.get("estate") not in (None, "auto"):
        request["estate"] = payload["estate"]
    result = render_payload(request)
    result["detail"] = annotate_research(_detail(result, item), result["recipe"]["equipment"])
    result["catalog_item"] = deepcopy(item)
    return result
