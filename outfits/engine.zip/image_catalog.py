"""Portable catalogue and normal rendering entry point for the illustrated INDEX."""

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
from xml.etree import ElementTree as ET

from common import node, tag
import image_equipment


@lru_cache(maxsize=1)
def _items():
    records = json.loads(Path(__file__).with_name("image-inventory.json").read_text(encoding="utf-8"))
    return {record["id"]: record for record in records}


def catalogue():
    return deepcopy(list(_items().values()))


def _detail(result, item):
    from wardrobe_northwest_accessories import jewelry_detail_svg

    equipment = result["recipe"]["equipment"]
    hand_detail = jewelry_detail_svg(equipment) if "jewelry" in item["selection"] else None
    # An insole or boot selected alongside a necklace must not replace the
    # necklace's item card with the unrelated footwear detail.
    fallback_detail = None if {"jewelry", "accessory"} & item["selection"].keys() else result.get("detail")
    svg = image_equipment.detail_svg(item["id"], item["label"]) or hand_detail or fallback_detail
    if svg:
        root = ET.fromstring(svg)
        root.set("data-catalog-item", item["id"])
        title = root.find(tag("title"))
        if title is None:
            title = node(root, "title")
        title.text = item["label"]
        return ET.tostring(root, encoding="unicode")
    slot = next((field for field in item["selection"] if not field.endswith("_material")), "outfit")
    camera = {
        "headgear": "35 15 250 300", "footwear": "55 626 210 117", "shoe_accessory": "55 675 210 68",
        "leg_wraps": "65 565 190 170", "foot_lining": "55 640 210 101", "trousers": "60 450 200 267",
        "belt": "30 370 260 100", "belt_pouch": "25 335 270 220", "jewelry": "35 245 250 210",
        "accessory": "35 245 250 235", "gloves": "0 370 320 117", "arm_protection": "0 345 320 120",
        "leg_protection": "60 470 200 250", "neck_protection": "65 210 190 145",
    }.get(slot, "25 245 270 480")
    if slot == "jewelry" and equipment.get("jewelry") in {
        "ear_hoops", "shield_temple_ring", "hair_spiral", "riasna", "kolt",
    }:
        camera = "35 45 250 255"
    root = ET.fromstring(result["full"])
    root.attrib.update(width="320", height="260", viewBox=camera)
    title = root.find(tag("title"))
    if title is None:
        title = node(root, "title")
    title.text = item["label"]
    root.set("data-catalog-item", item["id"])
    return ET.tostring(root, encoding="unicode")


def render_catalog_payload(payload):
    identifier = payload.get("catalog_item")
    if not isinstance(identifier, str) or identifier not in _items():
        raise ValueError("Выберите вещь из каталога INDEX.")
    for name in ("appearance", "equipment"):
        if not isinstance(payload.get(name, {}), dict):
            raise ValueError(f"Поле {name} должно содержать объект с параметрами.")
    item = _items()[identifier]
    culture = item["cultures"][0]
    from editor import render_payload
    from generate import VERSION
    from costume_cultures import CULTURES

    skin = {"rus": "fair", "nordic": "fair", "baltic": "fair", "karelia": "fair", "western": "fair",
            "castile": "olive", "caucasus": "olive", "iraq_iran": "olive", "south_asia": "brown",
            "angkor": "brown", "song": "fair", "tang": "fair", "japan": "fair", "steppe": "olive",
            "bandiagara": "deep"}.get(culture, "fair")
    profile = "east_eurasia" if culture in {"song", "tang", "japan", "steppe"} else "free"
    if culture in {"rus", "baltic", "nordic", "karelia", "western", "castile"}:
        profile = "novgorod"
    if culture == "bandiagara":
        profile = "sub_saharan"
    appearance = {"skin": skin, **item["appearance"], **payload.get("appearance", {})}
    gear = {"outfit": "shirt", "headgear": "none", "accessory": "none", "background": "parchment",
            "cloth_color": "natural", "trousers": "straight", "footwear": "novgorod_shoes",
            "belt": "leather", "carry": "carried", "shield_carry": "back"}
    if appearance["age"] == "child":
        gear["outfit"] = "rus_child_svita"
    if culture in {"song", "tang", "japan", "south_asia", "angkor"}:
        gear["footwear"] = "cloth_shoes"
    if appearance["age"] != "child" and "outfit" not in item["selection"] and (
            identifier.startswith("wp_") or "protection" in " ".join(item["selection"])):
        gear["outfit"] = "nw_mail_hauberk"
    if identifier == "loincloth_fur":
        gear.update(trousers="none", footwear="barefoot", belt="none")
    gear.update(item["selection"])
    gear.update(payload.get("equipment", {}))
    request = {"version": VERSION, "seed": payload.get("seed"), "profile": payload.get("profile", profile),
               "generate": False, "appearance": appearance, "equipment": gear}
    if culture in CULTURES:
        request["culture"] = culture
    if payload.get("estate") not in (None, "auto"):
        request["estate"] = payload["estate"]
    result = render_payload(request)
    result["detail"] = _detail(result, item)
    result["catalog_item"] = deepcopy(item)
    return result
