"""Selectable equipment added while checking the illustrated INDEX."""

import image_armour_art as armour
import image_arsenal_art as arsenal
import image_court_art as court
import image_daily_art as daily
from pathlib import Path
from xml.etree import ElementTree as ET
from common import node, tag


OPTIONS = {
    "outfit": {**armour.OUTFITS, **court.OUTFITS, **daily.OUTFITS},
    "headgear": {**armour.HEADGEAR, **court.HEADGEAR},
    "weapon": arsenal.WEAPONS,
    "belt": court.BELTS,
    **armour.OPTIONS,
}
for slot, choices in daily.OPTIONS.items():
    OPTIONS[slot] = {**OPTIONS.get(slot, {}), **choices}
OPTIONS["belt_pouch"] = {**OPTIONS["belt_pouch"], **court.BELT_POUCHES}
DETAIL_DRAWERS = {**arsenal.DETAIL_DRAWERS, **daily.DETAIL_DRAWERS, **court.DETAIL_DRAWERS}
ITEM_METADATA = {**arsenal.META, **daily.META, **court.ITEM_METADATA, **armour.ITEM_METADATA}
for record in ITEM_METADATA.values():
    if "detail" in record["selection"]:
        record["selection"] = {"item_detail": record["selection"]["detail"]}
OPTIONS["item_detail"] = {"none": "Без отдельной детали", **{
    key: value["label"] for key, value in arsenal.META.items() if "item_detail" in value["selection"]
}}
LABELS = {**armour.LABELS, "item_detail": "Предмет и части снаряжения крупно"}

ARMAMENT_FIELDS = {"arm_protection", "leg_protection", "neck_protection"}
NEW_ITEMS = {(slot, item) for slot, choices in OPTIONS.items() for item in choices if item != "none"}
AGES = {key: {"adult"} for key in NEW_ITEMS}
CASTS = {key: {None} for key in NEW_ITEMS}
CULTURES = {key: ("rus",) for key in NEW_ITEMS}
MATERIALS = {}
ESTATES = {}
for meta in ITEM_METADATA.values():
    cultures = tuple(meta.get("cultures", (meta.get("culture", "rus"),)))
    for slot, item in meta["selection"].items():
        key = slot, item
        if key not in NEW_ITEMS:
            continue
        AGES[key] = {meta.get("age", "adult")}
        CASTS[key] = {meta.get("cast", "men" if slot in ARMAMENT_FIELDS or slot == "weapon" else None)}
        CULTURES[key] = cultures
        if item.startswith("court_"):
            estates = ("dynastic_elite", "landowners", "urban_elite")
        elif slot in ARMAMENT_FIELDS or slot == "weapon":
            estates = ("dynastic_elite", "landowners", "urban_elite", "free_commons", "dependent_commons")
        else:
            estates = ("urban_elite", "landowners", "free_commons", "dependent_commons", "outcasts")
        ESTATES[key] = estates
        finishes = meta.get("materials", ())
        if finishes:
            MATERIALS.setdefault(slot + "_material", {})[item] = {finishes[0]: True}
        if meta.get("trim_materials"):
            MATERIALS.setdefault(slot + "_trim_material", {})[item] = dict.fromkeys(meta["trim_materials"], True)


def detail_svg(identifier, label):
    drawer = DETAIL_DRAWERS.get(identifier)
    if drawer is None:
        return None
    root = ET.Element(tag("svg"), width="320", height="260", viewBox="0 0 320 260", role="img")
    node(root, "title").text = label
    root.append(ET.parse(Path(__file__).with_name("stage.svg")).getroot().find(tag("defs")))
    node(root, "rect", width=320, height=260, fill="#504438")
    drawer(node(root, "g", data_part="catalog-item", data_source_id=identifier))
    return ET.tostring(root, encoding="unicode")
