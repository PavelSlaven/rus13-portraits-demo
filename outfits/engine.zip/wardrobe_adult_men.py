from common import node, number, path


OPTIONS = {
    "rus_gilt_cuff_tunic": "Рубаха с золотными обшлагами",
    "castile_laced_saya": "Кастильская сая со шнуровкой",
    "yuan_fur_hunt_robe": "Юаньский охотничий халат на меху",
    "song_round_robe": "Парадное одеяние Южной Сун",
}


def _line(parent, contour, color, width, **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def draw_rus_gilt_cuff_tunic(art):
    front, body, cloth = art.front, art.body, art.cloth
    left = number(160 - art.neck)
    right = number(160 + art.neck)
    shoulder = 160 - body.shoulder
    side = 160 - min(body.chest, body.waist)
    gilt, gilt_light, backing = "#c39250", "#ecd08e", "#654638"

    left_fold, right_fold = side + 15, 320 - side - 4
    if art.hem_y is None:
        left_lower = f"H{side + 3} "
        right_lower = f"H{320 - side + 4} "
    else:
        bottom = art.hem_y + 11
        lower_left, lower_right = 160 - art.hem_half, 160 + art.hem_half
        bend = (440 + art.hem_y) // 2
        left_lower = (f"Q{left_fold - 5} {bend} {lower_left + 13} {bottom} "
                      f"H{lower_left - 3} Q{side + 2} {bend} {side + 3} 440 ")
        right_lower = (f"Q{right_fold + 5} {bend} {lower_right - 7} {bottom} "
                       f"H{lower_right + 4} Q{320 - side + 5} {bend} {320 - side + 4} 445 ")
    path(
        front,
        f"M{shoulder + 14} {body.shoulder_y + 7} Q{side + 19} 341 {left_fold} 440 "
        f"{left_lower}Q{side + 8} 359 {shoulder + 9} {body.shoulder_y + 15}Z "
        f"M{320 - shoulder - 13} {body.shoulder_y + 8} Q{320 - side - 6} 346 {right_fold} 445 "
        f"{right_lower}Q{320 - side + 5} 347 {320 - shoulder - 5} {body.shoulder_y + 14}Z",
        cloth.shade, opacity=".72",
    )
    path(front, f"M{side + 23} 326 Q{side + 29} 350 {side + 24} 377 "
         f"m3 36 l-3 24 M{320 - side - 20} 332q7 22 5 47", class_="seam")

    collar = node(front, "g", data_part="gilt-round-collar")
    path(
        collar,
        f"M{left} 273 Q160 307 {right} 273 Q184 293 169 300 L168 324 "
        f"Q160 329 152 324 L152 300 Q136 293 {left} 273Z",
        backing, class_="edge",
    )
    _line(collar, f"M{number(157 - art.neck)} 278 Q141 296 156 299 V321 Q160 324 164 321 "
          f"V299 Q179 296 {number(163 + art.neck)} 278", gilt, 4.9)
    _line(collar, "M143 289q8 8 15 8 m4 0q7 0 15 -8 M157 311h6 m-6 5h6", gilt_light, 1.35)
    _line(collar, "M160 301v17", "#352727", 1.35)

    outside = 160 - body.sleeve
    inside = 160 - body.hem + 11
    middle = (outside + inside) // 2
    for sleeve in art.sleeves:
        cuff = node(sleeve, "g", data_part="gilt-cuff")
        left_edge, right_edge = outside - 5, inside + 16
        top = f"M{left_edge} 396 Q{middle} 408 {right_edge} 398"
        path(cuff, f"{top} L{right_edge + 2} 431 Q{middle} 441 {left_edge} 429Z", backing, class_="edge")
        _line(cuff, f"M{left_edge} 400 Q{middle} 412 {right_edge} 402 "
              f"M{left_edge} 425 Q{middle} 437 {right_edge + 2} 427", gilt, 5.6)
        _line(cuff, f"M{left_edge} 404 Q{middle} 416 {right_edge} 406 "
              f"M{left_edge} 422 Q{middle} 434 {right_edge + 2} 424", gilt_light, 1.4)
        for x in range(outside + 5, inside + 9, 9):
            y = 416 - round(3 * ((x - middle) / (inside - outside) * 2) ** 2)
            _line(cuff, f"M{x - 4} {y} q4 -8 8 0 q-4 8 -8 0Z", gilt, 2.1)
            path(cuff, f"M{x} {y - 2} l1.8 2 -1.8 2 -1.8 -2Z", gilt_light)


def draw_castile_laced_saya(art):
    front, body, cloth = art.front, art.body, art.cloth
    # The tie sits on the wearer's left side.
    top = 160 + body.chest - 23
    bottom = 160 + body.waist - 23
    left, right = number(156 - art.neck), number(164 + art.neck)
    path(
        front,
        f"M{left} 276 C{number(150 - art.neck)} 296 139 314 160 315 "
        f"C181 314 {number(170 + art.neck)} 296 {right} 276 "
        f"Q183 300 160 301 Q137 300 {left} 276Z",
        cloth.deep,
    )
    _line(front, f"M{left} 278 C{number(152 - art.neck)} 296 141 312 160 312 "
          f"S{number(168 + art.neck)} 296 {right} 278", "#c8a36c", 2.75)
    _line(front, f"M{number(154 - art.neck)} 277 Q160 314 {number(166 + art.neck)} 277",
          "#d1b38a", 2.6)

    # Muted shield motifs evoke the quartered silk at Las Huelgas.
    tower = "m-3 9v-4h2v-2h2v2h2v4Z"
    lion = "m-3 11l2 -5 2 1 1 -3 2 1 -2 4 -1 4 -2 -4Z"
    rows = 4 if art.hem_y is None else (art.hem_y - 326 - 15) // 31 + 1
    for row in range(rows):
        y = 326 + 31 * row
        count = 3 + row % 2
        for index in range(count):
            x = 160 + (2 * index - count + 1) * 14
            path(front, f"M{x - 6} {y}h12v7q-1 5 -6 8q-5 -3 -6 -8Z", cloth.deep, opacity=".62")
            mark = tower if (index + row) % 2 else lion
            path(front, f"M{x} {y}{mark}", "#d7b17c", opacity=".62")

    seam = node(front, "g", data_part="saya-side-lacing")
    path(seam, f"M{top - 6} 336 Q{top - 5} 362 {bottom - 7} 402 L{bottom + 11} 403 "
         f"Q{top + 15} 367 {top + 12} 335Z", cloth.deep, class_="edge")
    _line(seam, f"M{top - 5} 338 Q{top - 4} 365 {bottom - 6} 399 "
          f"M{top + 11} 338 Q{top + 12} 365 {bottom + 10} 399", cloth.light, 1.6)
    for index in range(6):
        y = 342 + index * 10
        x = round(top + (bottom - top) * index / 5)
        node(seam, "circle", cx=x, cy=y, r=2.15, fill="#332629")
        node(seam, "circle", cx=x + 8, cy=y + 5, r=2.15, fill="#332629")
        _line(seam, f"M{x} {y} l8 5", "#e7c18b", 2.75)
        if index < 5:
            next_x = round(top + (bottom - top) * (index + 1) / 5)
            _line(seam, f"M{x + 8} {y + 5} L{next_x} {y + 10}", "#bf905a", 2.5)
    _line(seam, f"M{bottom + 8} 397 q17 -7 11 2 q-4 6 -11 -2 q-10 8 2 21 m-2 -21 q4 6 10 9",
          "#e7c18b", 2.5)
    if art.hem_y is None:
        path(front, f"M{bottom - 9} 401 Q{bottom - 5} 425 {160 + body.hem - 12} 439 "
             f"M{174 - body.waist} 398 Q{170 - body.hem} 423 {171 - body.hem} 438", class_="seam")
    else:
        bend = (401 + art.hem_y) // 2
        path(front, f"M{bottom - 9} 401 Q{bottom - 5} {bend} {150 + art.hem_half} {art.hem_y - 4} "
             f"M{174 - body.waist} 398 Q{170 - body.hem} {bend} {171 - art.hem_half} {art.hem_y - 4}",
             class_="seam")

    outside = 160 - body.sleeve
    inside = 160 - body.hem + 11
    for sleeve in art.sleeves:
        path(sleeve, f"M{outside + 12} 341 Q{outside + 6} 379 {outside + 20} 425 "
             f"Q{outside + 22} 438 {inside} 445 Q{outside + 11} 443 {outside + 10} 418 "
             f"Q{outside} 379 {outside + 9} 347Z", cloth.deep, opacity=".49")
        path(sleeve, f"M{outside + 17} 350 Q{outside + 11} 386 {outside + 22} 410 "
             f"M{outside + 22} 419 Q{outside + 32} 431 {inside - 2} 432", class_="etch")


def draw_yuan_fur_hunt_robe(art):
    front, body, cloth = art.front, art.body, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    endpoint = 152 - body.waist
    bottom, shade_bend, shade_tip, shade_back = 445, 436, endpoint + 28, endpoint - 5
    if art.hem_y is not None:
        bottom = art.hem_y + 12
        shade_bend = (414 + bottom) // 2
        shade_tip, shade_back = 195 - art.hem_half, 166 - art.hem_half
    path(
        front,
        f"M{left} 274 Q132 302 167 322 Q134 366 {endpoint + 6} 414 "
        f"Q{endpoint + 14} {shade_bend} {shade_tip} {bottom} H{shade_back} "
        f"Q{endpoint + 4} 377 132 316 Q120 304 {left} 274Z",
        cloth.shade, opacity=".78",
    )
    path(
        front,
        f"M{right} 275 Q{193 + body.chest // 3} 303 186 341 "
        f"Q138 367 {endpoint + 27} 420 Q{endpoint + 33} 387 121 350 Q176 291 {right} 275Z",
        cloth.light, opacity=".82",
    )
    path(front, f"M{endpoint + 22} 411q3 16 17 25 M181 370q-25 19 -29 36 "
         "M185 380q-15 13 -21 31 M194 367q-8 7 -9 13", class_="etch", opacity=".55")
    _line(front, f"M{endpoint + 44} 399q-3 3 -5 8 m13 -4q-4 3 -7 9 m12 -7q-3 4 -4 7 "
          "M176 345q-4 3 -6 7 m13 -6q-5 2 -8 8 m14 -7q-3 2 -5 6",
          cloth.shade, 1.5)

    outside = 160 - body.sleeve
    inside = 160 - body.hem + 11
    shoulder = 160 - body.shoulder
    for sleeve in art.sleeves:
        path(sleeve, f"M{shoulder + 11} {body.shoulder_y} Q{outside + 14} 334 {outside + 8} 371 "
             f"Q{outside + 2} 409 {outside + 15} 437 Q{outside + 31} 434 {inside + 8} 441 "
             f"Q{outside + 18} 404 {outside + 32} 350 Q{shoulder + 14} 324 {shoulder + 11} {body.shoulder_y}Z",
             cloth.light, opacity=".76")
        path(sleeve, f"M{outside + 16} 351 q-7 20 -6 49 m10 -38q-8 19 -5 40 "
             f"M{outside + 21} 415 l6 10 m0 -13 6 11 m1 -8 5 10 M{outside + 11} 432 l8 6 m2 -5 9 7",
             class_="etch", opacity=".55")
        _line(sleeve, f"M{outside + 23} 330q-4 3 -5 7 m9 -5q-2 4 -3 8 "
              f"M{outside + 20} 405q1 5 4 8 m1 -10q1 4 4 7 m1 -10q1 4 4 7", cloth.shade, 1.55)

    trim = node(art.outer, "g", data_part="crossed-fur-edging")
    path(trim, f"M{left} 273 C144 287 160 296 179 309 L169 324 "
         f"Q137 309 {number(150 - art.neck)} 283Z", "#564440", class_="edge")
    if art.hem_y is None:
        trim_tip, trim_inner, trim_end = endpoint + 4, endpoint - 9, 442
        piping = f"L{endpoint - 1} 440"
        trim_bottom = f"L{trim_tip} {trim_end} H{trim_inner} L{endpoint - 5} 406 "
    else:
        trim_tip, trim_inner, trim_end = 177 - art.hem_half, 164 - art.hem_half, art.hem_y + 11
        bend = (407 + trim_end) // 2
        trim_bottom = (f"Q{endpoint + 4} {bend} {trim_tip} {trim_end} H{trim_inner} "
                       f"Q{endpoint - 9} {bend} {endpoint - 5} 406 ")
        piping = f"Q{endpoint - 3} {bend} {trim_inner + 7} {trim_end - 2}"
    path(trim, f"M{right} 273 Q187 295 164 329 Q{endpoint + 27} 367 {endpoint + 9} 407 "
         f"{trim_bottom}"
         f"Q{endpoint + 12} 365 147 326 Q168 300 {number(171 + art.neck)} 277Z",
         "#433633", class_="edge")
    _line(trim, f"M{number(154 - art.neck)} 280 Q143 295 162 306 "
          f"M{number(165 + art.neck)} 279 Q183 293 155 328 "
          f"Q{endpoint + 19} 366 {endpoint + 2} 407 {piping}", "#977961", 2.4)
    _line(trim, f"M176 295l5 3 m-9 4 5 3 m-11 4 6 3 m-10 3 6 4 "
          f"M153 324l7 3 m-15 8 7 2 m-16 11 7 1 "
          f"M{endpoint + 18} 379l6 2 m-13 10 5 2 m-13 16 5 2 m-7 9 5 2", "#aa8e73", 1.2)
    if art.hem_y is not None:
        for y in range(439, art.hem_y - 2, 13):
            t = (y - 407) / (trim_end - 407)
            x = round((1 - t) ** 2 * (endpoint - 2) + 2 * t * (1 - t) * (endpoint - 6) + t ** 2 * (trim_inner + 3))
            _line(trim, f"M{x} {y}l5 2", "#aa8e73", 1.2)


def draw_song_round_robe(art):
    front, body, cloth = art.front, art.body, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    chest = 160 - body.chest
    hem = 160 - body.hem
    if art.hem_y is None:
        left_lower = f"L{hem + 14} 438 H{hem + 4} "
        right_lower = f"Q{304 - chest} 369 {294 - hem} 438 H{305 - hem} "
    else:
        edge = 160 - art.hem_half
        bottom = art.hem_y + 12
        bend = (414 + art.hem_y) // 2
        left_lower = (f"Q{hem + 14} {bend} {edge + 12} {bottom} H{edge + 1} "
                      f"Q{hem + 8} {bend} {hem + 8} 431 ")
        right_lower = (f"Q{304 - chest} 369 {294 - hem} 438 "
                       f"Q{294 - hem} {bend} {309 - edge} {bottom} H{321 - edge} "
                       f"Q{302 - hem} {bend} {305 - hem} 438 ")
    path(
        front, f"M{chest - 4} 320 Q{chest + 41} 320 {chest + 48} 351 "
        f"Q{chest + 17} 369 {hem + 25} 414 {left_lower}"
        f"Q{chest + 19} 374 {chest + 11} 365 Q{chest + 22} 347 {chest - 4} 320Z "
        f"M{322 - chest} 320 Q{278 - chest} 325 {271 - chest} 351 "
        f"{right_lower}"
        f"Q{302 - chest} 388 {304 - chest} 365 Q{297 - chest} 345 {322 - chest} 320Z",
        cloth.shade, opacity=".68",
    )
    path(front, f"M{chest + 18} 346 Q{chest + 50} 351 138 372 "
         f"M{302 - chest} 346 Q{270 - chest} 351 182 373 M107 395q10 -19 26 -24 m76 23q-9 -17 -24 -24",
         class_="seam", opacity=".73")
    if art.hem_y is not None:
        path(front, f"M{hem + 40} 421 Q{hem + 31} {bend} {edge + 31} {art.hem_y - 7} "
             f"M{281 - hem} 426 Q{290 - hem} {bend} {286 - edge} {art.hem_y - 9}",
             class_="seam", opacity=".73")

    collar = node(front, "g", data_part="song-round-neckline")
    path(collar, f"M{left} 273 Q160 307 {right} 273 Q185 296 160 303 "
         f"Q135 296 {left} 273Z", "#f0e3c8")
    _line(collar, f"M{number(157 - art.neck)} 278 Q132 298 160 303 Q188 298 {number(163 + art.neck)} 278",
          cloth.deep, 3.15)
    _line(collar, "M160 305q4 6 12 6", cloth.deep, 1.5)

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{outside + 15} 347 Q{outside + 37} 368 {outside + 38} 397 "
             f"Q{outside + 22} 393 {outside + 9} 377 Q{outside + 24} 399 {outside + 43} 410 "
             f"Q{outside + 47} 387 {outside + 40} 373Z", cloth.shade, opacity=".70")
        path(sleeve, f"M{outside + 14} 379q13 19 32 24 m-23 -46q18 14 24 34 "
             f"M{outside + 13} 419q8 13 26 22", class_="etch")

    belt = f"M{155 - body.waist} 395 Q160 437 {165 + body.waist} 395"
    _line(art.waist, belt, "#653730", 18)
    _line(art.waist, belt, "#ce8047", 13.5)
    _line(art.waist, f"M{155 - body.waist} 391 Q160 433 {165 + body.waist} 391", "#e8a86a", 2.8)


DRAWERS = {
    "rus_gilt_cuff_tunic": draw_rus_gilt_cuff_tunic,
    "castile_laced_saya": draw_castile_laced_saya,
    "yuan_fur_hunt_robe": draw_yuan_fur_hunt_robe,
    "song_round_robe": draw_song_round_robe,
}
