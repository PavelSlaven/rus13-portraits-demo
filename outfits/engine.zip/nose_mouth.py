import re
from dataclasses import dataclass

from common import node, number, path
from face_shape import make_head


DETAILS = {
    "nose_root": {"standard": "Обычный", "narrow": "Узкий", "wide": "Широкий"},
    "nose_wings": {"standard": "Обычные", "flat": "Плоские", "flared": "Раскрытые", "angular": "Угловатые"},
    "nostril_shape": {"standard": "Обычные", "round": "Округлые", "slit": "Узкие", "tilted": "Наклонные"},
    "nose_tip_height": {"standard": "Обычный", "raised": "Приподнятый", "low": "Опущенный"},
    "upper_lip": {"standard": "Обычная", "thin": "Тонкая", "full": "Полная"},
    "lower_lip": {"standard": "Обычная", "thin": "Тонкая", "full": "Полная"},
    "mouth_height": {"standard": "Средняя", "high": "Высокая", "low": "Низкая"},
    "mouth_corners": {"standard": "Обычные", "upturned": "Приподнятые", "downturned": "Опущенные"},
    "lip_border": {"standard": "Обычный", "soft": "Мягкий", "defined": "Чёткий"},
    "philtrum": {"standard": "Обычный", "shallow": "Неглубокий", "defined": "Выраженный"},
}

DETAIL_LABELS = {
    "nose_root": "Корень носа", "nose_wings": "Крылья носа", "nostril_shape": "Форма ноздрей",
    "nose_tip_height": "Высота кончика носа", "upper_lip": "Толщина верхней губы",
    "lower_lip": "Толщина нижней губы", "mouth_height": "Высота рта", "mouth_corners": "Уголки рта",
    "lip_border": "Край губ", "philtrum": "Подносовой желобок",
}


_BRIDGE_PLANES = {
    "straight": (
        "M157.5 150 Q160 147 162 153 L160.5 177 156 183 152 182 Q156 172 157.5 150Z",
        "M162 150 Q166 160 164 176 L170 183 166 186 160.5 177Z",
        "M163.5 155 Q165 166 163.5 175.5",
    ),
    "convex": (
        "M157 148 Q161 145 164 153 Q164 167 160 177 L156 184 152 182 Q156 170 157 148Z",
        "M163 148 Q169 156 165.5 173 L171 183 167 187 160 177 Q165 160 163 148Z",
        "M164.5 153 Q167 163 164.5 176",
    ),
    "concave": (
        "M159 151 Q161 148 161 154 Q157 169 162 177 L158 183 152 182 Q156 174 156 166Z",
        "M161 151 Q166 155 162.5 165 Q161.5 174 170 183 L167 187 161 178 Q156.5 170 161 151Z",
        "M163.5 154 Q160 165 163 175",
    ),
}

_NOSE_BOTTOM = {"short": 194, "medium": 200, "long": 205}
_TIP_SHIFT = {"standard": 0, "raised": -3, "low": 2.5}
_BAND_FIELDS = ("mouth_height", "upper_lip", "mouth_corners", "nose_tip_height")
_LEGACY_MOUSTACHES = {"short", "broad", "drooping"}
_BRIDGE_COORDINATES = re.compile(r"(\d+(?:\.\d+)?) (\d+(?:\.\d+)?)")


def _reshape_bridge(outline, scale):
    def shift(match):
        x, y = map(float, match.groups())
        strength = min(1, max(0, (177 - y) / 21))
        return f"{number(160 + (x - 160) * (1 + strength * (scale - 1)))} {match[2]}"

    return _BRIDGE_COORDINATES.sub(shift, outline)


def _nostrils(half, bottom, shape):
    extent, depth, rise = {
        "round": (.23, 2.5, 0), "slit": (.29, 1.15, .35), "tilted": (.24, 2.25, 1.45),
    }[shape]
    width = half * extent
    center = 160 + half * .45
    inner, outer = center - width, center + width
    y = bottom - 4.6
    return (
        f"M{inner} {y + rise} Q{center} {y - depth} {outer} {y - rise} "
        f"Q{center} {y + depth} {inner} {y + rise}Z "
        f"M{320 - inner} {y + rise} Q{320 - center} {y - depth} {320 - outer} {y - rise} "
        f"Q{320 - center} {y + depth} {320 - inner} {y + rise}Z"
    )


def draw_nose(parent, defs, look, skin):
    bridge = node(parent, "g", clip_path="url(#face-features-nose-bridge)")
    clip = node(defs, "clipPath", id="face-features-nose-bridge")
    root = look.get("nose_root", "standard")
    path(clip, "M151 144H169V174L167 179 172 185V187H149V185L154 179 151 174Z"
         if root == "wide" else "M154 144H167V179L172 185V187H149V185L154 179Z")
    light, shade, contour = _BRIDGE_PLANES[look.get("nose_bridge", "straight")]
    if root != "standard":
        scale = .57 if root == "narrow" else 1.45
        light, shade, contour = (_reshape_bridge(outline, scale) for outline in (light, shade, contour))
    path(bridge, light, skin.light)
    path(bridge, shade, skin.shade, opacity=".93")
    path(bridge, contour, class_="etch", opacity=".9")

    half = {"medium": 16, "narrow": 10.5, "wide": 22.5}[look.get("nose_width", "medium")]
    bottom = _NOSE_BOTTOM[look.get("nose_length", "medium")]
    tip = {"round": 6, "defined": 3.8, "broad": 8.5}[look.get("nose_tip", "round")]
    tip_shift = _TIP_SHIFT[look.get("nose_tip_height", "standard")]
    tip_bottom = bottom + tip_shift
    wings = look.get("nose_wings", "standard")
    shoulder, wall, outset, crease = {
        "standard": (0, 0, 0, 0), "flat": (3, 2, -.75, 2),
        "flared": (-1.5, -1, 2.5, -1.8), "angular": (-3, 2, 1, -2.25),
    }[wings]
    left = 160 - half
    right = 160 + half
    left_root = 160 - half * .58
    right_root = 160 + half * .58
    nostril = number(half * .50)
    plane = (
        f"M156 180 Q160 177 165 180 C167 {max(180, bottom - 18)} {right_root} {max(180, bottom - 16 + shoulder)} {right - 2} {bottom - 12 + shoulder} "
        f"Q{right + 2 + outset} {bottom - 8 + wall} {right} {bottom - 4} Q{right - 3} {bottom + 2} {right_root} {bottom - 2} "
        f"Q160 {bottom + 3 + tip_shift * 2 if tip_shift else bottom + 3} {left_root} {bottom - 2} Q{left + 4} {bottom + 1} {left} {bottom - 4} "
        f"Q{left - 2 - outset} {bottom - 8 + wall} {left + 2} {bottom - 11 + shoulder} Q154 {bottom - 15} 156 180Z"
    )
    path(parent, plane, skin.shade)
    path(parent, f"M157 181 Q164 {max(180, bottom - 20)} {160 + tip} {tip_bottom - 9} Q{160 + tip * .7} {tip_bottom - 4} 160 {tip_bottom - 4.5} Q{160 - tip * .85} {tip_bottom - 5} {160 - tip} {tip_bottom - 8} Q153 {bottom - 13} 157 181Z", skin.light)
    path(parent, f"M{left_root} {max(181, bottom - 14 + crease)} Q{left - 3 - outset} {bottom - 9 + wall} {left + .5} {bottom - 5} Q{left + 2} {bottom - 2} {left + 5} {bottom - 3} M{right_root} {max(181, bottom - 15 + crease)} Q{right + 3 + outset} {bottom - 10 + wall} {right - .5} {bottom - 5} Q{right - 2} {bottom - 2} {right - 5} {bottom - 3}", class_="seam")
    nostril_shape = look.get("nostril_shape", "standard")
    if nostril_shape == "standard":
        nostril_path = f"M{number(160 - half * .70)} {bottom - 4} q{nostril} -4 {nostril} 1 q-{nostril} -1 -{nostril} -1Z M{number(160 + half * .20)} {bottom - 3} q1 -5 {nostril} -1 q-2 0 -{nostril} 1Z"
    else:
        nostril_path = _nostrils(half, bottom, nostril_shape)
    nostril_clip = None
    if nostril_shape != "standard" or wings != "standard" or tip_shift:
        identifier = "face-features-nose-silhouette"
        path(node(defs, "clipPath", id=identifier), plane)
        nostril_clip = f"url(#{identifier})"
    path(parent, nostril_path, "#3b2524", clip_path=nostril_clip)
    path(parent, f"M156.8 {tip_bottom - 1.7} Q160.25 {tip_bottom + 1} 163.3 {tip_bottom - 1.7}", class_="seam")


@dataclass(frozen=True)
class _Mouth:
    half: int
    corner: float
    center: float
    opening: float
    peak: float
    cupid: float
    bottom: float

    @property
    def upper_edge(self):
        # У широкого рта приподнятый уголок бывает выше дуги губы.
        return min(self.peak, self.corner - 1)


def _nose_edge(look):
    bottom = _NOSE_BOTTOM[look.get("nose_length", "medium")]
    tip_shift = _TIP_SHIFT[look.get("nose_tip_height", "standard")]
    return bottom + max(0, tip_shift + .5)


def _has_band_change(look):
    return any(look.get(field, "standard") != "standard" for field in _BAND_FIELDS)


def _mouth_geometry(look):
    half = {"medium": 27, "narrow": 20, "wide": 34}[look.get("mouth_width", "medium")]
    upper, lower = {"medium": (6, 7), "thin": (3.5, 4.5), "full": (8, 10)}[look.get("lip_volume", "medium")]
    shape = look.get("lip_shape", "soft")
    upper += {"soft": 0, "bow": 1, "lower": -1}[shape]
    lower += {"soft": 0, "bow": 0, "lower": 1.7}[shape]
    cupid = {"soft": 1.5, "bow": 4.2, "lower": .8}[shape]
    corner, center, opening = {
        "neutral": (221, 222, 0),
        "smile": (217.5, 222, 2.7),
        "tense": (222, 220.5, 0),
        "open": (220, 221, 8.5),
    }[look.get("expression", "neutral")]

    upper_detail = look.get("upper_lip", "standard")
    lower_detail = look.get("lower_lip", "standard")
    height = look.get("mouth_height", "standard")
    corners = look.get("mouth_corners", "standard")
    if upper_detail != "standard":
        upper *= {"thin": .62, "full": 1.48}[upper_detail]
        cupid = min(cupid, upper - .5)
    if lower_detail != "standard":
        lower *= {"thin": .62, "full": 1.42}[lower_detail]
    if corners != "standard":
        corner += {"upturned": -3.8, "downturned": 3.8}[corners]
    band_changed = _has_band_change(look)
    if band_changed or lower_detail != "standard" or look.get("chin_mark", "standard") != "standard":
        chin_limit = make_head(look).chin_y - 12
        shift = {"standard": 0, "high": -5.5, "low": 6}[height]
        reserve = 7.5 if band_changed and look.get("moustache") in _LEGACY_MOUSTACHES else 3
        upper_limit = _nose_edge(look) + reserve
        latest = min(chin_limit - center - opening - 2.5, chin_limit - corner - 3)
        if band_changed:
            upper = min(upper, center + latest - upper_limit)
            cupid = min(cupid, upper - .5)
        else:
            upper_limit = min(upper_limit, center - upper, corner - 1)
        earliest = upper_limit - min(center - upper, corner - 1)
        shift = max(earliest, min(shift, latest))
        lower = max(2.5, min(lower, chin_limit - (center + shift + opening)))
        corner += shift
        center += shift
    return _Mouth(half, corner, center, opening, center - upper, cupid, center + opening + lower)


def moustache_band(look, *, force=False):
    if force or _has_band_change(look):
        return _nose_edge(look), _mouth_geometry(look).upper_edge
    return None


def beard_mouth_opening(look):
    mouth = _mouth_geometry(look)
    half = mouth.half + 3
    x = number(160 - half)
    top = number(mouth.upper_edge - 2.5)
    right = number(160 + half)
    bottom = number(max(mouth.bottom, mouth.corner) + 2.5)
    return (
        f"M{x} {top}H{right}V{bottom}H{x}Z"
    )


def _draw_philtrum(parent, look, skin, mouth):
    detail = look.get("philtrum", "standard")
    if detail == "standard":
        return
    start = _nose_edge(look) + 1.1
    finish = mouth.peak + mouth.cupid / 2 - 1.4
    if finish - start < 1:
        return
    shoulder = start + (finish - start) * .48
    opacity = ".68" if detail == "defined" else ".3"
    path(parent, f"M158.7 {start} Q158.7 {shoulder} 156.9 {finish} Q159.6 {finish - .6} 160.1 {shoulder} Q160.3 {finish - .6} 163 {finish} Q161.1 {shoulder} 161.4 {start}Z", skin.shade, opacity=opacity)
    if detail == "defined" and finish - start > 4:
        path(parent, f"M161.4 {start + 1} Q161.5 {shoulder} 163.1 {finish - .2}", "none", stroke=skin.light, stroke_width="1.1", stroke_linecap="round", opacity=".78")


def _draw_chin_mark(parent, look, skin, mouth):
    mark = look.get("chin_mark", "standard")
    if mark == "standard":
        return
    chin = make_head(look).chin_y
    center = max(chin - 15, mouth.bottom + 5)
    relief = node(parent, "g", transform=f"translate(160 {number(center)})")
    if mark == "cleft":
        path(relief, "M-1 -4Q2 -1 1 1Q.6 3 2 4Q-3 2 -1 -4Z", skin.shade)
        path(relief, "M2 -3Q3 0 2.5 2.8", "none", stroke=skin.light, stroke_width="1.2", stroke_linecap="round")
    else:
        path(relief, "M-5 -.6Q-1 -3.8 4.8 -.5Q2 2.2 -1 1.8Q-3 1.8 -5 -.6Z", skin.shade)
        path(relief, "M-3 1.8Q0 3 3 1.7", "none", stroke=skin.light, stroke_width="1.3", stroke_linecap="round")


def draw_mouth(parent, look, skin):
    mouth = _mouth_geometry(look)
    _draw_philtrum(parent, look, skin, mouth)
    half, corner, center, opening = mouth.half, mouth.corner, mouth.center, mouth.opening
    peak, cupid, bottom = mouth.peak, mouth.cupid, mouth.bottom
    left, right = 160 - half, 160 + half
    near_left, near_right = number(160 - half * .55), number(160 + half * .55)
    altered_corners = look.get("mouth_corners", "standard") != "standard"
    top_control = min(corner - 1, center - 2) if altered_corners else corner - 1
    bottom_control = max(bottom - 2, center + opening + .7) if altered_corners else bottom - 2
    top = (
        f"M{left} {corner} C{near_left} {top_control} 151 {peak} 154 {peak} "
        f"Q157 {peak} 160 {peak + cupid} Q163 {peak} 166 {peak} C169 {peak} {near_right} {top_control} {right} {corner}"
    )
    parting = f"C{near_left} {center - .6} 153 {center - 1} 160 {center} C167 {center - 1.3} {near_right} {center + .25} {right} {corner}"
    silhouette = f"{top} C{near_right} {bottom_control} 171 {bottom} 160 {bottom} C148 {bottom} {near_left} {bottom_control} {left} {corner}Z"
    border = look.get("lip_border", "standard")
    attrs = {"stroke": skin.shade, "stroke_width": "1.05", "stroke_linejoin": "round"} if border == "defined" else {}
    path(parent, silhouette, skin.lip, **attrs)
    path(parent, f"{top} C{near_right} {center + .25} 167 {center - 1.3} 160 {center} C153 {center - 1} {near_left} {center - .6} {left} {corner}Z", "#56322f", opacity=".46" if border == "soft" else ".72")
    if opening:
        cavity = center + opening
        cavity_path = f"M{left} {corner} {parting} C{near_right} {cavity} 169 {cavity} 160 {cavity} C150 {cavity} {near_left} {cavity} {left} {corner}Z"
        path(parent, cavity_path, "#362324")
        if opening > 4:
            cavity_clip = None
            if altered_corners:
                identifier = "face-features-mouth-cavity"
                path(node(parent, "clipPath", id=identifier), cavity_path)
                cavity_clip = f"url(#{identifier})"
            path(parent, f"M{left + 8} {corner + 1} Q153 {center - .8} 160 {center + .55} Q167 {center - 1.1} {right - 8} {corner + 1} Q171 {center + 3.4} 160 {center + 3.7} Q148 {center + 3.4} {left + 8} {corner + 1}Z", "#eed7ae", clip_path=cavity_clip)
    else:
        path(parent, f"M{left} {corner} {parting}", class_="seam")
    path(parent, f"M{number(160 - half * .32)} {bottom - 2.8} Q160 {bottom - 1.3} {number(160 + half * .3)} {bottom - 2.8}", "none", stroke=skin.light, stroke_width="1.4", stroke_linecap="round", opacity=".76")
    _draw_chin_mark(parent, look, skin, mouth)


