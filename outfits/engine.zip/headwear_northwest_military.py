from common import brow_top, eye_height, node, number, path


OPTIONS = {
    "nw_rus_half_mask": "Шелом с полумаской",
    "nw_iron_hat": "Железная шляпа с полями",
    "nw_great_helm": "Закрытый шелом",
}

_IRON = "#85887b"
_LIGHT = "#c2bdab"
_SHADE = "#5d625a"
_DARK = "#3c403c"
_EDGE = "#332b27"
_HOLE = "#282321"


def _line(parent, contour, color, width, **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def _place(parent, x_scale, y_scale=1, offset=0):
    return node(parent, "g", transform=f"matrix({number(x_scale)} 0 0 {number(y_scale)} "
                f"{number(160 * (1 - x_scale))} {number(offset)})")


def _rivet(parent, x, y):
    node(parent, "circle", cx=x, cy=y, r=2.25, fill="#a69c85", stroke=_EDGE, stroke_width=1.1)
    _line(parent, f"M{number(x - .7)} {number(y - .6)} l.7 -.35", "#d5c7a7", .85)


def draw_rus_half_mask(parent, look, head):
    brow = brow_top(look, include_standard=True)
    rim_y = min(112, brow - 9)
    point_y = max(18, head.top_y - 54)
    x_scale = (head.temple_half + 14) / 82
    y_scale = (rim_y - point_y) / 93
    shell = _place(parent, x_scale, y_scale, rim_y - 115 * y_scale)
    path(shell, "M79 110 C83 91 100 69 124 54 Q151 36 158 23 Q160 19 163 24 "
         "Q175 42 201 56 Q231 73 242 109 L236 118 Q160 122 83 120Z", _IRON, class_="edge")
    path(shell, "M86 105 C98 78 118 66 139 50 Q154 39 160 27 "
         "Q153 56 136 75 Q123 92 120 111Z", _LIGHT)
    path(shell, "M163 28 Q178 45 200 58 Q231 76 239 109 L192 115 "
         "Q185 77 163 28Z", _SHADE)
    path(shell, "M181 55 Q225 76 238 108 L223 112 Q211 89 181 55Z", "url(#ink-lines)", opacity=".51")
    path(shell, "M160 27 Q149 59 132 81 Q125 92 119 108 M163 28 Q185 75 191 113", class_="seam")
    path(shell, "M95 99 l9-14 m7-7 6-6 m9 14 -6 11 m82-26 9 9 m6 7 7 13", class_="etch", opacity=".8")
    _line(shell, "M157 26 q2 -4 4 -4", "#dfd1b2", 1.25)

    fittings = _place(parent, x_scale, offset=rim_y)
    face_band = (
        "M80 -9 Q111 -2 128 -8 Q151 -11 160 -2 Q169 -10 193 -8 Q222 -2 240 -9 "
        "L239 5 L226 10 Q216 2 204 0 Q181 -3 171 8 Q160 16 149 8 "
        "Q134 -3 116 1 Q102 2 94 10 L81 5Z"
    )
    path(fittings, face_band, "#777a6e", class_="edge")
    path(fittings, "M83 -6 Q105 0 127 -6 Q148 -8 158 1 L152 4 Q140 -3 127 -3 "
         "Q107 2 86 -2Z M164 1 Q174 -7 193 -5 Q215 1 236 -6 L235 -2 "
         "Q214 5 193 -2 Q180 -3 166 4Z", _LIGHT)
    _line(fittings, "M95 5 Q115 -7 131 -3 Q146 -1 152 5 M168 5 Q183 -6 200 -3 Q215 -1 225 5", _SHADE, 2)
    for x, y in ((91, 1), (112, -1), (138, -3), (182, -3), (208, -1), (229, 1)):
        _rivet(fittings, x, y)

    # Draw the nasal in face coordinates. Scaling it with the skull pinches the inner eye corners.
    top = rim_y + 3
    bottom = 175 + eye_height(look) * .6
    nasal = (
        f"M148 {number(top)} Q151 {number(top - 5)} 160 {number(top - 2)} "
        f"Q168 {number(top - 5)} 172 {number(top)} Q168 132 167.5 148 "
        f"L167 {number(bottom - 3)} Q160 {number(bottom + 3)} 153 {number(bottom - 3)} "
        f"L152.5 148 Q152 132 148 {number(top)}Z"
    )
    path(parent, nasal, "#929386", stroke=_EDGE, stroke_width=2.6, stroke_linejoin="round")
    path(parent, f"M153 {number(top)} Q156 {number(top - 2)} 160 {number(top + 1)} "
         f"Q157 131 158 151 L158 {number(bottom - 1)} L155 {number(bottom - 4)} "
         f"L155 148 Q156 132 153 {number(top)}Z", _LIGHT)
    _line(parent, f"M163 {number(top + 6)} Q161 144 163 {number(bottom - 5)}", _SHADE, 1.4)
    _rivet(parent, 160, top + 7)


def draw_iron_hat(parent, look, head):
    brim_y = min(105, brow_top(look, include_standard=True) - 17)
    top_y = head.top_y - 22
    x_scale = (head.temple_half + 13) / 84
    y_scale = (brim_y - top_y) / 62
    crown = _place(parent, x_scale, y_scale, brim_y - 110 * y_scale)
    path(crown, "M76 111 C82 88 92 71 116 58 Q135 48 159 48 Q188 46 207 59 "
         "Q233 77 244 110 L236 119 Q160 117 84 119Z", "#8e8f80", class_="edge")
    path(crown, "M87 106 Q105 63 145 53 Q128 66 116 87 L108 108Z", _LIGHT)
    path(crown, "M163 50 Q190 47 211 63 Q233 79 241 110 L189 112 "
         "Q187 71 163 50Z", _SHADE)
    path(crown, "M194 58 Q229 78 238 108 L216 111 Q212 80 194 58Z", "url(#ink-lines)", opacity=".68")
    path(crown, "M159 49 Q144 60 134 75 Q120 91 117 110 M162 50 Q183 69 190 111", class_="seam")
    path(crown, "M99 90 l8-10 m5-5 8-6 m80 1 10 8 m5 4 7 10 m-82-27 5-5", class_="etch")

    brim_scale = min(1.07, x_scale + .05)
    brim = _place(parent, brim_scale, offset=brim_y)
    path(brim, "M30 10 Q52 -5 84 -15 Q113 -7 159 -7 Q208 -7 236 -15 Q266 -5 290 8 "
         "Q273 21 234 17 Q160 10 86 18 Q48 21 30 10Z", "#686e63", class_="edge")
    path(brim, "M36 9 Q59 -3 83 -11 Q109 -3 159 -5 Q203 -3 237 -11 "
         "Q260 -3 280 7 Q263 13 239 11 Q155 4 82 13 Q51 17 36 9Z", "#a5a391")
    path(brim, "M54 5 Q79 -7 89 -8 Q102 -4 121 -2 Q91 4 71 10 Q53 13 43 9Z", _LIGHT)
    path(brim, "M191 -4 Q216 -4 237 -11 Q264 -3 278 7 Q261 14 227 10Z", "#75776a")
    path(brim, "M222 -7 Q247 -9 277 7 Q261 10 247 9Z", "url(#ink-lines)", opacity=".67")
    _line(brim, "M41 11 Q62 16 93 11 Q160 5 226 10 Q260 15 281 10", "#dfcfaf", 1.4, opacity=".77")
    _line(brim, "M81 -11 Q119 -3 159 -5 Q211 -4 238 -11", _EDGE, 2.1)
    path(brim, "M70 6 l12-4 m4-1 9-2 m122 2 14 2 m8-3 12 4 m4 1 7 2", class_="etch", opacity=".83")
    for x, y in ((87, -8), (109, -5), (132, -4), (184, -4), (211, -5), (233, -8)):
        _rivet(brim, x, y)


def draw_great_helm(parent, look, head):
    top_y = max(26, head.top_y - 29)
    bottom_y = head.chin_y + 17
    x_scale = max((head.temple_half + 14) / 85, (head.cheek_half + 4) / 79, (head.jaw_half + 6) / 70)
    y_scale = (bottom_y - top_y) / 218
    barrel = _place(parent, x_scale, y_scale, top_y - 51 * y_scale)
    path(barrel, "M82 63 Q106 52 155 51 Q201 50 231 64 Q241 91 244 120 "
         "L247 156 Q245 201 240 233 L234 251 Q206 266 163 269 Q123 269 86 252 "
         "L80 230 Q76 195 73 156 L75 119 Q76 89 82 63Z", _IRON, class_="edge")
    path(barrel, "M84 63 Q117 53 155 52 Q198 52 230 65 Q196 77 155 73 Q112 72 84 63Z", "#a5a493")
    _line(barrel, "M87 63 Q113 56 139 56 m8-.4 14 .1", "#d4c9ad", 1.85)
    path(barrel, "M86 68 Q101 76 125 76 Q118 101 119 128 L87 129 "
         "Q83 94 86 68Z", _LIGHT)
    path(barrel, "M182 75 Q208 73 231 66 Q242 99 244 125 L192 134 "
         "Q189 94 182 75Z", _SHADE)
    path(barrel, "M204 73 Q220 70 232 67 Q241 96 242 125 L221 128Z", "url(#ink-lines)", opacity=".56")
    path(barrel, "M80 120 Q115 124 160 131 Q201 127 240 119 L243 154 "
         "Q241 207 231 249 Q196 264 160 265 Q120 265 89 249 Q81 211 77 155Z", "#858578",
         stroke="#3b332d", stroke_width=2.45, stroke_linejoin="round")
    path(barrel, "M82 126 Q111 127 156 138 L151 256 Q124 256 99 244 Q86 209 82 164Z", "#a29d89")
    path(barrel, "M89 162 Q107 168 125 162 Q122 215 133 251 Q109 247 101 241 Q92 209 89 162Z",
         "#b5ab93", opacity=".78")
    path(barrel, "M160 137 Q206 135 241 126 L242 157 Q235 215 222 250 Q190 264 160 263Z", "#676a61")
    path(barrel, "M204 143 L239 132 Q237 196 220 249 L199 256 Q216 198 204 143Z", "#51564f")
    path(barrel, "M212 147 L240 135 Q235 199 219 248 L208 251 Q223 202 212 147Z", "url(#ink-lines)", opacity=".62")
    _line(barrel, "M84 128 Q126 132 160 139 Q199 133 235 126", "#b2a691", 1.7)
    _line(barrel, "M160 139 Q156 192 160 262", "#33302c", 3.5)
    _line(barrel, "M157 145 Q153 195 157 258", "#b9b098", 1.45)
    _line(barrel, "M92 247 Q119 259 157 261 Q197 259 229 245", "#b5a98d", 1.5, opacity=".82")

    sight = (
        "M84 145 Q120 141 150 149 L149 156 Q120 151 87 153Z "
        "M168 149 Q206 141 237 142 L234 150 Q204 148 169 156Z"
    )
    path(barrel, sight, "#211d1c", stroke="#332924", stroke_width=2.45, stroke_linejoin="round")
    _line(barrel, "M88 155 Q122 153 147 158 M172 158 Q204 151 232 152", "#c5bba0", 1.6)
    for x, y in ((92, 134), (117, 135), (143, 141), (178, 141), (208, 133), (231, 130),
                 (93, 205), (226, 202), (108, 249), (134, 257), (182, 256), (209, 248)):
        _rivet(barrel, x, y)
    for x, y in ((182, 185), (195, 182), (209, 178), (221, 175),
                 (181, 197), (194, 194), (207, 191), (218, 187),
                 (180, 209), (192, 206), (205, 203), (215, 200),
                 (187, 217), (202, 214)):
        node(barrel, "ellipse", cx=x, cy=y, rx=2.3, ry=3.1, fill=_HOLE)
        _line(barrel, f"M{x - 1.8} {y + 2} q1.4 1.5 2.8 .4", "#aea68e", .8, opacity=".69")
    path(barrel, "M96 174 l1 11 m3 21 4 12 m5 4 3 8 m14-47 -4 9 m5 43 6 6 "
         "m26-141 11 1 m6-3 8 1 m-4 135 5-5 m25 1 5-6", class_="etch", opacity=".73")


DRAWERS = {
    "nw_rus_half_mask": draw_rus_half_mask,
    "nw_iron_hat": draw_iron_hat,
    "nw_great_helm": draw_great_helm,
}
