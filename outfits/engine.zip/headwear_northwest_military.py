from common import brow_top, eye_height, node, number, path
from face_features import eye_layout


OPTIONS = {
    "nw_rus_half_mask": "Шелом с полумаской",
    "nw_iron_hat": "Железная шляпа с полями",
    "nw_great_helm": "Закрытый шелом",
    "nw_duboshin_helm": "Шлем с Дубошина раскопа",
    "nw_lykovo_helm": "Шлем из Лыкова",
    "nw_gjermundbu_helm": "Шлем из Гьёрмундбю",
    "nw_pakalniskiai_helm": "Шлем из Пакальнишкяя",
}

_IRON = "#85887b"
_LIGHT = "#c2bdab"
_SHADE = "#5d625a"
_DARK = "#3c403c"
_EDGE = "#332b27"
_HOLE = "#282321"


def _line(parent, contour, color, width, **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def _place(parent, x_scale, y_scale=1, offset=0):
    return node(parent, "g", transform=f"matrix({number(x_scale)} 0 0 {number(y_scale)} "
                f"{number(160 * (1 - x_scale))} {number(offset)})")


def _rivet(parent, x, y):
    node(parent, "circle", cx=x, cy=y, r=2.25, fill="#a69c85", stroke=_EDGE, stroke_width=1.1)
    _line(parent, f"M{number(x - .7)} {number(y - .6)} l.7 -.35", "#d5c7a7", .85)


def draw_rus_half_mask(parent, look, head):
    brow = brow_top(look, include_standard=True)
    rim_y = min(112, brow - 9)
    point_y = max(18, head.top_y - 54)
    x_scale = (head.temple_half + 14) / 82
    y_scale = (rim_y - point_y) / 93
    shell = _place(parent, x_scale, y_scale, rim_y - 115 * y_scale)
    path(shell, "M79 110 C83 91 100 69 124 54 Q151 36 158 23 Q160 19 163 24 "
         "Q175 42 201 56 Q231 73 242 109 L236 118 Q160 122 83 120Z", _IRON, class_="edge")
    path(shell, "M86 105 C98 78 118 66 139 50 Q154 39 160 27 "
         "Q153 56 136 75 Q123 92 120 111Z", _LIGHT)
    path(shell, "M163 28 Q178 45 200 58 Q231 76 239 109 L192 115 "
         "Q185 77 163 28Z", _SHADE)
    path(shell, "M181 55 Q225 76 238 108 L223 112 Q211 89 181 55Z", "url(#ink-lines)", opacity=".51")
    path(shell, "M160 27 Q149 59 132 81 Q125 92 119 108 M163 28 Q185 75 191 113", class_="seam")
    path(shell, "M95 99 l9-14 m7-7 6-6 m9 14 -6 11 m82-26 9 9 m6 7 7 13", class_="etch", opacity=".8")
    _line(shell, "M157 26 q2 -4 4 -4", "#dfd1b2", 1.25)

    fittings = _place(parent, x_scale, offset=rim_y)
    face_band = (
        "M80 -9 Q111 -2 128 -8 Q151 -11 160 -2 Q169 -10 193 -8 Q222 -2 240 -9 "
        "L239 5 L226 10 Q216 2 204 0 Q181 -3 171 8 Q160 16 149 8 "
        "Q134 -3 116 1 Q102 2 94 10 L81 5Z"
    )
    path(fittings, face_band, "#777a6e", class_="edge")
    path(fittings, "M83 -6 Q105 0 127 -6 Q148 -8 158 1 L152 4 Q140 -3 127 -3 "
         "Q107 2 86 -2Z M164 1 Q174 -7 193 -5 Q215 1 236 -6 L235 -2 "
         "Q214 5 193 -2 Q180 -3 166 4Z", _LIGHT)
    _line(fittings, "M95 5 Q115 -7 131 -3 Q146 -1 152 5 M168 5 Q183 -6 200 -3 Q215 -1 225 5", _SHADE, 2)
    for x, y in ((91, 1), (112, -1), (138, -3), (182, -3), (208, -1), (229, 1)):
        _rivet(fittings, x, y)

    # Draw the nasal in face coordinates. Scaling it with the skull pinches the inner eye corners.
    top = rim_y + 3
    bottom = 175 + eye_height(look) * .6
    nasal = (
        f"M148 {number(top)} Q151 {number(top - 5)} 160 {number(top - 2)} "
        f"Q168 {number(top - 5)} 172 {number(top)} Q168 132 167.5 148 "
        f"L167 {number(bottom - 3)} Q160 {number(bottom + 3)} 153 {number(bottom - 3)} "
        f"L152.5 148 Q152 132 148 {number(top)}Z"
    )
    path(parent, nasal, "#929386", stroke=_EDGE, stroke_width=2.6, stroke_linejoin="round")
    path(parent, f"M153 {number(top)} Q156 {number(top - 2)} 160 {number(top + 1)} "
         f"Q157 131 158 151 L158 {number(bottom - 1)} L155 {number(bottom - 4)} "
         f"L155 148 Q156 132 153 {number(top)}Z", _LIGHT)
    _line(parent, f"M163 {number(top + 6)} Q161 144 163 {number(bottom - 5)}", _SHADE, 1.4)
    _rivet(parent, 160, top + 7)


def draw_iron_hat(parent, look, head):
    brim_y = min(105, brow_top(look, include_standard=True) - 17)
    top_y = head.top_y - 22
    x_scale = (head.temple_half + 13) / 84
    y_scale = (brim_y - top_y) / 62
    crown = _place(parent, x_scale, y_scale, brim_y - 110 * y_scale)
    path(crown, "M76 111 C82 88 92 71 116 58 Q135 48 159 48 Q188 46 207 59 "
         "Q233 77 244 110 L236 119 Q160 117 84 119Z", "#8e8f80", class_="edge")
    path(crown, "M87 106 Q105 63 145 53 Q128 66 116 87 L108 108Z", _LIGHT)
    path(crown, "M163 50 Q190 47 211 63 Q233 79 241 110 L189 112 "
         "Q187 71 163 50Z", _SHADE)
    path(crown, "M194 58 Q229 78 238 108 L216 111 Q212 80 194 58Z", "url(#ink-lines)", opacity=".68")
    path(crown, "M159 49 Q144 60 134 75 Q120 91 117 110 M162 50 Q183 69 190 111", class_="seam")
    path(crown, "M99 90 l8-10 m5-5 8-6 m80 1 10 8 m5 4 7 10 m-82-27 5-5", class_="etch")

    brim_scale = min(1.07, x_scale + .05)
    brim = _place(parent, brim_scale, offset=brim_y)
    path(brim, "M30 10 Q52 -5 84 -15 Q113 -7 159 -7 Q208 -7 236 -15 Q266 -5 290 8 "
         "Q273 21 234 17 Q160 10 86 18 Q48 21 30 10Z", "#686e63", class_="edge")
    path(brim, "M36 9 Q59 -3 83 -11 Q109 -3 159 -5 Q203 -3 237 -11 "
         "Q260 -3 280 7 Q263 13 239 11 Q155 4 82 13 Q51 17 36 9Z", "#a5a391")
    path(brim, "M54 5 Q79 -7 89 -8 Q102 -4 121 -2 Q91 4 71 10 Q53 13 43 9Z", _LIGHT)
    path(brim, "M191 -4 Q216 -4 237 -11 Q264 -3 278 7 Q261 14 227 10Z", "#75776a")
    path(brim, "M222 -7 Q247 -9 277 7 Q261 10 247 9Z", "url(#ink-lines)", opacity=".67")
    _line(brim, "M41 11 Q62 16 93 11 Q160 5 226 10 Q260 15 281 10", "#dfcfaf", 1.4, opacity=".77")
    _line(brim, "M81 -11 Q119 -3 159 -5 Q211 -4 238 -11", _EDGE, 2.1)
    path(brim, "M70 6 l12-4 m4-1 9-2 m122 2 14 2 m8-3 12 4 m4 1 7 2", class_="etch", opacity=".83")
    for x, y in ((87, -8), (109, -5), (132, -4), (184, -4), (211, -5), (233, -8)):
        _rivet(brim, x, y)


def draw_great_helm(parent, look, head):
    top_y = max(26, head.top_y - 29)
    bottom_y = head.chin_y + 17
    x_scale = max((head.temple_half + 14) / 85, (head.cheek_half + 4) / 79, (head.jaw_half + 6) / 70)
    y_scale = (bottom_y - top_y) / 218
    barrel = _place(parent, x_scale, y_scale, top_y - 51 * y_scale)
    path(barrel, "M82 63 Q106 52 155 51 Q201 50 231 64 Q241 91 244 120 "
         "L247 156 Q245 201 240 233 L234 251 Q206 266 163 269 Q123 269 86 252 "
         "L80 230 Q76 195 73 156 L75 119 Q76 89 82 63Z", _IRON, class_="edge")
    path(barrel, "M84 63 Q117 53 155 52 Q198 52 230 65 Q196 77 155 73 Q112 72 84 63Z", "#a5a493")
    _line(barrel, "M87 63 Q113 56 139 56 m8-.4 14 .1", "#d4c9ad", 1.85)
    path(barrel, "M86 68 Q101 76 125 76 Q118 101 119 128 L87 129 "
         "Q83 94 86 68Z", _LIGHT)
    path(barrel, "M182 75 Q208 73 231 66 Q242 99 244 125 L192 134 "
         "Q189 94 182 75Z", _SHADE)
    path(barrel, "M204 73 Q220 70 232 67 Q241 96 242 125 L221 128Z", "url(#ink-lines)", opacity=".56")
    path(barrel, "M80 120 Q115 124 160 131 Q201 127 240 119 L243 154 "
         "Q241 207 231 249 Q196 264 160 265 Q120 265 89 249 Q81 211 77 155Z", "#858578",
         stroke="#3b332d", stroke_width=2.45, stroke_linejoin="round")
    path(barrel, "M82 126 Q111 127 156 138 L151 256 Q124 256 99 244 Q86 209 82 164Z", "#a29d89")
    path(barrel, "M89 162 Q107 168 125 162 Q122 215 133 251 Q109 247 101 241 Q92 209 89 162Z",
         "#b5ab93", opacity=".78")
    path(barrel, "M160 137 Q206 135 241 126 L242 157 Q235 215 222 250 Q190 264 160 263Z", "#676a61")
    path(barrel, "M204 143 L239 132 Q237 196 220 249 L199 256 Q216 198 204 143Z", "#51564f")
    path(barrel, "M212 147 L240 135 Q235 199 219 248 L208 251 Q223 202 212 147Z", "url(#ink-lines)", opacity=".62")
    _line(barrel, "M84 128 Q126 132 160 139 Q199 133 235 126", "#b2a691", 1.7)
    _line(barrel, "M160 139 Q156 192 160 262", "#33302c", 3.5)
    _line(barrel, "M157 145 Q153 195 157 258", "#b9b098", 1.45)
    _line(barrel, "M92 247 Q119 259 157 261 Q197 259 229 245", "#b5a98d", 1.5, opacity=".82")

    sight = (
        "M84 145 Q120 141 150 149 L149 156 Q120 151 87 153Z "
        "M168 149 Q206 141 237 142 L234 150 Q204 148 169 156Z"
    )
    path(barrel, sight, "#211d1c", stroke="#332924", stroke_width=2.45, stroke_linejoin="round")
    _line(barrel, "M88 155 Q122 153 147 158 M172 158 Q204 151 232 152", "#c5bba0", 1.6)
    for x, y in ((92, 134), (117, 135), (143, 141), (178, 141), (208, 133), (231, 130),
                 (93, 205), (226, 202), (108, 249), (134, 257), (182, 256), (209, 248)):
        _rivet(barrel, x, y)
    for x, y in ((182, 185), (195, 182), (209, 178), (221, 175),
                 (181, 197), (194, 194), (207, 191), (218, 187),
                 (180, 209), (192, 206), (205, 203), (215, 200),
                 (187, 217), (202, 214)):
        node(barrel, "ellipse", cx=x, cy=y, rx=2.3, ry=3.1, fill=_HOLE)
        _line(barrel, f"M{x - 1.8} {y + 2} q1.4 1.5 2.8 .4", "#aea68e", .8, opacity=".69")
    path(barrel, "M96 174 l1 11 m3 21 4 12 m5 4 3 8 m14-47 -4 9 m5 43 6 6 "
         "m26-141 11 1 m6-3 8 1 m-4 135 5-5 m25 1 5-6", class_="etch", opacity=".73")


OPEN_BROW_HELMETS = {"nw_duboshin_helm", "nw_pakalniskiai_helm"}


def helmet_rim(look, head):
    """Give the half width and lower edge height at the temples."""
    rim_y = min(122, 125 + eye_height(look))
    if look["headgear"] in OPEN_BROW_HELMETS:
        rim_y = min(rim_y, brow_top(look, include_standard=True) - 8)
    return head.temple_half + 8, rim_y


def _fitted_shell(parent, look, head, apex, lift):
    half, rim_y = helmet_rim(look, head)
    shell = node(parent, "g", data_part="helmet-shell")
    scale = half / 82
    top_y = max(19, head.top_y - lift)
    y_scale = (rim_y - 6 - top_y) / (114 - apex)
    crown = _place(shell, scale, y_scale, top_y - apex * y_scale)
    rim = _place(shell, scale, offset=rim_y)
    return crown, rim


def _iron_rim(parent, fill, rivets):
    path(parent, "M78 -11 Q160 -4 242 -11 L242 0 Q160 10 78 0Z", fill, class_="edge")
    _line(parent, "M82 -7 Q158 0 236 -7", "#c5baa3", 1.35, opacity=".85")
    _line(parent, "M84 -2 Q159 6 236 -2", "#4d4d46", 1.4)
    for x, y in rivets:
        _rivet(parent, x, y)


def draw_duboshin_helm(parent, look, head):
    crown, rim = _fitted_shell(parent, look, head, 21, 51)
    path(crown, "M79 112 C85 89 108 69 132 55 Q148 43 157 28 Q160 21 164 29 "
         "Q173 44 193 57 C216 71 235 86 241 112 Q160 121 79 112Z", _IRON, class_="edge")
    path(crown, "M85 109 C94 88 111 74 133 60 Q151 45 157 34 Q149 59 132 72 "
         "Q117 88 111 113Z", "#b1ae9c")
    path(crown, "M162 30 Q177 46 193 57 C216 71 234 88 240 111 Q212 115 197 115 "
         "Q195 96 185 84 Q179 77 180 68 Q173 58 171 50Z", "#5e635c")
    path(crown, "M192 65 Q225 85 239 112 L218 113 Q210 89 192 65Z", "url(#ink-lines)", opacity=".5")

    left_seam = ("M155 35 Q151 44 145 47 Q142 51 143 55 Q141 59 135 60 Q129 62 130 68 "
                 "Q128 72 123 74 Q118 77 119 82 Q118 86 113 89 Q107 93 108 98 Q103 105 102 113")
    right_seam = ("M164 35 Q171 44 174 49 Q172 53 179 56 Q185 59 183 64 Q181 69 188 71 "
                  "Q194 74 192 80 Q191 85 198 89 Q204 92 202 98 Q207 105 208 115")
    _line(crown, left_seam + " " + right_seam, "#42443d", 3)
    _line(crown, "M150 42 Q145 46 143 49 M132 65 q-2 1-2 3 M119 80 q1 4-4 8 "
          "M110 93 q-2 2-2 4 M176 52 q1 3 5 4 M188 73 q4 3 3 5 M200 91 q3 2 2 5",
          "#c9bea3", 1.25)
    path(crown, "M94 99 l8-10 m3-3 6-5 m70-18 5 5 m25 14 8 9 m5 7 4 7",
         class_="etch", opacity=".7")
    path(crown, "M146 45 Q151 38 153 26 Q155 17 160 21 Q165 21 167 29 Q169 39 175 45 "
         "Q161 50 146 45Z", "#8f735d", stroke=_EDGE, stroke_width=2.5, stroke_linejoin="round")
    path(crown, "M150 43 Q155 34 157 25 Q159 22 161 25 Q163 35 161 45Z", "#bfafa1")
    _rivet(crown, 160, 42)

    _iron_rim(rim, "#776c5e", ((87, -4), (107, -2.2), (213, -2.2), (233, -4)))
    trident = ("M112 -11 Q122 -16 130 -28 Q138 -23 142 -11 L150 -10 "
               "Q153 -22 160 -43 Q167 -24 170 -10 L178 -11 Q182 -23 190 -28 "
               "Q198 -16 208 -11 L207 1 Q160 10 113 1Z")
    path(rim, trident, "#946c55", stroke=_EDGE, stroke_width=2.15, stroke_linejoin="round")
    path(rim, "M116 -9 Q124 -15 130 -23 Q136 -19 139 -8 L152 -6 "
         "Q156 -23 160 -34 Q164 -22 167 -6 L181 -8 Q184 -18 190 -23 Q196 -15 204 -9 "
         "L204 -2 Q160 6 116 -2Z", "#c7b6a1")
    _line(rim, "M119 -4 Q139 1 151 0 M169 0 Q185 0 200 -4", "#f0d8b8", 1.25)
    _line(rim, "M126 -12 l4-4 4 5 M157 -16 l3-6 3 6 M186 -11 l4-5 4 4", "#926d58", 1.1)
    for x, y in ((130, -8.5), (160, -18), (160, .5), (190, -8.5)):
        _rivet(rim, x, y)


_GOLD = "#aa8451"
_GOLD_LIGHT = "#dcc08a"
_GOLD_SHADE = "#705638"


def _draw_lykovo_ornament(crown, rim):
    path(crown, "M137 52 Q151 41 156 30 Q159 26 162 30 Q171 45 184 52 "
         "Q177 57 172 57 L164 50 L157 59 L150 52 Q142 56 137 52Z",
         _GOLD, stroke=_EDGE, stroke_width=2.35, stroke_linejoin="round")
    path(crown, "M142 51 Q154 42 159 31 Q164 39 167 48 L160 48 L156 54 L150 50Z", _GOLD_LIGHT)
    for x, y in ((145, 52), (160, 47), (176, 52)):
        _rivet(crown, x, y)
    path(crown, "M160 55 Q173 64 173 71 Q173 78 160 83 Q147 78 147 71 Q147 64 160 55Z "
         "M136 58 Q135 69 128 77 Q124 81 116 81 Q116 73 123 67Z "
         "M184 58 L197 67 Q204 73 204 81 Q196 81 192 77 Q185 69 184 58Z",
         "#a39d88", stroke=_GOLD_SHADE, stroke_width=1.45, stroke_linejoin="round")
    _line(crown, "M157 67 q3 -4 6 0 m-4 3 q1 4 6 5 m-6 -4 q-4 1 -5 5 "
          "M123 75 q6 -1 8 -6 m58 0 q2 5 8 6", "#e0c99b", 1.15)

    path(rim, "M78 -19 Q160 -9 242 -19 L242 0 Q160 10 78 0Z", "#96754c", class_="edge")
    _line(rim, "M82 -15 Q160 -6 238 -15 M82 -4 Q160 5 238 -4", _GOLD_LIGHT, 1.65)
    for x, y in ((88, -10), (105, -8.3), (122, -7), (198, -7), (215, -8.3), (232, -10)):
        leaf = node(rim, "g", transform=f"translate({x} {number(y)})")
        path(leaf, "M0 6 Q-10 1 -7 -3 Q-5 -6 0 -2 Q5 -6 7 -3 Q10 1 0 6Z",
             "#b89762", stroke=_GOLD_SHADE, stroke_width=1.1)
        _line(leaf, "M0 4 L0 0 m0 3 q-5 0 -5 -3 m5 3 q5 0 5 -3", "#ead2a0", 1)

    path(rim, "M132 -6 L133 -28 Q137 -34 143 -34 Q152 -37 160 -49 Q168 -37 177 -34 "
         "Q183 -34 187 -28 L188 -6 Q160 1 132 -6Z",
         "#806643", stroke=_EDGE, stroke_width=2.3, stroke_linejoin="round")
    path(rim, "M137 -9 L138 -26 Q150 -31 160 -42 Q170 -31 182 -26 L183 -9 Q160 -3 137 -9Z",
         "#b69a68", stroke="#e0c397", stroke_width=1.55, stroke_linejoin="round")
    node(rim, "circle", cx=160, cy=-30, r=4.6, fill="#dfc18c", stroke=_GOLD_SHADE, stroke_width=1.05)
    path(rim, "M158 -31 Q160 -34 162 -31 L162 -28 L161 -26 L164 -23 L166 -13 "
         "Q159 -11 154 -13 L156 -23 L159 -26Z", "#d4b78b", stroke="#654f3c",
         stroke_width=1, stroke_linejoin="round")
    _line(rim, "M156 -24 Q151 -30 145 -26 Q150 -20 155 -18 M164 -24 Q169 -30 175 -26 "
          "Q170 -20 165 -18 M146 -28 L149 -13 M174 -26 L170 -12",
          "#745b3d", 1.45)
    _line(rim, "M145 -26 Q150 -26 154 -21 M166 -21 Q170 -26 173 -26 M159 -23 l-1 8 m3-8 2 8",
          "#e4ca94", 1)
    _line(rim, "M140 -25 l1.4 4 m-.7 2 .5 3 M180 -25 l-1.4 4 m.7 2 -.5 3 "
          "M143 -10 l3 .7 m2.5 .4 2.5 .4 m17 0 2.5 -.4 m2.5 -.4 3 -.7", "#6c5139", 1.1)


def _points(*values):
    return " ".join(number(value) for value in values)


def _draw_lykovo_faceguard(parent, look, head):
    layout = eye_layout(look, head)
    _, rim_y = helmet_rim(look, head)
    guard = node(parent, "g", data_part="helmet-faceguard")
    center = 160 - layout.spacing
    outer = center - layout.outer - 8
    arch = min(rim_y + 8, 126 + layout.height_offset)
    tip = 175 + .35 * layout.height_offset
    guard_path = (
        f"M{_points(outer, rim_y - 3)} Q{_points(center - 14, rim_y + 1, center + 5, rim_y - 1)} "
        f"Q{_points(151, rim_y - 5, 160, rim_y)} "
        f"Q{_points(169, rim_y - 5, 315 - center, rim_y - 1)} "
        f"Q{_points(334 - center, rim_y + 1, 320 - outer, rim_y - 3)} "
        f"L{_points(321 - outer, arch + 19)} "
        f"C{_points(317 - outer, arch + 10, 327 - center, arch + 1, 320 - center, arch)} "
        f"Q{_points(320 - center - 13, arch - 2, 169, arch + 12)} "
        f"Q{_points(167.5, arch + 29, 167, tip - 7)} Q{_points(165, tip - 1, 160, tip)} "
        f"Q{_points(156, tip - 3, 153, tip - 8)} Q{_points(151.5, arch + 29, 151, arch + 12)} "
        f"Q{_points(center + 13, arch - 2, center, arch)} "
        f"C{_points(center - 7, arch + 1, outer + 3, arch + 13, outer - 1, arch + 19)}Z"
    )
    path(guard, guard_path, _GOLD, stroke=_EDGE, stroke_width=2.5, stroke_linejoin="round")
    _line(guard, f"M{_points(outer + 2, arch + 11)} Q{_points(center - 12, arch - 6, center + 5, arch - 4)} "
          f"M{_points(315 - center, arch - 4)} Q{_points(332 - center, arch - 6, 318 - outer, arch + 11)}",
          _GOLD_LIGHT, 1.5)
    path(guard, f"M{_points(155, arch + 6)} Q{_points(159, arch + 1, 162, arch + 6)} "
         f"Q{_points(159, arch + 28, 160, tip - 3)} L{_points(155, tip - 7)}Z", _GOLD_LIGHT)
    _line(guard, f"M{_points(164, arch + 11)} Q{_points(162, arch + 28, 164, tip - 6)}", _GOLD_SHADE, 1.6)
    for x in (outer + 5, 160, 315 - outer):
        _rivet(guard, x, rim_y + 2)


def draw_lykovo_helm(parent, look, head):
    crown, rim = _fitted_shell(parent, look, head, 29, 38)
    path(crown, "M78 111 C82 87 103 66 125 55 Q143 45 153 43 Q161 40 168 43 "
         "Q184 47 200 57 C221 69 236 87 242 111 Q158 122 78 111Z",
         "#a99572", class_="edge")
    path(crown, "M83 108 C97 79 122 65 144 56 Q135 71 130 91 L124 114Z", "#d4b88a")
    path(crown, "M173 48 Q221 64 239 109 L202 114 Q202 84 173 48Z", "#796b56")
    path(crown, "M201 67 Q229 86 239 109 L226 111 Q220 87 201 67Z", "url(#ink-lines)", opacity=".44")
    _line(crown, "M91 98 Q103 79 123 69 m77 8 q12 10 16 18", "#d2bc93", 1.15, opacity=".83")
    _draw_lykovo_ornament(crown, rim)
    _draw_lykovo_faceguard(parent, look, head)


def _spectacle_opening(outside, inside, *, center=0, side=1):
    start = center - side * outside
    middle = center + side * inside
    return (
        f"M{_points(start, 0)} C{_points(start, -20, center - side * 15, -30, center + side * 2, -29)} "
        f"C{_points(center + side * 16, -31, middle, -20, middle, 0)} "
        f"C{_points(middle, 15, center + side * 13, 24, center + side, 24)} "
        f"C{_points(center - side * 13, 25, start, 15, start, 0)}Z"
    )


def _draw_gjermundbu_faceguard(parent, look, head):
    layout = eye_layout(look, head)
    half, rim_y = helmet_rim(look, head)
    guard = node(parent, "g", data_part="helmet-faceguard")
    eye_y = 160 + layout.height_offset
    outside = layout.outer + 5.5
    inside = layout.inner + 4.6
    outer = -min(half - 3, layout.spacing + outside + 8)
    upper = rim_y - eye_y - 4
    lobe = layout.spacing + 3
    tip = min(22, 181 - eye_y)
    mask = (
        f"M{_points(outer, upper + 1)} Q{_points(-lobe, upper + 4, 0, upper + 6)} "
        f"Q{_points(lobe, upper + 4, -outer, upper + 1)} L{_points(-outer + 1, -9)} "
        f"C{_points(-outer, 11, lobe + 9, 30, lobe - 5, 30)} "
        f"Q{_points(24, 24, 10, tip - 4)} L{_points(7, tip - 2)} "
        f"Q{_points(3.5, tip, 0, tip)} Q{_points(-3.5, tip, -7, tip - 2)} L{_points(-10, tip - 4)} "
        f"Q{_points(-24, 24, 5 - lobe, 30)} "
        f"C{_points(-lobe - 9, 30, outer, 11, outer - 1, -9)}Z"
    )
    for side in (1, -1):
        # Hole contours are true cut-outs in the single cheek-and-nose plate.
        mask += " " + _spectacle_opening(outside, inside, center=-side * layout.spacing, side=side)
    plate = node(guard, "g", transform=f"translate(160 {number(eye_y)})")
    path(plate, mask, "#656860", fill_rule="evenodd", stroke=_EDGE, stroke_width=2.6, stroke_linejoin="round")
    for side in (1, -1):
        brow = node(plate, "g", transform=f"matrix({side} 0 0 1 {number(-side * layout.spacing)} 0)")
        hole = _spectacle_opening(outside, inside)
        _line(brow, hole, "#ada99b", 1.25)
        _line(brow, f"M{_points(-outside - 3, 5)} Q{_points(-outside, 28, -2, 28)}",
              "#a5a296", 1.25)
        _line(brow, f"M{_points(-outside + 1, -19)} Q-11 -40 6 -32", "#bebaac", 1.65)
        _rivet(brow, -outside + .5, -21.5)
        _rivet(brow, 2, 27.5)
    path(plate, f"M-3 -24 Q-.5 -27 2 -24 Q{_points(-.5, -1, 1.5, tip - 5)} "
         f"L{_points(-.5, tip - 2, -3.5, tip - 5)} Q-5 -1 -3 -24Z", "#96978a")
    _line(plate, f"M3 -21 Q{_points(2, -3, 4, tip - 6)}", "#42463f", 1.45)
    _rivet(plate, 0, upper + 13)


def draw_gjermundbu_helm(parent, look, head):
    crown, rim = _fitted_shell(parent, look, head, 39, 32)
    path(crown, "M78 113 C78 93 85 74 103 61 Q124 46 159 47 Q192 46 214 60 "
         "Q240 77 242 112 Q160 122 78 113Z", "#757a71", class_="edge")
    path(crown, "M83 109 Q87 71 131 55 Q144 51 155 51 Q122 65 111 110Z", "#a9a89a")
    path(crown, "M165 49 Q198 49 218 64 Q239 82 241 112 L200 114 Q196 72 165 49Z", "#555e56")
    path(crown, "M204 62 Q235 80 240 111 L222 114 Q218 83 204 62Z", "url(#ink-lines)", opacity=".5")
    _line(crown, "M156 49 Q129 59 116 81 Q108 94 106 112 M164 49 Q190 63 202 89 Q207 101 209 113",
          "#4b514b", 4)
    _line(crown, "M153 52 Q129 64 119 83 Q112 97 110 110 M166 52 Q192 69 200 89 Q204 99 206 111",
          "#b0ad9c", 1.4)
    for x, y in ((119, 79), (109, 105), (195, 79), (207, 105)):
        _rivet(crown, x, y)
    path(crown, "M148 52 Q150 47 155 46 L159 39 Q160 36 162 40 L165 46 Q170 47 172 52 "
         "Q160 56 148 52Z", "#8d8e7e", stroke=_EDGE, stroke_width=2.2, stroke_linejoin="round")
    _line(crown, "M152 49 Q158 47 160 41", "#c7c0aa", 1.2)
    path(crown, "M90 98 l5-12 m6-9 5-4 m115 5 7 10 m3 7 3 9", class_="etch", opacity=".72")
    _iron_rim(rim, "#666b63", ((87, -4), (106, -2.2), (214, -2.2), (233, -4)))
    _draw_gjermundbu_faceguard(parent, look, head)


def draw_pakalniskiai_helm(parent, look, head):
    crown, rim = _fitted_shell(parent, look, head, 21, 55)
    path(crown, "M78 110 C83 96 98 86 114 73 Q137 54 156 29 L163 29 "
         "Q181 54 205 73 C222 86 237 96 242 110 Q160 121 78 110Z", "#858a7c", class_="edge")
    path(crown, "M84 108 Q98 87 119 72 Q143 51 158 32 Q153 55 137 76 Q127 93 122 112Z", "#b8b7a6")
    path(crown, "M163 34 Q183 58 205 74 Q230 92 239 109 L191 113 Q185 77 163 34Z", "#5d675c")
    path(crown, "M193 71 Q222 89 237 110 L224 112 Q212 94 193 71Z", "url(#ink-lines)", opacity=".5")
    path(crown, "M92 103 l9-10 m6-5 11-9 m14-15 8-8 m57 21 9 7 m7 6 10 10", class_="etch", opacity=".58")
    path(crown, "M154 34 L156 28 Q151 25 154 20 Q158 15 163 18 Q169 21 166 26 "
         "Q165 28 163 28 L166 34 Q160 36 154 34Z",
         "#8e9585", stroke=_EDGE, stroke_width=2.15, stroke_linejoin="round")
    _line(crown, "M155 23 q1 -4 5 -4 M157 32 l1-4", "#c8c8b2", 1.1)
    path(rim, "M78 -10 Q160 -3 242 -10 L242 0 Q160 8 78 0Z", "#687166", class_="edge")
    _line(rim, "M82 -6 Q160 1 237 -6", "#b4b5a2", 1.45)
    for x, y in ((87, -2.5), (99, -1.4), (221, -1.4), (233, -2.5)):
        _rivet(rim, x, y)


DRAWERS = {
    "nw_rus_half_mask": draw_rus_half_mask,
    "nw_iron_hat": draw_iron_hat,
    "nw_great_helm": draw_great_helm,
    "nw_duboshin_helm": draw_duboshin_helm,
    "nw_lykovo_helm": draw_lykovo_helm,
    "nw_gjermundbu_helm": draw_gjermundbu_helm,
    "nw_pakalniskiai_helm": draw_pakalniskiai_helm,
}
