from common import node, number, path, use


OPTIONS = {
    "nw_mail_hauberk": "Кольчуга поверх стёганки",
    "nw_nov_lamellar": "Новгородский пластинчатый доспех",
    "nw_mail_surcoat": "Кольчуга и льняное сюрко",
    "nw_nov_scale": "Новгородский чешуйчатый панцирь",
    "nw_nov_copper_mail": "Новгородская кольчуга с медной каймой",
    "nw_gomel_lamellar": "Ламеллярный панцирь из Гомия",
    "nw_magdeburg_plate_coat": "Магдебургский нагрудник поверх кольчуги",
    "rus_suzdal_silk_over_mail": "Владимиро-суздальская шёлковая накидка поверх кольчуги",
    "steppe_polovtsian_lamellar": "Степной панцирь поверх кафтана",
    "steppe_mongol_leather_armour": "Монгольский кожаный наборный доспех",
}
FULL_HEMS = {
    "nw_mail_hauberk": 570,
    "nw_nov_lamellar": 555,
    "nw_mail_surcoat": 599,
    "nw_nov_scale": 548,
    "nw_nov_copper_mail": 579,
    "nw_gomel_lamellar": 564,
    "nw_magdeburg_plate_coat": 609,
    "rus_suzdal_silk_over_mail": 609,
    "steppe_polovtsian_lamellar": 620,
    "steppe_mongol_leather_armour": 625,
}
_MAIL = "#666659"
_MAIL_LIGHT = "#adab95"
_MAIL_SHADE = "#333532"
_BINDING = "#694a3b"
_BINDING_LIGHT = "#b28964"
_IRON = ("#71756b", "#7c7e70", "#898775", "#6c7168", "#93917e")


def _line(parent, contour, color, width, **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def _rings(parent, contour, *, opacity=".92"):
    path(parent, contour, "url(#mail-rings)", opacity=opacity)


def _divide_curve(points, t):
    level, left, right = list(points), [points[0]], [points[-1]]
    while len(level) > 1:
        level = [(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                 for a, b in zip(level, level[1:])]
        left.append(level[0])
        right.append(level[-1])
    return tuple(left), tuple(reversed(right))


def _divide_at_height(curve, y):
    low, high = 0., 1.
    direction = 1 if curve[-1][1] > curve[0][1] else -1
    for _ in range(24):
        t = (low + high) / 2
        left, right = _divide_curve(curve, t)
        if (left[-1][1] - y) * direction < 0:
            low = t
        else:
            high = t
    return left, right


def _sleeve_cut(body, outfit, bottom):
    """Тот же крой рукава, укороченный на точной поперечной опоре."""
    from wardrobe import _sleeve_curves, _curve_command
    upper, lower, inner = _sleeve_curves(body, outfit)
    contour = f"M{number(upper[0][0])} {number(upper[0][1])}" + _curve_command(upper)
    for curve in lower:
        if curve[-1][1] <= bottom:
            contour += _curve_command(curve)
        else:
            contour += _curve_command(_divide_at_height(curve, bottom)[0])
            break
    tail = inner if bottom >= 445 else _divide_at_height(inner, bottom)[1]
    return contour + f"L{number(tail[0][0])} {number(tail[0][1])}" + _curve_command(tail) + "Z"


def _sleeve_lip(body, outfit, y):
    from wardrobe import sleeve_section
    left, right = sleeve_section(body, outfit, y)
    return f"M{number(left)} {number(y)}Q{number((left + right) / 2)} {number(y + 4)} {number(right)} {number(y)}"


def _mail_sleeve(sleeve, body, cuff, *, right, outfit=None):
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    metal = _sleeve_cut(body, outfit, cuff)
    identifier = f"nw-mail-sleeve-{int(right)}-{cuff}"
    path(sleeve, metal, "#55594f" if right else _MAIL, data_part="mail-sleeve-shell")
    path(node(sleeve, "clipPath", id=identifier), metal)
    sleeve = node(sleeve, "g", clip_path=f"url(#{identifier})")
    light = (
        f"M{shoulder + 9} {crest - 1} Q{outer + 8} 319 {outer + 13} 350 "
        f"Q{outer + 11} 375 {outer + 16} {cuff + 2} H{outer + 32} "
        f"Q{outer + 18} 379 {outer + 27} 348 Q{outer + 26} 316 {shoulder + 16} {crest + 4}Z"
    )
    fold = (
        f"M{shoulder + 22} {crest + 10} Q{outer + 25} 335 {outer + 31} 371 "
        f"Q{outer + 32} 398 {outer + 42} {cuff + 4} H{shoulder + 38}V{crest + 5}Z"
    )
    path(sleeve, light, _MAIL_LIGHT, opacity=".21" if right else ".49")
    path(sleeve, fold, _MAIL_SHADE, opacity=".43")
    _rings(sleeve, metal)
    path(sleeve, fold, "url(#ink-lines)", opacity=".38")
    _line(sleeve, f"M{outer + 13} 371 q8 -8 16 -10 m-17 18 q8 -7 16 -10",
          "#b5ae96", 1, opacity=".49")
    lip = _sleeve_lip(body, outfit, cuff - 3)
    _line(sleeve, lip, "#33312b", 2.5)
    _line(sleeve, lip, "#969381", 1.1, opacity=".8")


def _mail_torso(front, body, neck, *, hem, hem_half=None, slit=False):
    from wardrobe import _front_shape
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    waist = 160 - body.waist
    edge = 160 - body.hem
    lip = f"M{160 - neck} 273 Q160 307 {160 + neck} 273"
    edge_half = body.hem + 4 if hem_half is None else hem_half
    field = _front_shape(body, neck, hem_y=hem, hem_half=edge_half)
    slit_edge = None
    if slit:
        # The two skirts descend from the same waist and reveal the under-tunic.
        slit_edge = (f"Q{(160 - edge_half + 148) / 2} {hem + 10} 148 {hem + 5} "
                     f"Q155 {hem - 23} 160 {hem - 66} "
                     f"Q165 {hem - 23} 172 {hem + 5} "
                     f"Q{(160 + edge_half + 172) / 2} {hem + 10} {160 + edge_half} {hem}")
        field = field.replace(f"Q160 {hem + 19} {160 + edge_half} {hem}", slit_edge)
    surface = node(front, "g", data_part="mail-torso")
    path(surface, field, _MAIL, data_part="mail-shell")
    identifier = f"nw-mail-torso-{len(list(front))}"
    path(node(surface, "clipPath", id=identifier), field)
    front = node(surface, "g", clip_path=f"url(#{identifier})")
    shadow = (
        f"M194 287 Q{320 - shoulder - 13} 296 {327 - chest} 340 "
        f"Q{315 - waist} 383 {332 - waist} 433 L{332 - edge} {hem} "
        f"H{307 - edge} Q{320 - waist - 26} 403 {320 - chest - 17} 364 "
        "Q216 315 194 287Z"
    )
    path(front, f"M{shoulder + 11} 287 Q104 268 137 287 Q109 319 {chest + 23} 351 "
         f"Q{waist + 14} 382 {edge + 24} {hem} H{edge + 5} "
         f"Q{waist + 13} 369 {chest + 5} 341 Q{chest + 7} 312 {shoulder + 11} 287Z",
         _MAIL_LIGHT, opacity=".38")
    path(front, shadow, _MAIL_SHADE, opacity=".61")
    _rings(front, field)
    path(front, shadow, "url(#ink-lines)", opacity=".46")
    _line(front, f"M{chest + 12} 327 q3 -14 12 -23 M{waist + 18} 373 q-3 15 0 26 "
          f"M{315 - waist} 370 q-1 -20 -8 -32", "#c2b8a1", 1.2, opacity=".42")
    _line(front, lip, "#32312d", 7)
    _line(front, lip, "#9c9783", 3)
    _line(front, lip, "#c1b79c", 1.1, stroke_dasharray="1.4 3")
    if slit_edge is not None:
        _line(surface, f"M{160 - edge_half} {hem} {slit_edge}", "#34362f", 2.2)


def draw_mail_hauberk(art):
    body, cloth = art.body, art.cloth
    for side, sleeve in enumerate(art.sleeves):
        outer = 160 - body.sleeve
        for x in range(outer + 5, 160 - body.shoulder + 35, 9):
            _line(sleeve, f"M{x} 415 q-3 13 1 31", cloth.deep, 1.25, opacity=".61")
            _line(sleeve, f"M{x + 2} 418 q-3 12 1 27", cloth.light, .85, opacity=".64")
        _mail_sleeve(sleeve, body, 422, right=bool(side), outfit=art.look["outfit"])
    _mail_torso(art.front, body, art.neck, hem=435 if art.hem_y is None else art.hem_y,
                hem_half=art.hem_half, slit=art.hem_y is not None)


def _lamella(parent, identifier, width, color):
    tile = node(parent, "g", id=identifier)
    contour = f"M1 2 Q{width / 2} .25 {width - 1} 1.5 L{width} 18 q-1 2.8 -3.2 3 H3 Q.3 21 0 18Z"
    path(tile, contour, color, stroke="#2d2926", stroke_width=1.35, stroke_linejoin="round")
    path(tile, f"M1.6 3 Q{width / 2} 1.2 {width - 1.3} 2.5 "
         f"L{width - 1.4} 4.5 Q4 4 2.1 10Z", "#b4ad94", opacity=".62")
    path(tile, f"M{width - 2} 5 L{width - .7} 17 q-.7 3 -3.5 3 H2.6 "
         f"Q{width - 3.5} 17 {width - 2} 5Z", "#494c45", opacity=".66")
    _line(tile, f"M2.9 7 l2.5 -1 M{width - 4} 10 l1.2 -1.2", "#c4b99d", .68, opacity=".62")
    for hole in (3.6, width - 3.7):
        node(tile, "circle", cx=hole, cy=14.7, r=1.13, fill="#332922")
    _line(tile, f"M3.6 14.6 q{width / 2 - 3.4} -3.7 {width - 7.3} 0", "#534033", 1.65)
    _line(tile, f"M4.6 13.7 q{width / 2 - 4.8} -1.5 {width - 9.3} -.1", "#ac8762", .68)


def draw_nov_lamellar(art):
    front, body, cloth = art.front, art.body, art.cloth
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest + 9
    waist = 160 - body.waist + 6
    hem = 160 - body.hem + 9
    neckline = art.neck + 2
    for sleeve in art.sleeves:
        _line(sleeve, f"M{shoulder - 9} {body.shoulder_y + 7} "
              f"Q{shoulder + 13} 313 {shoulder + 9} 341", cloth.deep, 2.1, opacity=".83")
    if art.hem_y is not None:
        bottom = art.hem_y + 11
        fold = (f"M{waist - 14} 416 Q{waist + 4} 474 {hem + 24} {bottom} "
                f"H{hem - 18}V427Z")
        path(front, fold, cloth.shade)
        path(front, fold, cloth.deep, opacity=".42", transform="translate(320 0) scale(-1 1)")
        path(front, f"M135 434 Q129 494 118 {bottom - 12} "
             f"M179 436 Q183 485 193 {bottom - 15} M151 449 Q151 495 147 {bottom - 12}",
             class_="etch")
    shell = (
        f"M{160 - neckline} 273 C{146 - neckline} 273 {shoulder + 13} {body.shoulder_y - 10} {shoulder} {body.shoulder_y} "
        f"Q{shoulder + 17} 308 {chest} 337 Q{chest - 2} 366 {waist} 392 "
        f"Q{waist - 4} 419 {hem} 433 Q160 453 {320 - hem} 433 "
        f"Q{324 - waist} 419 {320 - waist} 392 Q{322 - chest} 366 {320 - chest} 337 "
        f"Q{303 - shoulder} 308 {320 - shoulder} {body.shoulder_y} "
        f"C{307 - shoulder} {body.shoulder_y - 10} {174 + neckline} 273 {160 + neckline} 273 "
        f"Q160 317 {160 - neckline} 273Z"
    )
    path(front, shell, "#53493c", class_="edge")
    mask = node(front, "clipPath", id="nw-lamellar-shell")
    path(mask, shell)
    layer = node(front, "g", clip_path="url(#nw-lamellar-shell)")
    count = 13 if body.chest >= 79 else 11
    width = (2 * (160 - min(chest, waist, hem) + 16)) / count
    definitions = node(layer, "defs")
    plate_ids = tuple(f"nw-lamella-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        _lamella(definitions, identifier, width + 1, color)
    for row, y in enumerate(range(277, 439, 16)):
        origin = 160 - count * width / 2 - (width / 2 if row % 2 else 0)
        for column in range(count + 1):
            x = origin + column * width
            cross = (x + width / 2 - 160) / 100
            height = y + 5 - 7 * cross ** 2
            angle = round(-7 * cross)
            identifier = plate_ids[(column * 2 + row * 3) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({number(x)} {number(height)}) rotate({angle})")
    shade = (
        f"M{320 - shoulder} 283 Q{310 - chest} 337 {307 - waist} 395 "
        f"Q{317 - hem} 426 {328 - hem} 443 H{340 - hem} V279Z"
    )
    path(layer, shade, "#3a3029", opacity=".51")
    path(layer, shade, "url(#ink-lines)", opacity=".45")
    _line(front, shell, "#342721", 6)
    _line(front, shell, _BINDING, 3.65)
    _line(front, shell, _BINDING_LIGHT, .9, stroke_dasharray="1 4", opacity=".91")


def draw_mail_surcoat(art):
    body, cloth = art.body, art.cloth
    front, outer = art.front, art.outer
    for side, sleeve in enumerate(art.sleeves):
        _mail_sleeve(sleeve, body, 445, right=bool(side), outfit=art.look["outfit"])
    _mail_torso(front, body, art.neck, hem=445 if art.hem_y is None else art.hem_y,
                hem_half=art.hem_half, slit=art.hem_y is not None)
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest + 8
    waist = 160 - body.waist + 3
    hem = 160 - body.hem + 3
    collar = art.neck + 10
    if art.hem_y is None:
        tail = (f"Q{waist - 1} 414 {hem} 438 Q160 449 {320 - hem} 438 "
                f"Q{321 - waist} 414 {320 - waist} 396 ")
        shadow_tail = (f"Q{318 - waist} 420 {316 - hem} 437 "
                       f"L{295 - hem} 440 Q{304 - waist} 422 {296 - waist} 386 ")
    else:
        edge = hem - 8
        bottom = art.hem_y + 2
        tail = (f"C{waist - 5} 418 {edge + 7} 477 {edge} {bottom} "
                f"Q160 {bottom + 19} {320 - edge} {bottom} "
                f"C{313 - edge} 477 {325 - waist} 418 {320 - waist} 396 ")
        shadow_tail = (f"C{321 - waist} 434 {318 - edge} 485 {314 - edge} {bottom - 5} "
                       f"Q{305 - edge} {bottom - 3} {294 - edge} {bottom - 1} "
                       f"Q{299 - waist} 503 {296 - waist} 386 ")
    cloth_shape = (
        f"M{160 - collar} 273 C{146 - collar} 273 {shoulder + 13} {body.shoulder_y - 10} {shoulder} {body.shoulder_y} "
        f"Q{shoulder + 18} 310 {chest} 341 Q{chest - 1} 369 {waist} 396 "
        f"{tail}Q{321 - chest} 369 {320 - chest} 341 "
        f"Q{302 - shoulder} 310 {320 - shoulder} {body.shoulder_y} "
        f"C{307 - shoulder} {body.shoulder_y - 10} {174 + collar} 273 {160 + collar} 273 "
        f"Q180 304 160 311 Q140 304 {160 - collar} 273Z"
    )
    path(outer, cloth_shape, cloth.base, class_="edge", data_part="surcoat-shell")
    path(outer, f"M{shoulder + 13} {body.shoulder_y + 1} Q113 291 120 286 Q128 296 143 307 "
         f"Q128 322 {chest + 17} 353 Q{chest + 23} 321 {shoulder + 13} {body.shoulder_y + 1}Z", cloth.light)
    shadow = (
        f"M{316 - shoulder} {body.shoulder_y + 1} Q{303 - shoulder} 315 {317 - chest} 343 "
        f"Q{317 - chest} 367 {317 - waist} 397 {shadow_tail}"
        f"Q{297 - chest} 352 184 319 Q197 310 210 286 Q{304 - shoulder} 285 "
        f"{316 - shoulder} {body.shoulder_y + 1}Z"
    )
    path(outer, shadow, cloth.shade)
    path(outer, shadow, "url(#ink-lines)", opacity=".45")
    path(outer, f"M{chest + 10} 359 Q{waist + 17} 373 {waist + 10} 396 "
         f"Q{waist + 8} 378 {chest + 10} 359Z M133 415 q-8 11 -10 26 l-9 1 q6-19 19-27Z", cloth.light)
    path(outer, f"M{chest + 18} 341 q12 -21 19 -24 m-14 53 q8 8 7 22 "
         f"M{301 - chest} 341 q-6 -11 -18 -23 m9 71 q4 -14 -2 -26 m-13 52 q4 8 6 21", class_="seam")
    if art.hem_y is not None:
        path(outer, f"M126 413Q112 495 109 {art.hem_y - 12} "
             f"M164 430Q151 498 152 {art.hem_y - 2} "
             f"M183 451Q194 502 202 {art.hem_y - 10}", class_="etch")
    _line(outer, cloth_shape, cloth.deep, 3.2)
    _line(outer, cloth_shape, cloth.light, 1.1, opacity=".78")


def _cloth_cuff(sleeve, body, cloth, *, right):
    contour = _sleeve_lip(body, "nw_nov_scale", 434)
    _line(sleeve, contour, cloth.deep, 8)
    _line(sleeve, contour, cloth.shade if right else cloth.light, 3.1)
    _line(sleeve, contour, cloth.deep, .95, stroke_dasharray="1 3")


def _armor_upper(art, *, shoulder_inset, neck_depth):
    body = art.body
    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    chest = 163 - body.chest
    waist = 162 - body.waist
    neck = art.neck + 2
    return (
        f"M{waist} 401 Q{chest} 365 {chest} 346 Q{shoulder + shoulder_inset + 9} 312 {shoulder} {crest} "
        f"C{shoulder + 13} {crest - 10} {146 - neck} 273 {160 - neck} 273 "
        f"Q160 {neck_depth - 12} {160 + neck} 273 "
        f"C{174 + neck} 273 {307 - shoulder} {crest - 10} {320 - shoulder} {crest} "
        f"Q{311 - shoulder - shoulder_inset} 312 {320 - chest} 346 Q{320 - chest} 365 {320 - waist} 401 "
    )


def _clipped_field(parent, part, identifier, contour, fill):
    layer = node(parent, "g", data_part=part)
    path(layer, contour, fill)
    path(node(layer, "clipPath", id=identifier), contour)
    return layer, node(layer, "g", clip_path=f"url(#{identifier})")


def _suzdal_goldwork(parent, body, bottom):
    from wardrobe import _curve_command

    threads = node(parent, "g", data_part="suzdal-goldwork", data_material_surface="fixed")
    motif = node(node(threads, "defs"), "g", id="rus-suzdal-gold-lozenge")
    path(motif, "M0 -5.8 4.1 0 0 5.8 -4.1 0Z", "#756145", fill_opacity=".65",
         stroke="#bc9b64", stroke_width=".86")
    _line(motif, "M-2.5 0Q0 -.8 0 -3M2.5 0Q0 .8 0 3", "#e3c596", .78)

    drop = bottom + 13 - 405
    lower_count = max(2, round(drop / 25))
    for column, offset in enumerate((-.85, -.57, -.28, .02, .32, .60, .85)):
        upper_x = 160 + offset * (body.chest - 3)
        waist_x = 160 + offset * (body.waist - 7)
        hem_x = 160 + offset * (body.hem - 3)
        upper = ((upper_x + 3, 276), (upper_x + 5, 322), (waist_x - 3, 376), (waist_x, 405))
        lower = ((waist_x, 405), (waist_x + 3, 405 + drop * .34),
                 (hem_x - 4, 405 + drop * .65), (hem_x, bottom + 13))
        trace = f"M{number(upper_x + 3)} 276{_curve_command(upper)}{_curve_command(lower)}"
        _line(threads, trace, "#a68c5d", .9, opacity=".72")
        _line(threads, trace, "#dec493", .77, opacity=".63", stroke_dasharray="1.4 3.4")
        phase = .48 if column % 2 else .68
        for curve, count in ((upper, 5), (lower, lower_count)):
            for row in range(count):
                _, remainder = _divide_curve(curve, (row + phase) / count)
                x, y = remainder[0]
                use(threads, "rus-suzdal-gold-lozenge", transform=f"translate({number(x)} {number(y)})")


def draw_suzdal_silk_over_mail(art):
    from wardrobe_northwest_accessories import draw_belt

    body, cloth = art.body, art.cloth
    for side, sleeve in enumerate(art.sleeves):
        sleeve.set("data-material-surface", "fixed")
        _mail_sleeve(sleeve, body, 445, right=bool(side), outfit=art.look["outfit"])
    full_hem = art.hem_y is not None
    armor = node(art.front, "g", data_material_surface="fixed")
    _mail_torso(armor, body, art.neck, hem=min(567, art.hem_y) if full_hem else 445,
                hem_half=body.hem, slit=full_hem)

    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    chest = 160 - body.chest
    waist = 160 - body.waist
    neck = art.neck + 8
    bottom = art.hem_y if full_hem else 445
    edge = 160 - body.hem
    # Match the torso mask at the waist and hem, with an inset round neck and open armholes.
    if full_hem:
        edge = 160 - (art.hem_half if art.hem_half is not None else body.hem + 4)
        tail = (f"C{waist - 1} 418 {161 - body.hem} 476 {edge} {bottom} "
                f"Q160 {bottom + 19} {320 - edge} {bottom} "
                f"C{159 + body.hem} 476 {321 - waist} 418 {320 - waist} 400 ")
    else:
        tail = (f"C{waist - 1} 415 {edge + 5} 431 {edge} {bottom} "
                f"H{320 - edge} C{315 - edge} 431 {321 - waist} 415 {320 - waist} 400 ")
    neck_curve = f"Q160 330 {160 - neck} 279"
    shoulder_point = f"{shoulder + 10} {crest}"
    arm_curve = f"C{shoulder + 24} {crest + 20} {chest + 17} 327 {chest + 8} 346"
    shell = (
        f"M{160 - neck} 279C{148 - neck} 278 {shoulder + 27} {crest - 8} "
        f"{shoulder_point}{arm_curve} C{chest + 7} 366 {waist + 1} 388 {waist} 400 "
        f"{tail}C{319 - waist} 388 {313 - chest} 366 {312 - chest} 346 "
        f"C{303 - chest} 327 {296 - shoulder} {crest + 20} {310 - shoulder} {crest} "
        f"C{293 - shoulder} {crest - 8} {172 + neck} 278 {160 + neck} 279 "
        f"{neck_curve}Z"
    )
    silk, field = _clipped_field(art.front, "suzdal-silk", "rus-suzdal-silk-mask", shell, cloth.base)
    silk.set("data-material-slot", "outfit")
    # Keep the material finish subordinate to the drawn folds and goldwork.
    ground_opacity = ".84" if art.look.get("outfit_material") == "brocade" else ".57"
    path(field, shell, cloth.base, opacity=ground_opacity, data_material_surface="fixed")
    near = number(405 + (bottom - 405) * .34)
    far = number(405 + (bottom - 405) * .72)
    highlight = (
        f"M{shoulder + 19} {crest + 2} Q{chest + 37} 323 {chest + 25} 353 "
        f"Q{waist + 28} 378 {waist + 22} 400 Q{waist + 17} 377 {chest + 14} 351 "
        f"Q{chest + 27} 326 {shoulder + 19} {crest + 2}Z "
        f"M{waist + 17} 405 C{waist + 19} {near} {edge + 26} {far} {edge + 18} {bottom + 10} "
        f"L{edge + 35} {bottom + 13} C{edge + 37} {far} {waist + 33} {near} {waist + 25} 405Z"
    )
    shadow = (
        f"M{306 - shoulder} {crest - 5} Q{295 - chest} 328 {300 - chest} 352 "
        f"Q{293 - waist} 377 {300 - waist} 407 C{297 - waist} {near} {307 - edge} {far} "
        f"{295 - edge} {bottom + 17} H{331 - edge} V{crest - 5}Z"
    )
    path(field, highlight, cloth.light, opacity=".58", data_material_surface="fixed")
    path(field, shadow, cloth.shade, opacity=".74", data_material_surface="fixed")
    _suzdal_goldwork(field, body, bottom)
    path(field, shadow, "url(#ink-lines)", opacity=".26")
    _line(field, f"M145 418Q137 {near} 142 {far}T135 {bottom + 6} "
          f"M179 417Q186 {near} 183 {far}T192 {bottom + 5}", cloth.deep, 1.2, opacity=".53")
    _line(silk, shell, cloth.deep, 3.4, data_material_surface="fixed")
    trim = node(silk, "g", data_material_surface="fixed")
    left_armhole = f"M{shoulder_point}{arm_curve}"
    _line(trim, f"M{160 + neck} 279{neck_curve}", "#b99a69", 1.2, opacity=".83")
    _line(trim, left_armhole, "#b99a69", 1.2, opacity=".83")
    _line(trim, left_armhole, "#b99a69", 1.05, opacity=".64", transform="translate(320 0) scale(-1 1)")
    if full_hem:
        hemline = f"M{edge} {bottom - 4}Q160 {bottom + 15} {320 - edge} {bottom - 4}"
        _line(field, hemline, cloth.deep, 6.2, data_material_surface="fixed")
        _line(field, hemline, "#b99a69", 1.2, data_material_surface="fixed")
    if "belt" not in art.look:
        draw_belt(art.front, body, "gold_plaques")


def _scale_tiles(layer, left, right, top, bottom, *, prefix, shade=False):
    width, advance = 18, 13
    definitions = node(layer, "defs")
    plate_ids = tuple(f"{prefix}-scale-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        plate = node(definitions, "g", id=identifier)
        path(plate, "M.8 1 Q9 -.5 17.2 1 L18 9 Q18 17 9 22 Q0 18 0 9Z",
             color, stroke="#2b2d29", stroke_width=1.3, stroke_linejoin="round")
        path(plate, "M2 3 Q7 1 15 2 Q6 4 4 12 L2 14 Q1 8 2 3Z", "#c8c3ac", opacity=".73")
        path(plate, "M16 3 Q19 14 9 20 Q5 18 3 16 Q13 17 16 3Z", "#414940", opacity=".76")
        node(plate, "circle", cx=9, cy=6, r=1.15, fill="#3d3b33")
    rows = range(top, bottom + 1, advance)
    for row, y in reversed(tuple(enumerate(rows))):
        x = left - (row % 2) * 9
        for column, start in enumerate(range(x, right + 1, width)):
            bend = (start + 9 - 160) / 100
            height = number(y - 4 * bend ** 2)
            identifier = plate_ids[(2 * column + 3 * row + shade) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({start} {height})")
    if shade:
        path(layer, f"M{left} {top - 18} H{right + width} V{bottom + 24} H{left}Z",
             "#282d29", opacity=".25")


def draw_nov_scale(art):
    body, cloth = art.body, art.cloth
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    waist = 162 - body.waist
    for side, sleeve in enumerate(art.sleeves):
        _cloth_cuff(sleeve, body, cloth, right=bool(side))
        lip = _sleeve_lip(body, art.look["outfit"], 347)
        shell = _sleeve_cut(body, art.look["outfit"], 350)
        identifier = f"nw-scale-sleeve-{side}"
        sleeve_field, tiles = _clipped_field(sleeve, "scale-sleeve", identifier, shell, "#626354")
        _scale_tiles(tiles, outer - 8, shoulder + 30, 282, 355, prefix=identifier, shade=bool(side))
        _line(sleeve_field, lip, "#302923", 6)
        _line(sleeve_field, lip, _BINDING_LIGHT, 2.5)

    full_hem = art.hem_y is not None
    bottom = art.hem_y - 5 if full_hem else 451
    edge = 163 - body.hem
    upper = _armor_upper(art, shoulder_inset=5, neck_depth=342)
    half_step = (160 - edge) / 8
    hemline = ""
    edge_scales = []
    previous = bottom
    for scallop in range(16):
        end = 320 - edge - (scallop + 1) * half_step
        y = bottom + 8 * (1 - ((end - 160) / (160 - edge)) ** 2)
        start = end + half_step
        center = end + half_step / 2
        arc_height = (y + previous) / 2 + 5
        arc = f"Q{number(center)} {number(arc_height)} {number(end)} {number(y)}"
        hemline += f" {arc}"
        edge_scales.append((f"M{number(start)} {number(previous)} {arc} V{number(y - 11)} "
                            f"Q{number(center)} {number(arc_height - 14)} "
                            f"{number(start)} {number(previous - 11)}Z", center, arc_height))
        previous = y
    right_edge = f"C{320 - waist} 427 {318 - edge} {bottom - 19} {320 - edge} {bottom}"
    left_edge = f"C{edge + 2} {bottom - 19} {waist} 427 {waist} 401"
    contour = f"{upper}{right_edge}{hemline} {left_edge}Z"
    field, tiles = _clipped_field(art.front, "scale-armor", "nw-scale-front", contour, "#636659")
    _scale_tiles(tiles, edge - 21, 337 - edge, 264, bottom + 12, prefix="nw-scale-front")
    if full_hem:
        for index, (plate, center, height) in enumerate(edge_scales):
            color = _IRON[index % len(_IRON)]
            path(tiles, plate, color, stroke="#3a342b", stroke_width=1.3)
            node(tiles, "circle", cx=center, cy=height - 9, r=1, fill="#342c26")
    shade = (f"M{295 - shoulder} 286 Q{305 - waist} 334 {304 - waist} 398 "
             f"Q{304 - edge} 470 {299 - edge} {bottom + 15} H{340 - edge} V274Z")
    path(tiles, shade, "#30352d", opacity=".49")
    path(tiles, shade, "url(#ink-lines)", opacity=".39")
    trim = contour if full_hem else f"{upper}{right_edge} M{edge} {bottom} {left_edge}"
    _line(field, trim, "#322921", 5.8)
    _line(field, trim, _BINDING, 3.5)
    _line(field, trim, _BINDING_LIGHT, 1, stroke_dasharray="1 3")


_COPPER = "#aa6542"
_COPPER_LIGHT = "#d9a873"


def _copper_edge(parent, contour):
    _line(parent, contour, "#392a23", 7.4)
    _line(parent, contour, _COPPER, 4.8)
    _line(parent, contour, "#683c2b", 4, stroke_dasharray=".6 2.2")
    _line(parent, contour, _COPPER_LIGHT, 1.3, stroke_dasharray="1.5 1.3")


def draw_nov_copper_mail(art):
    body, cloth = art.body, art.cloth
    waist = 162 - body.waist
    for side, sleeve in enumerate(art.sleeves):
        _cloth_cuff(sleeve, body, cloth, right=bool(side))
        lip = _sleeve_lip(body, art.look["outfit"], 367)
        shell = _sleeve_cut(body, art.look["outfit"], 370)
        metal, rings = _clipped_field(
            sleeve, "copper-mail-sleeve", f"nw-copper-sleeve-{side}", shell, _MAIL)
        _mail_sleeve(rings, body, 370, right=bool(side), outfit=art.look["outfit"])
        _copper_edge(metal, lip)

    full_hem = art.hem_y is not None
    bottom = art.hem_y - 4 if full_hem else 456
    edge = 161 - body.hem
    upper = _armor_upper(art, shoulder_inset=2, neck_depth=329)
    outer_right = f"C{321 - waist} 431 {318 - edge} {bottom - 23} {320 - edge} {bottom}"
    outer_left = f"C{edge + 2} {bottom - 23} {waist - 1} 431 {waist} 401"
    slit = bottom - 58 if full_hem else bottom + 10
    hemline = (
        f"Q{235 - edge / 2} {bottom + 11} 173 {bottom + 4} Q162 {bottom - 12} 160 {slit} "
        f"Q156 {bottom - 11} 147 {bottom + 4} Q{85 + edge / 2} {bottom + 11} {edge} {bottom}"
        if full_hem else f"H{edge}"
    )
    contour = f"{upper}{outer_right} {hemline} {outer_left}Z"
    field, metal = _clipped_field(art.front, "copper-mail", "nw-copper-front", contour, "#555a53")
    _mail_torso(metal, body, art.neck, hem=bottom + 14)
    _copper_edge(field, f"M{160 - art.neck - 2} 276 Q160 330 {160 + art.neck + 2} 276")
    if full_hem:
        _copper_edge(field, f"M{320 - edge} {bottom} {hemline}")


def _gomel_plates(layer, left, right, first_row, bottom, *, prefix, column_step, row_step, lean=0):
    definitions = node(layer, "defs")
    plate_ids = tuple(f"{prefix}-plate-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        _lamella(definitions, identifier, column_step + 1, color)
    for row, y in enumerate(range(first_row, bottom + 1, row_step)):
        offset = left - (row % 2) * (column_step // 2)
        for column, x in enumerate(range(offset, right + 1, column_step)):
            rise = number(y - abs(x - 160) / 15)
            identifier = plate_ids[(column + 3 * row) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({x} {rise}) rotate({lean}) scale(1 1.27)")
        _line(layer, f"M{left - 12} {y + 4} L{right + 13} {y + 3}", "#493a31", 2.9)
        _line(layer, f"M{left - 12} {y + 3} L{right + 13} {y + 2}", "#b59872", .8,
              stroke_dasharray="2.2 3")


def _gomel_edge(parent, contour):
    _line(parent, contour, "#322821", 7)
    _line(parent, contour, "#805a42", 4)
    _line(parent, contour, "#c1a07a", .95, stroke_dasharray="1.4 3.6")


def draw_gomel_lamellar(art):
    body, cloth = art.body, art.cloth
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    waist = 162 - body.waist
    for side, sleeve in enumerate(art.sleeves):
        _cloth_cuff(sleeve, body, cloth, right=bool(side))
        blade = _sleeve_cut(body, art.look["outfit"], 378)
        identifier = f"nw-gomel-shoulder-{side}"
        field, plates = _clipped_field(sleeve, "gomel-shoulder", identifier, blade, "#635c4d")
        _gomel_plates(plates, outer - 9, shoulder + 34, 274, 388,
                      prefix=identifier, column_step=14, row_step=21, lean=9)
        strap = _sleeve_lip(body, art.look["outfit"], 355)
        _line(plates, strap, "#3d2e27", 7)
        _line(plates, strap, "#997252", 3.2)
        if side:
            path(plates, blade, "#2f2823", opacity=".25")
        _gomel_edge(field, blade)

    front = art.front
    edge = 164 - body.hem
    full_hem = art.hem_y is not None
    bottom = art.hem_y - 4 if full_hem else 459
    for right in (False, True):
        side = "right" if right else "left"
        group = node(front, "g", transform="translate(320 0) scale(-1 1)" if right else None)
        outer_edge = (f"M{waist - 1} 399 Q{waist - 2} 439 {edge} {bottom - 10} "
                      f"Q{edge + 4} {bottom - 1} {edge + 10} {bottom - 1}")
        lower = f"Q{(edge + 160) // 2} {bottom + 11} 149 {bottom + 2} Q154 {bottom} 155 {bottom - 10}"
        inner = "Q154 451 158 400"
        blade = f"{outer_edge} {lower} {inner}Z"
        identifier = f"nw-gomel-skirt-{side}"
        field, plates = _clipped_field(group, f"gomel-skirt-{side}", identifier, blade, "#625a4d")
        _gomel_plates(plates, edge - 10, 169, 392, bottom, prefix=identifier, column_step=13, row_step=20, lean=3)
        path(plates, f"M150 401 Q139 467 138 {bottom + 14} H169 V398Z",
             "#3e332b", opacity=".48")
        if right:
            path(plates, blade, "#37312a", opacity=".2")
        _gomel_edge(field, blade if full_hem else f"{outer_edge} M155 {bottom - 10} {inner}")

    upper = _armor_upper(art, shoulder_inset=11, neck_depth=333)
    shell = f"{upper}L{319 - waist} 410 Q160 424 {waist + 1} 410Z"
    field, plates = _clipped_field(front, "gomel-cuirass", "nw-gomel-chest", shell, "#61584c")
    _gomel_plates(plates, min(shoulder, waist) - 12, 331 - min(shoulder, waist), 273, 413,
                  prefix="nw-gomel-chest", column_step=11, row_step=18)
    shade = (f"M{310 - shoulder} 280 Q{313 - body.chest} 308 218 333 "
             f"Q{308 - waist} 374 {301 - waist} 423 H{338 - waist} V276Z")
    path(plates, shade, "#342c27", opacity=".42")
    path(plates, shade, "url(#ink-lines)", opacity=".37")
    _gomel_edge(field, shell)
    for right in (False, True):
        side = node(field, "g", transform="translate(320 0) scale(-1 1)" if right else None)
        buckle = (f"M{waist + 3} 375 Q{waist + 16} 372 {waist + 27} 377 "
                  f"M{waist + 5} 391 Q{waist + 18} 388 {waist + 29} 391")
        _line(side, buckle, "#3c3028", 5.5)
        node(side, "rect", x=waist + 18, y=373, width=7, height=7, rx=1.2, fill="none",
             stroke="#b09a75", stroke_width=1.4)
        node(side, "rect", x=waist + 20, y=387, width=7, height=7, rx=1.2, fill="none",
             stroke="#b09a75", stroke_width=1.4)


def draw_magdeburg_plate_coat(art):
    body, cloth = art.body, art.cloth
    for side, sleeve in enumerate(art.sleeves):
        _mail_sleeve(sleeve, body, 443, right=bool(side), outfit=art.look["outfit"])
    front = art.front
    full_hem = art.hem_y is not None
    bottom = art.hem_y if full_hem else 458
    _mail_torso(front, body, art.neck, hem=bottom, hem_half=art.hem_half, slit=full_hem)

    waist = 162 - body.waist
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    edge = 177 - body.hem
    hem = bottom - 22 if full_hem else bottom
    bend = 461 if full_hem else 439
    apron_left = f"M{waist + 6} 405 Q{waist + 11} {bend} {edge + 2} {hem}"
    apron_hem = f"Q160 {hem + 25} {318 - edge} {hem}" if full_hem else f"H{318 - edge}"
    apron_right = f"Q{309 - waist} {bend} {314 - waist} 405 Q160 415 {waist + 6} 405"
    contour = f"{apron_left} {apron_hem} {apron_right}Z"
    apron, apron_cloth = _clipped_field(front, "magdeburg-apron", "nw-magdeburg-apron", contour, cloth.base)
    path(apron_cloth, f"M{301 - waist} 410 Q{283 - waist} 496 {296 - edge} {hem + 12} "
         f"H{331 - edge} V405Z", cloth.shade)
    path(apron_cloth, f"M{waist + 23} 404 Q{waist + 38} 470 {edge + 15} {hem + 4} "
         f"Q{edge + 29} {hem + 12} {edge + 41} {hem + 7} Q{waist + 36} 471 {waist + 41} 408Z",
         cloth.light)
    path(apron_cloth, f"M144 425 Q140 499 131 {hem} M175 431 Q175 514 188 {hem + 4} "
         f"M{292 - waist} 441 Q{283 - edge} 522 {296 - edge} {hem + 2}", class_="etch")
    apron_trim = contour if full_hem else f"{apron_left} M{318 - edge} {hem} {apron_right}"
    _line(apron, apron_trim, "#352b27", 4.6)
    _line(apron, apron_trim, cloth.deep, 2.1)

    upper = _armor_upper(art, shoulder_inset=9, neck_depth=326)
    shell = f"{upper}L{318 - waist} 412 Q160 428 {waist + 2} 412Z"
    field, facing = _clipped_field(front, "magdeburg-breastpiece", "nw-magdeburg-chest", shell, cloth.base)
    path(facing, f"M{shoulder + 11} 280 Q123 267 134 284 Q128 310 {chest + 20} 335 "
         f"Q{chest + 28} 365 {waist + 18} 390 Q{waist + 6} 367 {chest + 8} 339 "
         f"Q{chest + 16} 307 {shoulder + 11} 280Z", cloth.light)
    shadow = (f"M{309 - shoulder} 280 Q{304 - chest} 329 {312 - chest} 354 "
              f"Q{304 - waist} 385 {297 - waist} 424 H{335 - waist} V277Z")
    path(facing, shadow, cloth.shade)
    path(facing, shadow, "url(#ink-lines)", opacity=".48")
    for row, y in enumerate((316, 341, 365, 391)):
        half_width = min(body.chest, body.waist) - 11
        for column in range(-2, 3):
            x = 160 + column * half_width / 2
            rivet_y = y + (2 if row == 3 else -2) * abs(column)
            node(facing, "circle", cx=x, cy=rivet_y, r=3.7, fill="#765a3d", stroke="#382a24", stroke_width=1.1)
            node(facing, "circle", cx=x - .75, cy=rivet_y - .8, r=1.61, fill="#debc7b")
    _line(field, shell, "#3d2b24", 5)
    _line(field, shell, cloth.deep, 2.7)
    _line(field, shell, cloth.light, .9, stroke_dasharray="1 3")


def _polovtsian_rows(tiles, body):
    width, rise = 13, 21
    left, right = 151 - body.chest, 169 + body.chest
    definitions = node(tiles, "defs")
    colors = ("#a5876c", "#9a795f", "#b29578", "#927463")
    plate_ids = tuple(f"steppe-polovtsian-plate-{index}" for index in range(len(colors)))
    for identifier, color in zip(plate_ids, colors):
        _lamella(definitions, identifier, width + 1, color)
    for row, y in enumerate(range(299, 404, rise)):
        line = node(tiles, "g", data_part="polovtsian-plate-row")
        row_start = left - row % 2 * (width // 2)
        for column, x in enumerate(range(row_start, right, width)):
            height = number(y + 5 - 4 * ((x + width / 2 - 160) / body.chest) ** 2)
            use(line, plate_ids[(column + row * 3) % len(colors)], transform=f"translate({x} {height})")
        binding = f"M{left} {y + 2}Q160 {y + 11} {right} {y + 2}"
        _line(line, binding, "#432e29", 7.2)
        _line(line, binding, "#864743" if row % 2 else "#526a59", 4.6)
        _line(line, binding, "#bb8964" if row % 2 else "#8a9b78", 1.05, stroke_dasharray="1.4 2.6")


def draw_polovtsian_lamellar(art):
    from wardrobe_northwest_accessories import draw_belt

    body, cloth = art.body, art.cloth
    front = art.front
    outfit = art.look["outfit"]
    waist = 160 - body.waist
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    neck = art.neck
    bottom = art.hem_y if art.hem_y is not None else 445
    hem_half = art.hem_half if art.hem_half is not None else body.hem
    edge = 160 - hem_half
    knee = round(419 + (bottom - 419) * .58)
    wrap_top = 160 + round(body.waist * .31)
    wrap_knee = 160 + round(body.waist * .18)
    wrap_hem = 160 - round(body.waist * .43)
    lining = node(front, "g", data_part="polovtsian-kaftan", data_material_slot="outfit")
    path(lining, f"M0 406H320V{bottom + 16}H0Z", cloth.base)
    path(lining, f"M{waist - 6} 402Q{waist + 16} {knee} {edge + 12} {bottom + 9} "
         f"H{edge + 37}Q{edge + 40} {knee} {waist + 26} 403Z",
         cloth.light, opacity=".6", data_material_surface="light")
    overlap = f"M{wrap_top} 408Q{wrap_knee} {knee} {wrap_hem} {bottom + 10}"
    path(lining, f"{overlap} "
         f"H{325 - edge}L{327 - waist} 406Z", cloth.shade, data_material_surface="shade")
    path(lining, f"M{wrap_top + 3} 413Q{wrap_knee + 4} {knee} {wrap_hem + 5} {bottom + 11} "
         f"H{wrap_hem + 25}Q{wrap_knee + 18} {knee} {wrap_top + 17} 408Z", "url(#ink-lines)", opacity=".37")
    path(lining, f"M{wrap_top - 9} 414Q{wrap_knee - 12} {knee} {wrap_hem - 16} {bottom + 10} "
         f"L{wrap_hem - 4} {bottom + 11}Q{wrap_knee - 4} {knee} {wrap_top - 3} 416Z",
         cloth.light, opacity=".24", data_material_surface="light")
    _line(lining, overlap, cloth.deep, 4)
    _line(lining, overlap, "#ad765d", 1.75, opacity=".86")
    _line(lining, f"M{waist + 18} 428Q{edge + 40} {knee} {edge + 26} {bottom - 8} "
          f"M{300 - waist} 449Q{279 - edge} {knee} {289 - edge} {bottom - 7}", cloth.deep, 1.35, opacity=".52")
    if art.hem_y is not None:
        hemline = f"M{edge} {bottom - 5}Q160 {bottom + 14} {320 - edge} {bottom - 5}"
        _line(lining, hemline, cloth.deep, 6.2)
        _line(lining, hemline, "#a16b55", 3.4)
        _line(lining, hemline, "#c5a17a", .9, stroke_dasharray="2.6 3")
    collar = f"M{160 + neck + 4} 277Q174 314 149 328"
    _line(lining, collar, cloth.deep, 8)
    _line(lining, collar, "#a16b55", 4.2)
    _line(lining, collar, "#d4ac7b", 1.05)

    for side, sleeve in enumerate(art.sleeves):
        forearm = (
            f"{_sleeve_lip(body, outfit, 409)}V449H{153 - body.sleeve}V409Z"
        )
        path(sleeve, forearm, "#4a6363" if side else "#5b7672", data_material_surface="fixed")
        for y in (415, 428, 440):
            _line(sleeve, _sleeve_lip(body, outfit, y), "#283d3d", 3.5)
            _line(sleeve, _sleeve_lip(body, outfit, y - 1), "#9da186", 1.25, opacity=".7")
        upper_cuff = _sleeve_lip(body, outfit, 406)
        _line(sleeve, upper_cuff, cloth.deep, 5)
        _line(sleeve, upper_cuff, "#ad765d", 2.3)

    suspender = (f"M{shoulder + 14} {body.shoulder_y - 3} Q{chest + 17} 299 {chest + 19} 319 "
                 f"M{306 - shoulder} {body.shoulder_y - 3} Q{303 - chest} 299 {301 - chest} 319")
    mount = node(front, "g", data_part="polovtsian-shoulder-straps", data_material_surface="fixed")
    _line(mount, suspender, "#3c2925", 12.5)
    _line(mount, suspender, "#8d5847", 7.7)
    _line(mount, suspender, "#b58165", 1.2, stroke_dasharray="1.8 2.6")
    chest_piece = (
        f"M{chest + 10} 305Q116 298 131 304Q160 315 189 304Q204 298 {310 - chest} 305 "
        f"C{315 - chest} 337 {319 - waist} 366 {320 - waist} 398 "
        f"Q160 407 {waist} 398C{waist + 1} 366 {chest + 5} 337 {chest + 10} 305Z"
    )
    armor, tiles = _clipped_field(front, "polovtsian-lamellar", "steppe-polovtsian-lamellar-shape",
                                  chest_piece, "#704039")
    armor.set("data-material-surface", "fixed")
    _polovtsian_rows(tiles, body)
    path(tiles, f"M{302 - chest} 305Q{295 - waist} 347 {296 - waist} 402H{329 - waist}V300Z",
         "#402e2d", opacity=".36")
    _line(armor, chest_piece, "#402a25", 5.9)
    _line(armor, chest_piece, "#95634d", 2.6)
    if "belt" not in art.look:
        draw_belt(front, body, "leather")


_MONGOL_LEATHER = ("#95694f", "#855a46", "#9b7056", "#8d614e", "#8a624c")


def _mongol_plate_rows(field, left, right, top, bottom, *, advance, lean=0):
    middle = (left + right) // 2
    for row, y in enumerate(range(top, bottom, advance)):
        band = node(field, "g", data_part="mongol-leather-row")
        upper = f"M{left} {y}Q{middle} {y + 7} {right} {y + lean}"
        contour = (f"{upper}v{advance + 2} "
                   f"Q{middle} {y + advance + 9} {left} {y + advance + 2}Z")
        path(band, contour, _MONGOL_LEATHER[row % len(_MONGOL_LEATHER)])
        _line(band, upper, "#4b342d", 2.2)
        _line(band, f"M{left} {y + 3}Q{middle} {y + 10} {right} {y + lean + 3}",
              "#b48763", 1.3, opacity=".74")
        for column, x in enumerate(range(left + 9 + row % 2 * 6, right, 12)):
            t = (x - left) / (right - left)
            fy = y + 4 + lean * t + 14 * t * (1 - t)
            _line(band, f"M{x} {number(fy)}q-.6 3.8 .1 {advance - 5}", "#563c32", .85, opacity=".77")
            _line(band, f"M{x + 2} {number(fy)}l2.6 -.2", "#c09a71", .9, opacity=".7")
            if (row + column) % 3 == 0:
                _line(band, f"M{x + 4} {number(fy + 5)}q1.7 -.7 3.1 .4",
                      "#624438", .85, opacity=".49")


def draw_mongol_leather_armour(art):
    from wardrobe_northwest_accessories import draw_belt

    body, cloth = art.body, art.cloth
    front = art.front
    outfit = art.look["outfit"]
    waist = 160 - body.waist
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    outer = 160 - body.sleeve
    crest = body.shoulder_y
    neck = art.neck + 4
    for side, sleeve in enumerate(art.sleeves):
        cuff = _sleeve_lip(body, outfit, 438)
        _line(sleeve, cuff, cloth.deep, 6.2)
        _line(sleeve, cuff, cloth.light, 1.8)
        sleeve_shape = _sleeve_cut(body, outfit, 419)
        leather, rows = _clipped_field(sleeve, "mongol-leather-sleeve", f"steppe-mongol-sleeve-{side}",
                                       sleeve_shape, _MONGOL_LEATHER[0])
        leather.set("data-material-surface", "fixed")
        _mongol_plate_rows(rows, outer - 9, shoulder + 44, crest - 13, 432, advance=13, lean=8)
        if side:
            path(rows, sleeve_shape, "#3f302d", opacity=".24")
        _line(leather, sleeve_shape, "#4c342b", 3.5)
        _line(leather, _sleeve_lip(body, outfit, 416), "#b48b6b", 1.45, opacity=".78")

    full_hem = art.hem_y is not None
    bottom = art.hem_y if full_hem else 445
    hem = bottom - 22 if full_hem else 445
    hem_half = art.hem_half if art.hem_half is not None else body.hem
    edge = 172 - hem_half
    bend = round(411 + (hem - 411) * .46)
    hemline = (f"Q{edge + 29} {hem + 11} 145 {hem + 6}Q155 {hem - 10} 160 {hem - 62} "
               f"Q166 {hem - 15} 177 {hem + 6}Q{291 - edge} {hem + 11} {320 - edge} {hem}"
               if full_hem else f"H{320 - edge}")
    skirt = (
        f"M{waist + 4} 408C{waist + 2} 428 {edge + 7} {bend} {edge} {hem} "
        f"{hemline}C{313 - edge} {bend} {318 - waist} 428 {316 - waist} 408 "
        f"Q160 418 {waist + 4} 408Z"
    )
    skirt_shell, skirt_rows = _clipped_field(front, "mongol-leather-skirt", "steppe-mongol-skirt",
                                              skirt, _MONGOL_LEATHER[1])
    skirt_shell.set("data-material-surface", "fixed")
    _mongol_plate_rows(skirt_rows, edge - 16, 336 - edge, 402, hem + 15, advance=17, lean=4)
    path(skirt_rows, f"M{296 - waist} 407Q{304 - edge} {bend} {293 - edge} {hem + 12}H{328 - edge}V401Z",
         "#43312d", opacity=".39")
    _line(skirt_shell, skirt, "#48332c", 5.6)
    _line(skirt_shell, skirt, "#a17a59", 1.7)
    if full_hem:
        cloth_hem = f"M{160 - hem_half} {bottom - 4}Q160 {bottom + 15} {160 + hem_half} {bottom - 4}"
        _line(front, cloth_hem, cloth.deep, 5)
        _line(front, cloth_hem, cloth.light, 1.25, opacity=".72")

    collar = f"Q160 327 {160 - neck} 279"
    breast = (
        f"M{160 - neck} 279C{146 - neck} 278 {shoulder + 16} {crest - 7} {shoulder + 3} {crest + 2} "
        f"Q{shoulder + 18} {crest + 18} {chest + 4} 346Q{chest + 3} 370 {waist + 2} 403 "
        f"Q160 411 {318 - waist} 403Q{317 - chest} 370 {316 - chest} 346 "
        f"Q{302 - shoulder} {crest + 18} {317 - shoulder} {crest + 2} "
        f"C{304 - shoulder} {crest - 7} {174 + neck} 278 {160 + neck} 279 {collar}Z"
    )
    armor, rows = _clipped_field(front, "mongol-leather-body", "steppe-mongol-breast", breast, _MONGOL_LEATHER[0])
    armor.set("data-material-surface", "fixed")
    _mongol_plate_rows(rows, chest - 9, 329 - chest, 274, 408, advance=16, lean=3)
    shadow = (
        f"M{309 - shoulder} 277Q{301 - chest} 342 {297 - waist} 406H{329 - waist}V277Z"
    )
    path(rows, shadow, "#43312d", opacity=".40")
    path(rows, shadow, "url(#ink-lines)", opacity=".27")
    _line(armor, breast, "#48332c", 5.3)
    _line(armor, breast, "#a17a59", 1.7)
    _line(armor, f"M{160 + neck} 279{collar}", "#705745", 5)
    _line(armor, f"M{160 + neck} 279{collar}", "#d0a579", 1.3, stroke_dasharray="1.3 2.6")
    if "belt" not in art.look:
        draw_belt(front, body, "leather")


DRAWERS = {
    "nw_mail_hauberk": draw_mail_hauberk,
    "nw_nov_lamellar": draw_nov_lamellar,
    "nw_mail_surcoat": draw_mail_surcoat,
    "nw_nov_scale": draw_nov_scale,
    "nw_nov_copper_mail": draw_nov_copper_mail,
    "nw_gomel_lamellar": draw_gomel_lamellar,
    "nw_magdeburg_plate_coat": draw_magdeburg_plate_coat,
    "rus_suzdal_silk_over_mail": draw_suzdal_silk_over_mail,
    "steppe_polovtsian_lamellar": draw_polovtsian_lamellar,
    "steppe_mongol_leather_armour": draw_mongol_leather_armour,
}
