from common import node, number, path, use


OPTIONS = {
    "nw_mail_hauberk": "Кольчуга поверх стёганки",
    "nw_nov_lamellar": "Новгородский пластинчатый доспех",
    "nw_mail_surcoat": "Кольчуга и льняное сюрко",
    "nw_nov_scale": "Новгородский чешуйчатый панцирь",
    "nw_nov_copper_mail": "Новгородская кольчуга с медной каймой",
    "nw_gomel_lamellar": "Ламеллярный панцирь из Гомия",
    "nw_magdeburg_plate_coat": "Магдебургский нагрудник поверх кольчуги",
}
FULL_HEMS = {
    "nw_mail_hauberk": 570,
    "nw_nov_lamellar": 555,
    "nw_mail_surcoat": 599,
    "nw_nov_scale": 548,
    "nw_nov_copper_mail": 579,
    "nw_gomel_lamellar": 564,
    "nw_magdeburg_plate_coat": 609,
}
_MAIL = "#666659"
_MAIL_LIGHT = "#adab95"
_MAIL_SHADE = "#333532"
_BINDING = "#694a3b"
_BINDING_LIGHT = "#b28964"
_IRON = ("#71756b", "#7c7e70", "#898775", "#6c7168", "#93917e")


def _line(parent, contour, color, width, **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def _rings(parent, contour, *, opacity=".92"):
    path(parent, contour, "url(#mail-rings)", opacity=opacity)


def _divide_curve(points, t):
    level, left, right = list(points), [points[0]], [points[-1]]
    while len(level) > 1:
        level = [(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                 for a, b in zip(level, level[1:])]
        left.append(level[0])
        right.append(level[-1])
    return tuple(left), tuple(reversed(right))


def _divide_at_height(curve, y):
    low, high = 0., 1.
    direction = 1 if curve[-1][1] > curve[0][1] else -1
    for _ in range(24):
        t = (low + high) / 2
        left, right = _divide_curve(curve, t)
        if (left[-1][1] - y) * direction < 0:
            low = t
        else:
            high = t
    return left, right


def _sleeve_cut(body, outfit, bottom):
    """Тот же крой рукава, укороченный на точной поперечной опоре."""
    from wardrobe import _sleeve_curves, _curve_command
    upper, lower, inner = _sleeve_curves(body, outfit)
    contour = f"M{number(upper[0][0])} {number(upper[0][1])}" + _curve_command(upper)
    for curve in lower:
        if curve[-1][1] <= bottom:
            contour += _curve_command(curve)
        else:
            contour += _curve_command(_divide_at_height(curve, bottom)[0])
            break
    tail = inner if bottom >= 445 else _divide_at_height(inner, bottom)[1]
    return contour + f"L{number(tail[0][0])} {number(tail[0][1])}" + _curve_command(tail) + "Z"


def _sleeve_lip(body, outfit, y):
    from wardrobe import sleeve_section
    left, right = sleeve_section(body, outfit, y)
    return f"M{number(left)} {number(y)}Q{number((left + right) / 2)} {number(y + 4)} {number(right)} {number(y)}"


def _mail_sleeve(sleeve, body, cuff, *, right, outfit=None):
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    metal = _sleeve_cut(body, outfit, cuff)
    identifier = f"nw-mail-sleeve-{int(right)}-{cuff}"
    path(sleeve, metal, "#55594f" if right else _MAIL, data_part="mail-sleeve-shell")
    path(node(sleeve, "clipPath", id=identifier), metal)
    sleeve = node(sleeve, "g", clip_path=f"url(#{identifier})")
    light = (
        f"M{shoulder + 9} {crest - 1} Q{outer + 8} 319 {outer + 13} 350 "
        f"Q{outer + 11} 375 {outer + 16} {cuff + 2} H{outer + 32} "
        f"Q{outer + 18} 379 {outer + 27} 348 Q{outer + 26} 316 {shoulder + 16} {crest + 4}Z"
    )
    fold = (
        f"M{shoulder + 22} {crest + 10} Q{outer + 25} 335 {outer + 31} 371 "
        f"Q{outer + 32} 398 {outer + 42} {cuff + 4} H{shoulder + 38}V{crest + 5}Z"
    )
    path(sleeve, light, _MAIL_LIGHT, opacity=".21" if right else ".49")
    path(sleeve, fold, _MAIL_SHADE, opacity=".43")
    _rings(sleeve, metal)
    path(sleeve, fold, "url(#ink-lines)", opacity=".38")
    _line(sleeve, f"M{outer + 13} 371 q8 -8 16 -10 m-17 18 q8 -7 16 -10",
          "#b5ae96", 1, opacity=".49")
    lip = _sleeve_lip(body, outfit, cuff - 3)
    _line(sleeve, lip, "#33312b", 2.5)
    _line(sleeve, lip, "#969381", 1.1, opacity=".8")


def _mail_torso(front, body, neck, *, hem, hem_half=None, slit=False):
    from wardrobe import _front_shape
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    waist = 160 - body.waist
    edge = 160 - body.hem
    lip = f"M{160 - neck} 273 Q160 307 {160 + neck} 273"
    edge_half = body.hem + 4 if hem_half is None else hem_half
    field = _front_shape(body, neck, hem_y=hem, hem_half=edge_half)
    slit_edge = None
    if slit:
        # The two skirts descend from the same waist and reveal the under-tunic.
        slit_edge = (f"Q{(160 - edge_half + 148) / 2} {hem + 10} 148 {hem + 5} "
                     f"Q155 {hem - 23} 160 {hem - 66} "
                     f"Q165 {hem - 23} 172 {hem + 5} "
                     f"Q{(160 + edge_half + 172) / 2} {hem + 10} {160 + edge_half} {hem}")
        field = field.replace(f"Q160 {hem + 19} {160 + edge_half} {hem}", slit_edge)
    surface = node(front, "g", data_part="mail-torso")
    path(surface, field, _MAIL, data_part="mail-shell")
    identifier = f"nw-mail-torso-{len(list(front))}"
    path(node(surface, "clipPath", id=identifier), field)
    front = node(surface, "g", clip_path=f"url(#{identifier})")
    shadow = (
        f"M194 287 Q{320 - shoulder - 13} 296 {327 - chest} 340 "
        f"Q{315 - waist} 383 {332 - waist} 433 L{332 - edge} {hem} "
        f"H{307 - edge} Q{320 - waist - 26} 403 {320 - chest - 17} 364 "
        "Q216 315 194 287Z"
    )
    path(front, f"M{shoulder + 11} 287 Q104 268 137 287 Q109 319 {chest + 23} 351 "
         f"Q{waist + 14} 382 {edge + 24} {hem} H{edge + 5} "
         f"Q{waist + 13} 369 {chest + 5} 341 Q{chest + 7} 312 {shoulder + 11} 287Z",
         _MAIL_LIGHT, opacity=".38")
    path(front, shadow, _MAIL_SHADE, opacity=".61")
    _rings(front, field)
    path(front, shadow, "url(#ink-lines)", opacity=".46")
    _line(front, f"M{chest + 12} 327 q3 -14 12 -23 M{waist + 18} 373 q-3 15 0 26 "
          f"M{315 - waist} 370 q-1 -20 -8 -32", "#c2b8a1", 1.2, opacity=".42")
    _line(front, lip, "#32312d", 7)
    _line(front, lip, "#9c9783", 3)
    _line(front, lip, "#c1b79c", 1.1, stroke_dasharray="1.4 3")
    if slit_edge is not None:
        _line(surface, f"M{160 - edge_half} {hem} {slit_edge}", "#34362f", 2.2)


def draw_mail_hauberk(art):
    body, cloth = art.body, art.cloth
    for side, sleeve in enumerate(art.sleeves):
        outer = 160 - body.sleeve
        for x in range(outer + 5, 160 - body.shoulder + 35, 9):
            _line(sleeve, f"M{x} 415 q-3 13 1 31", cloth.deep, 1.25, opacity=".61")
            _line(sleeve, f"M{x + 2} 418 q-3 12 1 27", cloth.light, .85, opacity=".64")
        _mail_sleeve(sleeve, body, 422, right=bool(side), outfit=art.look["outfit"])
    _mail_torso(art.front, body, art.neck, hem=435 if art.hem_y is None else art.hem_y,
                hem_half=art.hem_half, slit=art.hem_y is not None)


def _lamella(parent, identifier, width, color):
    tile = node(parent, "g", id=identifier)
    contour = f"M1 2 Q{width / 2} .25 {width - 1} 1.5 L{width} 18 q-1 2.8 -3.2 3 H3 Q.3 21 0 18Z"
    path(tile, contour, color, stroke="#2d2926", stroke_width=1.35, stroke_linejoin="round")
    path(tile, f"M1.6 3 Q{width / 2} 1.2 {width - 1.3} 2.5 "
         f"L{width - 1.4} 4.5 Q4 4 2.1 10Z", "#b4ad94", opacity=".62")
    path(tile, f"M{width - 2} 5 L{width - .7} 17 q-.7 3 -3.5 3 H2.6 "
         f"Q{width - 3.5} 17 {width - 2} 5Z", "#494c45", opacity=".66")
    _line(tile, f"M2.9 7 l2.5 -1 M{width - 4} 10 l1.2 -1.2", "#c4b99d", .68, opacity=".62")
    for hole in (3.6, width - 3.7):
        node(tile, "circle", cx=hole, cy=14.7, r=1.13, fill="#332922")
    _line(tile, f"M3.6 14.6 q{width / 2 - 3.4} -3.7 {width - 7.3} 0", "#534033", 1.65)
    _line(tile, f"M4.6 13.7 q{width / 2 - 4.8} -1.5 {width - 9.3} -.1", "#ac8762", .68)


def draw_nov_lamellar(art):
    front, body, cloth = art.front, art.body, art.cloth
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest + 9
    waist = 160 - body.waist + 6
    hem = 160 - body.hem + 9
    neckline = art.neck + 2
    for sleeve in art.sleeves:
        _line(sleeve, f"M{shoulder - 9} {body.shoulder_y + 7} "
              f"Q{shoulder + 13} 313 {shoulder + 9} 341", cloth.deep, 2.1, opacity=".83")
    if art.hem_y is not None:
        bottom = art.hem_y + 11
        fold = (f"M{waist - 14} 416 Q{waist + 4} 474 {hem + 24} {bottom} "
                f"H{hem - 18}V427Z")
        path(front, fold, cloth.shade)
        path(front, fold, cloth.deep, opacity=".42", transform="translate(320 0) scale(-1 1)")
        path(front, f"M135 434 Q129 494 118 {bottom - 12} "
             f"M179 436 Q183 485 193 {bottom - 15} M151 449 Q151 495 147 {bottom - 12}",
             class_="etch")
    shell = (
        f"M{160 - neckline} 273 C{146 - neckline} 273 {shoulder + 13} {body.shoulder_y - 10} {shoulder} {body.shoulder_y} "
        f"Q{shoulder + 17} 308 {chest} 337 Q{chest - 2} 366 {waist} 392 "
        f"Q{waist - 4} 419 {hem} 433 Q160 453 {320 - hem} 433 "
        f"Q{324 - waist} 419 {320 - waist} 392 Q{322 - chest} 366 {320 - chest} 337 "
        f"Q{303 - shoulder} 308 {320 - shoulder} {body.shoulder_y} "
        f"C{307 - shoulder} {body.shoulder_y - 10} {174 + neckline} 273 {160 + neckline} 273 "
        f"Q160 317 {160 - neckline} 273Z"
    )
    path(front, shell, "#53493c", class_="edge")
    mask = node(front, "clipPath", id="nw-lamellar-shell")
    path(mask, shell)
    layer = node(front, "g", clip_path="url(#nw-lamellar-shell)")
    count = 13 if body.chest >= 79 else 11
    width = (2 * (160 - min(chest, waist, hem) + 16)) / count
    definitions = node(layer, "defs")
    plate_ids = tuple(f"nw-lamella-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        _lamella(definitions, identifier, width + 1, color)
    for row, y in enumerate(range(277, 439, 16)):
        origin = 160 - count * width / 2 - (width / 2 if row % 2 else 0)
        for column in range(count + 1):
            x = origin + column * width
            cross = (x + width / 2 - 160) / 100
            height = y + 5 - 7 * cross ** 2
            angle = round(-7 * cross)
            identifier = plate_ids[(column * 2 + row * 3) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({number(x)} {number(height)}) rotate({angle})")
    shade = (
        f"M{320 - shoulder} 283 Q{310 - chest} 337 {307 - waist} 395 "
        f"Q{317 - hem} 426 {328 - hem} 443 H{340 - hem} V279Z"
    )
    path(layer, shade, "#3a3029", opacity=".51")
    path(layer, shade, "url(#ink-lines)", opacity=".45")
    _line(front, shell, "#342721", 6)
    _line(front, shell, _BINDING, 3.65)
    _line(front, shell, _BINDING_LIGHT, .9, stroke_dasharray="1 4", opacity=".91")


def draw_mail_surcoat(art):
    body, cloth = art.body, art.cloth
    front, outer = art.front, art.outer
    for side, sleeve in enumerate(art.sleeves):
        _mail_sleeve(sleeve, body, 445, right=bool(side), outfit=art.look["outfit"])
    _mail_torso(front, body, art.neck, hem=445 if art.hem_y is None else art.hem_y,
                hem_half=art.hem_half, slit=art.hem_y is not None)
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest + 8
    waist = 160 - body.waist + 3
    hem = 160 - body.hem + 3
    collar = art.neck + 10
    if art.hem_y is None:
        tail = (f"Q{waist - 1} 414 {hem} 438 Q160 449 {320 - hem} 438 "
                f"Q{321 - waist} 414 {320 - waist} 396 ")
        shadow_tail = (f"Q{318 - waist} 420 {316 - hem} 437 "
                       f"L{295 - hem} 440 Q{304 - waist} 422 {296 - waist} 386 ")
    else:
        edge = hem - 8
        bottom = art.hem_y + 2
        tail = (f"C{waist - 5} 418 {edge + 7} 477 {edge} {bottom} "
                f"Q160 {bottom + 19} {320 - edge} {bottom} "
                f"C{313 - edge} 477 {325 - waist} 418 {320 - waist} 396 ")
        shadow_tail = (f"C{321 - waist} 434 {318 - edge} 485 {314 - edge} {bottom - 5} "
                       f"Q{305 - edge} {bottom - 3} {294 - edge} {bottom - 1} "
                       f"Q{299 - waist} 503 {296 - waist} 386 ")
    cloth_shape = (
        f"M{160 - collar} 273 C{146 - collar} 273 {shoulder + 13} {body.shoulder_y - 10} {shoulder} {body.shoulder_y} "
        f"Q{shoulder + 18} 310 {chest} 341 Q{chest - 1} 369 {waist} 396 "
        f"{tail}Q{321 - chest} 369 {320 - chest} 341 "
        f"Q{302 - shoulder} 310 {320 - shoulder} {body.shoulder_y} "
        f"C{307 - shoulder} {body.shoulder_y - 10} {174 + collar} 273 {160 + collar} 273 "
        f"Q180 304 160 311 Q140 304 {160 - collar} 273Z"
    )
    path(outer, cloth_shape, cloth.base, class_="edge", data_part="surcoat-shell")
    path(outer, f"M{shoulder + 13} {body.shoulder_y + 1} Q113 291 120 286 Q128 296 143 307 "
         f"Q128 322 {chest + 17} 353 Q{chest + 23} 321 {shoulder + 13} {body.shoulder_y + 1}Z", cloth.light)
    shadow = (
        f"M{316 - shoulder} {body.shoulder_y + 1} Q{303 - shoulder} 315 {317 - chest} 343 "
        f"Q{317 - chest} 367 {317 - waist} 397 {shadow_tail}"
        f"Q{297 - chest} 352 184 319 Q197 310 210 286 Q{304 - shoulder} 285 "
        f"{316 - shoulder} {body.shoulder_y + 1}Z"
    )
    path(outer, shadow, cloth.shade)
    path(outer, shadow, "url(#ink-lines)", opacity=".45")
    path(outer, f"M{chest + 10} 359 Q{waist + 17} 373 {waist + 10} 396 "
         f"Q{waist + 8} 378 {chest + 10} 359Z M133 415 q-8 11 -10 26 l-9 1 q6-19 19-27Z", cloth.light)
    path(outer, f"M{chest + 18} 341 q12 -21 19 -24 m-14 53 q8 8 7 22 "
         f"M{301 - chest} 341 q-6 -11 -18 -23 m9 71 q4 -14 -2 -26 m-13 52 q4 8 6 21", class_="seam")
    if art.hem_y is not None:
        path(outer, f"M126 413Q112 495 109 {art.hem_y - 12} "
             f"M164 430Q151 498 152 {art.hem_y - 2} "
             f"M183 451Q194 502 202 {art.hem_y - 10}", class_="etch")
    _line(outer, cloth_shape, cloth.deep, 3.2)
    _line(outer, cloth_shape, cloth.light, 1.1, opacity=".78")


def _cloth_cuff(sleeve, body, cloth, *, right):
    contour = _sleeve_lip(body, "nw_nov_scale", 434)
    _line(sleeve, contour, cloth.deep, 8)
    _line(sleeve, contour, cloth.shade if right else cloth.light, 3.1)
    _line(sleeve, contour, cloth.deep, .95, stroke_dasharray="1 3")


def _armor_upper(art, *, shoulder_inset, neck_depth):
    body = art.body
    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    chest = 163 - body.chest
    waist = 162 - body.waist
    neck = art.neck + 2
    return (
        f"M{waist} 401 Q{chest} 365 {chest} 346 Q{shoulder + shoulder_inset + 9} 312 {shoulder} {crest} "
        f"C{shoulder + 13} {crest - 10} {146 - neck} 273 {160 - neck} 273 "
        f"Q160 {neck_depth - 12} {160 + neck} 273 "
        f"C{174 + neck} 273 {307 - shoulder} {crest - 10} {320 - shoulder} {crest} "
        f"Q{311 - shoulder - shoulder_inset} 312 {320 - chest} 346 Q{320 - chest} 365 {320 - waist} 401 "
    )


def _clipped_field(parent, part, identifier, contour, fill):
    layer = node(parent, "g", data_part=part)
    path(layer, contour, fill)
    path(node(layer, "clipPath", id=identifier), contour)
    return layer, node(layer, "g", clip_path=f"url(#{identifier})")


def _scale_tiles(layer, left, right, top, bottom, *, prefix, shade=False):
    width, advance = 18, 13
    definitions = node(layer, "defs")
    plate_ids = tuple(f"{prefix}-scale-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        plate = node(definitions, "g", id=identifier)
        path(plate, "M.8 1 Q9 -.5 17.2 1 L18 9 Q18 17 9 22 Q0 18 0 9Z",
             color, stroke="#2b2d29", stroke_width=1.3, stroke_linejoin="round")
        path(plate, "M2 3 Q7 1 15 2 Q6 4 4 12 L2 14 Q1 8 2 3Z", "#c8c3ac", opacity=".73")
        path(plate, "M16 3 Q19 14 9 20 Q5 18 3 16 Q13 17 16 3Z", "#414940", opacity=".76")
        node(plate, "circle", cx=9, cy=6, r=1.15, fill="#3d3b33")
    rows = range(top, bottom + 1, advance)
    for row, y in reversed(tuple(enumerate(rows))):
        x = left - (row % 2) * 9
        for column, start in enumerate(range(x, right + 1, width)):
            bend = (start + 9 - 160) / 100
            height = number(y - 4 * bend ** 2)
            identifier = plate_ids[(2 * column + 3 * row + shade) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({start} {height})")
    if shade:
        path(layer, f"M{left} {top - 18} H{right + width} V{bottom + 24} H{left}Z",
             "#282d29", opacity=".25")


def draw_nov_scale(art):
    body, cloth = art.body, art.cloth
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    waist = 162 - body.waist
    for side, sleeve in enumerate(art.sleeves):
        _cloth_cuff(sleeve, body, cloth, right=bool(side))
        lip = _sleeve_lip(body, art.look["outfit"], 347)
        shell = _sleeve_cut(body, art.look["outfit"], 350)
        identifier = f"nw-scale-sleeve-{side}"
        sleeve_field, tiles = _clipped_field(sleeve, "scale-sleeve", identifier, shell, "#626354")
        _scale_tiles(tiles, outer - 8, shoulder + 30, 282, 355, prefix=identifier, shade=bool(side))
        _line(sleeve_field, lip, "#302923", 6)
        _line(sleeve_field, lip, _BINDING_LIGHT, 2.5)

    full_hem = art.hem_y is not None
    bottom = art.hem_y - 5 if full_hem else 451
    edge = 163 - body.hem
    upper = _armor_upper(art, shoulder_inset=5, neck_depth=342)
    half_step = (160 - edge) / 8
    hemline = ""
    edge_scales = []
    previous = bottom
    for scallop in range(16):
        end = 320 - edge - (scallop + 1) * half_step
        y = bottom + 8 * (1 - ((end - 160) / (160 - edge)) ** 2)
        start = end + half_step
        center = end + half_step / 2
        arc_height = (y + previous) / 2 + 5
        arc = f"Q{number(center)} {number(arc_height)} {number(end)} {number(y)}"
        hemline += f" {arc}"
        edge_scales.append((f"M{number(start)} {number(previous)} {arc} V{number(y - 11)} "
                            f"Q{number(center)} {number(arc_height - 14)} "
                            f"{number(start)} {number(previous - 11)}Z", center, arc_height))
        previous = y
    right_edge = f"C{320 - waist} 427 {318 - edge} {bottom - 19} {320 - edge} {bottom}"
    left_edge = f"C{edge + 2} {bottom - 19} {waist} 427 {waist} 401"
    contour = f"{upper}{right_edge}{hemline} {left_edge}Z"
    field, tiles = _clipped_field(art.front, "scale-armor", "nw-scale-front", contour, "#636659")
    _scale_tiles(tiles, edge - 21, 337 - edge, 264, bottom + 12, prefix="nw-scale-front")
    if full_hem:
        for index, (plate, center, height) in enumerate(edge_scales):
            color = _IRON[index % len(_IRON)]
            path(tiles, plate, color, stroke="#3a342b", stroke_width=1.3)
            node(tiles, "circle", cx=center, cy=height - 9, r=1, fill="#342c26")
    shade = (f"M{295 - shoulder} 286 Q{305 - waist} 334 {304 - waist} 398 "
             f"Q{304 - edge} 470 {299 - edge} {bottom + 15} H{340 - edge} V274Z")
    path(tiles, shade, "#30352d", opacity=".49")
    path(tiles, shade, "url(#ink-lines)", opacity=".39")
    trim = contour if full_hem else f"{upper}{right_edge} M{edge} {bottom} {left_edge}"
    _line(field, trim, "#322921", 5.8)
    _line(field, trim, _BINDING, 3.5)
    _line(field, trim, _BINDING_LIGHT, 1, stroke_dasharray="1 3")


_COPPER = "#aa6542"
_COPPER_LIGHT = "#d9a873"


def _copper_edge(parent, contour):
    _line(parent, contour, "#392a23", 7.4)
    _line(parent, contour, _COPPER, 4.8)
    _line(parent, contour, "#683c2b", 4, stroke_dasharray=".6 2.2")
    _line(parent, contour, _COPPER_LIGHT, 1.3, stroke_dasharray="1.5 1.3")


def draw_nov_copper_mail(art):
    body, cloth = art.body, art.cloth
    waist = 162 - body.waist
    for side, sleeve in enumerate(art.sleeves):
        _cloth_cuff(sleeve, body, cloth, right=bool(side))
        lip = _sleeve_lip(body, art.look["outfit"], 367)
        shell = _sleeve_cut(body, art.look["outfit"], 370)
        metal, rings = _clipped_field(
            sleeve, "copper-mail-sleeve", f"nw-copper-sleeve-{side}", shell, _MAIL)
        _mail_sleeve(rings, body, 370, right=bool(side), outfit=art.look["outfit"])
        _copper_edge(metal, lip)

    full_hem = art.hem_y is not None
    bottom = art.hem_y - 4 if full_hem else 456
    edge = 161 - body.hem
    upper = _armor_upper(art, shoulder_inset=2, neck_depth=329)
    outer_right = f"C{321 - waist} 431 {318 - edge} {bottom - 23} {320 - edge} {bottom}"
    outer_left = f"C{edge + 2} {bottom - 23} {waist - 1} 431 {waist} 401"
    slit = bottom - 58 if full_hem else bottom + 10
    hemline = (
        f"Q{235 - edge / 2} {bottom + 11} 173 {bottom + 4} Q162 {bottom - 12} 160 {slit} "
        f"Q156 {bottom - 11} 147 {bottom + 4} Q{85 + edge / 2} {bottom + 11} {edge} {bottom}"
        if full_hem else f"H{edge}"
    )
    contour = f"{upper}{outer_right} {hemline} {outer_left}Z"
    field, metal = _clipped_field(art.front, "copper-mail", "nw-copper-front", contour, "#555a53")
    _mail_torso(metal, body, art.neck, hem=bottom + 14)
    _copper_edge(field, f"M{160 - art.neck - 2} 276 Q160 330 {160 + art.neck + 2} 276")
    if full_hem:
        _copper_edge(field, f"M{320 - edge} {bottom} {hemline}")


def _gomel_plates(layer, left, right, first_row, bottom, *, prefix, column_step, row_step, lean=0):
    definitions = node(layer, "defs")
    plate_ids = tuple(f"{prefix}-plate-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        _lamella(definitions, identifier, column_step + 1, color)
    for row, y in enumerate(range(first_row, bottom + 1, row_step)):
        offset = left - (row % 2) * (column_step // 2)
        for column, x in enumerate(range(offset, right + 1, column_step)):
            rise = number(y - abs(x - 160) / 15)
            identifier = plate_ids[(column + 3 * row) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({x} {rise}) rotate({lean}) scale(1 1.27)")
        _line(layer, f"M{left - 12} {y + 4} L{right + 13} {y + 3}", "#493a31", 2.9)
        _line(layer, f"M{left - 12} {y + 3} L{right + 13} {y + 2}", "#b59872", .8,
              stroke_dasharray="2.2 3")


def _gomel_edge(parent, contour):
    _line(parent, contour, "#322821", 7)
    _line(parent, contour, "#805a42", 4)
    _line(parent, contour, "#c1a07a", .95, stroke_dasharray="1.4 3.6")


def draw_gomel_lamellar(art):
    body, cloth = art.body, art.cloth
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    waist = 162 - body.waist
    for side, sleeve in enumerate(art.sleeves):
        _cloth_cuff(sleeve, body, cloth, right=bool(side))
        blade = _sleeve_cut(body, art.look["outfit"], 378)
        identifier = f"nw-gomel-shoulder-{side}"
        field, plates = _clipped_field(sleeve, "gomel-shoulder", identifier, blade, "#635c4d")
        _gomel_plates(plates, outer - 9, shoulder + 34, 274, 388,
                      prefix=identifier, column_step=14, row_step=21, lean=9)
        strap = _sleeve_lip(body, art.look["outfit"], 355)
        _line(plates, strap, "#3d2e27", 7)
        _line(plates, strap, "#997252", 3.2)
        if side:
            path(plates, blade, "#2f2823", opacity=".25")
        _gomel_edge(field, blade)

    front = art.front
    edge = 164 - body.hem
    full_hem = art.hem_y is not None
    bottom = art.hem_y - 4 if full_hem else 459
    for right in (False, True):
        side = "right" if right else "left"
        group = node(front, "g", transform="translate(320 0) scale(-1 1)" if right else None)
        outer_edge = (f"M{waist - 1} 399 Q{waist - 2} 439 {edge} {bottom - 10} "
                      f"Q{edge + 4} {bottom - 1} {edge + 10} {bottom - 1}")
        lower = f"Q{(edge + 160) // 2} {bottom + 11} 149 {bottom + 2} Q154 {bottom} 155 {bottom - 10}"
        inner = "Q154 451 158 400"
        blade = f"{outer_edge} {lower} {inner}Z"
        identifier = f"nw-gomel-skirt-{side}"
        field, plates = _clipped_field(group, f"gomel-skirt-{side}", identifier, blade, "#625a4d")
        _gomel_plates(plates, edge - 10, 169, 392, bottom, prefix=identifier, column_step=13, row_step=20, lean=3)
        path(plates, f"M150 401 Q139 467 138 {bottom + 14} H169 V398Z",
             "#3e332b", opacity=".48")
        if right:
            path(plates, blade, "#37312a", opacity=".2")
        _gomel_edge(field, blade if full_hem else f"{outer_edge} M155 {bottom - 10} {inner}")

    upper = _armor_upper(art, shoulder_inset=11, neck_depth=333)
    shell = f"{upper}L{319 - waist} 410 Q160 424 {waist + 1} 410Z"
    field, plates = _clipped_field(front, "gomel-cuirass", "nw-gomel-chest", shell, "#61584c")
    _gomel_plates(plates, min(shoulder, waist) - 12, 331 - min(shoulder, waist), 273, 413,
                  prefix="nw-gomel-chest", column_step=11, row_step=18)
    shade = (f"M{310 - shoulder} 280 Q{313 - body.chest} 308 218 333 "
             f"Q{308 - waist} 374 {301 - waist} 423 H{338 - waist} V276Z")
    path(plates, shade, "#342c27", opacity=".42")
    path(plates, shade, "url(#ink-lines)", opacity=".37")
    _gomel_edge(field, shell)
    for right in (False, True):
        side = node(field, "g", transform="translate(320 0) scale(-1 1)" if right else None)
        buckle = (f"M{waist + 3} 375 Q{waist + 16} 372 {waist + 27} 377 "
                  f"M{waist + 5} 391 Q{waist + 18} 388 {waist + 29} 391")
        _line(side, buckle, "#3c3028", 5.5)
        node(side, "rect", x=waist + 18, y=373, width=7, height=7, rx=1.2, fill="none",
             stroke="#b09a75", stroke_width=1.4)
        node(side, "rect", x=waist + 20, y=387, width=7, height=7, rx=1.2, fill="none",
             stroke="#b09a75", stroke_width=1.4)


def draw_magdeburg_plate_coat(art):
    body, cloth = art.body, art.cloth
    for side, sleeve in enumerate(art.sleeves):
        _mail_sleeve(sleeve, body, 443, right=bool(side), outfit=art.look["outfit"])
    front = art.front
    full_hem = art.hem_y is not None
    bottom = art.hem_y if full_hem else 458
    _mail_torso(front, body, art.neck, hem=bottom, hem_half=art.hem_half, slit=full_hem)

    waist = 162 - body.waist
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    edge = 177 - body.hem
    hem = bottom - 22 if full_hem else bottom
    bend = 461 if full_hem else 439
    apron_left = f"M{waist + 6} 405 Q{waist + 11} {bend} {edge + 2} {hem}"
    apron_hem = f"Q160 {hem + 25} {318 - edge} {hem}" if full_hem else f"H{318 - edge}"
    apron_right = f"Q{309 - waist} {bend} {314 - waist} 405 Q160 415 {waist + 6} 405"
    contour = f"{apron_left} {apron_hem} {apron_right}Z"
    apron, apron_cloth = _clipped_field(front, "magdeburg-apron", "nw-magdeburg-apron", contour, cloth.base)
    path(apron_cloth, f"M{301 - waist} 410 Q{283 - waist} 496 {296 - edge} {hem + 12} "
         f"H{331 - edge} V405Z", cloth.shade)
    path(apron_cloth, f"M{waist + 23} 404 Q{waist + 38} 470 {edge + 15} {hem + 4} "
         f"Q{edge + 29} {hem + 12} {edge + 41} {hem + 7} Q{waist + 36} 471 {waist + 41} 408Z",
         cloth.light)
    path(apron_cloth, f"M144 425 Q140 499 131 {hem} M175 431 Q175 514 188 {hem + 4} "
         f"M{292 - waist} 441 Q{283 - edge} 522 {296 - edge} {hem + 2}", class_="etch")
    apron_trim = contour if full_hem else f"{apron_left} M{318 - edge} {hem} {apron_right}"
    _line(apron, apron_trim, "#352b27", 4.6)
    _line(apron, apron_trim, cloth.deep, 2.1)

    upper = _armor_upper(art, shoulder_inset=9, neck_depth=326)
    shell = f"{upper}L{318 - waist} 412 Q160 428 {waist + 2} 412Z"
    field, facing = _clipped_field(front, "magdeburg-breastpiece", "nw-magdeburg-chest", shell, cloth.base)
    path(facing, f"M{shoulder + 11} 280 Q123 267 134 284 Q128 310 {chest + 20} 335 "
         f"Q{chest + 28} 365 {waist + 18} 390 Q{waist + 6} 367 {chest + 8} 339 "
         f"Q{chest + 16} 307 {shoulder + 11} 280Z", cloth.light)
    shadow = (f"M{309 - shoulder} 280 Q{304 - chest} 329 {312 - chest} 354 "
              f"Q{304 - waist} 385 {297 - waist} 424 H{335 - waist} V277Z")
    path(facing, shadow, cloth.shade)
    path(facing, shadow, "url(#ink-lines)", opacity=".48")
    for row, y in enumerate((316, 341, 365, 391)):
        half_width = min(body.chest, body.waist) - 11
        for column in range(-2, 3):
            x = 160 + column * half_width / 2
            rivet_y = y + (2 if row == 3 else -2) * abs(column)
            node(facing, "circle", cx=x, cy=rivet_y, r=3.7, fill="#765a3d", stroke="#382a24", stroke_width=1.1)
            node(facing, "circle", cx=x - .75, cy=rivet_y - .8, r=1.61, fill="#debc7b")
    _line(field, shell, "#3d2b24", 5)
    _line(field, shell, cloth.deep, 2.7)
    _line(field, shell, cloth.light, .9, stroke_dasharray="1 3")


DRAWERS = {
    "nw_mail_hauberk": draw_mail_hauberk,
    "nw_nov_lamellar": draw_nov_lamellar,
    "nw_mail_surcoat": draw_mail_surcoat,
    "nw_nov_scale": draw_nov_scale,
    "nw_nov_copper_mail": draw_nov_copper_mail,
    "nw_gomel_lamellar": draw_gomel_lamellar,
    "nw_magdeburg_plate_coat": draw_magdeburg_plate_coat,
}
