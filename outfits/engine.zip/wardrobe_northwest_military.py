from common import node, number, path, use


OPTIONS = {
    "nw_mail_hauberk": "Кольчуга поверх стёганки",
    "nw_nov_lamellar": "Новгородский пластинчатый доспех",
    "nw_mail_surcoat": "Кольчуга и льняное сюрко",
}

_MAIL = "#666659"
_MAIL_LIGHT = "#adab95"
_MAIL_SHADE = "#333532"
_BINDING = "#694a3b"
_BINDING_LIGHT = "#b28964"
_IRON = ("#71756b", "#7c7e70", "#898775", "#6c7168", "#93917e")


def _line(parent, contour, color, width, **attrs):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def _rings(parent, contour, *, opacity=".92"):
    path(parent, contour, "url(#mail-rings)", opacity=opacity)


def _mail_sleeve(sleeve, body, cuff, *, right):
    outer = 160 - body.sleeve
    shoulder = 160 - body.shoulder
    crest = body.shoulder_y
    metal = f"M{outer - 17} {crest - 10}H{shoulder + 36}V{cuff + 3}H{outer - 17}Z"
    light = (
        f"M{shoulder + 9} {crest - 1} Q{outer + 8} 319 {outer + 13} 350 "
        f"Q{outer + 11} 375 {outer + 16} {cuff + 2} H{outer + 32} "
        f"Q{outer + 18} 379 {outer + 27} 348 Q{outer + 26} 316 {shoulder + 16} {crest + 4}Z"
    )
    fold = (
        f"M{shoulder + 22} {crest + 10} Q{outer + 25} 335 {outer + 31} 371 "
        f"Q{outer + 32} 398 {outer + 42} {cuff + 4} H{shoulder + 38}V{crest + 5}Z"
    )
    path(sleeve, metal, "#55594f" if right else _MAIL)
    path(sleeve, light, _MAIL_LIGHT, opacity=".21" if right else ".49")
    path(sleeve, fold, _MAIL_SHADE, opacity=".43")
    _rings(sleeve, metal)
    path(sleeve, fold, "url(#ink-lines)", opacity=".38")
    _line(sleeve, f"M{outer + 13} 371 q8 -8 16 -10 m-17 18 q8 -7 16 -10",
          "#b5ae96", 1, opacity=".49")
    lip = f"M{outer - 10} {cuff - 3} q22 10 {shoulder - outer + 46} -1"
    _line(sleeve, lip, "#33312b", 2.5)
    _line(sleeve, f"M{outer - 10} {cuff} q20 10 {shoulder - outer + 46} -1",
          "#969381", 1.1, opacity=".8")


def _mail_torso(front, body, neck, *, hem):
    shoulder = 160 - body.shoulder
    chest = 160 - body.chest
    waist = 160 - body.waist
    edge = 160 - body.hem
    lip = f"M{160 - neck - 2} 275 Q160 327 {160 + neck + 2} 275"
    field = f"M{edge - 15} 266 H{335 - edge} V{hem} H{edge - 15}Z"
    shadow = (
        f"M194 287 Q{320 - shoulder - 13} 296 {327 - chest} 340 "
        f"Q{315 - waist} 383 {332 - waist} 433 L{332 - edge} {hem} "
        f"H{307 - edge} Q{320 - waist - 26} 403 {320 - chest - 17} 364 "
        "Q216 315 194 287Z"
    )
    path(front, field, _MAIL)
    path(front, f"M{shoulder + 11} 287 Q104 268 137 287 Q109 319 {chest + 23} 351 "
         f"Q{waist + 14} 382 {edge + 24} {hem} H{edge + 5} "
         f"Q{waist + 13} 369 {chest + 5} 341 Q{chest + 7} 312 {shoulder + 11} 287Z",
         _MAIL_LIGHT, opacity=".38")
    path(front, shadow, _MAIL_SHADE, opacity=".61")
    _rings(front, field)
    path(front, shadow, "url(#ink-lines)", opacity=".46")
    _line(front, f"M{chest + 12} 327 q3 -14 12 -23 M{waist + 18} 373 q-3 15 0 26 "
          f"M{315 - waist} 370 q-1 -20 -8 -32", "#c2b8a1", 1.2, opacity=".42")
    _line(front, lip, "#32312d", 7)
    _line(front, lip, "#9c9783", 3)
    _line(front, lip, "#c1b79c", 1.1, stroke_dasharray="1.4 3")


def draw_mail_hauberk(art):
    body, cloth = art.body, art.cloth
    for side, sleeve in enumerate(art.sleeves):
        outer = 160 - body.sleeve
        for x in range(outer + 5, 160 - body.shoulder + 35, 9):
            _line(sleeve, f"M{x} 415 q-3 13 1 31", cloth.deep, 1.25, opacity=".61")
            _line(sleeve, f"M{x + 2} 418 q-3 12 1 27", cloth.light, .85, opacity=".64")
        _mail_sleeve(sleeve, body, 422, right=bool(side))
    _mail_torso(art.front, body, art.neck, hem=435)


def _lamella(parent, identifier, width, color):
    tile = node(parent, "g", id=identifier)
    contour = f"M1 2 Q{width / 2} .25 {width - 1} 1.5 L{width} 18 q-1 2.8 -3.2 3 H3 Q.3 21 0 18Z"
    path(tile, contour, color, stroke="#2d2926", stroke_width=1.35, stroke_linejoin="round")
    path(tile, f"M1.6 3 Q{width / 2} 1.2 {width - 1.3} 2.5 "
         f"L{width - 1.4} 4.5 Q4 4 2.1 10Z", "#b4ad94", opacity=".62")
    path(tile, f"M{width - 2} 5 L{width - .7} 17 q-.7 3 -3.5 3 H2.6 "
         f"Q{width - 3.5} 17 {width - 2} 5Z", "#494c45", opacity=".66")
    _line(tile, f"M2.9 7 l2.5 -1 M{width - 4} 10 l1.2 -1.2", "#c4b99d", .68, opacity=".62")
    for hole in (3.6, width - 3.7):
        node(tile, "circle", cx=hole, cy=14.7, r=1.13, fill="#332922")
    _line(tile, f"M3.6 14.6 q{width / 2 - 3.4} -3.7 {width - 7.3} 0", "#534033", 1.65)
    _line(tile, f"M4.6 13.7 q{width / 2 - 4.8} -1.5 {width - 9.3} -.1", "#ac8762", .68)


def draw_nov_lamellar(art):
    front, body, cloth = art.front, art.body, art.cloth
    shoulder = 160 - body.shoulder + 13
    chest = 160 - body.chest + 9
    waist = 160 - body.waist + 6
    hem = 160 - body.hem + 9
    neckline = art.neck + 2
    for sleeve in art.sleeves:
        _line(sleeve, f"M{shoulder - 9} {body.shoulder_y + 7} "
              f"Q{shoulder + 13} 313 {shoulder + 9} 341", cloth.deep, 2.1, opacity=".83")
    shell = (
        f"M{160 - neckline} 279 Q{shoulder + 16} 281 {shoulder} {body.shoulder_y - 1} "
        f"Q{shoulder + 17} 308 {chest} 337 Q{chest - 2} 366 {waist} 392 "
        f"Q{waist - 4} 419 {hem} 433 Q160 453 {320 - hem} 433 "
        f"Q{324 - waist} 419 {320 - waist} 392 Q{322 - chest} 366 {320 - chest} 337 "
        f"Q{303 - shoulder} 308 {320 - shoulder} {body.shoulder_y - 1} "
        f"Q{304 - shoulder} 281 {160 + neckline} 279 Q160 335 {160 - neckline} 279Z"
    )
    path(front, shell, "#53493c", class_="edge")
    mask = node(front, "clipPath", id="nw-lamellar-shell")
    path(mask, shell)
    layer = node(front, "g", clip_path="url(#nw-lamellar-shell)")
    count = 13 if body.chest >= 79 else 11
    width = (2 * (160 - min(chest, waist, hem) + 16)) / count
    definitions = node(layer, "defs")
    plate_ids = tuple(f"nw-lamella-{i}" for i in range(len(_IRON)))
    for identifier, color in zip(plate_ids, _IRON):
        _lamella(definitions, identifier, width + 1, color)
    for row, y in enumerate(range(277, 439, 16)):
        origin = 160 - count * width / 2 - (width / 2 if row % 2 else 0)
        for column in range(count + 1):
            x = origin + column * width
            cross = (x + width / 2 - 160) / 100
            height = y + 5 - 7 * cross ** 2
            angle = round(-7 * cross)
            identifier = plate_ids[(column * 2 + row * 3) % len(plate_ids)]
            use(layer, identifier, transform=f"translate({number(x)} {number(height)}) rotate({angle})")
    shade = (
        f"M{320 - shoulder} 283 Q{310 - chest} 337 {307 - waist} 395 "
        f"Q{317 - hem} 426 {328 - hem} 443 H{340 - hem} V279Z"
    )
    path(layer, shade, "#3a3029", opacity=".51")
    path(layer, shade, "url(#ink-lines)", opacity=".45")
    _line(front, shell, "#342721", 6)
    _line(front, shell, _BINDING, 3.65)
    _line(front, shell, _BINDING_LIGHT, .9, stroke_dasharray="1 4", opacity=".91")


def draw_mail_surcoat(art):
    body, cloth = art.body, art.cloth
    front, outer = art.front, art.outer
    for side, sleeve in enumerate(art.sleeves):
        _mail_sleeve(sleeve, body, 445, right=bool(side))
    _mail_torso(front, body, art.neck, hem=445)
    shoulder = 160 - body.shoulder + 13
    chest = 160 - body.chest + 8
    waist = 160 - body.waist + 3
    hem = 160 - body.hem + 3
    collar = art.neck + 10
    cloth_shape = (
        f"M{160 - collar} 279 Q{shoulder + 15} 281 {shoulder} {body.shoulder_y - 1} "
        f"Q{shoulder + 18} 310 {chest} 341 Q{chest - 1} 369 {waist} 396 "
        f"Q{waist - 1} 414 {hem} 438 Q160 449 {320 - hem} 438 "
        f"Q{321 - waist} 414 {320 - waist} 396 Q{321 - chest} 369 {320 - chest} 341 "
        f"Q{302 - shoulder} 310 {320 - shoulder} {body.shoulder_y - 1} "
        f"Q{305 - shoulder} 281 {160 + collar} 279 Q180 309 160 317 Q140 309 {160 - collar} 279Z"
    )
    path(outer, cloth_shape, cloth.base, class_="edge")
    path(outer, f"M{shoulder + 13} {body.shoulder_y + 1} Q113 291 120 286 Q128 296 143 307 "
         f"Q128 322 {chest + 17} 353 Q{chest + 23} 321 {shoulder + 13} {body.shoulder_y + 1}Z", cloth.light)
    shadow = (
        f"M{316 - shoulder} {body.shoulder_y + 1} Q{303 - shoulder} 315 {317 - chest} 343 "
        f"Q{317 - chest} 367 {317 - waist} 397 Q{318 - waist} 420 {316 - hem} 437 "
        f"L{295 - hem} 440 Q{304 - waist} 422 {296 - waist} 386 "
        f"Q{297 - chest} 352 184 319 Q197 310 210 286 Q{304 - shoulder} 285 "
        f"{316 - shoulder} {body.shoulder_y + 1}Z"
    )
    path(outer, shadow, cloth.shade)
    path(outer, shadow, "url(#ink-lines)", opacity=".45")
    path(outer, f"M{chest + 10} 359 Q{waist + 17} 373 {waist + 10} 396 "
         f"Q{waist + 8} 378 {chest + 10} 359Z M133 415 q-8 11 -10 26 l-9 1 q6-19 19-27Z", cloth.light)
    path(outer, f"M{chest + 18} 341 q12 -21 19 -24 m-14 53 q8 8 7 22 "
         f"M{301 - chest} 341 q-6 -11 -18 -23 m9 71 q4 -14 -2 -26 m-13 52 q4 8 6 21", class_="seam")
    _line(outer, cloth_shape, cloth.deep, 3.2)
    _line(outer, cloth_shape, cloth.light, 1.1, opacity=".78")


DRAWERS = {
    "nw_mail_hauberk": draw_mail_hauberk,
    "nw_nov_lamellar": draw_nov_lamellar,
    "nw_mail_surcoat": draw_mail_surcoat,
}
