"""Lower-body garments, footwear and mittens in the clothing list."""

from clothing_reference_types import ClothingReference as Ref


EXTRA_EQUIPMENT = {
    "foot_lining": {
        "none": "Без онуч и носков",
        "footcloth": "Онучи",
        "needlebound_sock": "Игольновязаные носки",
    },
    "insole": {
        "none": "Без стелек",
        "felt_insole": "Войлочная стелька",
        "needlebound_insole": "Игольновязаная стелька",
    },
    "shoe_accessory": {
        "none": "Без деталей обуви",
        "ice_grip": "Ледоходные шипы",
        "spur": "Шпоры",
    },
    "gloves": {
        "none": "Без рукавиц",
        "wool_mittens": "Шерстяные рукавицы",
        "work_mittens": "Кожаные рабочие рукавицы",
        "military_mittens": "Воинские рукавицы",
    },
}

EXTRA_LABELS = {
    "foot_lining": "Онучи и носки",
    "insole": "Стелька",
    "shoe_accessory": "Детали обуви",
    "gloves": "Рукавицы",
}

_LOW_SHOE = {"footwear": "novgorod_shoes"}
_BOOT = {"footwear": "novgorod_high_boots"}
_BAREFOOT = {"footwear": "barefoot"}

REFERENCES: dict[int, tuple[Ref, ...]] = {
    20: (
        Ref("trousers", "straight", ("plain_weave", "linen"), equipment=_LOW_SHOE),
        Ref("trousers", "plain_trousers", (), equipment=_LOW_SHOE),
        Ref("trousers", "gathered", (), equipment=_LOW_SHOE),
        Ref("trousers", "straight", ("plain_weave", "linen"), age="child", equipment=_LOW_SHOE),
    ),
    21: (Ref("trousers", "winter_trousers", ("wool",), equipment=_LOW_SHOE),),
    24: (Ref("trousers", "hose", (), equipment={"footwear": "cloth_shoes"}),),
    93: (Ref("footwear", "porshni", ("leather", "yuft")),),
    94: (
        Ref("footwear", "openwork_porshni", ("leather",)),
        Ref("footwear", "embroidered_porshni", ("leather",)),
    ),
    95: (Ref("footwear", "protective_porshni", ("leather",)),),
    96: (
        Ref("footwear", "novgorod_shoes", ("leather",)),
        Ref("footwear", "rus_ankle_strap_shoes", ("leather",)),
        Ref("footwear", "novgorod_shoes", ("leather",), age="child"),
    ),
    97: (Ref("footwear", "embroidered_town_shoes", ("leather",), cast="women", trim_materials=("pearl",)),),
    98: (Ref("footwear", "novgorod_ankle_boots", ("leather",)),),
    99: (
        Ref("footwear", "novgorod_high_boots", ("leather",)),
        Ref("footwear", "embroidered_high_boots", ("leather",), cast="women", detail=True, trim_materials=("pearl",)),
        Ref("footwear", "novgorod_high_boots", ("leather",), age="child"),
    ),
    # The list gives no cut for the proposed burial footwear.
    100: (Ref("footwear", "novgorod_shoes", ("leather",)),),
    101: (Ref("footwear", "bast_shoes", ("bast",), equipment={"leg_wraps": "wool"}),),
    102: (Ref("leg_wraps", "wool", ("wool",), equipment=_LOW_SHOE),),
    103: (Ref("foot_lining", "footcloth", (), equipment=_BAREFOOT),),
    104: (Ref("foot_lining", "needlebound_sock", ("wool",), equipment=_BAREFOOT),),
    105: (
        Ref("insole", "felt_insole", ("felt",), equipment=_BOOT, detail=True),
        Ref("insole", "needlebound_insole", ("wool",), equipment=_BOOT, detail=True),
    ),
    106: (Ref("shoe_accessory", "ice_grip", ("iron",), equipment=_BOOT),),
    107: (Ref("shoe_accessory", "spur", (), equipment=_BOOT),),
    129: (
        Ref("gloves", "wool_mittens", ("wool",)),
        Ref("gloves", "wool_mittens", ("wool",), age="child"),
    ),
    130: (Ref("gloves", "work_mittens", ("leather",)),),
    131: (Ref("gloves", "military_mittens", ("leather", "wool")),),
    261: (Ref("trousers", "gathered", (), equipment={"footwear": "oslo_strap_shoes"}),),
    262: (Ref("trousers", "hose", ("wool",), equipment={"footwear": "oslo_strap_shoes"}),),
    263: (Ref("trousers", "plain_trousers", (), equipment={"footwear": "oslo_strap_shoes"}),),
    264: (Ref("trousers", "straight", (), equipment={"footwear": "oslo_strap_shoes"}),),
    265: (Ref("leg_wraps", "siksala", (), equipment={"footwear": "oslo_strap_shoes"}),),
    266: (Ref("leg_wraps", "wool", ("wool",), equipment=_LOW_SHOE),),
    285: (Ref("footwear", "cloth_shoes", ("plain_weave", "leather")),),
    286: (Ref("footwear", "oslo_strap_shoes", ()),),
    287: (Ref("footwear", "porshni", ()),),
    288: (Ref("footwear", "steppe_boots", ()),),
}
