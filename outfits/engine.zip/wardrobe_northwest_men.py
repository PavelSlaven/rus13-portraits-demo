from common import node, number, path


OPTIONS = {
    "nw_nov_svita": "Новгородская свита поверх сорочицы",
    "nw_nov_sofia_tunic": "Новгородская рубаха с золотным шитьём",
    "nw_karel_tunic": "Приладожская туника с кольцевой фибулой",
    "nw_baltic_mens_coat": "Сиксальская шерстяная туника",
    "nw_nordic_gored_tunic": "Скандинавская туника с клиньями",
}


def draw_nov_svita(art):
    front, cloth = art.front, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    seam = ""
    highlight = ""
    if art.hem_y is not None:
        low = art.hem_y + 12
        bend = round((448 + low) / 2)
        seam = f" Q145 {bend} 146 {low}"
        highlight = f" Q143 {bend} 144 {low}"
    path(front, f"M{left} 271 Q160 295 {right} 271 L157 325 Q149 307 {left} 271 Z",
         "#c6ab82", stroke="#332424", stroke_width=1.8, stroke_linejoin="round")
    path(front, f"M{left} 279 Q139 298 154 302 L151 332 Q152 359 158 396 Q161 428 154 448{seam} "
         f"M{right} 278 Q178 291 165 298", "none", stroke=cloth.deep, stroke_width=3, stroke_linecap="round")
    path(front, f"M152 301 Q154 319 151 336 Q151 355 156 386 Q162 418 152 447{highlight}",
         "none", stroke=cloth.light, stroke_width=1.2)
    path(front, "M148 323 Q119 336 113 369 L104 407 Q123 380 129 355 L148 342 Z",
         cloth.shade, opacity=".63")
    for y, x in ((319, 153), (344, 152), (369, 154)):
        path(front, f"M{x - 8} {y - 1} q7 -6 14 -3 l4 3 -4 2z", "#b69a71", stroke="#332424", stroke_width=1.8)
        path(front, f"M{x - 4} {y - 1} q4 -3 9 -2", class_="etch")
    for sleeve in art.sleeves:
        x = 160 - art.body.sleeve
        path(sleeve, f"M{x - 3} 427 Q{x + 22} 421 {x + 45} 430 M{x - 3} 433 Q{x + 24} 427 {x + 47} 436",
             "none", stroke=cloth.deep, stroke_width=1.5)


def _gold_stitch(panel):
    path(panel, "M0 8Q-2 0 0-8Q3-3 2 8M0 3Q-8-4-10 0Q-4 5 0 3M1 1Q8-5 10-1Q7 4 1 1",
         "none", stroke="#e0b880", stroke_width=1.35, stroke_linecap="round")
    path(panel, "M-3 8 0 11 3 8 0 5Z", "#a97744")


def draw_nov_sofia_tunic(art):
    front, cloth = art.front, art.cloth
    left, right = 160 - art.neck, 160 + art.neck
    path(front, f"M{number(left)} 272 Q160 296 {number(right)} 272 L{number(right + 1)} 288 "
         f"Q181 304 178 304 L178 349 Q159 356 142 349 L142 304 Q139 302 {number(left - 1)} 288Z",
         "#663f3b", class_="edge")
    path(front, f"M{number(left)} 279 Q160 302 {number(right)} 279 M144 303V345Q159 352 176 345V303",
         "none", stroke="#d0a163", stroke_width=2, stroke_linejoin="round")
    for y in (309, 329):
        _gold_stitch(node(front, "g", transform=f"translate(160 {y})"))
    path(front, "M147 351 L145 390 M175 351 Q181 362 182 387 M132 355 Q122 367 119 389",
         "none", stroke=cloth.shade, stroke_width=1.7, stroke_linecap="round")
    x = 160 - art.body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{x - 4} 418 Q{x + 25} 408 {x + 52} 420 L{x + 50} 438 "
             f"Q{x + 25} 429 {x + 1} 440Z", "#744538", stroke="#332424", stroke_width=1.8)
        path(sleeve, f"M{x} 421 Q{x + 27} 412 {x + 50} 422 M{x} 435 Q{x + 26} 425 {x + 50} 435",
             "none", stroke="#cc9a5a", stroke_width=1.65)
        for dx in (14, 32):
            _gold_stitch(node(sleeve, "g", transform=f"translate({x + dx} 425) scale(.58)"))


def draw_karel_tunic(art):
    front, cloth = art.front, art.cloth
    left, right = number(160 - art.neck), number(160 + art.neck)
    collar = (f"M{left} 272 Q155 295 {right} 272 Q178 289 165 300 "
              "L160 333 147 329 153 301 Q136 289 " + left + " 272Z")
    path(front, collar, "#a69b7d", stroke="#332424", stroke_width=1.8, stroke_linejoin="round")
    path(front, "M151 286 L159 297 154 327 M102 310 Q126 318 146 332 "
         "M207 309 Q191 326 171 334", "none", stroke=cloth.deep, stroke_width=1.5)
    fastening = node(front, "g", transform="translate(154 309) rotate(19)")
    path(fastening, "M-7-3 C-12 11 11 12 8-2 Q6-8 2-8",
         "none", stroke="#44382c", stroke_width=6, stroke_linecap="round")
    path(fastening, "M-7-3 C-12 11 11 12 8-2 Q6-8 2-8",
         "none", stroke="#c6a375", stroke_width=3.6, stroke_linecap="round")
    path(fastening, "M-10 1 9-5 M1 8Q6 8 8 5", "none", stroke="#e1be86", stroke_width=1.5)
    path(front, "M149 337 Q136 364 145 396 M167 338 Q175 352 180 381 M190 394 Q190 416 197 438",
         "none", stroke=cloth.light, stroke_width=1.45, opacity=".74")


def draw_baltic_mens_coat(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = 160 - art.neck, 160 + art.neck
    seam = 160 + min(body.waist - 16, 42)
    edge = f"L{number(seam + 4)} 449"
    return_fold = "Q157 413 158 372"
    if art.hem_y is not None:
        low = art.hem_y + 12
        bend = round((405 + low) / 2)
        edge = f"Q{seam + 4} {bend} {seam + 1} {low}"
        return_fold = f"Q155 {low - 13} 157 {bend} Q157 413 158 372"
    path(front, f"M{number(left)} 273Q163 292 {number(right)} 273 Q180 301 {number(seam - 9)} 319 "
         f"Q{number(seam + 9)} 362 {number(seam)} 405 {edge} "
         f"{return_fold} Q154 318 {number(left)} 273Z", cloth.light, opacity=".74")
    path(front, f"M{number(left + 7)} 280Q161 308 {number(seam - 10)} 323 "
         f"Q{number(seam + 7)} 373 {number(seam - 1)} 406 {edge}",
         "none", stroke=cloth.deep, stroke_width=3)
    path(front, "M130 307 L132 324 M136 310 L139 327 M144 315 L146 331 M150 318 153 334",
         "none", stroke="#d9c393", stroke_width=1.6, stroke_linecap="round")
    path(front, "M103 344 Q126 337 147 350 M104 361 Q124 352 146 362 "
         "M110 415 Q126 401 138 398 M204 396 Q209 417 217 435",
         "none", stroke=cloth.shade, stroke_width=1.65, stroke_linecap="round")


def draw_nordic_gored_tunic(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = number(160 - art.neck), number(160 + art.neck)
    shoulder = 160 - body.shoulder
    seam_half, seam_y = body.hem - 9, 444
    gore_y, gore_half = 445, 34
    if art.hem_y is not None:
        seam_half, seam_y = art.hem_half - 10, art.hem_y + 1
        gore_half, gore_y = round(.67 * art.hem_half), art.hem_y + 13
    path(front, f"M{left} 273 Q159 293 {right} 273 Q180 293 164 301 "
         f"L162 323L153 320 155 300Q139 291 {left} 273Z", "#b3a995", stroke="#332424", stroke_width=1.8)
    path(front, f"M{shoulder + 9} 300 Q{shoulder + 28} 324 {shoulder + 10} 358 "
         f"L{160 - seam_half} {seam_y} M{311 - shoulder} 300 Q{292 - shoulder} 324 {310 - shoulder} 358 "
         f"L{160 + seam_half} {seam_y}", "none", stroke=cloth.deep, stroke_width=1.7)
    path(front, f"M{159 - gore_half} {gore_y}L145 407 L157 388 171 413 {159 + gore_half} {gore_y}Z",
         cloth.shade)
    path(front, f"M{160 - gore_half} {gore_y + 1} 156 390 {158 + gore_half} {gore_y + 1} "
         f"M{163 - gore_half} {gore_y} 156 400 {150 + gore_half} {gore_y}",
         "none", stroke=cloth.light, stroke_width=1.35, opacity=".71")
    path(front, "M128 318 Q112 336 109 353 M173 338 Q181 368 177 391 "
         "M139 359 Q135 377 139 390 M199 352 Q200 367 206 379",
         "none", stroke=cloth.deep, stroke_width=1.4, stroke_linecap="round")
    for sleeve in art.sleeves:
        x = 160 - body.sleeve
        path(sleeve, f"M{x + 6} 417Q{x + 27} 409 {x + 53} 421M{x + 7} 421Q{x + 27} 414 {x + 53} 425",
             "none", stroke=cloth.light, stroke_width=1.3, opacity=".75")


DRAWERS = {
    "nw_nov_svita": draw_nov_svita,
    "nw_nov_sofia_tunic": draw_nov_sofia_tunic,
    "nw_karel_tunic": draw_karel_tunic,
    "nw_baltic_mens_coat": draw_baltic_mens_coat,
    "nw_nordic_gored_tunic": draw_nordic_gored_tunic,
}
