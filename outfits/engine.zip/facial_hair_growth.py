GROWTH_STAGES = {
    "shaved": "Сбрито",
    "stubble": "Щетина",
    "short": "Короткий рост",
    "medium": "Средний рост",
    "full": "Полный рост",
}
GROWTH_OPTIONS = {"beard_growth": GROWTH_STAGES, "moustache_growth": GROWTH_STAGES}
GROWTH_LABELS = {"beard_growth": "Рост бороды", "moustache_growth": "Рост усов"}

_SHORT_BEARD_STYLES = {"stubble", "short", "short_point", "chin_only"}
_MEDIUM_BEARD_STYLES = {"broad", "full_round", "flat_end", "broad_rounded_end"}
_SHORT_MOUSTACHE_STYLES = {"short", "fine", "heavy"}
_MEDIUM_MOUSTACHE_STYLES = {"broad", "raised", "wide_curved", "winged"}

MOUSTACHE_STUBBLE = (
    "M155 212l1.5-.8 1.1 1.7-1.5 1.1Z M150 211l1.5-.4.7 1.9-1.6.7Z"
    " M145 213l1.9-1 .8 1.4-1.8 1.3Z M141 215l1.5-1 1 1.5-1.8 1Z"
    " M150 215l1.6-.5.5 1.5-1.7 1.1Z M136 217l1.8-1 .8 1.1-1.5 1.3Z",
    "M149 212l1-.3m-10 4 1-.6",
    (210, 219),
    .75,
)


def visible_facial_hair(look):
    """Keep the chosen shapes in the recipe and return the shapes visible at this growth stage."""
    beard, moustache = look["beard"], look["moustache"]
    beard_growth = look.get("beard_growth", "full")
    moustache_growth = look.get("moustache_growth", "full")
    if beard_growth == "shaved":
        beard = "none"
    elif beard != "none":
        if beard_growth == "stubble":
            beard = "stubble"
        elif beard_growth == "short" and beard not in _SHORT_BEARD_STYLES:
            beard = "short_point"
        elif beard_growth == "medium" and beard not in _SHORT_BEARD_STYLES | _MEDIUM_BEARD_STYLES:
            beard = "full_round"
    if moustache_growth == "shaved":
        moustache = "none"
    elif moustache != "none":
        if moustache_growth == "stubble":
            moustache = "stubble"
        elif moustache_growth == "short" and moustache not in _SHORT_MOUSTACHE_STYLES:
            moustache = "fine"
        elif moustache_growth == "medium" and moustache not in _SHORT_MOUSTACHE_STYLES | _MEDIUM_MOUSTACHE_STYLES:
            moustache = "wide_curved"
    return beard, moustache
