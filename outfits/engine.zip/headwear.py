from dataclasses import dataclass
from xml.etree.ElementTree import Element

import clothing_headwear_art
import headwear_adult_men
import headwear_adult_women
import headwear_child_east
import headwear_child_west
import headwear_eurasia
import headwear_rus
import headwear_northwest_men
import headwear_northwest_women
from wardrobe_bandiagara import draw_cap as draw_tellem_cap
from common import HeadGeometry, brow_top, node, number, path, use
from face_shape import face_outline, forehead_curve, forehead_curve_segment, make_head


ADULT_CASTS = {
    **dict.fromkeys(headwear_adult_men.OPTIONS, "men"),
    **dict.fromkeys(headwear_adult_women.OPTIONS, "women"),
    **dict.fromkeys(headwear_northwest_men.OPTIONS, "men"),
    **dict.fromkeys(headwear_northwest_women.OPTIONS, "women"),
    **clothing_headwear_art.ADULT_CASTS,
}
OPTIONS = {
    "fur_cap": "Шапка с меховым околышем",
    "felt_cap": "Войлочный колпак",
    "temple_rings": "Плат с височными кольцами",
    "shoulder_veil": "Наплечное покрывало",
    "linen_coif": "Завязная шапочка",
    "wimple": "Покрывало с подбородочной повязкой",
    "wrapped_turban": "Тюрбан из обмотанной ткани",
    "bocca": "Степная бокка",
    "eboshi": "Эбоси",
    "weimao": "Танская шляпа с вуалью",
    "tellem_cap": "Бандиагара · хлопковая шапочка",
    **headwear_child_west.OPTIONS,
    **headwear_child_east.OPTIONS,
    **headwear_adult_men.OPTIONS,
    **headwear_adult_women.OPTIONS,
    **headwear_northwest_men.OPTIONS,
    **headwear_northwest_women.OPTIONS,
    **clothing_headwear_art.OPTIONS,
}
COVERAGE = {
    "fur_cap": {"ears": True, "neck": True, "hair": True},
    "felt_cap": {"ears": True, "neck": True, "hair": True},
    "temple_rings": {"ears": False, "neck": True, "hair": True},
    "shoulder_veil": {"ears": False, "neck": False, "hair": False},
    "linen_coif": {"ears": False, "neck": True, "hair": False},
    "wimple": {"ears": False, "neck": False, "hair": False},
    "wrapped_turban": {"ears": True, "neck": True, "hair": True},
    "bocca": {"ears": False, "neck": True, "hair": False},
    "eboshi": {"ears": True, "neck": True, "hair": True},
    "weimao": {"ears": False, "neck": True, "hair": False},
    "tellem_cap": {"ears": True, "neck": True, "hair": True},
    **headwear_child_west.COVERAGE,
    **headwear_child_east.COVERAGE,
    **headwear_adult_men.COVERAGE,
    **headwear_adult_women.COVERAGE,
    **headwear_northwest_men.COVERAGE,
    **headwear_northwest_women.COVERAGE,
    **clothing_headwear_art.COVERAGE,
}
_DRAWERS = {
    "tellem_cap": draw_tellem_cap,
    **headwear_rus.DRAWERS,
    **headwear_eurasia.DRAWERS,
    **headwear_child_west.DRAWERS,
    **headwear_child_east.DRAWERS,
    **headwear_adult_men.DRAWERS,
    **headwear_adult_women.DRAWERS,
    **headwear_northwest_men.DRAWERS,
    **headwear_northwest_women.DRAWERS,
    **clothing_headwear_art.DRAWERS,
}
_BRIM = 115
_HAIR_ROOT_HALF = {
    "fur_cap": 77, "felt_cap": 70, "temple_rings": 68, "wrapped_turban": 67, "eboshi": 64,
    "tellem_cap": 74,
    **headwear_child_west.HAIR_ROOT_HALF,
    **headwear_child_east.HAIR_ROOT_HALF,
    **headwear_adult_men.HAIR_ROOT_HALF,
    **headwear_adult_women.HAIR_ROOT_HALF,
    **headwear_northwest_men.HAIR_ROOT_HALF,
    **headwear_northwest_women.HAIR_ROOT_HALF,
    **clothing_headwear_art.HAIR_ROOT_HALF,
}
OPEN_CROWNS = (headwear_child_west.OPEN_CROWNS | headwear_child_east.OPEN_CROWNS
               | headwear_adult_men.OPEN_CROWNS | headwear_adult_women.OPEN_CROWNS
               | headwear_northwest_women.OPEN_CROWNS | clothing_headwear_art.OPEN_CROWNS)
FOREHEAD_BANDS = (
    clothing_headwear_art.OPEN_CROWNS | headwear_adult_women.OPEN_CROWNS
    | headwear_northwest_women.OPEN_CROWNS | {"child_rus_browband"}
)
BRAID_HEMS = {**headwear_child_west.BRAID_HEMS, **headwear_child_east.BRAID_HEMS}
SIDE_BRAID_GEAR = BRAID_HEMS.keys() | {
    gear for styles in (headwear_child_west.COVERAGE, headwear_child_east.COVERAGE)
    for gear, coverage in styles.items() if coverage["hair"]
}


@dataclass(frozen=True)
class ForeheadBand:
    group: Element
    center: float
    temple: float
    half_width: float
    height: float
    card: bool

    def point(self, across, level=.5):
        span = abs(across)
        depth = (level - .5) * self.height
        curve = (self.temple - self.center) * span ** 5
        return 160 + across * self.half_width, self.center + depth * (1 - .38 * span ** 2) + curve

    def _trace(self, level, *, returning=False):
        def coords(*points):
            return " ".join(number(value) for point in points for value in point)

        def tangent(across):
            taper = -.76 * (level - .5) * self.height * across
            return taper + 5 * (self.temple - self.center) * across * abs(across) ** 3

        spans = (-1, -.55, 0, .55, 1)
        if returning:
            spans = spans[::-1]
        commands = [("L" if returning else "M") + coords(self.point(spans[0], level))]
        for start, end in zip(spans, spans[1:]):
            x0, y0 = self.point(start, level)
            x1, y1 = self.point(end, level)
            third = (end - start) / 3
            dx = self.half_width * third
            commands.append("C" + coords((x0 + dx, y0 + tangent(start) * third),
                                         (x1 - dx, y1 - tangent(end) * third), (x1, y1)))
        return "".join(commands)

    def line(self, level):
        return self._trace(level)

    def strip(self, top=0, bottom=1):
        return self.line(top) + self._trace(bottom, returning=True) + "Z"


@dataclass(frozen=True)
class HeadwearFit:
    x_scale: float
    top_y: float
    brim_y: float
    chin_y: float
    hairline_y: float | None = None
    card: bool = False

    @classmethod
    def for_head(cls, look, head: HeadGeometry, *, hairline_y=None, card=False):
        return cls(head.temple_half / 68, head.top_y, min(116, brow_top(look, include_standard=True) - 6.5),
                   head.chin_y, hairline_y, card)

    def _place(self, parent, y_scale, shift, *, x_scale=None):
        x_scale = self.x_scale if x_scale is None else x_scale
        return node(parent, "g", transform=(
            f"matrix({number(x_scale)} 0 0 {number(y_scale)} "
            f"{number(160 * (1 - x_scale))} {number(shift)})"
        ))

    def crown(self, parent, *, minimum_y=36):
        scale = max(.68, (self.brim_y - self.top_y) / (_BRIM - 75))
        # Tall ornaments share the usual 32 px crop with the face and clothes.
        scale = min(scale, (self.brim_y - 14) / (_BRIM - minimum_y))
        return self._place(parent, scale, self.brim_y - _BRIM * scale)

    def fitted_crown(self, parent, *, top, clearance):
        fitted_top = max(14, min(self.top_y - clearance, self.brim_y - 15))
        scale = (self.brim_y - fitted_top) / (_BRIM - top)
        return self._place(parent, scale, self.brim_y - _BRIM * scale)

    def sides(self, parent):
        return self._place(parent, 1, self.brim_y - _BRIM)

    def forehead_band(self, parent, look, *, height):
        head = make_head(look)
        brow_y = brow_top(look, include_standard=True)
        hairline = self.top_y if self.hairline_y is None else self.hairline_y
        gap = brow_y - hairline
        center = hairline + .38 * gap
        desired = max(height, 23.5) if self.card else height
        scalp_clearance = .1 if self.card else 1
        brow_clearance = min(1.5, .08 * gap) if self.card else 2
        half_height = max(.5, min(desired / 2, center - self.top_y - scalp_clearance, brow_y - center - brow_clearance))
        temple = min(126, max(center + 7, .26 * self.top_y + .74 * 128))
        forehead = ((0, self.top_y), *forehead_curve(look, head))
        _, _, (scalp_half, _) = forehead_curve_segment(forehead, temple - .62 * half_height)
        half = scalp_half - 2
        clip = node(node(parent, "defs"), "clipPath", id="headband-head-inset")
        inset = number((head.temple_half - 1.25) / head.temple_half)
        path(clip, face_outline(look, head),
             transform=f"translate(160 160) scale({inset} .99) translate(-160 -160)")
        group = node(parent, "g", clip_path="url(#headband-head-inset)", data_part="forehead-band",
                     data_hairline_y=number(hairline), data_brow_y=number(brow_y), data_center_y=number(center),
                     data_temple_half=number(half), data_temple_y=number(temple), data_band_height=number(2 * half_height))
        return ForeheadBand(group, center, temple, half, 2 * half_height, self.card)

    def temples(self, parent):
        return self._place(parent, 1, 0)

    def hair(self, parent):
        scale = (160 - self.top_y) / 85
        return self._place(parent, scale, 160 * (1 - scale))

    def chin(self, parent):
        return self._place(parent, 1, self.chin_y - 250)

    def hair_reveal(self, gear):
        half = _HAIR_ROOT_HALF[gear] * self.x_scale
        left, right = 160 - half, 160 + half
        top = number(self.brim_y - 5)
        temple = number(self.brim_y + 24)
        return (
            f"M{number(left)} {top}H{number(right)}"
            f"Q{number(right - 2)} {number(self.brim_y + 4)} {number(right + 18)} {temple}"
            "L320 215V440H0V215"
            f"L{number(left - 18)} {temple}Q{number(left + 2)} {number(self.brim_y + 4)} {number(left)} {top}Z"
        )


def draw(parent, look, head, *, hairline_y=None, card=False):
    gear = look["headgear"]
    material_slot = "headgear" if look.get("headgear_material") or look.get("headgear_trim_material") else None
    artwork = node(parent, "g", id=f"headgear-{gear}", data_material_slot=material_slot)
    fit = HeadwearFit.for_head(look, head, hairline_y=hairline_y, card=card)
    _DRAWERS[gear](artwork, look, fit)
    if gear not in clothing_headwear_art.OPTIONS:
        clothing_headwear_art.prepare_legacy_materials(artwork, look, fit)
    return artwork


def draw_band_temple_hair(parent, defs, artwork):
    hair = parent.find("./*[@id='hair-front']")
    if hair is None:
        return
    band = artwork.find("./*[@data-part='forehead-band']")
    half = float(band.get("data-temple-half"))
    temple = float(band.get("data-temple-y"))
    height = float(band.get("data-band-height"))
    left, middle = number(160 - half), number(169 - half)
    top, bottom = number(temple - .47 * height - 1), number(temple + .47 * height + 2)
    clip = node(defs, "clipPath", id="headband-temple-hair")
    reveal = f"M{number(151 - half)} {top}H{left}Q{middle} {temple} {middle} {bottom}H{number(151 - half)}Z"
    path(clip, reveal)
    path(clip, reveal, transform="translate(320 0) scale(-1 1)")
    use(parent, "hair-front", clip_path="url(#headband-temple-hair)", data_part="headband-temple-hair")
