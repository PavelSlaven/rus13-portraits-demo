from dataclasses import dataclass

import headwear_eurasia
import headwear_rus
from common import HeadGeometry, brow_top, node, number


OPTIONS = {
    "fur_cap": "Шапка с меховым околышем",
    "felt_cap": "Войлочный колпак",
    "temple_rings": "Плат с височными кольцами",
    "shoulder_veil": "Наплечное покрывало",
    "linen_coif": "Завязная шапочка",
    "wimple": "Покрывало с подбородочной повязкой",
    "wrapped_turban": "Тюрбан из обмотанной ткани",
    "bocca": "Степная бокка",
    "eboshi": "Эбоси",
    "weimao": "Танская шляпа с вуалью",
}
COVERAGE = {
    "fur_cap": {"ears": True, "neck": True, "hair": True},
    "felt_cap": {"ears": True, "neck": True, "hair": True},
    "temple_rings": {"ears": False, "neck": True, "hair": True},
    "shoulder_veil": {"ears": False, "neck": False, "hair": False},
    "linen_coif": {"ears": False, "neck": True, "hair": False},
    "wimple": {"ears": False, "neck": False, "hair": False},
    "wrapped_turban": {"ears": True, "neck": True, "hair": True},
    "bocca": {"ears": False, "neck": True, "hair": False},
    "eboshi": {"ears": True, "neck": True, "hair": True},
    "weimao": {"ears": False, "neck": True, "hair": False},
}
_DRAWERS = {**headwear_rus.DRAWERS, **headwear_eurasia.DRAWERS}
_BRIM = 115
_HAIR_ROOT_HALF = {"fur_cap": 77, "felt_cap": 70, "temple_rings": 68, "wrapped_turban": 67, "eboshi": 64}


@dataclass(frozen=True)
class HeadwearFit:
    x_scale: float
    top_y: float
    brim_y: float
    chin_y: float

    @classmethod
    def for_head(cls, look, head: HeadGeometry):
        return cls(head.temple_half / 68, head.top_y, min(116, brow_top(look, include_standard=True) - 6.5), head.chin_y)

    def _place(self, parent, y_scale, shift):
        return node(parent, "g", transform=(
            f"matrix({number(self.x_scale)} 0 0 {number(y_scale)} "
            f"{number(160 * (1 - self.x_scale))} {number(shift)})"
        ))

    def crown(self, parent, *, minimum_y=36):
        scale = max(.68, (self.brim_y - self.top_y) / (_BRIM - 75))
        # Tall ornaments share the usual 32 px crop with the face and clothes.
        scale = min(scale, (self.brim_y - 14) / (_BRIM - minimum_y))
        return self._place(parent, scale, self.brim_y - _BRIM * scale)

    def sides(self, parent):
        return self._place(parent, 1, self.brim_y - _BRIM)

    def chin(self, parent):
        return self._place(parent, 1, self.chin_y - 250)

    def hair_reveal(self, gear):
        half = _HAIR_ROOT_HALF[gear] * self.x_scale
        left, right = 160 - half, 160 + half
        top = number(self.brim_y - 5)
        temple = number(self.brim_y + 24)
        return (
            f"M{number(left)} {top}H{number(right)}"
            f"Q{number(right - 2)} {number(self.brim_y + 4)} {number(right + 18)} {temple}"
            "L320 215V440H0V215"
            f"L{number(left - 18)} {temple}Q{number(left + 2)} {number(self.brim_y + 4)} {number(left)} {top}Z"
        )


def draw(parent, look, head):
    gear = look["headgear"]
    artwork = node(parent, "g", id=f"headgear-{gear}")
    _DRAWERS[gear](artwork, look, HeadwearFit.for_head(look, head))
