from dataclasses import dataclass

import clothing_headwear_art
import headwear_adult_men
import headwear_adult_women
import headwear_child_east
import headwear_child_west
import headwear_eurasia
import headwear_rus
import headwear_northwest_men
import headwear_northwest_women
from wardrobe_bandiagara import draw_cap as draw_tellem_cap
from common import HeadGeometry, brow_top, node, number
from face_shape import forehead_curve, forehead_curve_segment, make_head
from hair_length import SCALP_STYLES


ADULT_CASTS = {
    **dict.fromkeys(headwear_adult_men.OPTIONS, "men"),
    **dict.fromkeys(headwear_adult_women.OPTIONS, "women"),
    **dict.fromkeys(headwear_northwest_men.OPTIONS, "men"),
    **dict.fromkeys(headwear_northwest_women.OPTIONS, "women"),
    **clothing_headwear_art.ADULT_CASTS,
}
OPTIONS = {
    "fur_cap": "Шапка с меховым околышем",
    "felt_cap": "Войлочный колпак",
    "temple_rings": "Плат с височными кольцами",
    "shoulder_veil": "Наплечное покрывало",
    "linen_coif": "Завязная шапочка",
    "wimple": "Покрывало с подбородочной повязкой",
    "wrapped_turban": "Тюрбан из обмотанной ткани",
    "bocca": "Степная бокка",
    "eboshi": "Эбоси",
    "weimao": "Танская шляпа с вуалью",
    "tellem_cap": "Бандиагара · хлопковая шапочка",
    **headwear_child_west.OPTIONS,
    **headwear_child_east.OPTIONS,
    **headwear_adult_men.OPTIONS,
    **headwear_adult_women.OPTIONS,
    **headwear_northwest_men.OPTIONS,
    **headwear_northwest_women.OPTIONS,
    **clothing_headwear_art.OPTIONS,
}
COVERAGE = {
    "fur_cap": {"ears": True, "neck": True, "hair": True},
    "felt_cap": {"ears": True, "neck": True, "hair": True},
    "temple_rings": {"ears": False, "neck": True, "hair": True},
    "shoulder_veil": {"ears": False, "neck": False, "hair": False},
    "linen_coif": {"ears": False, "neck": True, "hair": False},
    "wimple": {"ears": False, "neck": False, "hair": False},
    "wrapped_turban": {"ears": True, "neck": True, "hair": True},
    "bocca": {"ears": False, "neck": True, "hair": False},
    "eboshi": {"ears": True, "neck": True, "hair": True},
    "weimao": {"ears": False, "neck": True, "hair": False},
    "tellem_cap": {"ears": True, "neck": True, "hair": True},
    **headwear_child_west.COVERAGE,
    **headwear_child_east.COVERAGE,
    **headwear_adult_men.COVERAGE,
    **headwear_adult_women.COVERAGE,
    **headwear_northwest_men.COVERAGE,
    **headwear_northwest_women.COVERAGE,
    **clothing_headwear_art.COVERAGE,
}
_DRAWERS = {
    "tellem_cap": draw_tellem_cap,
    **headwear_rus.DRAWERS,
    **headwear_eurasia.DRAWERS,
    **headwear_child_west.DRAWERS,
    **headwear_child_east.DRAWERS,
    **headwear_adult_men.DRAWERS,
    **headwear_adult_women.DRAWERS,
    **headwear_northwest_men.DRAWERS,
    **headwear_northwest_women.DRAWERS,
    **clothing_headwear_art.DRAWERS,
}
_BRIM = 115
_HAIR_ROOT_HALF = {
    "fur_cap": 77, "felt_cap": 70, "temple_rings": 68, "wrapped_turban": 67, "eboshi": 64,
    "tellem_cap": 74,
    **headwear_child_west.HAIR_ROOT_HALF,
    **headwear_child_east.HAIR_ROOT_HALF,
    **headwear_adult_men.HAIR_ROOT_HALF,
    **headwear_adult_women.HAIR_ROOT_HALF,
    **headwear_northwest_men.HAIR_ROOT_HALF,
    **headwear_northwest_women.HAIR_ROOT_HALF,
    **clothing_headwear_art.HAIR_ROOT_HALF,
}
OPEN_CROWNS = (headwear_child_west.OPEN_CROWNS | headwear_child_east.OPEN_CROWNS
               | headwear_adult_men.OPEN_CROWNS | headwear_adult_women.OPEN_CROWNS
               | headwear_northwest_women.OPEN_CROWNS | clothing_headwear_art.OPEN_CROWNS)
BRAID_HEMS = {**headwear_child_west.BRAID_HEMS, **headwear_child_east.BRAID_HEMS}
SIDE_BRAID_GEAR = BRAID_HEMS.keys() | {
    gear for styles in (headwear_child_west.COVERAGE, headwear_child_east.COVERAGE)
    for gear, coverage in styles.items() if coverage["hair"]
}


@dataclass(frozen=True)
class HeadwearFit:
    x_scale: float
    top_y: float
    brim_y: float
    chin_y: float

    @classmethod
    def for_head(cls, look, head: HeadGeometry):
        return cls(head.temple_half / 68, head.top_y, min(116, brow_top(look, include_standard=True) - 6.5), head.chin_y)

    def _place(self, parent, y_scale, shift, *, x_scale=None):
        x_scale = self.x_scale if x_scale is None else x_scale
        return node(parent, "g", transform=(
            f"matrix({number(x_scale)} 0 0 {number(y_scale)} "
            f"{number(160 * (1 - x_scale))} {number(shift)})"
        ))

    def crown(self, parent, *, minimum_y=36):
        scale = max(.68, (self.brim_y - self.top_y) / (_BRIM - 75))
        # Tall ornaments share the usual 32 px crop with the face and clothes.
        scale = min(scale, (self.brim_y - 14) / (_BRIM - minimum_y))
        return self._place(parent, scale, self.brim_y - _BRIM * scale)

    def fitted_crown(self, parent, *, top, clearance):
        fitted_top = max(14, min(self.top_y - clearance, self.brim_y - 15))
        scale = (self.brim_y - fitted_top) / (_BRIM - top)
        return self._place(parent, scale, self.brim_y - _BRIM * scale)

    def sides(self, parent):
        return self._place(parent, 1, self.brim_y - _BRIM)

    def forehead_band(self, parent, look, *, center_top, center_bottom, side_top, side_bottom, half_width, trail=None):
        # Place the cloth across the forehead, with visible skin above the eyebrows.
        brow_y = brow_top(look, include_standard=True)
        forehead_height = brow_y - self.top_y
        clearance = min(forehead_height * .33, max(5, forehead_height * .22))
        center_y = brow_y - clearance
        band_height = center_bottom - center_top
        side_drop = side_bottom - center_bottom
        thickness = (center_y - self.top_y - 2) / (band_height + 2.3)
        y_scale = min(1, max(.24, thickness), clearance / (2.3 + .6 * side_drop))
        side_middle = (side_top + side_bottom) / 2
        side_y = min(128, center_y + (side_drop - 1.5) * y_scale)
        forehead = ((0, self.top_y), *forehead_curve(look, make_head(look)))
        _, _, (scalp_half, _) = forehead_curve_segment(forehead, side_y)
        hair_clearance = 2 if look["hair_style"] in SCALP_STYLES else 5
        x_scale = min(self.x_scale, (scalp_half + hair_clearance) / half_width)
        if trail is not None:
            # The attachment follows the side of the cloth. The hanging part stays at the temple.
            anchor = center_y + (side_middle - center_bottom) * y_scale
            shift = anchor - side_middle
            mount = self._place(parent, 1, shift)
            mount.set("data-part", "headband-attachments")
            temple_y = min(122, max(115, anchor + 3))
            _, _, (temple_half, _) = forehead_curve_segment(forehead, temple_y)
            trail(mount, x_scale / self.x_scale, 160 + temple_half / self.x_scale, temple_y - shift)
        band = self._place(parent, y_scale, center_y - center_bottom * y_scale, x_scale=x_scale)
        band.set("data-part", "forehead-band")
        return band

    def temples(self, parent):
        return self._place(parent, 1, 0)

    def hair(self, parent):
        scale = (160 - self.top_y) / 85
        return self._place(parent, scale, 160 * (1 - scale))

    def chin(self, parent):
        return self._place(parent, 1, self.chin_y - 250)

    def hair_reveal(self, gear):
        half = _HAIR_ROOT_HALF[gear] * self.x_scale
        left, right = 160 - half, 160 + half
        top = number(self.brim_y - 5)
        temple = number(self.brim_y + 24)
        return (
            f"M{number(left)} {top}H{number(right)}"
            f"Q{number(right - 2)} {number(self.brim_y + 4)} {number(right + 18)} {temple}"
            "L320 215V440H0V215"
            f"L{number(left - 18)} {temple}Q{number(left + 2)} {number(self.brim_y + 4)} {number(left)} {top}Z"
        )


def draw(parent, look, head):
    gear = look["headgear"]
    material_slot = "headgear" if look.get("headgear_material") or look.get("headgear_trim_material") else None
    artwork = node(parent, "g", id=f"headgear-{gear}", data_material_slot=material_slot)
    fit = HeadwearFit.for_head(look, head)
    _DRAWERS[gear](artwork, look, fit)
    if gear not in clothing_headwear_art.OPTIONS:
        clothing_headwear_art.prepare_legacy_materials(artwork, look, fit)
