import argparse
import json
import sys
from hashlib import sha256
from pathlib import Path
from xml.etree import ElementTree as ET

from clothing_catalog import (
    EXTRA_EQUIPMENT, EXTRA_LABELS, MATERIAL_CHOICES, MATERIAL_LABELS, MATERIAL_OPTIONS,
    REFERENCE_AGES, REFERENCE_CASTS, default_materials, validate_materials,
)
from clothing_materials import MATERIAL_FIELDS, apply_materials
from costume_cultures import AUTO_CULTURES, CULTURES, PROFILE_CULTURES, compatible_cultures, cultures_for_item
from estates import ESTATES, ITEM_ESTATES, estates_for_item
import face_features
import face_shape
from facial_hair_growth import GROWTH_LABELS, GROWTH_OPTIONS
import hair_headgear
from hair_length import HAIR_LENGTHS, STYLES_BY_LENGTH, length_allows
import headwear
import nose_mouth
import wardrobe
import wardrobe_northwest_accessories
import wardrobe_northwest_archery
import wardrobe_northwest_arms
import wardrobe_northwest_cloaks
import wardrobe_northwest_legs
from wardrobe_weapon_carry import SHEATHED
from common import node, number, tag, use
from profiles import (
    CAST_TRAITS, PROFILES, PROFILE_VERSION, age_allows, grooming_weights, required_cast,
    weights_for, weights_for_base, weights_for_child,
)

VERSION = "rus13-ink-v1"
PORTRAIT = (320, 440, "0 0 320 440")
FULL = (320, 752, "0 0 320 752")
CHILD_FULL = FULL
CARD = (32, 32, "7 8 305 305")
STAGE = Path(__file__).with_name("stage.svg")
BACKGROUNDS = {
    "parchment": ("Тёплый сумрак", "shirt-setting"),
    "ash": ("Серый сумрак", "armor-setting"),
    "rose": ("Лиловый сумрак", "woman-setting"),
    "transparent": ("Прозрачный", None),
}
BASE_APPEARANCE = {
    "cast": {"men": "Мужская основа", "women": "Женская основа"},
    **face_shape.OPTIONS,
    **face_features.OPTIONS,
    **{key: value for key, value in hair_headgear.OPTIONS.items() if key != "headgear"},
    "body": wardrobe.OPTIONS["body"],
}
DETAIL_OPTIONS = {**face_shape.DETAILS, **face_features.EYE_DETAILS, **nose_mouth.DETAILS}
OPTIONAL_APPEARANCE = {**GROWTH_OPTIONS, "hair_length": HAIR_LENGTHS}
APPEARANCE = {**BASE_APPEARANCE, **DETAIL_OPTIONS, **OPTIONAL_APPEARANCE}
BASE_EQUIPMENT = {
    **{key: value for key, value in wardrobe.OPTIONS.items() if key != "body"},
    "headgear": hair_headgear.OPTIONS["headgear"],
    "background": {key: value[0] for key, value in BACKGROUNDS.items()},
}
OPTIONAL_EQUIPMENT = {
    **wardrobe_northwest_legs.OPTIONS,
    **wardrobe_northwest_accessories.OPTIONS,
    **wardrobe_northwest_cloaks.OPTIONS,
    **wardrobe_northwest_arms.OPTIONS,
    **wardrobe_northwest_archery.OPTIONS,
    **EXTRA_EQUIPMENT,
    **MATERIAL_OPTIONS,
}
EQUIPMENT = {
    **BASE_EQUIPMENT,
    **{field: {"auto": "По комплекту", **options} for field, options in OPTIONAL_EQUIPMENT.items()},
}
for field in MATERIAL_OPTIONS:
    EQUIPMENT[field]["auto"] = "По фасону"

_MANUAL_CLOTHING = frozenset(key for key in REFERENCE_AGES if key[1] not in ITEM_ESTATES.get(key[0], {}))
EQUIPMENT_CASTS = {"outfit": dict(wardrobe.ADULT_CASTS), "headgear": dict(headwear.ADULT_CASTS)}
for (field, item), casts in REFERENCE_CASTS.items():
    if (field, item) in _MANUAL_CLOTHING and len(casts) == 1 and None not in casts:
        EQUIPMENT_CASTS.setdefault(field, {})[item] = next(iter(casts))

_ARMAMENT_FIELDS = ("weapon", "carry", "shield", "shield_carry", "bow", "bow_case", "quiver")
_ADULT_EQUIPMENT = {
    "outfit": (*wardrobe.ADULT_CASTS, *wardrobe.NORTHWEST_ARMOR),
    "headgear": (*headwear.ADULT_CASTS, *hair_headgear.NORTHWEST_HELMETS),
    "belt_pouch": ("sheathed_belt_knife", "knife_sheath"),
    **{field: tuple(choice for choice in EQUIPMENT[field] if choice not in {"auto", "none"})
       for field in _ARMAMENT_FIELDS},
}
for (field, item), ages in REFERENCE_AGES.items():
    if (field, item) in _MANUAL_CLOTHING and ages == {"adult"} and field in {"outfit", "headgear", "cloak", "vestment"}:
        _ADULT_EQUIPMENT[field] = (*_ADULT_EQUIPMENT.get(field, ()), item)
_HELMETS = {"helmet", "tall_helmet", *hair_headgear.NORTHWEST_HELMETS}
_ARMOR_AND_HELMETS = {"outfit": wardrobe.ARMORED_OUTFITS, "headgear": _HELMETS}
_CHILD_EQUIPMENT = {
    "outfit": frozenset(wardrobe._CHILD_DRAWERS),
    "headgear": frozenset(choice for choice in EQUIPMENT["headgear"] if choice.startswith("child_")),
}
_CHILD_ONLY = {}
for (field, item), ages in REFERENCE_AGES.items():
    if (field, item) in _MANUAL_CLOTHING and ages == {"child"}:
        _CHILD_ONLY.setdefault(field, set()).add(item)
for field, items in _CHILD_ONLY.items():
    _CHILD_EQUIPMENT[field] = _CHILD_EQUIPMENT.get(field, frozenset()) | items
_AUTO_EQUIPMENT_CASTS = {
    **EQUIPMENT_CASTS,
    "outfit": {
        **EQUIPMENT_CASTS["outfit"],
        **dict.fromkeys((*wardrobe.ARMORED_OUTFITS, "steppe_robe", "kariginu", "tellem_tunic"), "men"),
        **dict.fromkeys(("tang_jacket", "steppe_dress", "tellem_wrap"), "women"),
    },
    "headgear": {
        **EQUIPMENT_CASTS["headgear"],
        **dict.fromkeys((*_HELMETS, "eboshi", "tellem_cap"), "men"),
        **dict.fromkeys(("wrap", "temple_rings", "shoulder_veil", "wimple", "bocca", "weimao",
                         "child_rus_browband", "child_song_pearl_ribbons"), "women"),
    },
    **{field: dict.fromkeys(_ADULT_EQUIPMENT[field], "men") for field in _ARMAMENT_FIELDS},
}
LABELS = {
    "cast": "Пол",
    **face_shape.LABELS,
    **face_features.LABELS,
    **face_shape.DETAIL_LABELS,
    **face_features.EYE_DETAIL_LABELS,
    **nose_mouth.DETAIL_LABELS,
    **hair_headgear.LABELS,
    **GROWTH_LABELS,
    "hair_length": "Длина волос",
    **wardrobe.LABELS,
    **wardrobe_northwest_legs.LABELS,
    **wardrobe_northwest_accessories.LABELS,
    **wardrobe_northwest_cloaks.LABELS,
    **wardrobe_northwest_arms.LABELS,
    **wardrobe_northwest_archery.LABELS,
    **EXTRA_LABELS,
    **MATERIAL_LABELS,
    "background": "Фон",
}
MANUAL_FIELDS = {"gaze", "expression", "skin_state", "asymmetry"}
_DETAIL_STANDARD_WEIGHTS = {"chin_mark": 5, "freckle_pattern": 9, "philtrum": 4}


def _validate(values, options):
    for field, choice in values.items():
        if field not in options:
            raise ValueError(f"Неизвестное поле {field!r}")
        if not isinstance(choice, str) or choice not in options[field]:
            allowed = ", ".join(options[field])
            raise ValueError(f"{field}={choice!r}. Возможные значения — {allowed}")


def _restore_retired_moustache(appearance):
    if appearance.get("moustache") == "uneven_sweep":
        return {**appearance, "moustache": "solid_straight"}
    return appearance


def _matches_cast(cast, field, choice):
    return required_cast(field, choice) in (None, cast)


def _validate_traits(values, cast, age):
    for field, choice in values.items():
        if not age_allows(age, field, choice):
            allowed_age = "более старшего возраста" if age == "child" else "детского возраста 5–7 лет"
            raise ValueError(f"{LABELS[field]} «{APPEARANCE[field][choice]}» — вариант для {allowed_age}.")
        required = required_cast(field, choice)
        if required is not None and required != cast:
            allowed = "мужской" if required == "men" else "женской"
            raise ValueError(f"{LABELS[field]} «{APPEARANCE[field][choice]}» — только для {allowed} основы.")
    length, style = values.get("hair_length"), values.get("hair_style")
    if style is not None and not length_allows(length, style):
        label = APPEARANCE["hair_style"][style]
        if length is None:
            raise ValueError(f"Для причёски «{label}» укажите длину волос.")
        raise ValueError(f"Причёска «{label}» недоступна при длине «{HAIR_LENGTHS[length]}».")


def _seeded_choice(seed, field, choices):
    key = json.dumps([VERSION, str(seed), field], ensure_ascii=False).encode("utf-8")
    index = int.from_bytes(sha256(key).digest()[:8], "big")
    return choices[index % len(choices)]


def _validate_profile(profile):
    if profile is not None and (not isinstance(profile, str) or profile not in PROFILES):
        raise ValueError(f"Неизвестный профиль внешности {profile!r}")


def detail_weights(field):
    weights = dict.fromkeys(DETAIL_OPTIONS[field], 1)
    weights["standard"] = _DETAIL_STANDARD_WEIGHTS.get(field, 3)
    return weights


def resolve_appearance(
    seed, overrides=None, *, defaults=False, profile=None, extended=False, expanded_hair=False, distinct_bases=None,
    cast_traits=None,
):
    requested = _restore_retired_moustache(dict(overrides or {}))
    _validate(requested, APPEARANCE)
    _validate_profile(profile)
    if distinct_bases is None:
        distinct_bases = extended
    if cast_traits is None:
        cast_traits = distinct_bases
    casts = tuple(APPEARANCE["cast"])
    cast = requested.get("cast")
    if cast is None:
        cast = casts[0] if defaults else _seeded_choice(seed, "cast", casts)
    ages = tuple(value for value in APPEARANCE["age"] if value != "child")
    age = requested.get("age")
    if age is None:
        age = ages[0] if defaults else _seeded_choice(seed, "age", ages)
    _validate_traits(requested, cast, age)
    hair_length = requested.get("hair_length")
    resolved = {"cast": cast}
    for field, choices in APPEARANCE.items():
        if field == "cast":
            continue
        if field == "age":
            resolved[field] = age
            continue
        if field in requested:
            resolved[field] = requested[field]
            continue
        if field in OPTIONAL_APPEARANCE:
            continue
        if field in DETAIL_OPTIONS and not extended:
            continue
        variants = None
        if not expanded_hair and (field != "hair_style" or hair_length is None):
            variants = hair_headgear.LEGACY_STYLE_IDS.get(field)
        if variants is None:
            variants = tuple(choices)
        if field in MANUAL_FIELDS or (field in {"beard", "moustache"} and cast == "women"):
            resolved[field] = variants[0]
            continue
        new_traits = CAST_TRAITS.get(field)
        if new_traits:
            variants = tuple(choice for choice in variants if choice not in new_traits
                             or (cast_traits and new_traits[choice] == cast))
        variants = tuple(choice for choice in variants
                         if age_allows(age, field, choice) and _matches_cast(cast, field, choice))
        if field == "hair_style":
            variants = tuple(style for style in variants if length_allows(hair_length, style))
        if field in DETAIL_OPTIONS:
            weights = detail_weights(field)
        else:
            weights = weights_for(profile or "free", field, variants)
        if age == "child":
            weights = weights_for_child(cast, field, weights)
        elif distinct_bases or cast_traits:
            weights = weights_for_base(cast, field, weights, cast_traits=cast_traits)
        weights = grooming_weights(profile, cast, age, field, weights, hair_length=hair_length)
        if field in {"beard", "moustache"} and requested.get(f"{field}_growth") not in {None, "shaved"}:
            weights["none"] = 0
        if defaults:
            resolved[field] = max(weights, key=weights.get)
            continue
        pool = tuple(choice for choice in variants for _ in range(weights[choice]))
        if field in {"marks", "beard", "moustache"} and weights[variants[0]] > 0:
            pool = (variants[0],) * 4 + pool
        resolved[field] = _seeded_choice(seed, field, pool)
    return resolved


def revise_appearance(seed, previous, overrides, *, profile=None):
    """Apply changes to a resolved appearance, choosing a new hairstyle if the old one no longer fits."""
    _validate(overrides, APPEARANCE)
    cast = overrides.get("cast", previous["cast"])
    age = overrides.get("age", previous["age"])
    length = overrides.get("hair_length", previous.get("hair_length"))
    inherited = {field: choice for field, choice in previous.items()
                 if _matches_cast(cast, field, choice) and age_allows(age, field, choice)}
    if "hair_style" in inherited and not length_allows(length, inherited["hair_style"]):
        inherited.pop("hair_style")
    return resolve_appearance(seed, {**inherited, **overrides}, profile=profile, cast_traits=cast != previous["cast"])


def equipment_allows(field, choice, appearance):
    required = EQUIPMENT_CASTS.get(field, {}).get(choice)
    if appearance["age"] == "child":
        if choice in _ADULT_EQUIPMENT.get(field, ()) and choice not in _CHILD_ONLY.get(field, ()):
            return False
    elif choice in _CHILD_ONLY.get(field, ()):
        return False
    return required is None or appearance["cast"] == required


def _generated_equipment_allows(field, choice, appearance):
    if not equipment_allows(field, choice, appearance):
        return False
    if _AUTO_EQUIPMENT_CASTS.get(field, {}).get(choice) not in (None, appearance["cast"]):
        return False
    if appearance["age"] == "child":
        return choice not in _ARMOR_AND_HELMETS.get(field, ())
    return choice not in _CHILD_EQUIPMENT.get(field, ())


def _validate_equipment_traits(equipment, appearance):
    for field, choice in equipment.items():
        if not equipment_allows(field, choice, appearance):
            if choice in _CHILD_ONLY.get(field, ()) and appearance["age"] != "child":
                raise ValueError(f"«{EQUIPMENT[field][choice]}» доступно детям 5–7 лет.")
            cast = EQUIPMENT_CASTS.get(field, {}).get(choice)
            if cast is None:
                raise ValueError(f"«{EQUIPMENT[field][choice]}» доступно персонажам старше детского возраста.")
            label = "мужской" if cast == "men" else "женской"
            raise ValueError(f"«{EQUIPMENT[field][choice]}» доступно на {label} основе старше детского возраста.")


def resolve_equipment(overrides=None, *, appearance=None):
    requested = dict(overrides or {})
    _validate(requested, EQUIPMENT)
    if appearance is not None:
        if appearance["age"] == "child":
            for field in _ARMAMENT_FIELDS:
                requested.pop(field, None)
        _validate_equipment_traits(requested, appearance)
    equipment = {field: requested.get(field, next(iter(options))) for field, options in BASE_EQUIPMENT.items()}
    equipment.update({
        field: requested[field] for field in OPTIONAL_EQUIPMENT
        if requested.get(field, "auto") != "auto"
    })
    validate_materials(equipment)
    return equipment


def _validate_estate(estate):
    if estate is not None and (not isinstance(estate, str) or estate not in ESTATES):
        raise ValueError("Выберите сословие из списка.")


def _generated_base(seed, traits, gear):
    pairs = []
    for cast in APPEARANCE["cast"]:
        for age in APPEARANCE["age"]:
            if traits.get("cast", cast) != cast or traits.get("age", age) != age:
                continue
            if not all(_matches_cast(cast, field, value) and age_allows(age, field, value)
                       for field, value in traits.items()):
                continue
            base = {"cast": cast, "age": age}
            if all(_generated_equipment_allows(field, value, base) for field, value in gear.items()):
                pairs.append((cast, age))
    if not pairs:
        raise ValueError("Выбранные черты и вещи несовместимы с одной основой и возрастом.")
    cast = _seeded_choice(seed, "cast", tuple(dict.fromkeys(cast for cast, _ in pairs)))
    weights = {"adult": 6, "young": 3, "old": 2, "child": 2}
    ages = tuple(age for base, age in pairs if base == cast for _ in range(weights[age]))
    return cast, _seeded_choice(seed, "age", ages)


def _generated_appearance(seed, profile, traits):
    face_seed = json.dumps([seed, profile], ensure_ascii=False)
    if "hair_length" not in traits:
        style = traits.get("hair_style")
        if style is not None:
            lengths = tuple(length for length in HAIR_LENGTHS if length_allows(length, style))
        elif traits["cast"] == "women":
            lengths = ("long",)
        else:
            lengths = ("short", "medium", "long")
        traits["hair_length"] = _seeded_choice(face_seed, "hair_length", lengths)
    appearance = resolve_appearance(face_seed, traits, profile=profile, extended=True, expanded_hair=True)
    for field in ("beard", "moustache"):
        growth = field + "_growth"
        if appearance[field] != "none" and growth not in traits:
            lengths = ("short", "medium", "full")
            if traits["age"] == "young":
                lengths = ("stubble", "short", "medium")
            appearance[growth] = _seeded_choice(face_seed, growth, lengths)
    return appearance


_BUNDLED_CLOAKS = {"cloak", *wardrobe._DRAPED_CLOAKS}


def _generated_equipment(seed, culture, estate, appearance, overrides):
    gear = dict(overrides)
    child = appearance["age"] == "child"

    def choose(field, *, eligible=lambda choice: True, prefer=None, weight=1):
        if field in gear:
            return gear[field]
        options = tuple(choice for choice in EQUIPMENT[field]
                        if choice != "auto" and (field, choice) not in _MANUAL_CLOTHING
                        and estate in estates_for_item(field, choice)
                        and culture in cultures_for_item(field, choice)
                        and _generated_equipment_allows(field, choice, appearance) and eligible(choice))
        if not options:
            return None
        preference = (prefer,) * weight if prefer in options else ()
        gear[field] = _seeded_choice(seed, "equipment." + field, options + preference)
        return gear[field]

    pinned_helmet = gear.get("headgear") in _HELMETS
    outfit = choose("outfit", eligible=lambda choice: not pinned_helmet or choice in wardrobe.ARMORED_OUTFITS)
    if outfit is None:
        outfit = choose("outfit")
    if outfit is None:
        raise ValueError("В выбранном гардеробе нет одежды для этого персонажа.")
    armoured = outfit in wardrobe.ARMORED_OUTFITS
    choose("headgear", eligible=lambda choice: choice not in _HELMETS or armoured, prefer="none", weight=3)
    choose("cloth_color", prefer="natural", weight=3)
    choose("footwear")
    choose("trousers", eligible=lambda choice: (choice == "none") == (culture == "bandiagara"))
    choose("leg_wraps", prefer="none", weight=3)
    if outfit not in _BUNDLED_CLOAKS:
        choose("cloak", prefer="none", weight=5)
    if outfit not in wardrobe.BELTLESS_OUTFITS:
        belt = choose("belt", prefer="none", weight=1)
        if belt != "none" and gear.get("accessory") != "pouch":
            choose("belt_pouch", prefer="none", weight=4)
    if not armoured and gear.get("accessory") not in {"brooch", "pendant"}:
        choose("jewelry", prefer="none", weight=5)
    if not child and appearance["cast"] == "men":
        weapon = choose("weapon", prefer="none", weight=4 if armoured else 36)
        if armoured or weapon not in {None, "none", "auto"}:
            choose("shield", prefer="none", weight=3 if armoured else 14)
        choose("bow", prefer="none", weight=7 if armoured else 20)
    if gear.get("bow") in {"novgorod_composite", "northern_wood"}:
        choose("quiver", prefer="birchbark", weight=1)
        if gear["bow"] == "novgorod_composite":
            choose("bow_case", prefer="plain_leather", weight=1)
    if gear.get("weapon") not in {None, "none", "auto"} or gear.get("bow") not in {None, "none", "auto"}:
        gear.setdefault("carry", "carried")
    if gear.get("shield") not in {None, "none", "auto"}:
        positions = ("back",) if gear.get("cloak") in wardrobe.HANDHELD_HIDDEN_BY["shield"] else ("held", "back")
        gear.setdefault("shield_carry", _seeded_choice(seed, "equipment.shield_carry", positions))
    choose("background", eligible=lambda choice: choice != "transparent", prefer="ash" if armoured else "parchment", weight=2)
    return resolve_equipment(gear, appearance=appearance)


def generate_character(seed, *, profile=None, estate=None, appearance=None, equipment=None):
    """Resolve automatic choices and preserve the compatible choices supplied by the caller."""
    seed = str(seed)
    _validate_profile(profile)
    _validate_estate(estate)
    traits = _restore_retired_moustache(dict(appearance or {}))
    gear = dict(equipment or {})
    _validate(traits, APPEARANCE)
    _validate(gear, EQUIPMENT)
    gear = {field: value for field, value in gear.items() if value != "auto"}
    if traits.get("age") == "child":
        gear = {field: value for field, value in gear.items() if field not in _ARMAMENT_FIELDS}
    if profile is None:
        profiles = tuple(name for name, cultures in PROFILE_CULTURES.items() if compatible_cultures(cultures, gear))
        if not profiles:
            raise ValueError("Выбранные вещи не образуют гардероб одного профиля. Для ручного комплекта доступен «Свободный выбор».")
        profile = _seeded_choice(seed, "profile", profiles)
    cultures = PROFILE_CULTURES.get(profile, AUTO_CULTURES)
    compatible = compatible_cultures(cultures, gear)
    if not compatible and profile != "free":
        raise ValueError("Выбранные вещи не сочетаются в гардеробе этого профиля.")
    if not compatible and "outfit" in gear:
        compatible = compatible_cultures(CULTURES, gear) or cultures_for_item("outfit", gear["outfit"])
    culture = _seeded_choice(seed, "culture", compatible or cultures)
    traits["cast"], traits["age"] = _generated_base(seed, traits, gear)
    if estate is None:
        common = tuple(name for name in ESTATES
                       if all(name in estates_for_item(field, value) for field, value in gear.items()))
        estate = _seeded_choice(seed, "estate", common or tuple(ESTATES))
    resolved = _generated_appearance(seed, profile, traits)
    equipment = _generated_equipment(seed, culture, estate, resolved, gear)
    return save_recipe(seed, resolved, equipment, profile=profile, estate=estate, culture=culture)


def save_recipe(seed, appearance, equipment, *, profile=None, estate=None, culture=None):
    _validate_profile(profile)
    _validate_estate(estate)
    appearance = _restore_retired_moustache(appearance)
    _validate(appearance, APPEARANCE)
    _validate_traits(appearance, appearance["cast"], appearance["age"])
    _validate(equipment, EQUIPMENT)
    _validate_equipment_traits(equipment, appearance)
    validate_materials(equipment)
    recipe = {
        "version": VERSION,
        "seed": str(seed),
        "appearance": dict(appearance),
        "equipment": dict(equipment),
    }
    if profile is not None:
        recipe.update(profile=profile, profile_version=PROFILE_VERSION)
    if estate is not None:
        recipe["estate"] = estate
    if culture is not None:
        if not isinstance(culture, str) or culture not in CULTURES:
            raise ValueError("Выберите культуру из каталога.")
        recipe["culture"] = culture
    return recipe


def load_recipe(source):
    data = json.loads(Path(source).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("version") != VERSION:
        raise ValueError(f"Поддерживается версия {VERSION}")
    appearance = _restore_retired_moustache(data["appearance"])
    _validate(appearance, APPEARANCE)
    if not BASE_APPEARANCE.keys() <= appearance.keys():
        raise ValueError("В сохранённой внешности отсутствуют поля")
    if appearance["cast"] == "women" and appearance["age"] != "child":
        appearance = {**appearance, "beard": "none", "moustache": "none"}
    equipment = resolve_equipment(data["equipment"], appearance=appearance)
    estate = data.get("estate")
    recipe = save_recipe(data["seed"], appearance, equipment, profile=data.get("profile"),
                         estate=None if estate == "foreigners" else estate, culture=data.get("culture"))
    if "profile_version" in data and "profile" in recipe:
        recipe["profile_version"] = data["profile_version"]
    return recipe


def render_svg(appearance, equipment=None, *, view="portrait", title="Портрет Rus13"):
    appearance = _restore_retired_moustache(appearance)
    _validate(appearance, APPEARANCE)
    if not BASE_APPEARANCE.keys() <= appearance.keys():
        raise ValueError("Передайте полный набор полей из resolve_appearance")
    _validate_traits(appearance, appearance["cast"], appearance["age"])
    if view not in {"portrait", "card", "full"}:
        raise ValueError("Формат должен быть full, portrait или card")
    gear = default_materials(resolve_equipment(equipment, appearance=appearance), _MANUAL_CLOTHING)
    if view == "card":
        root = _draw_figure(appearance, gear, view=view, title=title)
        apply_materials(root, gear)
        return ET.tostring(root, encoding="unicode")

    from full_costume import full_svg

    svg = full_svg(appearance, gear, title=title, portrait=view == "portrait")
    if MATERIAL_OPTIONS.keys().isdisjoint(gear):
        return svg
    root = ET.fromstring(svg)
    apply_materials(root, gear)
    return ET.tostring(root, encoding="unicode")


def render_clothing_detail(equipment):
    slot = "insole" if equipment.get("insole", "none") != "none" else "footwear"
    style = equipment.get(slot)
    if slot == "footwear" and style != "embroidered_high_boots":
        return None
    root = ET.Element(tag("svg"), width="320", height="200", viewBox="0 0 320 200", role="img")
    node(root, "title").text = EQUIPMENT[slot][style]
    root.append(ET.parse(STAGE).getroot().find(tag("defs")))
    wardrobe_northwest_legs.draw_detail(root, slot, style)
    apply_materials(root, default_materials(equipment, _MANUAL_CLOTHING))
    return ET.tostring(root, encoding="unicode")


def _draw_figure(appearance, gear, *, view, title, handheld=None):
    look = {**appearance, **gear}
    full = view == "full"
    width, height, viewbox = FULL if full else CARD
    root = ET.Element(tag("svg"), width=str(width), height=str(height), viewBox=viewbox,
                      role="img", attrib={"aria-labelledby": "title"})
    if "belt" in gear:
        root.set("data-belt", gear["belt"])
    node(root, "title", id="title").text = title
    defs = ET.parse(STAGE).getroot().find(tag("defs"))
    root.append(defs)
    frame = node(defs, "clipPath", id="portrait-frame")
    node(frame, "rect", width=PORTRAIT[0], height=height if full else PORTRAIT[1])
    subject = node(root, "g", clip_path="url(#portrait-frame)")
    setting = BACKGROUNDS[gear["background"]][1]
    if setting:
        use(subject, setting)
    head = face_shape.make_head(look)
    coverage = hair_headgear.COVERAGE[gear["headgear"]]
    if coverage["hair"]:
        hair_headgear.draw_back_hair(subject, defs, look, head)
    if coverage["neck"]:
        neck = node(subject, "g", data_part="neck")
        face_shape.draw_neck(neck, look, head)
    wardrobe.draw_outfit(subject, defs, look, head, full=full)
    if view == "full":
        wardrobe.draw_shoulder_straps(subject, look)
    if view == "full" and gear.get("cloak", "none") != "none":
        wardrobe.draw_waist_accessories(root, look, full=True)
        if handheld is not None:
            root.append(handheld)
        wardrobe.draw_cloak_layer(root, look, head)
        wardrobe.draw_shield_sling(root, defs, look)
        foreground = node(root, "g", data_part="head-over-cloak", clip_path="url(#portrait-frame)")
    else:
        foreground = subject
        if view == "full":
            wardrobe.draw_shield_sling(subject, defs, look)
    if view != "full":
        wardrobe.draw_waist_accessories(subject, look)
        wardrobe.draw_cloak_layer(subject, look, head)
    hair_headgear.draw_headgear_base(foreground, defs, look, head)
    face_parent = foreground
    if gear["headgear"] == "nw_great_helm":
        face_parent = node(foreground, "g", id="face-under-closed-helm", visibility="hidden")
    face_shape.draw_skin(face_parent, defs, look, head, show_ears=coverage["ears"])
    face = node(face_parent, "g", clip_path="url(#face-shape-clip)")
    compact_mouth = view == "card" and hair_headgear.has_dense_card_moustache(look)
    face_features.draw_features(face, defs, look, head, compact_mouth=compact_mouth)
    hair_headgear.draw_facial_hair(foreground, defs, look, head, card=view == "card")
    band_hair = hair_headgear.draw_hair(foreground, defs, look, head) if coverage["hair"] else None
    hair_headgear.draw_headgear_top(foreground, defs, look, head, band_hair=band_hair, card=view == "card")
    if view == "card" and gear["headgear"] in headwear.FOREHEAD_BANDS:
        # Center the cloth on a row boundary so both colors survive low-resolution sampling.
        band = foreground.find(".//*[@data-part='forehead-band']")
        center = float(band.get("data-center-y"))
        _, crop_top, _, crop_height = map(float, CARD[2].split())
        pixel = crop_height / CARD[1]
        cloth_height = float(band.get("data-band-height"))
        # With room for just one cloth row, separate it cleanly from the visible scalp.
        scalp_edge = (gear["headgear"] == "rus_folded_headband" and cloth_height < pixel
                      and band.get("data-headband-base") == "scalp")
        anchor = center - cloth_height / 2 if scalp_edge else center
        nearest_boundary = crop_top + round((anchor - crop_top) / pixel) * pixel
        narrow_adjustment = 0 if scalp_edge else min(1.25, max(0, 10 - cloth_height) * .66)
        shift = number(nearest_boundary - anchor - narrow_adjustment)
        subject.set("transform", f"translate(0 {shift})")
        subject.set("data-headband-card-shift", shift)
    wardrobe_northwest_accessories.draw_head_jewelry(
        foreground, look, head, show_ears=coverage["ears"], show_hair=coverage["hair"],
    )
    return root


def _catalog():
    exclusive_traits = {}
    age_restrictions = {age: {} for age in APPEARANCE["age"]}
    for field, options in APPEARANCE.items():
        restricted = {value: cast for value in options if (cast := required_cast(field, value))}
        if restricted:
            exclusive_traits[field] = restricted
        for age, restrictions in age_restrictions.items():
            unavailable = [value for value in options if not age_allows(age, field, value)]
            if unavailable:
                restrictions[field] = unavailable
    age_restrictions["child"].update({field: [item for item in choices if item not in _CHILD_ONLY.get(field, ())]
                                      for field, choices in _ADULT_EQUIPMENT.items()})
    for age, restrictions in age_restrictions.items():
        if age != "child":
            restrictions.update({field: sorted(items) for field, items in _CHILD_ONLY.items()})
    generated_age_restrictions = {
        age: {**restrictions, **{field: sorted(set(restrictions.get(field, ())) | choices)
                                for field, choices in (_ARMOR_AND_HELMETS if age == "child" else _CHILD_EQUIPMENT).items()}}
        for age, restrictions in age_restrictions.items()
    }
    return {
        "version": VERSION,
        "appearance": {key: {"label": LABELS[key], "values": values} for key, values in APPEARANCE.items()},
        "equipment": {key: {"label": LABELS[key], "values": values} for key, values in EQUIPMENT.items()},
        "equipment_materials": MATERIAL_CHOICES,
        "material_slots": {field: MATERIAL_FIELDS[field][0] for field in MATERIAL_OPTIONS},
        "exclusive_traits": exclusive_traits,
        "age_restrictions": age_restrictions,
        "equipment_casts": EQUIPMENT_CASTS,
        "generated_equipment_casts": _AUTO_EQUIPMENT_CASTS,
        "generated_age_restrictions": generated_age_restrictions,
        "estates": ESTATES,
        "equipment_estates": {field: {item: list(estates_for_item(field, item)) for item in options}
                              for field, options in EQUIPMENT.items()},
        "cultures": CULTURES,
        "profile_cultures": PROFILE_CULTURES,
        "equipment_cultures": {field: {item: list(cultures_for_item(field, item)) for item in options}
                               for field, options in EQUIPMENT.items()},
        "jewelry_hidden_by": sorted(wardrobe.ARMORED_OUTFITS),
        "cloak_coverage": wardrobe_northwest_cloaks.COVERAGE,
        "headgear_coverage": hair_headgear.AVENTAIL_COVERAGE,
        "handheld_hidden_by": {field: list(cloaks) for field, cloaks in wardrobe.HANDHELD_HIDDEN_BY.items()},
        "weapon_groups": wardrobe_northwest_arms.WEAPON_GROUPS,
        "sheathed_weapons": sorted(SHEATHED),
        "back_weapons": sorted(wardrobe_northwest_arms.BACK_WEAPONS),
        "hair_styles_by_length": {
            "default": [style for style in APPEARANCE["hair_style"] if length_allows(None, style)],
            **{length: list(styles) for length, styles in STYLES_BY_LENGTH.items()},
        },
    }


def _selection(entries):
    result = {}
    for entry in entries:
        name, sep, value = entry.partition("=")
        if not sep or not name or not value or name in result:
            raise ValueError(f"Укажите уникальное поле в виде имя=значение, получено {entry!r}")
        result[name] = value
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="Создать SVG-портрет Rus13")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("seed", nargs="?")
    source.add_argument("--recipe", type=Path, help="Восстановить сохранённую внешность")
    parser.add_argument("--defaults", action="store_true")
    parser.add_argument("--extended", action="store_true", help="Подбирать дополнительные черты при создании по seed")
    parser.add_argument("--expanded-hair", action="store_true", help="Подбирать из расширенного каталога причёсок, бород и усов")
    parser.add_argument("--profile", choices=(*PROFILES, "auto"), help="Художественный набор автоматического выбора")
    parser.add_argument("--generate", action="store_true", help="Подобрать внешность, сословие и вещи по seed")
    parser.add_argument("--estate", choices=(*ESTATES, "auto"), help="Сословие для подбора вещей")
    parser.add_argument("--cast", choices=APPEARANCE["cast"])
    parser.add_argument("--outfit", choices=EQUIPMENT["outfit"])
    parser.add_argument("--headgear", choices=EQUIPMENT["headgear"])
    parser.add_argument("--background", choices=EQUIPMENT["background"])
    parser.add_argument("--cloth-color", choices=EQUIPMENT["cloth_color"])
    parser.add_argument("--accessory", choices=EQUIPMENT["accessory"])
    for field in OPTIONAL_EQUIPMENT:
        parser.add_argument("--" + field.replace("_", "-"), choices=EQUIPMENT[field])
    parser.add_argument("--set", action="append", default=[], metavar="ПОЛЕ=ЗНАЧЕНИЕ")
    parser.add_argument("--view", choices=("full", "portrait", "card"), default="full")
    parser.add_argument("--output", "-o", type=Path)
    parser.add_argument("--save-recipe", type=Path)
    parser.add_argument("--options", action="store_true", help="Напечатать каталог полей и значений")
    args = parser.parse_args(argv)
    if args.options:
        sys.stdout.buffer.write((json.dumps(_catalog(), ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
        return
    if args.recipe is None and args.seed is None:
        parser.error("Укажите seed или --recipe")
    try:
        requested = _selection(args.set)
        profile = args.profile if args.profile != "auto" else None
        estate = args.estate if args.estate != "auto" else None
        culture = None
        selected_equipment = {field: getattr(args, field) for field in EQUIPMENT if getattr(args, field) is not None}
        if args.cast:
            requested["cast"] = args.cast
        if args.recipe:
            saved = load_recipe(args.recipe)
            seed = saved["seed"]
            profile = profile or saved.get("profile")
            estate = estate or saved.get("estate")
            culture = saved.get("culture")
            appearance = revise_appearance(seed, saved["appearance"], requested, profile=profile)
            equipment = {field: choice for field, choice in saved["equipment"].items()
                         if equipment_allows(field, choice, appearance)}
            equipment = resolve_equipment({**equipment, **selected_equipment}, appearance=appearance)
        elif args.generate or args.estate is not None or args.profile == "auto":
            seed = args.seed
            generated = generate_character(seed, profile=profile, estate=estate, appearance=requested,
                                           equipment=selected_equipment)
            profile, estate = generated["profile"], generated["estate"]
            culture = generated["culture"]
            appearance, equipment = generated["appearance"], generated["equipment"]
        else:
            seed = args.seed
            appearance = resolve_appearance(
                seed, requested, defaults=args.defaults, profile=profile,
                extended=args.extended, expanded_hair=args.expanded_hair,
            )
            equipment = resolve_equipment(selected_equipment, appearance=appearance)
        svg = render_svg(appearance, equipment, view=args.view)
        if args.output:
            args.output.write_text(svg + "\n", encoding="utf-8")
        else:
            sys.stdout.buffer.write((svg + "\n").encode("utf-8"))
        if args.save_recipe:
            args.save_recipe.write_text(
                json.dumps(save_recipe(seed, appearance, equipment, profile=profile, estate=estate, culture=culture),
                           ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
    except (ValueError, KeyError, OSError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
