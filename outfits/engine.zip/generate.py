import argparse
import json
import sys
from hashlib import sha256
from pathlib import Path
from xml.etree import ElementTree as ET

import face_features
import face_shape
import hair_headgear
import nose_mouth
import wardrobe
from common import node, tag, use
from profiles import (
    CAST_TRAITS, PROFILES, PROFILE_VERSION, age_allows, required_cast, weights_for, weights_for_base, weights_for_child,
)

VERSION = "rus13-ink-v1"
PORTRAIT = (320, 440, "0 0 320 440")
CARD = (32, 32, "7 8 305 305")
STAGE = Path(__file__).with_name("stage.svg")
BACKGROUNDS = {
    "parchment": ("Тёплый сумрак", "shirt-setting"),
    "ash": ("Серый сумрак", "armor-setting"),
    "rose": ("Лиловый сумрак", "woman-setting"),
    "transparent": ("Прозрачный", None),
}
BASE_APPEARANCE = {
    "cast": {"men": "Мужская основа", "women": "Женская основа"},
    **face_shape.OPTIONS,
    **face_features.OPTIONS,
    **{key: value for key, value in hair_headgear.OPTIONS.items() if key != "headgear"},
    "body": wardrobe.OPTIONS["body"],
}
DETAIL_OPTIONS = {**face_shape.DETAILS, **face_features.EYE_DETAILS, **nose_mouth.DETAILS}
APPEARANCE = {**BASE_APPEARANCE, **DETAIL_OPTIONS}
EQUIPMENT = {
    **{key: value for key, value in wardrobe.OPTIONS.items() if key != "body"},
    "headgear": hair_headgear.OPTIONS["headgear"],
    "background": {key: value[0] for key, value in BACKGROUNDS.items()},
}
LABELS = {
    "cast": "Основа",
    **face_shape.LABELS,
    **face_features.LABELS,
    **face_shape.DETAIL_LABELS,
    **face_features.EYE_DETAIL_LABELS,
    **nose_mouth.DETAIL_LABELS,
    **hair_headgear.LABELS,
    **wardrobe.LABELS,
    "background": "Фон",
}
MANUAL_FIELDS = {"gaze", "expression", "skin_state", "asymmetry"}
_DETAIL_STANDARD_WEIGHTS = {"chin_mark": 5, "freckle_pattern": 9, "philtrum": 4}


def _validate(values, options):
    for field, choice in values.items():
        if field not in options:
            raise ValueError(f"Неизвестное поле {field!r}")
        if not isinstance(choice, str) or choice not in options[field]:
            allowed = ", ".join(options[field])
            raise ValueError(f"{field}={choice!r}. Возможные значения — {allowed}")


def _matches_cast(cast, field, choice):
    return required_cast(field, choice) in (None, cast)


def _validate_traits(values, cast, age):
    for field, choice in values.items():
        if not age_allows(age, field, choice):
            raise ValueError(f"{LABELS[field]} «{APPEARANCE[field][choice]}» — вариант для более старшего возраста.")
        required = required_cast(field, choice)
        if required is not None and required != cast:
            allowed = "мужской" if required == "men" else "женской"
            raise ValueError(f"{LABELS[field]} «{APPEARANCE[field][choice]}» — только для {allowed} основы.")


def _seeded_choice(seed, field, choices):
    key = json.dumps([VERSION, str(seed), field], ensure_ascii=False).encode("utf-8")
    index = int.from_bytes(sha256(key).digest()[:8], "big")
    return choices[index % len(choices)]


def _validate_profile(profile):
    if profile is not None and (not isinstance(profile, str) or profile not in PROFILES):
        raise ValueError(f"Неизвестный профиль внешности {profile!r}")


def detail_weights(field):
    weights = dict.fromkeys(DETAIL_OPTIONS[field], 1)
    weights["standard"] = _DETAIL_STANDARD_WEIGHTS.get(field, 3)
    return weights


def resolve_appearance(
    seed, overrides=None, *, defaults=False, profile=None, extended=False, expanded_hair=False, distinct_bases=None,
    cast_traits=None,
):
    requested = dict(overrides or {})
    _validate(requested, APPEARANCE)
    _validate_profile(profile)
    if distinct_bases is None:
        distinct_bases = extended
    if cast_traits is None:
        cast_traits = distinct_bases
    casts = tuple(APPEARANCE["cast"])
    cast = requested.get("cast")
    if cast is None:
        cast = casts[0] if defaults else _seeded_choice(seed, "cast", casts)
    ages = tuple(value for value in APPEARANCE["age"] if value != "child")
    age = requested.get("age")
    if age is None:
        age = ages[0] if defaults else _seeded_choice(seed, "age", ages)
    _validate_traits(requested, cast, age)
    resolved = {"cast": cast}
    for field, choices in APPEARANCE.items():
        if field == "cast":
            continue
        if field == "age":
            resolved[field] = age
            continue
        if field in requested:
            resolved[field] = requested[field]
            continue
        if field in DETAIL_OPTIONS and not extended:
            continue
        variants = hair_headgear.LEGACY_STYLE_IDS.get(field) if not expanded_hair else None
        if variants is None:
            variants = tuple(choices)
        if field in MANUAL_FIELDS or (field in {"beard", "moustache"} and cast == "women"):
            resolved[field] = variants[0]
            continue
        new_traits = CAST_TRAITS.get(field)
        if new_traits:
            variants = tuple(choice for choice in variants if choice not in new_traits
                             or (cast_traits and new_traits[choice] == cast))
        if age == "child":
            variants = tuple(choice for choice in variants if age_allows(age, field, choice))
        if field in DETAIL_OPTIONS:
            weights = detail_weights(field)
        else:
            weights = weights_for(profile, field, variants) if profile is not None else dict.fromkeys(variants, 1)
        if age == "child":
            weights = weights_for_child(cast, field, weights)
        elif distinct_bases or cast_traits:
            weights = weights_for_base(cast, field, weights, cast_traits=cast_traits)
        if defaults:
            resolved[field] = max(weights, key=weights.get)
            continue
        pool = tuple(choice for choice in variants for _ in range(weights[choice]))
        if field in {"marks", "beard", "moustache"} and weights[variants[0]] > 0:
            pool = (variants[0],) * 4 + pool
        resolved[field] = _seeded_choice(seed, field, pool)
    return resolved


def resolve_equipment(overrides=None):
    requested = dict(overrides or {})
    _validate(requested, EQUIPMENT)
    return {field: requested.get(field, next(iter(options))) for field, options in EQUIPMENT.items()}


def save_recipe(seed, appearance, equipment, *, profile=None):
    _validate_profile(profile)
    _validate(appearance, APPEARANCE)
    _validate_traits(appearance, appearance["cast"], appearance["age"])
    recipe = {
        "version": VERSION,
        "seed": str(seed),
        "appearance": dict(appearance),
        "equipment": dict(equipment),
    }
    if profile is not None:
        recipe.update(profile=profile, profile_version=PROFILE_VERSION)
    return recipe


def load_recipe(source):
    data = json.loads(Path(source).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("version") != VERSION:
        raise ValueError(f"Поддерживается версия {VERSION}")
    appearance = data["appearance"]
    _validate(appearance, APPEARANCE)
    if not BASE_APPEARANCE.keys() <= appearance.keys():
        raise ValueError("В сохранённой внешности отсутствуют поля")
    if appearance["cast"] == "women" and appearance["age"] != "child":
        appearance = {**appearance, "beard": "none", "moustache": "none"}
    recipe = save_recipe(data["seed"], appearance, resolve_equipment(data["equipment"]), profile=data.get("profile"))
    if "profile_version" in data and "profile" in recipe:
        recipe["profile_version"] = data["profile_version"]
    return recipe


def render_svg(appearance, equipment=None, *, view="portrait", title="Портрет Rus13"):
    _validate(appearance, APPEARANCE)
    if not BASE_APPEARANCE.keys() <= appearance.keys():
        raise ValueError("Передайте полный набор полей из resolve_appearance")
    _validate_traits(appearance, appearance["cast"], appearance["age"])
    if view not in {"portrait", "card"}:
        raise ValueError("Формат должен быть portrait или card")
    gear = resolve_equipment(equipment)
    look = {**appearance, **gear}
    width, height, viewbox = CARD if view == "card" else PORTRAIT
    root = ET.Element(tag("svg"), width=str(width), height=str(height), viewBox=viewbox,
                      role="img", attrib={"aria-labelledby": "title"})
    node(root, "title", id="title").text = title
    defs = ET.parse(STAGE).getroot().find(tag("defs"))
    root.append(defs)
    frame = node(defs, "clipPath", id="portrait-frame")
    node(frame, "rect", width=PORTRAIT[0], height=PORTRAIT[1])
    subject = node(root, "g", clip_path="url(#portrait-frame)")
    setting = BACKGROUNDS[gear["background"]][1]
    if setting:
        use(subject, setting)
    head = face_shape.make_head(look)
    coverage = hair_headgear.COVERAGE[gear["headgear"]]
    if coverage["hair"]:
        hair_headgear.draw_back_hair(subject, defs, look, head)
    if coverage["neck"]:
        neck = node(subject, "g", data_part="neck")
        face_shape.draw_neck(neck, look, head)
    wardrobe.draw_outfit(subject, defs, look, head)
    hair_headgear.draw_headgear_base(subject, defs, look, head)
    face_shape.draw_skin(subject, defs, look, head, show_ears=coverage["ears"])
    face = node(subject, "g", clip_path="url(#face-shape-clip)")
    face_features.draw_features(face, defs, look, head)
    hair_headgear.draw_facial_hair(subject, defs, look, head, card=view == "card")
    if coverage["hair"]:
        hair_headgear.draw_hair(subject, defs, look, head)
    hair_headgear.draw_headgear_top(subject, defs, look, head)
    return ET.tostring(root, encoding="unicode")


def _catalog():
    exclusive_traits = {}
    child_restrictions = {}
    for field, options in APPEARANCE.items():
        restricted = {value: cast for value in options if (cast := required_cast(field, value))}
        if restricted:
            exclusive_traits[field] = restricted
        unavailable = [value for value in options if not age_allows("child", field, value)]
        if unavailable:
            child_restrictions[field] = unavailable
    return {
        "version": VERSION,
        "appearance": {key: {"label": LABELS[key], "values": values} for key, values in APPEARANCE.items()},
        "equipment": {key: {"label": LABELS[key], "values": values} for key, values in EQUIPMENT.items()},
        "exclusive_traits": exclusive_traits,
        "age_restrictions": {"child": child_restrictions},
    }


def _selection(entries):
    result = {}
    for entry in entries:
        name, sep, value = entry.partition("=")
        if not sep or not name or not value or name in result:
            raise ValueError(f"Укажите уникальное поле в виде имя=значение, получено {entry!r}")
        result[name] = value
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="Создать SVG-портрет Rus13")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("seed", nargs="?")
    source.add_argument("--recipe", type=Path, help="Восстановить сохранённую внешность")
    parser.add_argument("--defaults", action="store_true")
    parser.add_argument("--extended", action="store_true", help="Подбирать дополнительные черты при создании по seed")
    parser.add_argument("--expanded-hair", action="store_true", help="Подбирать из расширенного каталога причёсок, бород и усов")
    parser.add_argument("--profile", choices=PROFILES, help="Художественный набор автоматического выбора")
    parser.add_argument("--cast", choices=APPEARANCE["cast"])
    parser.add_argument("--outfit", choices=EQUIPMENT["outfit"])
    parser.add_argument("--headgear", choices=EQUIPMENT["headgear"])
    parser.add_argument("--background", choices=EQUIPMENT["background"])
    parser.add_argument("--cloth-color", choices=EQUIPMENT["cloth_color"])
    parser.add_argument("--accessory", choices=EQUIPMENT["accessory"])
    parser.add_argument("--set", action="append", default=[], metavar="ПОЛЕ=ЗНАЧЕНИЕ")
    parser.add_argument("--view", choices=("portrait", "card"), default="portrait")
    parser.add_argument("--output", "-o", type=Path)
    parser.add_argument("--save-recipe", type=Path)
    parser.add_argument("--options", action="store_true", help="Напечатать каталог полей и значений")
    args = parser.parse_args(argv)
    if args.options:
        sys.stdout.buffer.write((json.dumps(_catalog(), ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
        return
    if args.recipe is None and args.seed is None:
        parser.error("Укажите seed или --recipe")
    try:
        requested = _selection(args.set)
        profile = args.profile
        if args.cast:
            requested["cast"] = args.cast
        if args.recipe:
            saved = load_recipe(args.recipe)
            seed = saved["seed"]
            profile = profile or saved.get("profile")
            previous = saved["appearance"]
            cast = requested.get("cast", previous["cast"])
            age = requested.get("age", previous["age"])
            inherited = {field: value for field, value in previous.items()
                         if _matches_cast(cast, field, value) and age_allows(age, field, value)}
            appearance = resolve_appearance(seed, {**inherited, **requested}, profile=profile,
                                            cast_traits=cast != previous["cast"])
            equipment = saved["equipment"]
        else:
            seed = args.seed
            appearance = resolve_appearance(
                seed, requested, defaults=args.defaults, profile=profile,
                extended=args.extended, expanded_hair=args.expanded_hair,
            )
            equipment = {}
        equipment = resolve_equipment({**equipment, **{
            field: getattr(args, field) for field in EQUIPMENT if getattr(args, field) is not None
        }})
        svg = render_svg(appearance, equipment, view=args.view)
        if args.output:
            args.output.write_text(svg + "\n", encoding="utf-8")
        else:
            sys.stdout.buffer.write((svg + "\n").encode("utf-8"))
        if args.save_recipe:
            args.save_recipe.write_text(
                json.dumps(save_recipe(seed, appearance, equipment, profile=profile), ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
    except (ValueError, KeyError, OSError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
