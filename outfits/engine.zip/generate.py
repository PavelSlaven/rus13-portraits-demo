import argparse
import json
import sys
from hashlib import sha256
from pathlib import Path
from xml.etree import ElementTree as ET

import face_features
import face_shape
from facial_hair_growth import GROWTH_LABELS, GROWTH_OPTIONS
import hair_headgear
from hair_length import HAIR_LENGTHS, STYLES_BY_LENGTH, length_allows
import headwear
import nose_mouth
import wardrobe
from common import node, tag, use
from profiles import (
    CAST_TRAITS, PROFILES, PROFILE_VERSION, age_allows, grooming_weights, required_cast,
    weights_for, weights_for_base, weights_for_child,
)

VERSION = "rus13-ink-v1"
PORTRAIT = (320, 440, "0 0 320 440")
FULL = (320, 752, "0 0 320 752")
CHILD_FULL = (320, 680, "0 0 320 680")
CARD = (32, 32, "7 8 305 305")
STAGE = Path(__file__).with_name("stage.svg")
BACKGROUNDS = {
    "parchment": ("Тёплый сумрак", "shirt-setting"),
    "ash": ("Серый сумрак", "armor-setting"),
    "rose": ("Лиловый сумрак", "woman-setting"),
    "transparent": ("Прозрачный", None),
}
BASE_APPEARANCE = {
    "cast": {"men": "Мужская основа", "women": "Женская основа"},
    **face_shape.OPTIONS,
    **face_features.OPTIONS,
    **{key: value for key, value in hair_headgear.OPTIONS.items() if key != "headgear"},
    "body": wardrobe.OPTIONS["body"],
}
DETAIL_OPTIONS = {**face_shape.DETAILS, **face_features.EYE_DETAILS, **nose_mouth.DETAILS}
OPTIONAL_APPEARANCE = {**GROWTH_OPTIONS, "hair_length": HAIR_LENGTHS}
APPEARANCE = {**BASE_APPEARANCE, **DETAIL_OPTIONS, **OPTIONAL_APPEARANCE}
EQUIPMENT = {
    **{key: value for key, value in wardrobe.OPTIONS.items() if key != "body"},
    "headgear": hair_headgear.OPTIONS["headgear"],
    "background": {key: value[0] for key, value in BACKGROUNDS.items()},
}
EQUIPMENT_CASTS = {"outfit": wardrobe.ADULT_CASTS, "headgear": headwear.ADULT_CASTS}
_ADULT_EQUIPMENT = {
    "outfit": (*wardrobe.ADULT_CASTS, *wardrobe.NORTHWEST_ARMOR),
    "headgear": (*headwear.ADULT_CASTS, *hair_headgear.NORTHWEST_HELMETS),
}
LABELS = {
    "cast": "Основа",
    **face_shape.LABELS,
    **face_features.LABELS,
    **face_shape.DETAIL_LABELS,
    **face_features.EYE_DETAIL_LABELS,
    **nose_mouth.DETAIL_LABELS,
    **hair_headgear.LABELS,
    **GROWTH_LABELS,
    "hair_length": "Длина волос",
    **wardrobe.LABELS,
    "background": "Фон",
}
MANUAL_FIELDS = {"gaze", "expression", "skin_state", "asymmetry"}
_DETAIL_STANDARD_WEIGHTS = {"chin_mark": 5, "freckle_pattern": 9, "philtrum": 4}


def _validate(values, options):
    for field, choice in values.items():
        if field not in options:
            raise ValueError(f"Неизвестное поле {field!r}")
        if not isinstance(choice, str) or choice not in options[field]:
            allowed = ", ".join(options[field])
            raise ValueError(f"{field}={choice!r}. Возможные значения — {allowed}")


def _matches_cast(cast, field, choice):
    return required_cast(field, choice) in (None, cast)


def _validate_traits(values, cast, age):
    for field, choice in values.items():
        if not age_allows(age, field, choice):
            allowed_age = "более старшего возраста" if age == "child" else "детского возраста 5–7 лет"
            raise ValueError(f"{LABELS[field]} «{APPEARANCE[field][choice]}» — вариант для {allowed_age}.")
        required = required_cast(field, choice)
        if required is not None and required != cast:
            allowed = "мужской" if required == "men" else "женской"
            raise ValueError(f"{LABELS[field]} «{APPEARANCE[field][choice]}» — только для {allowed} основы.")
    length, style = values.get("hair_length"), values.get("hair_style")
    if style is not None and not length_allows(length, style):
        label = APPEARANCE["hair_style"][style]
        if length is None:
            raise ValueError(f"Для причёски «{label}» укажите длину волос.")
        raise ValueError(f"Причёска «{label}» недоступна при длине «{HAIR_LENGTHS[length]}».")


def _seeded_choice(seed, field, choices):
    key = json.dumps([VERSION, str(seed), field], ensure_ascii=False).encode("utf-8")
    index = int.from_bytes(sha256(key).digest()[:8], "big")
    return choices[index % len(choices)]


def _validate_profile(profile):
    if profile is not None and (not isinstance(profile, str) or profile not in PROFILES):
        raise ValueError(f"Неизвестный профиль внешности {profile!r}")


def detail_weights(field):
    weights = dict.fromkeys(DETAIL_OPTIONS[field], 1)
    weights["standard"] = _DETAIL_STANDARD_WEIGHTS.get(field, 3)
    return weights


def resolve_appearance(
    seed, overrides=None, *, defaults=False, profile=None, extended=False, expanded_hair=False, distinct_bases=None,
    cast_traits=None,
):
    requested = dict(overrides or {})
    _validate(requested, APPEARANCE)
    _validate_profile(profile)
    if distinct_bases is None:
        distinct_bases = extended
    if cast_traits is None:
        cast_traits = distinct_bases
    casts = tuple(APPEARANCE["cast"])
    cast = requested.get("cast")
    if cast is None:
        cast = casts[0] if defaults else _seeded_choice(seed, "cast", casts)
    ages = tuple(value for value in APPEARANCE["age"] if value != "child")
    age = requested.get("age")
    if age is None:
        age = ages[0] if defaults else _seeded_choice(seed, "age", ages)
    _validate_traits(requested, cast, age)
    hair_length = requested.get("hair_length")
    resolved = {"cast": cast}
    for field, choices in APPEARANCE.items():
        if field == "cast":
            continue
        if field == "age":
            resolved[field] = age
            continue
        if field in requested:
            resolved[field] = requested[field]
            continue
        if field in OPTIONAL_APPEARANCE:
            continue
        if field in DETAIL_OPTIONS and not extended:
            continue
        variants = None
        if not expanded_hair and (field != "hair_style" or hair_length is None):
            variants = hair_headgear.LEGACY_STYLE_IDS.get(field)
        if variants is None:
            variants = tuple(choices)
        if field in MANUAL_FIELDS or (field in {"beard", "moustache"} and cast == "women"):
            resolved[field] = variants[0]
            continue
        new_traits = CAST_TRAITS.get(field)
        if new_traits:
            variants = tuple(choice for choice in variants if choice not in new_traits
                             or (cast_traits and new_traits[choice] == cast))
        variants = tuple(choice for choice in variants
                         if age_allows(age, field, choice) and _matches_cast(cast, field, choice))
        if field == "hair_style":
            variants = tuple(style for style in variants if length_allows(hair_length, style))
        if field in DETAIL_OPTIONS:
            weights = detail_weights(field)
        else:
            weights = weights_for(profile or "free", field, variants)
        if age == "child":
            weights = weights_for_child(cast, field, weights)
        elif distinct_bases or cast_traits:
            weights = weights_for_base(cast, field, weights, cast_traits=cast_traits)
        weights = grooming_weights(profile, cast, age, field, weights, hair_length=hair_length)
        if defaults:
            resolved[field] = max(weights, key=weights.get)
            continue
        pool = tuple(choice for choice in variants for _ in range(weights[choice]))
        if field in {"marks", "beard", "moustache"} and weights[variants[0]] > 0:
            pool = (variants[0],) * 4 + pool
        resolved[field] = _seeded_choice(seed, field, pool)
    return resolved


def revise_appearance(seed, previous, overrides, *, profile=None):
    """Apply changes to a resolved appearance, choosing a new hairstyle if the old one no longer fits."""
    _validate(overrides, APPEARANCE)
    cast = overrides.get("cast", previous["cast"])
    age = overrides.get("age", previous["age"])
    length = overrides.get("hair_length", previous.get("hair_length"))
    inherited = {field: choice for field, choice in previous.items()
                 if _matches_cast(cast, field, choice) and age_allows(age, field, choice)}
    if "hair_style" in inherited and not length_allows(length, inherited["hair_style"]):
        inherited.pop("hair_style")
    return resolve_appearance(seed, {**inherited, **overrides}, profile=profile, cast_traits=cast != previous["cast"])


def equipment_allows(field, choice, appearance):
    required = EQUIPMENT_CASTS.get(field, {}).get(choice)
    if appearance["age"] == "child" and choice in _ADULT_EQUIPMENT.get(field, ()):
        return False
    return required is None or appearance["cast"] == required


def _validate_equipment_traits(equipment, appearance):
    for field, choice in equipment.items():
        if not equipment_allows(field, choice, appearance):
            cast = EQUIPMENT_CASTS.get(field, {}).get(choice)
            if cast is None:
                raise ValueError(f"«{EQUIPMENT[field][choice]}» доступно персонажам старше детского возраста.")
            label = "мужской" if cast == "men" else "женской"
            raise ValueError(f"«{EQUIPMENT[field][choice]}» доступно на {label} основе старше детского возраста.")


def resolve_equipment(overrides=None, *, appearance=None):
    requested = dict(overrides or {})
    _validate(requested, EQUIPMENT)
    if appearance is not None:
        _validate_equipment_traits(requested, appearance)
    return {field: requested.get(field, next(iter(options))) for field, options in EQUIPMENT.items()}


def save_recipe(seed, appearance, equipment, *, profile=None):
    _validate_profile(profile)
    _validate(appearance, APPEARANCE)
    _validate_traits(appearance, appearance["cast"], appearance["age"])
    _validate_equipment_traits(equipment, appearance)
    recipe = {
        "version": VERSION,
        "seed": str(seed),
        "appearance": dict(appearance),
        "equipment": dict(equipment),
    }
    if profile is not None:
        recipe.update(profile=profile, profile_version=PROFILE_VERSION)
    return recipe


def load_recipe(source):
    data = json.loads(Path(source).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("version") != VERSION:
        raise ValueError(f"Поддерживается версия {VERSION}")
    appearance = data["appearance"]
    _validate(appearance, APPEARANCE)
    if not BASE_APPEARANCE.keys() <= appearance.keys():
        raise ValueError("В сохранённой внешности отсутствуют поля")
    if appearance["cast"] == "women" and appearance["age"] != "child":
        appearance = {**appearance, "beard": "none", "moustache": "none"}
    recipe = save_recipe(data["seed"], appearance, resolve_equipment(data["equipment"]), profile=data.get("profile"))
    if "profile_version" in data and "profile" in recipe:
        recipe["profile_version"] = data["profile_version"]
    return recipe


def render_svg(appearance, equipment=None, *, view="portrait", title="Портрет Rus13"):
    _validate(appearance, APPEARANCE)
    if not BASE_APPEARANCE.keys() <= appearance.keys():
        raise ValueError("Передайте полный набор полей из resolve_appearance")
    _validate_traits(appearance, appearance["cast"], appearance["age"])
    if view not in {"portrait", "card", "full"}:
        raise ValueError("Формат должен быть full, portrait или card")
    gear = resolve_equipment(equipment, appearance=appearance)
    if view == "full":
        from full_costume import full_svg

        return full_svg(appearance, gear, title=title)
    return ET.tostring(_draw_figure(appearance, gear, view=view, title=title), encoding="unicode")


def _draw_figure(appearance, gear, *, view, title):
    look = {**appearance, **gear}
    full_armor = view == "full" and gear["outfit"] in wardrobe.NORTHWEST_ARMOR
    full_size = CHILD_FULL if appearance["age"] == "child" else FULL
    width, height, viewbox = {"portrait": PORTRAIT, "card": CARD, "full": full_size}[view]
    root = ET.Element(tag("svg"), width=str(width), height=str(height), viewBox=viewbox,
                      role="img", attrib={"aria-labelledby": "title"})
    node(root, "title", id="title").text = title
    defs = ET.parse(STAGE).getroot().find(tag("defs"))
    root.append(defs)
    frame = node(defs, "clipPath", id="portrait-frame")
    node(frame, "rect", width=PORTRAIT[0], height=height if full_armor else PORTRAIT[1])
    subject = node(root, "g", clip_path="url(#portrait-frame)")
    setting = BACKGROUNDS[gear["background"]][1]
    if setting:
        use(subject, setting)
    head = face_shape.make_head(look)
    coverage = hair_headgear.COVERAGE[gear["headgear"]]
    if coverage["hair"]:
        hair_headgear.draw_back_hair(subject, defs, look, head)
    if coverage["neck"]:
        neck = node(subject, "g", data_part="neck")
        face_shape.draw_neck(neck, look, head)
    wardrobe.draw_outfit(subject, defs, look, head, full=full_armor)
    hair_headgear.draw_headgear_base(subject, defs, look, head)
    face_parent = subject
    if gear["headgear"] == "nw_great_helm":
        face_parent = node(subject, "g", id="face-under-closed-helm", visibility="hidden")
    face_shape.draw_skin(face_parent, defs, look, head, show_ears=coverage["ears"])
    face = node(face_parent, "g", clip_path="url(#face-shape-clip)")
    face_features.draw_features(face, defs, look, head)
    hair_headgear.draw_facial_hair(subject, defs, look, head, card=view == "card")
    if coverage["hair"]:
        hair_headgear.draw_hair(subject, defs, look, head)
    hair_headgear.draw_headgear_top(subject, defs, look, head)
    return root


def _catalog():
    exclusive_traits = {}
    age_restrictions = {age: {} for age in APPEARANCE["age"]}
    for field, options in APPEARANCE.items():
        restricted = {value: cast for value in options if (cast := required_cast(field, value))}
        if restricted:
            exclusive_traits[field] = restricted
        for age, restrictions in age_restrictions.items():
            unavailable = [value for value in options if not age_allows(age, field, value)]
            if unavailable:
                restrictions[field] = unavailable
    age_restrictions["child"].update({field: list(choices) for field, choices in _ADULT_EQUIPMENT.items()})
    return {
        "version": VERSION,
        "appearance": {key: {"label": LABELS[key], "values": values} for key, values in APPEARANCE.items()},
        "equipment": {key: {"label": LABELS[key], "values": values} for key, values in EQUIPMENT.items()},
        "exclusive_traits": exclusive_traits,
        "age_restrictions": age_restrictions,
        "equipment_casts": EQUIPMENT_CASTS,
        "hair_styles_by_length": {
            "default": [style for style in APPEARANCE["hair_style"] if length_allows(None, style)],
            **{length: list(styles) for length, styles in STYLES_BY_LENGTH.items()},
        },
    }


def _selection(entries):
    result = {}
    for entry in entries:
        name, sep, value = entry.partition("=")
        if not sep or not name or not value or name in result:
            raise ValueError(f"Укажите уникальное поле в виде имя=значение, получено {entry!r}")
        result[name] = value
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="Создать SVG-портрет Rus13")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("seed", nargs="?")
    source.add_argument("--recipe", type=Path, help="Восстановить сохранённую внешность")
    parser.add_argument("--defaults", action="store_true")
    parser.add_argument("--extended", action="store_true", help="Подбирать дополнительные черты при создании по seed")
    parser.add_argument("--expanded-hair", action="store_true", help="Подбирать из расширенного каталога причёсок, бород и усов")
    parser.add_argument("--profile", choices=PROFILES, help="Художественный набор автоматического выбора")
    parser.add_argument("--cast", choices=APPEARANCE["cast"])
    parser.add_argument("--outfit", choices=EQUIPMENT["outfit"])
    parser.add_argument("--headgear", choices=EQUIPMENT["headgear"])
    parser.add_argument("--background", choices=EQUIPMENT["background"])
    parser.add_argument("--cloth-color", choices=EQUIPMENT["cloth_color"])
    parser.add_argument("--accessory", choices=EQUIPMENT["accessory"])
    parser.add_argument("--set", action="append", default=[], metavar="ПОЛЕ=ЗНАЧЕНИЕ")
    parser.add_argument("--view", choices=("full", "portrait", "card"), default="full")
    parser.add_argument("--output", "-o", type=Path)
    parser.add_argument("--save-recipe", type=Path)
    parser.add_argument("--options", action="store_true", help="Напечатать каталог полей и значений")
    args = parser.parse_args(argv)
    if args.options:
        sys.stdout.buffer.write((json.dumps(_catalog(), ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
        return
    if args.recipe is None and args.seed is None:
        parser.error("Укажите seed или --recipe")
    try:
        requested = _selection(args.set)
        profile = args.profile
        if args.cast:
            requested["cast"] = args.cast
        if args.recipe:
            saved = load_recipe(args.recipe)
            seed = saved["seed"]
            profile = profile or saved.get("profile")
            appearance = revise_appearance(seed, saved["appearance"], requested, profile=profile)
            equipment = {field: choice for field, choice in saved["equipment"].items()
                         if equipment_allows(field, choice, appearance)}
        else:
            seed = args.seed
            appearance = resolve_appearance(
                seed, requested, defaults=args.defaults, profile=profile,
                extended=args.extended, expanded_hair=args.expanded_hair,
            )
            equipment = {}
        equipment = resolve_equipment({**equipment, **{
            field: getattr(args, field) for field in EQUIPMENT if getattr(args, field) is not None
        }}, appearance=appearance)
        svg = render_svg(appearance, equipment, view=args.view)
        if args.output:
            args.output.write_text(svg + "\n", encoding="utf-8")
        else:
            sys.stdout.buffer.write((svg + "\n").encode("utf-8"))
        if args.save_recipe:
            args.save_recipe.write_text(
                json.dumps(save_recipe(seed, appearance, equipment, profile=profile), ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
    except (ValueError, KeyError, OSError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
