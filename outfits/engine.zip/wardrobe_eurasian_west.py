from common import node, path
from wardrobe_weapon_art import INK, LEATHER, STEEL, STEEL_LIGHT, STEEL_SHADE, hatch, line, shape


_WOOD = "#886748"
_WOOD_SHADE = "#5e4235"
_WOOD_LIGHT = "#c19a6a"
_BRASS = "#ae9060"
_BRASS_LIGHT = "#e0c795"


def _sword_grip(parent):
    shape(parent, "M-4-18Q0-20 4-18L5 16Q0 19-5 16Z", LEATHER, 1.9, data_part="weapon-grip")
    line(parent, "M-3-15l6 2m-6 4 6 2m-6 5 7 2m-7 5 7 2m-7 4 7 2", _WOOD_LIGHT, .95)


def _draw_lobed_sword(parent):
    shape(parent, "M-10 17Q-12 113-9 182Q-7 200-1 205Q6 201 9 182Q12 101 10 17Z", STEEL)
    shade = "M4 23L9 23Q11 109 8 181Q6 196-1 203Q3 180 4 108Z"
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .52)
    line(parent, "M-7 25Q-9 111-6 180Q-5 189-3 195", STEEL_LIGHT, 1.25)
    line(parent, "M-3 27Q-4 108-2 169M3 26Q4 107 2 169", STEEL_SHADE, 1.1)
    _sword_grip(parent)
    shape(parent, "M-24 24Q-24 17-18 14Q0 19 18 14Q24 17 24 24Q16 23 0 23Q-15 23-24 24Z",
          STEEL_SHADE, 2.2)
    shape(parent, "M-17-24Q-19-32-15-35Q-11-38-7-34Q-6-44 0-45Q7-44 8-34"
          "Q12-38 16-35Q19-32 17-24Q0-17-17-24Z", STEEL_SHADE, 2.25)
    line(parent, "M-15-25Q0-20 15-25M-8-33l3 7m13-7-3 7M-12-29l2 3m7-10 2 3"
         "m0-5 2 3m10 4 2 3M-18 17l3 4m0-4 3 4m10-3 3 3m6-3 3 3m4-4 3 3",
         _BRASS_LIGHT, 1.05)


def _draw_oval_sword(parent):
    shape(parent, "M-8 16Q-6 110-3 180L0 212Q8 189 8 181Q10 116 8 16Z", STEEL, 2.7)
    shade = "M3 23L7 24Q10 127 6.5 180L1 206Q4 173 3 23Z"
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .57)
    line(parent, "M-6 25Q-4 118-2 178M-.8 26L.6 146", STEEL_LIGHT, 1.2)
    _sword_grip(parent)
    shape(parent, "M-32 15L31 14Q33 16 31 20L-31 21Q-33 19-32 15Z", STEEL_SHADE, 2.2)
    line(parent, "M-29 17L-7 16m5 0 30-.3", STEEL_LIGHT, 1.1)
    shape(parent, "M-13-25Q-15-32-9-39Q-4-44 0-45Q5-44 10-38"
          "Q16-32 13-25Q7-19 0-20Q-7-20-13-25Z", STEEL, 2.3)
    path(parent, "M-12-26Q-1-23 11-34Q15-30 12-26Q4-18-6-22Z", STEEL_SHADE)
    line(parent, "M-11-31Q-7-41 0-43", STEEL_LIGHT, 1.3)


def _draw_broad_axe(parent):
    axe = node(parent, "g", transform="scale(-1 1)")
    shape(axe, "M-5-40Q-2-44 2-40Q5 52 1 117L-1 162Q-4 165-8 162L-5 111Q-2 44-5-40Z",
          _WOOD, 2.2, data_part="weapon-grip")
    line(axe, "M-2-35Q2 54-2 112L-4 156m-2-18-.6 18", _WOOD_LIGHT, 1.05)
    shape(axe, "M-8 90Q15 103 38 71Q43 111 34 150Q14 118-7 121Q-11 105-8 90Z",
          STEEL, 2.75)
    shade = "M-7 96Q13 107 36 79Q21 105 24 124Q8 111-6 117Z"
    path(axe, shade, STEEL_SHADE)
    hatch(axe, shade, .6)
    line(axe, "M38 80Q41 113 34 141M-6 102Q4 111 13 109", STEEL_LIGHT, 1.5)
    shape(axe, "M-7 121L0 119l-.4 13-7 1Z", _BRASS, 1.3)
    line(axe, "M-6 124l4-1", _BRASS_LIGHT, .9)


def _draw_francisca(parent):
    shape(parent, "M-4-20Q-1-23 3-21Q1 17 6 44Q12 76 17 97"
          "Q14 102 10 100Q5 77-.6 47Q-6 13-4-20Z", _WOOD, 2.1, data_part="weapon-grip")
    line(parent, "M-.9-16Q-3 13 3 45L13 96", _WOOD_LIGHT, 1.05)
    shape(parent, "M5 63Q18 70 31 55Q32 69 40 82Q34 87 28 88"
          "Q23 79 17 81Q11 83 9 85Q5 80 5 63Z", STEEL, 2.35)
    shade = "M7 67Q19 75 31 59Q32 72 36 78Q26 77 23 78Q17 77 11 81Z"
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .65)
    line(parent, "M31 60Q32 73 38 82M11 69l5 2m13 14 5-2", STEEL_LIGHT, 1.15)


def _draw_winged_spear(parent):
    shape(parent, "M-29-245L-23-246Q-10-212-6-143Q3-26 4 137"
          "Q1 141-2 137Q-3-14-12-142Q-16-211-29-245Z",
          _WOOD, 2, data_part="weapon-grip")
    line(parent, "M-25-241Q-14-213-9-141Q-1-35 0 94m.4 8 .4 29", _WOOD_LIGHT, 1.05)
    shape(parent, "M-30-237L-31-249Q-36-252-40-252L-41-259L-31-258"
          "Q-35-265-38-272Q-40-297-39-320Q-30-300-25-274Q-25-266-23-259"
          "L-12-262L-11-254Q-16-252-22-249L-22-240Q-25-236-30-237Z",
          STEEL, 2.55)
    shade = "M-38-316Q-30-299-26-273L-25-256L-13-260L-12-256L-24-250L-23-240L-26-238L-33-274Z"
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .54)
    line(parent, "M-38-308Q-39-292-36-272L-32-263M-38-256l5 1M-19-257l5-1.4"
         "M-29-249l4-2", STEEL_LIGHT, 1.1)


def _draw_scalvian_spear(parent):
    shape(parent, "M-30-225L-23-226Q-13-155-4-65Q-.78-25.98 1.95 20"
          "C3.4 45 10.8 66 12.3 90Q16.4 134 21 172"
          "Q17.6 176 14 172Q9.5 132 5.55 90C4.15 66-3.18 45-4.62 20"
          "Q-6.97-20.86-10-64Q-21-159-30-225Z",
          _WOOD, 2.1, data_part="weapon-grip")
    line(parent, "M-26-221Q-16-146-7-63Q-3.41-18.71-.93 20"
         "C.6 44 7.4 65 9 90Q10.9 109 12.8 125m1 9 3.6 32", _WOOD_LIGHT, 1.1)
    shape(parent, "M-30-213L-29-244Q-40-251-41-264Q-39-288-32-316"
          "Q-21-292-17-267Q-17-254-24-245L-20-215Q-23-211-30-213Z",
          STEEL, 2.5)
    shade = "M-32-312Q-21-286-18-265Q-18-252-25-245L-21-215"
    shade += "L-24-214L-28-245Q-26-259-29-278Z"
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .51)
    line(parent, "M-34-302Q-39-278-39-264Q-38-255-33-252M-29-244l-1-21",
         STEEL_LIGHT, 1.25)
    line(parent, "M-27-241l3 3-2 3-2-2m0 7 4-3 2 2-3 3m-2 4 3-2 3 2m-6 6 5-2",
         STEEL_LIGHT, 1.1)


def _draw_seax(parent):
    seax = node(parent, "g", transform="rotate(5)")
    shape(seax, "M-6-24Q0-27 5-25L7 15Q1 20-7 16Z", _WOOD, 2.15, data_part="weapon-grip")
    line(seax, "M-4-22Q-5-7-3 14m4-35 2 18", _WOOD_LIGHT, 1.05)
    shape(seax, "M-11 15L7 12L13 103L-2 143Q-6 146-9 128Q-13 79-11 15Z", STEEL)
    shade = "M-6 18L6 15L11 102L-2 139Q3 110 1 79Z"
    path(seax, shade, STEEL_SHADE)
    hatch(seax, shade, .38)
    line(seax, "M-9 22Q-11 81-6 126l3 12", STEEL_LIGHT, 1.3)
    line(seax, "M2 22L7 100M-1 23L4 102", _BRASS_LIGHT, 1)
    line(seax, "M.8 38l3 2-3 3m1 8 3 2-3 3m1 10 3 2-3 4m1 9 3 3-3 3",
         "#d1ac72", .9)
    shape(seax, "M-8 11L8 10l.5 7-16 1Z", STEEL_SHADE, 1.55)


def _draw_bayeux_club(parent):
    shape(parent, "M-5-19Q-1-22 4-19Q4 15 9 36Q13 47 17 65Q20 75 15 82"
          "Q8 90-1 83Q-9 76-5 65Q-1 53-2 42Q-7 19-5-19Z", _WOOD, 2.55,
          data_part="weapon-grip")
    shade = "M1-18L3-18Q4 17 8 36Q11 46 16 65Q19 75 14 81Q9 86 3 84"
    shade += "Q10 79 9 71Q7 56 3 44Q0 25 1-18Z"
    path(parent, shade, _WOOD_SHADE)
    hatch(parent, shade, .65)
    line(parent, "M-2-17Q-4 17 1 40m2 9q1 11-3 18q-3 11 2 13M6 63q1 7 .4 10",
         _WOOD_LIGHT, 1.35)


def _draw_taull_sling(parent):
    strap = "M2-6C-8 4-22 31-23 51Q-26 78-15 108L-9 111Q-21 80-19 54"
    strap += "Q-17 28 5-4Z"
    shape(parent, strap, LEATHER, 1.5, data_part="weapon-grip")
    line(parent, "M0 0Q-16 31-21 53Q-23 77-13 106", _WOOD_LIGHT, .95)
    line(parent, "M3-4C16 9 21 37 14 59C8 79 1 92-1 109", INK, 2.65)
    line(parent, "M3-4C16 9 21 37 14 59C8 79 1 92-1 109", _WOOD_LIGHT, 1.1)
    shape(parent, "M-16 106Q-8 111 0 105Q4 115-4 128Q-10 131-16 124Q-20 115-16 106Z",
          LEATHER, 2.1)
    path(parent, "M-2 109Q1 117-5 126Q-10 130-14 123Q-7 124-2 109Z", _WOOD_SHADE)
    line(parent, "M-15 112Q-9 115-4 111M-14 116l.5 4", _WOOD_LIGHT, 1)


def _draw_drosten_crossbow(parent):
    line(parent, "M-40-9Q-1-13 37-36", INK, 1.5)
    line(parent, "M-39-9Q-1-14 36-35", _WOOD_LIGHT, .7)
    shape(parent, "M-8-17Q-4-22 0-18L4 8Q10 36 14 67L19 102"
          "Q16 107 10 105Q5 97 4 81L-2 37Q-4 11-8-17Z",
          _WOOD, 2.4, data_part="weapon-grip")
    line(parent, "M-5-13Q1 11 3 33L10 86q1 10 4 15", _WOOD_LIGHT, 1.25)
    shape(parent, "M-41-8Q-30-36-12-53Q-8-58-2-56Q19-52 39-36"
          "Q30-39 18-44Q5-49-6-47Q-19-40-26-25Q-33-14-41-8Z",
          _WOOD, 2.15)
    shape(parent, "M-9-18L-13-46Q-10-50-5-49L1-18Q-4-14-9-18Z", _WOOD, 2.2)
    line(parent, "M-36-15Q-26-37-9-48m12-5q17 3 29 12M-9-44l4 24",
         _WOOD_LIGHT, 1.15)


WEAPONS = {
    "eur_west_lobed_sword": ("Скандинавский трёхдольный меч", _draw_lobed_sword),
    "eur_west_oval_sword": ("Меч с заострённо-овальным навершием", _draw_oval_sword),
    "eur_west_broad_axe": ("Широколезвийная секира", _draw_broad_axe),
    "eur_west_francisca": ("Франциска", _draw_francisca),
    "eur_west_winged_spear": ("Крылатое копьё", _draw_winged_spear),
    "eur_west_scalvian_spear": ("Скальвское листовидное копьё", _draw_scalvian_spear),
    "eur_west_seax": ("Англосаксонский сакс", _draw_seax),
    "eur_west_bayeux_club": ("Деревянная палица", _draw_bayeux_club),
    "eur_west_taull_sling": ("Праща из Тауля", _draw_taull_sling),
    "eur_west_drosten_crossbow": ("Ранний арбалет с камня Дростена", _draw_drosten_crossbow),
}
