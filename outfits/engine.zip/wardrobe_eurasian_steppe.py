from common import node, path
from wardrobe_weapon_art import INK, LEATHER, STEEL, STEEL_LIGHT, STEEL_SHADE, hatch, line, shape


_WOOD = "#866448"
_WOOD_LIGHT = "#c29a6d"
_BRONZE = "#a38756"
_BRONZE_SHADE = "#6d573d"
_BRONZE_LIGHT = "#ddbd7e"
_BONE = "#bcb196"


def _draw_nefedyevo_flail(parent):
    shape(parent, "M-5 22Q-7-12-12-38L-17-69Q-14-74-9-71Q-2-46 3-17L6 19"
          "Q2 25-5 22Z", _WOOD, 2, data_part="weapon-grip")
    line(parent, "M-14-66Q-8-40-4-14M-2 13l1 7", _WOOD_LIGHT, 1)
    shape(parent, "M-17-69L-20-78Q-24-77-24-82Q-23-86-18-84"
          "Q-14-88-8-85Q-2-86-2-82Q-2-77-7-78L-8-71Z", _BRONZE, 1.65)
    line(parent, "M-21-83q3-2 4 1m7-2q4-2 5 1m-13 6 9-1m-8 4 8-1", _BRONZE_LIGHT, .9)
    line(parent, "M-16-80Q-37-62-38-32Q-39 3-33 35", INK, 4.6)
    line(parent, "M-17-80Q-37-62-38-32Q-39 3-33 35", "#9a7453", 2.15)
    shape(parent, "M-36 48Q-40 40-35 36Q-31 32-28 36Q-24 42-30 48L-31 55L-36 54Z"
          "M-33.5 43Q-35 39-32 38Q-29 38-30 42L-32 44Z", STEEL_SHADE,
          1.5, fill_rule="evenodd")
    shape(parent, "M-38 51Q-33 48-28 50Q-23 53-22 64L-21 73Q-21 82-28 85"
          "L-33 90Q-37 89-37 85Q-41 81-41 75L-40 58Z", _BONE, 1.9)
    shade = "M-29 51Q-22 55-22 67L-21 73Q-21 82-28 85L-33 89L-35 84Q-25 78-28 65Z"
    path(parent, shade, "#8a7c65")
    hatch(parent, shade, .47)
    path(parent, "M-37 84Q-32 86-28 84L-33 89Q-36 88-37 84Z", STEEL_SHADE)
    line(parent, "M-37 59q-2 9-1 16m4-22 2 3m5 5 1 6", "#e6d6af", 1.12)


def _draw_zagorye_mace(parent):
    shape(parent, "M-10-89L-1-91Q1-54 4-23L6 40Q0 45-5 41Q-9-31-10-89Z",
          _WOOD, 2.1, data_part="weapon-grip")
    line(parent, "M-7-83Q-5-46-3-23M-1 16l1 21m3-20 1 11", _WOOD_LIGHT, 1.2)
    head = node(parent, "g", transform="translate(0 21)")
    shape(head, "M-10-114L-11-103L2-102L4-116Z", STEEL_SHADE, 1.9)
    shape(head, "M-31-133Q-27-140-17-145L-14-148L-10-153L5-154L10-149"
          "Q23-148 31-136Q29-127 16-117Q3-112-15-117Q-27-123-31-133Z", STEEL, 2.6)
    path(head, "M-30-133L-16-132L-2-119L15-132L30-136Q26-125 16-118"
         "Q3-114-15-118Q-25-124-30-133Z", STEEL_SHADE)
    shape(head, "M-19-133L-2-146L16-134L-2-118Z", "#83887a", 1.38)
    path(head, "M-18-133L-2-145L1-133L-2-119Z", STEEL_LIGHT)
    hatch(head, "M2-134L15-134L-2-119Z", .51)
    line(head, "M-28-134l9 1m25-16 6 1m7 13 7-1m-35 24 8 1", STEEL_LIGHT, 1)


def _draw_zaryadye_mace(parent):
    shape(parent, "M-13-92L-3-94Q-1-42 5 23L7 54Q3 58-3 57"
          "Q-7 12-10-31Z", "#795942", 2.1, data_part="weapon-grip")
    line(parent, "M-11-87l3 57m1 7 3 26m2 13 3 35", "#b58f63", 1.12)
    shape(parent, "M-27-110L-19-124L0-127L15-118L18-102L8-89L-12-88L-26-98Z",
          STEEL, 2.5)
    path(parent, "M-11-115L4-120L15-118L18-102L8-89L-12-88L-18-99Z", STEEL_SHADE)
    line(parent, "M-27-110l16-5 11-11m-11 11 15-5 11 2m-26 3-7 16 6 11m-6-11 24 2 12-5"
          "m-12 5 2 8", INK, 1.38)
    hatch(parent, "M-17-98L6-96L16-101L8-90L-11-89Z", .62)
    line(parent, "M-25-108l13-4 9-8m-20 22 9 7M4-118l9 2", STEEL_LIGHT, 1.12)


def _draw_seltso_hammer_axe(parent):
    shape(parent, "M-12-125Q-7-128-3-125Q0-60 5 15L7 43Q2 47-3 45"
          "Q-9-25-12-125Z", _WOOD, 2, data_part="weapon-grip")
    line(parent, "M-9-120Q-7-57-5-36m2 19 2 23m1 8 3 25", _WOOD_LIGHT, 1.1)
    shape(parent, "M-39-128Q-31-127-19-126L-14-131L-4-130L2-126"
          "L19-128L21-134L30-134L31-120L22-118L20-122L3-118"
          "L-4-111L-13-111L-17-116Q-26-113-35-109Q-39-116-39-128Z", STEEL, 2.4)
    path(parent, "M-36-116Q-27-118-17-120L-11-126L-5-127L1-122L20-124"
         "L22-129L29-129L30-121L22-120L20-122L3-118L-4-112L-13-112"
         "L-18-117L-34-110Z", STEEL_SHADE)
    hatch(parent, "M-34-116L-17-120L-11-124L-3-125L-5-113L-13-112L-18-117L-34-111Z", .61)
    line(parent, "M-37-126q-1 7 3 14m7-13 9 1m7-5 6 .4m28-3 6 .5", STEEL_LIGHT, 1.22)


def _draw_dargavs_double_axe(parent):
    parent = node(parent, "g", transform="rotate(3) scale(-.91 1)")
    shape(parent, "M-6-35Q-2-40 4-37Q5 21 5 63L3 109Q-2 113-7 110"
          "Q-4 62-6-35Z", "#75553e", 2.05, data_part="weapon-grip")
    line(parent, "M-3-34Q-3 22-2 53M-3 66l-1 31m5-21-1 20", "#b48a5c", 1.12)
    shape(parent, "M-40.5 94Q-28 95-15 91L-8 88L5 89L10 94"
          "Q21 94 31 95Q37 95 38 102Q41 113 33 133Q30 138 24 136"
          "Q20 133 24 125Q28 114 25 109Q23 107 15 106L8 105L2 110"
          "L-7 110L-13 105Q-27 104-40.5 97Z", STEEL, 2.45)
    shade = ("M-38 97Q-25 98-13 95L-8 92L5 93L9 98L30 98"
             "Q34 98 35 104Q38 113 32 129Q29 135 26 134"
             "Q29 126 30 115Q30 107 25 105L8 102L2 108L-7 108L-13 103Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .61)
    line(parent, "M-34 96L-13 94M-8 94Q-12 99-6 107M4 92q4 4 1 10"
          "M27 100q7 1 8 8q1 11-4 21", STEEL_LIGHT, 1.24)


def _draw_vienna_sabre(parent):
    shape(parent, "M-9 20Q-13 84-8 136Q-5 174 8 198Q16 211 25 214"
          "Q17 192 10 164Q3 127 5 78L6 22Z", STEEL, 2.6)
    path(parent, "M2 22L6 22Q2 113 7 145Q11 181 25 214Q20 210 14 202"
         "Q-4 167-4 122Q-6 72 2 22Z", STEEL_SHADE)
    hatch(parent, "M1 28L4 26Q0 126 6 157Q11 190 22 211Q9 199 3 175Q-5 138-4 102Z", .4)
    line(parent, "M-7 26Q-12 107-3 160Q3 197 19 209M-3 37Q-6 97-2 133", STEEL_LIGHT, 1.16)
    shape(parent, "M-4-20Q1-23 5-20L5 17Q0 22-7 18Q-5 4-4-20Z", LEATHER,
          1.8, data_part="weapon-grip")
    line(parent, "M-2-16l5 2m-6 4 6 2m-6 3 6 2m-6 4 6 2m-7 4 7 2", _BRONZE_LIGHT, .84)
    shape(parent, "M-5-18L-6-25L-1-31Q6-31 10-27L6-21L5-17Z", _BRONZE, 1.85)
    shape(parent, "M-21 16L-15 12L-9 17Q-1 15 10 18L17 14L23 19"
          "L19 23L10 23L4 27L-8 24L-18 23Z", _BRONZE, 2.02)
    line(parent, "M-17 17l5 3 5-1m3 3 5-3 4 4 5-2 8 1m-21-47q4-4 9-1",
          _BRONZE_LIGHT, 1.1)
    line(parent, "M-6 30q3 5 6 0m-6 8q3 5 6 0m-6 8q3 5 6 0", _BRONZE_LIGHT, .8)


def _draw_yaroslavl_sabre(parent):
    shape(parent, "M-6-19Q-10-69-13-108Q-18-178-28-232"
          "Q-32-258-39-275Q-27-267-22-246Q-12-190-6-133Q0-67 5-20Z",
          STEEL, 2.5)
    shade = ("M-37-272Q-27-265-23-246Q-12-190-6-133L5-20L1-21"
             "Q-4-75-7-116Q-13-215-37-272Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .48)
    line(parent, "M-36-267Q-26-231-21-187Q-13-141-8-69M-8-61l4 32", STEEL_LIGHT, 1.3)
    line(parent, "M-32-253Q-23-226-19-195m1 7 3 20m3 26 2 25", "#7b7d6f", .87)
    shape(parent, "M-6-17Q-1-20 4-17L8 17Q4 21-1 19Z", "#664333",
          1.8, data_part="weapon-grip")
    line(parent, "M-4-13l7 2m-6 4 7 2m-6 3 7 2m-6 4 7 2m-6 3 7 2", "#ae865d", .96)
    shape(parent, "M-15-23Q-6-20 0-24L11-29Q14-28 13-24L4-18Q-5-14-14-17Z",
          STEEL_SHADE, 1.95)
    line(parent, "M-12-21q8 2 16-2m4-2 3-2", STEEL_LIGHT, 1)
    shape(parent, "M-4 18Q2 20 8 16L10 22Q8 27 0 27L-4 24Z", STEEL, 1.8)


def _draw_grigorovo_dart(parent):
    shape(parent, "M-27-233Q-24-236-22-233L-13-155Q0-49 10 62L19 147"
          "Q18 151 13 150L4 64Q-8-60-18-155Z", "#8c6c48", 1.85, data_part="weapon-grip")
    line(parent, "M-25-228l11 92m1 11 11 98M1 7l6 58m3 30 5 43", _WOOD_LIGHT, .98)
    shape(parent, "M-29-232L-32-251L-40-246L-32-272L-19-249L-28-252L-26-233Z",
          STEEL, 2.1)
    path(parent, "M-32-270L-20-250L-29-253L-27-233L-29-233L-31-251Z", STEEL_SHADE)
    line(parent, "M-38-249l6-19 2 15", STEEL_LIGHT, .9)
    for y_offset in range(0, 10, 3):
        line(parent, f"M-28.5 {y_offset - 240}l6-1", "#664b37", .85)


def _draw_samanid_khanjar(parent):
    shape(parent, "M-11-23Q-13-81-9-126Q-7-150-2-171Q7-151 10-126"
          "Q12-73 10-24Q0-20-11-23Z", STEEL, 2.45)
    shade = ("M-2-170Q7-151 10-126Q12-73 10-24L2-22Q4-68 2-124"
             "Q1-151-2-170Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .52)
    line(parent, "M-9-27Q-11-84-7-128Q-5-152-2-167M-3-36Q-4-96-2-138",
          STEEL_LIGHT, 1.17)
    line(parent, "M-1-107q4-3 2-7m-4 3 5 2m-4-9 2-3m-2-4 6 1m-4-3 1-5m1 8 2-2",
          _BRONZE_LIGHT, .96)
    shape(parent, "M-5-19Q0-21 5-19Q3.5-9 4 4L5 14Q0 18-5 14"
          "Q-3.5 3-4-8Z", LEATHER, 1.28, data_part="weapon-grip")
    line(parent, "M-3.7-15l7 1.2m-7 3.5 7 1M-3.4 10l7 1.1m-7.3 2.4 7 1", _BRONZE_LIGHT, .82)
    shape(parent, "M-10-25L10-25L18-23L19-31Q21-35 25-32L28-31L28-28L25-28"
          "Q26-22 22-17L10-17Q5-14-8-16L-22-17Q-26-22-25-28"
          "L-28-28L-28-31L-25-32Q-21-35-19-31L-18-23Z", _BRONZE, 2.05)
    line(parent, "M-23-25l1 4 13 1m19 0 10-1 2.5-4", _BRONZE_LIGHT, 1.13)
    line(parent, "M24.8-30l2.6 1M-24.8-30l-2.6 1", _BRONZE_SHADE, .9)
    for eye_x in (-22.3, 22.3):
        node(parent, "circle", cx=eye_x, cy=-30.35, r=1.04, fill=INK)
    shape(parent, "M-8 13Q0 16 8 13L9 19Q16 19 16 24Q14 30 1 31"
          "Q-12 30-15 24Q-15 19-9 19Z", _BRONZE, 1.88)
    line(parent, "M-11 22Q1 18 12 22m-16 5q3 1 9 0", _BRONZE_LIGHT, 1.1)


def _draw_ghaznavid_feline_mace(parent):
    shape(parent, "M-14-116L-5-118Q-.5-63 4-18L4 78Q1 82-4 79"
          "L-4 18Q-7-45-14-116Z", "#77766a", 1.8, data_part="weapon-grip")
    path(parent, "M-8-115L-5.5-116Q-.5-60 3.4-18V77L1.5 79Q.2 25-.6-1Z", STEEL_SHADE)
    line(parent, "M-11-112Q-7-74-3.3-42m.5 12 .7 21m.2 24L-.5 73", STEEL_LIGHT, 1.06)
    head = node(parent, "g", transform="translate(-20.5 -14) scale(-.68 1)")
    shape(head, "M-22-91Q-25-107-22-119Q-21-137-16-148"
          "Q-20-154-15-159Q-12-162-8-158Q-2-165 7-163Q17-161 20-154"
          "Q23-146 30-142Q33-139 30-135L23-132L19-127Q13-121 8-124"
          "Q3-128 0-136L-4-139Q-11-128-10-113Q-6-115-2-109"
          "Q-2-100-8-97L-7-91Q-15-88-22-91Z"
          "M7-135Q10-128 15-128L22-133Q18-137 14-137Z",
          _BRONZE, 2.3, fill_rule="evenodd")
    shade = ("M-16-147Q-9-142-5-141Q-11-128-11-115Q-12-110-16-109"
             "L-8-105Q-4-103-9-99L-9-92Q-16-90-21-93"
             "Q-24-110-21-123Q-20-138-16-147Z"
             "M1-143Q5-144 8-138L8-135Q10-128 15-128L21-132"
             "L18-127Q13-122 8-125Q3-129 0-137Z")
    path(head, shade, _BRONZE_SHADE)
    hatch(head, shade, .52)
    line(head, "M-16-154q2-5 6-2m5 0q6-6 12-5m8 10q4 0 5 3"
          "m-8 1q-3 3 0 5m11 3 4 1M-20-105q7-3 14 0m-13 12 8 .4",
          _BRONZE_LIGHT, 1.19)
    line(head, "M-12-145q3 4 7 3M9-148q2-5 7-3q4 3 0 6q-4 1-6-1"
          "M10-135l2 4m4-6 1 4m4-3v2", INK, 1.04)
    node(head, "circle", cx=14.6, cy=-148.8, r=1.15, fill="#e6c98b")
    for x, y in ((-16, -138), (-13, -131), (-17, -123), (-15, -116)):
        node(head, "circle", cx=x, cy=y, r=2.05, fill="#98734e",
             stroke="#c6aa76", stroke_width=.82)


WEAPONS = {
    "eur_steppe_nefedyevo_flail": ("Роговой кистень из Нефедьева", _draw_nefedyevo_flail),
    "eur_steppe_zagorye_mace": ("Четырёхшипная булава", _draw_zagorye_mace),
    "eur_steppe_zaryadye_mace": ("Кубовидная булава", _draw_zaryadye_mace),
    "eur_steppe_seltso_hammer_axe": ("Топор-чекан из Сельца", _draw_seltso_hammer_axe),
    "eur_steppe_dargavs_double_axe": ("Двулезвийный топор из Даргавса", _draw_dargavs_double_axe),
    "eur_steppe_vienna_sabre": ("Венская сабля венгерского типа", _draw_vienna_sabre),
    "eur_steppe_yaroslavl_sabre": ("Ярославская сабля", _draw_yaroslavl_sabre),
    "eur_steppe_grigorovo_dart": ("Двушипная сулица", _draw_grigorovo_dart),
    "eur_steppe_samanid_khanjar": ("Саманидский ханджар", _draw_samanid_khanjar),
    "eur_steppe_ghaznavid_feline_mace": ("Газневидская булава со звериной головой",
                                        _draw_ghaznavid_feline_mace),
}
