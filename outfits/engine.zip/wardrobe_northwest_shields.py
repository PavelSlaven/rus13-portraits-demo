from common import node, number, path
from wardrobe_weapon_art import INK, STEEL_LIGHT, STEEL_SHADE, hatch, line, shape


LABELS = {
    "novgorod_george": "Круглый щит с иконы Георгия",
    "novgorod_dish": "Миндалевидный щит с чаши Неревского раскопа",
    "yuriev_lion": "Щит со зверем из Юрьева-Польского",
    "gokstad": "Круглый щит из Гокстада",
    "szczecin_painted": "Расписной щит из Щецина",
    "lewis": "Щит с фигурки из Льюиса",
}

OUTLINES = {
    "round": ("M-19-30C17-32 44-5 44 30C45 64 19 93-16 94"
              "C-51 95-80 68-80 34C-81-2-54-29-19-30Z"),
    "kite": ("M-12-34C16-33 41-19 44 9C47 50 20 142-15 204"
             "C-52 164-78 89-76 33C-74-6-49-34-12-34Z"),
    "triangular": "M-75-27Q-21-36 44-24Q41 89-14 179Q-65 108-75-27Z",
    "novgorod_george": ("M-28-41C9-42 37-16 39 21C41 61 12 91-26 93"
                        "C-63 95-94 68-94 29C-94-9-66-39-28-41Z"),
    "novgorod_dish": ("M-36-65C-7-69 24-47 29-15C37 39 8 131-28 184"
                      "C-56 159-78 116-91 65C-107 10-99-45-67-61Q-52-68-36-65Z"),
    "yuriev_lion": ("M-93-51Q-68-76-31-72Q13-73 36-48C38 4 24 71 5 113"
                   "Q-10 150-31 175Q-70 137-90 85C-103 49-112-17-93-51Z"),
    "gokstad": ("M-43-57C1-58 33-27 35 19C38 64 3 99-41 101"
                "C-87 103-121 69-121 23C-122-23-88-56-43-57Z"),
    "szczecin_painted": ("M-111-48L-44-87L33-48C47-22 33 41 10 99"
                         "Q-11 155-43 192Q-81 154-106 95C-128 42-137-30-111-48Z"),
    "lewis": ("M-100-48Q-82-66-37-66Q12-66 34-49C38-20 31 44 14 94"
              "Q-9 153-34 172Q-69 141-87 89C-101 47-108-19-100-48Z"),
}

# Upper and lower limits and the rightmost control point of each SVG outline.
_BACK_LIMITS = {
    "round": (-32, 95, 45),
    "kite": (-34, 204, 47),
    "triangular": (-36, 179, 44),
    "novgorod_george": (-42, 95, 41),
    "novgorod_dish": (-69, 184, 37),
    "yuriev_lion": (-76, 175, 38),
    "gokstad": (-58, 103, 38),
    "szczecin_painted": (-87, 192, 47),
    "lewis": (-66, 172, 38),
}


def _face(parent, style, color):
    contour = OUTLINES[style]
    shape(parent, contour, color, 3.5)
    clip_id = f"shield-face-{style}"
    path(node(parent, "clipPath", id=clip_id), contour)
    return node(parent, "g", clip_path=f"url(#{clip_id})")


def _rim(parent, style, color):
    line(parent, OUTLINES[style], INK, 8)
    line(parent, OUTLINES[style], color, 4.1)


def _boss(parent, *, x, y, size):
    group = node(parent, "g", transform=f"translate({x} {y}) scale({size})")
    node(group, "ellipse", rx=21, ry=20, fill="#87897d", stroke=INK, stroke_width=2.3)
    shape(group, "M-13 0C-13-8-7-13 0-13Q11-13 13-2Q15 10 2 13Q-12 13-13 0Z", STEEL_SHADE, 1.9)
    path(group, "M-12-1Q-10-12 0-11Q7-11 10-4Q3-7-2-5L-11 1Z", "#9d9d8d")
    line(group, "M-8-5Q-6-9 1-9", STEEL_LIGHT, 1.1)
    for dx, dy in ((-17, 0), (17, 0), (0, -16), (0, 16)):
        node(group, "circle", cx=dx, cy=dy, r=1.25, fill=INK)


def _draw_george(parent):
    face = _face(parent, "novgorod_george", "#87564b")
    shade = "M6-39Q45-5 37 43Q29 91-32 96Q-62 94-83 71Q-48 84-23 68Q9 44 6-39Z"
    path(face, shade, "#67413d")
    hatch(face, shade, .51)
    line(face, "M-82 12C-72-26-28-41 8-25M-73 57Q-62 71-47 74M7 68l11-11", "#be8c73", 1.55)
    node(face, "ellipse", cx=-27, cy=26, rx=59, ry=58, fill="none", stroke="#c3a080", stroke_width=2.1)
    node(face, "ellipse", cx=-27, cy=26, rx=55, ry=54, fill="none", stroke="#422c29", stroke_width=1.05)
    _rim(face, "novgorod_george", "#966951")
    _boss(face, x=-28, y=27, size=.73)


def _draw_dish(parent):
    # The outline follows Kolchin, plate 47:1. The gray-brown field is interpretive.
    face = _face(parent, "novgorod_dish", "#a29a88")
    shade = ("M-21-66C7-51 13-17 9 21C5 68-15 139-38 170L-28 185"
             "C10 130 38 42 31-18Q14-58-21-66Z")
    path(face, shade, "#756d62")
    hatch(face, "M18-30C34-1 27 55 6 107Q-12 157-28 183L-34 173"
          "C-6 127 17 53 18-30Z", .46)
    path(face, "M-91 13C-88-33-67-56-31-57Q-68-44-72 0Q-78 51-63 105"
         "Q-88 69-91 13Z", "#c0b7a1", opacity=.68)
    line(face, "M-83-16Q-73-48-46-55M-85 28l4 16m3 9 3 12M-67 97l7 17"
         "M-48 137l10 16", "#c9c0ac", 1.35)
    line(face, "M-82 50l4 14m4 8 5 13M12 39q-2 20-8 36m4-9-4 11M-24 150l-5 10",
         "#726858", 1.1)
    _rim(face, "novgorod_dish", "#887866")


def _draw_yuriev(parent):
    face = _face(parent, "yuriev_lion", "#787952")
    shade = "M-8-74Q36-75 39-17C26 71 3 133-31 176L-52 154C-22 91-13 6-8-74Z"
    path(face, shade, "#555942")
    hatch(face, shade, .5)
    border = "M-84-41Q-34-79 24-39C26 40 7 117-31 160Q-81 107-95 23Q-103-22-84-41Z"
    line(face, border, "#b39a6c", 2.8)
    line(face, "M-88-22l6 6-7 7 6 8-6 7 7 7-5 7 7 7M16-22l-6 8 6 7-7 8 6 8-6 7 5 7-6 8",
         "#ad986e", 1.9)
    beast = ("M-61-20Q-60-30-49-33L-43-30-40-35-37-27Q-28-22-33-13"
             "L-39-10Q-37-3-30 1Q-25 9-27 22Q-17 34-22 45L-31 49"
             "Q-37 53-31 59L-22 63-24 69-45 68Q-51 65-48 57L-42 47"
             "Q-53 37-47 24L-51 21-63 31-74 27-76 21-65 22-59 11"
             "L-69 5-76 1-75-5-65-4-56 1Q-49-2-49-10L-56-9-65-14Z")
    shape(face, beast, "#c7a875", 1.8)
    tail = "M-27 45C-7 47 2 32-5 16C-10 8-7 0 2-2Q11-5 7-16"
    line(face, tail, "#433a2c", 7.1)
    line(face, tail, "#c7a875", 4.2)
    shape(face, "M7-14Q4-22 13-26Q15-19 13-15Z", "#c7a875", 1.5)
    line(face, "M-58-20l5-2m9 9q6 15 12 24M-39 34l3 8", "#62503a", 1.2)
    _rim(face, "yuriev_lion", "#967c55")


def _draw_gokstad(parent):
    face = _face(parent, "gokstad", "#ad915c")
    shade = "M-8-64C29-45 42-20 39 27C37 73-1 98-42 104Q-79 100-103 78C-31 101-1 31-8-64Z"
    path(face, shade, "#806c43")
    hatch(face, shade, .53)
    for x in (-103, -77, -49, -22, 5):
        line(face, f"M{x} -58q-3 74 2 163", "#7f6944", 1.6)
        line(face, f"M{x + 2} -58q-3 74 2 163", "#c9ac70", 1.05)
    line(face, "M-105-10Q-91-44-62-45M-104 41l4 17m18 18 14 6M-1 74l10-8",
         "#dcc18b", 1.5)
    _rim(face, "gokstad", "#937244")
    _boss(face, x=-43, y=23, size=1.02)


def _rosette(parent, x, y, angle):
    axis = node(parent, "g", transform=f"translate({x} {y}) rotate({angle})")
    node(axis, "ellipse", rx=7, ry=10, fill="#42312b", stroke="#352724", stroke_width=1.2)
    for dx, dy in ((-3, 0), (3, 0), (0, -4), (0, 4)):
        node(axis, "ellipse", cx=dx, cy=dy, rx=1.3, ry=2.1, fill="#d3ab66",
             transform=f"rotate(90 {dx} {dy})" if dx else None)
    node(axis, "circle", r=1.45, fill="#e2c388")


def _draw_szczecin(parent):
    face = _face(parent, "szczecin_painted", "#b69568")
    inside = ("M-95-37L-44-68 18-38Q29-20 14 36"
              "C1 88-17 134-44 166Q-78 120-95 63Q-117-12-95-37Z")
    path(face, OUTLINES["szczecin_painted"], "#a35447")
    shape(face, inside, "#b69a6e", 2.3)
    shade = "M3-52Q36-44 23 12C12 63-16 135-44 166L-52 149C-24 88-6 13 3-52Z"
    path(face, shade, "#886b4a")
    hatch(face, shade, .45)
    cross = ("M-62-37L-29-36-29-22-39-23-39 12-16 12-16 2-5 3-7 33-18 33"
             "L-18 23-39 23-40 103-30 102-31 116-63 116-62 103-53 103-52 23"
             "L-76 22-76 35-86 33-87 2-75 2-76 11-52 12-52-23-62-22Z")
    path(face, cross, "#934738", stroke="#d7b26e", stroke_width=3.2, stroke_linejoin="round")
    line(face, cross, "#533428", 1.05)
    line(face, "M-78 4Q-85 34-70 62M-72 77q8 18 19 27", "#d6bc89", 1.5)
    for x, y, angle in ((-82, -58, 58), (-44, -78, 90), (15, -54, 124),
                        (-119, -12, -12), (33, -18, 12), (-113, 46, -15),
                        (16, 46, 19), (-91, 101, -25), (-10, 106, 25), (-45, 179, 0)):
        _rosette(face, x, y, angle)
    for x, y in ((-57, -65), (-4, -63), (-107, -40), (32, -36), (-119, 18),
                 (28, 14), (-103, 74), (4, 79), (-74, 130), (-27, 134)):
        node(face, "circle", cx=x, cy=y, r=3.6, fill="#ca8170", stroke="#774137", stroke_width=1.1)
    _rim(face, "szczecin_painted", "#79493a")


def _draw_lewis(parent):
    face = _face(parent, "lewis", "#8a9785")
    shade = "M14-61Q45-67 34 14Q28 108-34 172L-48 158Q-8 110 5 26Z"
    path(face, shade, "#576a61")
    hatch(face, shade, .61)
    shape(face, "M-85-45Q-34-51 21-43Q26 36 2 97Q-12 133-34 155Q-76 114-89 40Q-97-9-85-45Z",
          "none", 1.9)
    line(face, "M-83-41Q-49-48-8-45M-87-24Q-91 5-85 31M-78 55Q-68 91-52 115M8 72l-11 27",
         "#c2bf9d", 1.45)
    line(face, "M-78-21l1 13m2 7 2 9M-49 92l8 19m7 12 3 8M-15 47l-4 14",
         "#4f6056", 1.2)
    shape(face, "M-38-37L10 18-34 95-84 24Z", "none", 2.2)
    line(face, "M-38-33L6 19-34 89-79 24Z", "#c5b78e", 1.8)
    cross = "M-45-12H-31L-32 16H-10V29H-32L-33 64H-45L-44 29H-66V17H-44Z"
    shape(face, cross, "#c3b487", 1.7)
    line(face, "M-42-8L-41 19-63 20M-41 33l-.5 25", "#e3d0a4", .9)
    _rim(face, "lewis", "#967958")


DRAWERS = {
    "novgorod_george": _draw_george,
    "novgorod_dish": _draw_dish,
    "yuriev_lion": _draw_yuriev,
    "gokstad": _draw_gokstad,
    "szczecin_painted": _draw_szczecin,
    "lewis": _draw_lewis,
}


def back_shield_style(look):
    return look.get("shield", "none") if look.get("shield_carry") == "back" else "none"


def shield_sling_anchor(body):
    return 165 + body.shoulder, body.shoulder_y - 10


def draw_back_shield(parent, style, body):
    top, bottom, edge = _BACK_LIMITS[style]
    skew, width, height = .048, .92, .95
    right = 314 - max(0, 80 - body.shoulder) * .12
    x = right - width * edge - skew * bottom
    y = body.shoulder_y + 39 - height * (top + bottom) / 2
    reverse = node(parent, "g", data_part="back-shield", data_style=style,
                   transform=f"matrix({width} 0 {skew} {height} {number(x)} {number(y)})")
    contour = OUTLINES[style]
    shape(reverse, contour, "#8a6b4e", 3.65)
    clip_id = "shield-reverse-outline"
    path(node(reverse, "clipPath", id=clip_id), contour)
    inside = node(reverse, "g", clip_path=f"url(#{clip_id})")
    shade = f"M5 {top - 3}H55V{bottom + 4}H-11Q12 111 5 {top - 3}Z"
    path(inside, shade, "#6a503d")
    hatch(inside, shade, .49)
    for grain in range(-116, 42, 22):
        line(inside, f"M{grain} {top}q-3 67 1 {bottom - top}", "#574134", 1.8)
        line(inside, f"M{grain + 3} {top}q-3 67 1 {bottom - top}", "#b28c64", 1.1)
    line(inside, "M12-27q-2 32 2 62m6 8 2 16m-1 13 2 23M-5 92q1 28-1 45", "#a58159", 1.05)
    _rim(inside, style, "#a18258")
    shoulder_x, shoulder_y = shield_sling_anchor(body)

    def local(dx, dy):
        row = (shoulder_y + dy - y) / height
        column = (shoulder_x + dx - x - skew * row) / width
        return f"{number(column)} {number(row)}"

    # The visible return on the reverse of the shield meets the front strap at the shoulder.
    strap = node(inside, "g", data_part="shield-sling-return")
    curve = f"M{local(15, -14)}Q{local(3, -19)} {local(0, 0)}L{local(-1, 9)}"
    line(strap, curve, "#342820", 10.6)
    line(strap, curve, "#876142", 7.3)
    path(strap, curve, "none", stroke="#c3a079", stroke_width=1, stroke_dasharray="2 4")
