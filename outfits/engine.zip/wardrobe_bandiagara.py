"""Portrait adaptations of Bandiagara textiles, following Bedaux and Bolland."""

from common import number, path


OPTIONS = {
    "tellem_tunic": "Бандиагара · хлопковая туника",
    "tellem_wrap": "Бандиагара · одежда из обёрнутой ткани",
}


def _tunic(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = number(160 - art.neck), number(160 + art.neck)
    bottom = art.hem_y + 8 if art.hem_y is not None else 446
    breadth = body.waist
    for x in (160 - breadth // 2, 160 + breadth // 2):
        path(front, f"M{x} 288Q{x - 5} 391 {x + 3} {bottom}", "none",
             stroke=cloth.shade, stroke_width=4)
        path(front, f"M{x + 2} 294Q{x - 2} 394 {x + 6} {bottom}", "none",
             stroke=cloth.light, stroke_width=1.15, opacity=".8")
    path(front, f"M{left} 273Q160 310 {right} 273", "none",
         stroke=cloth.deep, stroke_width=5.5, stroke_linecap="round")
    path(front, f"M{left} 275Q160 310 {right} 275", "none",
         stroke="#d8ba87", stroke_width=1.7, stroke_dasharray="3 2")
    if art.hem_y is not None:
        path(front, f"M{160 - art.hem_half} {bottom - 16}Q160 {bottom} {160 + art.hem_half} {bottom - 16}",
             "none", stroke=cloth.deep, stroke_width=3)
    cuff = f"M{160 - body.sleeve} 437Q{148 - breadth // 2} 444 {175 - breadth} 435"
    for sleeve in art.sleeves:
        path(sleeve, cuff, "none", stroke=cloth.deep, stroke_width=3.3)
        path(sleeve, cuff, "none", stroke=cloth.light, stroke_width=1.2)


def _wrap(art):
    front, cloth, body = art.front, art.cloth, art.body
    waist_left, waist_right = 161 - body.waist, 159 + body.waist
    top_left, top_right = 160 - body.shoulder, 160 + body.shoulder
    bottom = art.hem_y + 8 if art.hem_y is not None else 448
    half = art.hem_half if art.hem_half is not None else body.hem
    overlap = 160 - round(half * .43)
    path(front, f"M{top_left} 300Q112 341 {waist_right - 5} 357L{top_right} 291V319"
         f"Q173 343 205 386Q122 352 {top_left} 317Z", cloth.shade)
    path(front, f"M{top_left} 303Q125 348 {waist_right - 7} 360M{top_left} 310Q127 357 {waist_right - 6} 369",
         "none", stroke="#bca984", stroke_width=2.2)
    wrap_top = f"M{waist_left - 6} 392Q163 406 {waist_right + 3} 380"
    path(front, f"{wrap_top}L{160 + half + 8} {bottom}H{160 - half - 8}Z", cloth.deep)
    path(front, f"{wrap_top}Q{waist_right - 27} 442 {overlap} {bottom}"
         f"H{160 - half - 8}Z", cloth.shade)
    path(front, f"M{waist_left - 6} 398Q163 412 {waist_right + 3} 385"
         f"M{waist_left - 6} 405Q163 418 {waist_right + 3} 392",
         "none", stroke="#c9ad83", stroke_width=2.5)
    path(front, f"M{waist_right - 5} 388Q{waist_right - 25} 442 {overlap + 3} {bottom}",
         "none", stroke="#ae9276", stroke_width=2)
    if art.hem_y is not None:
        path(front, f"M{160 - half - 3} {bottom - 23}Q160 {bottom - 2} {160 + half + 3} {bottom - 23}"
             f"M{160 - half - 3} {bottom - 17}Q160 {bottom + 4} {160 + half + 3} {bottom - 17}",
             "none", stroke="#ae9276", stroke_width=1.7)


def draw_cap(parent, look, fit):
    crown = fit.crown(parent, minimum_y=54)
    path(crown, "M80 114Q83 93 97 74Q114 55 158 56Q202 55 222 75Q238 94 241 114"
         "Q162 127 80 114Z", "#384c61", class_="edge")
    path(crown, "M89 106Q94 83 122 69Q141 59 159 60Q134 73 129 112Z", "#587486")
    path(crown, "M174 60Q216 65 234 109L199 116Q199 85 174 60Z", "#2b3949")
    path(crown, "M83 106Q160 117 238 106L240 113Q160 126 81 114Z", "#b9a783", class_="edge")
    for y, x in ((76, 110), (84, 103), (93, 94)):
        path(crown, f"M{x} {y}Q160 {y + 14} {320 - x} {y}", "none",
             stroke="#a6a799", stroke_width=1.4, stroke_dasharray="3 4")


DRAWERS = {"tellem_tunic": _tunic, "tellem_wrap": _wrap}
