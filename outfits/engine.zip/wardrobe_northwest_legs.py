from dataclasses import dataclass
from common import node, number, path
import image_daily_art


OPTIONS = {
    "trousers": {
        "straight": "Прямые порты",
        "gathered": "Порты с напуском",
        "hose": "Раздельные шерстяные шоссы",
        "plain_trousers": "Простые штаны",
        "winter_trousers": "Шерстяные зимние порты",
        "none": "Без штанов",
    },
    "leg_wraps": {
        "none": "Без обмоток",
        "wool": "Шерстяные обмотки",
        "siksala": "Синие обмотки Сиксаля",
    },
    "footwear": {
        "porshni": "Поршни",
        "openwork_porshni": "Ажурные поршни",
        "embroidered_porshni": "Поршни с вышивкой",
        "protective_porshni": "Поршни поверх туфель",
        "novgorod_shoes": "Новгородские мягкие туфли",
        "rus_ankle_strap_shoes": "Мягкие туфли с ремешком у щиколотки",
        "embroidered_town_shoes": "Разноцветные городские туфли",
        "novgorod_ankle_boots": "Новгородские полусапожки",
        "novgorod_high_boots": "Новгородские сапоги",
        "embroidered_high_boots": "Сапоги с вышивкой и жемчугом",
        "bast_shoes": "Лапти",
        "oslo_strap_shoes": "Туфли с ремешком из Осло",
        "cloth_shoes": "Мягкие туфли",
        "steppe_boots": "Мягкие степные сапоги",
        "barefoot": "Без обуви",
    },
}
LABELS = {
    "trousers": "Порты и шоссы",
    "leg_wraps": "Обмотки",
    "footwear": "Обувь",
}

_CLOTH = {
    "straight": ("#655b4c", "#82745e", "#514940"),
    "gathered": ("#6d6154", "#8a7a65", "#574a43"),
    "hose": ("#60615b", "#79796b", "#494c48"),
    "plain_trousers": ("#665e54", "#8c7f6f", "#494039"),
    "winter_trousers": ("#62514c", "#8b7061", "#483b3a"),
}
_WRAP = {
    "wool": ("#96816b", "#71604e", "#b09a7b", "#635243"),
    "siksala": ("#526572", "#3e4e5a", "#76858a", "#384752"),
}
_SHOES = {
    "cloth_shoes": (
        "#413e3f", "#66606a", "#252629",
        "M-17 698Q-4 695 15 700L17 721Q7 731 -33 729Q-47 728 -43 719"
        "Q-40 711 -28 708Q-20 705 -17 698Z",
        "M-36 718Q-19 708 -9 710Q6 712 14 718Q-3 725 -32 725Z",
    ),
    "steppe_boots": (
        "#694b39", "#947156", "#442f26",
        "M-18 663Q-2 655 17 663Q13 684 17 711L19 723Q9 730 -28 728"
        "Q-50 728 -42 717Q-37 710 -23 704Q-15 688 -18 663Z",
        "M-15 665Q-9 657 -2 664Q-8 688 -6 704L-19 720L-37 723Q-39 715 -24 709Q-16 703 -15 665Z",
    ),
    "porshni": (
        "#8c634c", "#ab8061", "#614735",
        "M-18 702Q-17 695 -12 694Q0 690 15 696Q19 706 19 719"
        "Q16 728 1 729L-33 728Q-45 727 -45 720Q-45 713 -35 710Z",
        "M-43 720Q-37 715 -22 713Q-5 707 13 710L15 720"
        "Q-12 730 -34 725Z",
    ),
    "novgorod_shoes": (
        "#694b3e", "#8b654e", "#4c3731",
        "M-17 695Q-8 689 4 694Q11 696 17 694Q18 707 21 718"
        "Q21 725 11 727Q-9 730 -33 728Q-45 727 -44 720"
        "Q-42 711 -29 708Q-22 705 -17 695Z",
        "M-42 720Q-36 711 -23 711Q-13 708 -8 700"
        "Q3 705 13 704Q8 712 16 721Q-13 729 -34 725Z",
    ),
    "novgorod_ankle_boots": (
        "#61463b", "#795845", "#48342d",
        "M-23 665Q-14 659 1 664Q14 668 21 664Q20 676 18 686"
        "Q17 697 22 718Q23 725 10 727Q-11 730 -34 728"
        "Q-44 727 -43 721Q-42 714 -31 709Q-24 704 -21 696"
        "Q-18 685 -23 665Z",
        "M-19 668Q-5 662 4 670Q-7 690 -5 701Q-3 711 12 724"
        "Q-17 729 -38 724Q-34 716 -25 712Q-12 701 -17 682Z",
    ),
    "novgorod_high_boots": (
        "#5e483c", "#7b5a46", "#47352f",
        "M-26 637Q-11 631 1 636Q12 639 21 636Q22 654 20 666"
        "Q16 681 18 697Q18 706 22 718Q25 725 13 727"
        "Q-12 731 -36 728Q-45 726 -43 721Q-41 713 -31 709"
        "Q-22 705 -19 697Q-17 680 -21 666Q-24 651 -26 637Z",
        "M-23 640Q-8 634 2 641Q-5 655 -8 676Q-10 689 -7 699"
        "Q0 713 13 724Q-21 728 -38 724Q-35 715 -27 712"
        "Q-18 704 -16 691Q-14 676 -20 658Z",
    ),
    "oslo_strap_shoes": (
        "#78543f", "#a27756", "#563b2f",
        "M-18 698Q-15 692 -8 692Q-4 695 0 700Q8 704 16 695"
        "Q20 704 21 718Q20 725 11 727Q-13 730 -37 728"
        "Q-45 726 -43 720Q-41 714 -33 710Q-23 705 -18 698Z",
        "M-41 720Q-36 714 -27 712Q-18 711 -10 705"
        "Q-2 711 12 709L16 722Q-12 729 -34 725Z",
    ),
    "rus_ankle_strap_shoes": (
        "#8b5f45", "#ad7e5c", "#553d34",
        "M-15 702Q-7 694 3 698Q10 700 16 697Q16 707 19 717Q23 725 12 728"
        "Q-10 732 -35 728Q-45 726 -43 720Q-41 714 -31 710Q-20 706 -15 702Z",
        "M-40 720Q-32 714 -20 713Q-10 711 -4 704Q0 708 11 707L14 722"
        "Q-15 728 -35 725Z",
    ),
    "bast_shoes": (
        "#a98955", "#c7a777", "#62503a",
        "M-15 701Q-7 704 9 702Q18 704 19 714Q24 727 11 729"
        "Q-13 730 -35 728Q-47 727 -46 721Q-45 712 -32 710Q-19 706 -15 701Z",
        "M-42 720Q-37 716 -25 714Q-18 712 -13 707Q-7 707 7 706Q14 708 15 716"
        "Q3 722 -11 723Q-28 725 -40 723Z",
    ),
}
_SHOE_CUTS = {
    "openwork_porshni": ("porshni", ("#815143", "#a57259", "#543931")),
    "embroidered_porshni": ("porshni", ("#6e4c42", "#90675b", "#483732")),
    "protective_porshni": ("porshni", ("#755b4b", "#9a7c5d", "#504036")),
    "embroidered_town_shoes": ("novgorod_shoes", ("#934c40", "#b8634d", "#603831")),
    "embroidered_high_boots": ("novgorod_high_boots", ("#85463e", "#a95d4e", "#542f2f")),
}
_FOOT_LININGS = {
    "footcloth": ("#b1a085", "#d1bfa3", "#88765d"),
    "needlebound_sock": ("#847a66", "#a89c82", "#59534b"),
}
_INSOLES = {
    "felt_insole": ("#938170", "#b19d88", "#64564c"),
    "needlebound_insole": ("#8b775d", "#aa9279", "#5d4b3f"),
}
_MITTENS = {
    "wool_mittens": ("#8d766a", "#ae9585", "#63514a"),
    "work_mittens": ("#8e654a", "#ad8160", "#574234"),
    "military_mittens": ("#62504a", "#8b6e5e", "#413535"),
}


def _draw_trousers(parent, style, outer_hip, inner_hip, *, wrapped, geometry_only=False):
    base, light, shade = _CLOTH[style]
    outer = number(outer_hip)
    inner = number(inner_hip)
    outer_fall = number(outer_hip + 7)
    inner_fall = number(min(28, inner_hip))
    ankle_outer, ankle_inner = (-11, 11) if wrapped or style == "hose" else (-13, 12)
    if style == "winter_trousers" and not wrapped:
        ankle_outer, ankle_inner = -15, 14
    if style == "gathered":
        if wrapped:
            outside = (
                f"Q-15 666 -21 623Q-32 628 -30 619Q-37 614 -31 606"
                f"Q-34 597 -30 579Q{outer} 544 {outer} 465"
            )
            inside = f"Q{inner_fall} 535 22 567Q20 586 20 600Q25 611 16 626Q11 662 11 708"
            highlight = (
                f"M{outer_fall} 482Q-13 536 -14 573Q-15 601 -10 615"
                "Q-16 625 -23 615Q-21 605 -24 599Q-25 586 -23 579Z"
            )
            folds = "M-22 562Q-19 593 -24 605M-27 614Q-19 616 -14 607M12 590Q16 607 10 617"
        else:
            outside = (
                f"Q-20 686 -21 671Q-28 673 -25 662Q-35 663 -29 647"
                f"Q-35 639 -31 626Q-33 601 -30 579Q{outer} 544 {outer} 465"
            )
            inside = (
                f"Q{inner_fall} 535 22 567Q21 593 19 608Q24 623 19 633Q23 644 17 654"
                f"Q22 662 16 671Q10 682 {ankle_inner} 708"
            )
            highlight = (
                f"M{outer_fall} 482Q-13 536 -14 573Q-15 601 -10 617"
                "Q-13 635 -8 646Q-6 656 -14 667Q-16 651 -22 644"
                "Q-19 622 -23 610Q-25 592 -23 579Z"
            )
            folds = (
                "M-22 562Q-19 593 -24 614M-14 608Q-15 625 -22 638"
                "M-27 651Q-19 649 -16 642M-22 662Q-15 659 -12 652"
                "M12 590Q16 621 10 637M14 642Q13 656 8 662"
            )
    elif style == "hose":
        outside = f"Q-16 650 -19 621Q-22 604 -25 580Q{outer_fall} 544 {outer} 465"
        inside = f"Q{inner_fall} 519 23 554Q19 581 15 607Q10 651 {ankle_inner} 708"
        highlight = (
            f"M{outer_fall} 477Q-13 512 -10 553Q-10 580 -6 608"
            "Q-7 647 -3 687L-8 702Q-12 652 -17 621Q-17 593 -19 574Z"
        )
        folds = "M11 503Q11 560 7 585Q4 623 4 665M-13 602q8 8 17 8M-12 625q7 4 10 9"
    else:
        outside = f"Q-19 655 -22 622Q-25 600 -26 575Q{outer} 532 {outer} 465"
        inside = f"Q{inner_fall} 527 22 564Q21 593 17 626Q13 664 {ankle_inner} 708"
        highlight = (
            f"M{outer_fall} 477Q-13 537 -11 578Q-15 608 -9 634"
            "Q-9 666 -4 695L-9 702Q-18 654 -18 626Q-18 605 -22 590Z"
        )
        folds = "M13 517Q16 558 10 579M-19 567Q-13 585 -8 589M-17 608q7 15 17 21M8 643Q5 667 8 690"
    outline = (
        f"M{outer} 465Q{number((outer_hip + inner_hip) / 2)} 461 {inner} 465{inside}"
        f"Q0 711 {ankle_outer} 708{outside}Z"
    )
    if geometry_only:
        return outline
    path(parent, outline, base, data_material_surface="base")
    path(parent, f"M{inner} 465{inside}Q7 709 5 708Q1 664 5 629"
         f"Q11 566 {number(inner_hip - 10)} 466Z", shade, opacity=".76", data_material_surface="shade")
    path(parent, highlight, light, opacity=".78", data_material_surface="light")
    path(parent, outline, "none", class_="edge")
    path(parent, folds, class_="etch")
    if style == "winter_trousers":
        path(parent, "M-19 601Q-11 629 -10 657Q-9 680 -6 703M-9 702Q2 706 10 702",
             "none", stroke=shade, stroke_width=2.2, data_material_surface="shade")
        path(parent, "M-10 610l4 1m-2 5 4 1m-2 5 4 1m-2 5 4 1m-3 5 4 1m-3 5 4 1",
             "none", stroke=light, stroke_width=1.2, data_material_surface="light")


_WRAP_OUTLINE = ("M-23 623Q-13 617 -5 619Q5 624 17 625Q14 645 15 669"
                 "Q14 685 15 708Q1 712 -15 708Q-14 691 -18 667Q-22 645 -23 623Z")


def _draw_wrap(parent, style):
    if style == "image_leather_footrags":
        image_daily_art.draw_leg_wrap(parent, style)
        return
    base, shade, light, seam = _WRAP[style]
    outline = _WRAP_OUTLINE
    path(parent, outline, base, stroke="#392c2a", stroke_width=2.4, stroke_linejoin="round",
         data_material_surface="base")
    path(parent, "M-20 625Q-14 625 -10 628Q-8 651 -4 672Q-2 692 2 708L-13 708"
         "Q-13 685 -16 669Q-20 647 -20 625Z", shade, data_material_surface="shade")
    for index, (y, left, right) in enumerate((
        (627, -22, 16), (639, -21, 15), (651, -19, 15),
        (663, -17, 14), (675, -16, 14), (687, -14, 14), (699, -14, 14),
    )):
        drop = (9, 10, 8)[index % 3]
        curve = f"M{left} {y}Q-5 {y + 2} {right} {y + drop}"
        path(parent, curve, "none", stroke=seam, stroke_width=1.65, stroke_linecap="round",
             data_material_surface="fixed")
        path(parent, f"M{left + 3} {y + 3}Q-3 {y + 5} {right - 2} {y + drop + 2}",
             "none", stroke=light, stroke_width=1.05, stroke_linecap="round", opacity=".78",
             data_material_surface="light")
        if style == "siksala":
            path(parent, f"M{left + 7} {y + 3}l3 5m2 -4 3 5m2 -3 3 5m2 -4 3 5",
                 "none", stroke=light, stroke_width=.65, opacity=".65", data_material_surface="light")
    if style == "siksala":
        path(parent, "M-19 624Q-18 634 -17 638Q-16 647 -15 657",
             "none", stroke="#a48a67", stroke_width=1.4, stroke_linecap="round",
             data_material_surface="fixed")
        for x, y in ((-19, 634), (-17, 645), (-15, 656)):
            path(parent, f"M{x} {y}v3q-3 1 -3 4a3.25 3.25 0 1 0 5 -2"
                 "q-2 -1 -3 1t2 2", "none", stroke="#483a33", stroke_width=2.9,
                 stroke_linecap="round", data_material_surface="fixed")
            path(parent, f"M{x} {y}v3q-3 1 -3 4a3.25 3.25 0 1 0 5 -2"
                 "q-2 -1 -3 1t2 2", "none", stroke="#b79868", stroke_width=1.2,
                 stroke_linecap="round", data_material_surface="fixed")


_PROTECTIVE_SHOE_OUTLINE = "M-18 709Q-17 691 -10 688Q1 688 6 691L15 689L17 711Z"


def _draw_shoe(parent, style):
    cut, palette = _SHOE_CUTS.get(style, (style, None))
    base, light, shade, outline, highlight = _SHOES[cut]
    if palette is not None:
        base, light, shade = palette
    if style == "protective_porshni":
        path(parent, _PROTECTIVE_SHOE_OUTLINE,
             "#47332f", class_="edge", data_material_surface="fixed")
        path(parent, "M-13 693Q0 692 5 696L13 694", "none", stroke="#9d765d",
             stroke_width=1.6, data_material_surface="fixed")
    path(parent, outline, base, class_="edge", data_material_surface="base")
    path(parent, highlight, light, opacity=".84", data_material_surface="light")
    if cut == "porshni":
        path(parent, "M-43 718Q-37 717 -28 716Q-21 713 -17 702Q-6 699 3 701L14 704"
             "Q5 705 2 706Q-17 707 -18 716Q-36 723 -43 718Z", shade, data_material_surface="shade")
        path(parent, "M-39 716q4 1 8 4m-3 -8q5 2 7 5m-1 -7q5 2 7 4m-2 -6q5 1 7 3"
             "m-1 -11q1 4 2 5m4 -7 2 5m5 -6 1 5m5 -5v5m5 -3v5", class_="etch")
        path(parent, "M-19 704Q-13 696 0 699Q9 700 15 703", "none",
             stroke="#c59770", stroke_width=1.5, stroke_linecap="round")
    elif cut == "novgorod_shoes":
        path(parent, "M-15 697Q-5 697 2 701Q11 702 16 698L18 705Q5 711 -4 706Q-9 702 -17 704Z",
             shade, data_material_surface="shade")
        path(parent, "M-38 717Q-28 713 -20 714Q-13 712 -8 707", class_="etch")
        path(parent, "M-34 717l1 2m4 -4 1 2m4 -3 1 2m4 -3 1 2m3 -4 1 2m3 -5 1 2",
             "none", stroke="#c49773", stroke_width=1.05, stroke_linecap="round")
        path(parent, "M-5 704q-7 -4 -8 -1q0 3 8 1q8 -5 9 -2q0 3 -9 2q-2 3 -3 6m3 -6 5 4",
             "none", stroke="#c49b76", stroke_width=1.5, stroke_linecap="round")
    elif style == "novgorod_ankle_boots":
        path(parent, "M-19 668Q-6 663 7 668Q12 670 18 668M-16 693q13 -5 28 3"
             "M-19 703Q-9 702 -2 710Q7 715 16 716", class_="etch")
        path(parent, "M9 670Q4 685 12 697L15 706", "none",
             stroke="#a68060", stroke_width=1.4, stroke_linecap="round")
        path(parent, "M9 676l2 1m-4 4 3 1m-3 4 3 1m-1 4 3 1", class_="etch")
    elif cut == "novgorod_high_boots":
        path(parent, "M-21 640Q-14 637 -6 640Q7 644 17 640"
             "M-20 658q6 1 14 6m-11 8q7 1 9 4m-5 13q10 -5 24 0"
             "M-17 701Q-4 695 14 706M-22 709Q-9 708 -3 715", class_="etch")
        path(parent, "M13 643Q13 662 10 676Q9 683 12 688", "none",
             stroke="#a47b5e", stroke_width=1.4, stroke_linecap="round")
    elif style == "oslo_strap_shoes":
        path(parent, "M-16 696Q-9 696 -5 701Q5 707 16 697L18 708"
             "Q8 717 -2 716Q-11 715 -21 707Z", "#a9855e",
             stroke="#3c2924", stroke_width=2.05, stroke_linejoin="round", data_material_surface="light")
        path(parent, "M-16 700l-2 5m4-4 -2 5M-37 719q8 -2 13 -4", class_="etch")
        node(parent, "circle", cx=13, cy=705.5, r=1.55, fill="#d4ad76", stroke=shade, stroke_width=.85,
             data_material_surface="fixed")
    elif style == "rus_ankle_strap_shoes":
        path(parent, "M-13 690Q-2 687 14 690L14 696Q-2 699 -13 696Z", shade, class_="edge",
             data_material_surface="shade")
        path(parent, "M4 694l-4 11m4 -11 4 9m-44 15q8 -1 15 -4", class_="etch")
        path(parent, "M-10 692q12 -2 21 0", "none", stroke=light, stroke_width=1.15,
             data_material_surface="light")
    elif style == "bast_shoes":
        _draw_bast_weave(parent, light, shade)
    elif style == "steppe_boots":
        path(parent, "M-16 669Q-3 663 14 668M-14 684Q-2 681 10 687M-19 704Q-4 703 6 712",
             class_="etch")
    else:
        path(parent, "M-22 705Q-4 711 13 705M-36 718Q-24 713 -18 713", class_="etch")
    _draw_shoe_decoration(parent, style)
    path(parent, "M-39 724Q-15 730 16 723", class_="seam")


def _draw_bast_weave(parent, light, shade):
    path(parent, "M-13 705Q-10 699 -5 699Q2 698 9 704M-10 704Q-2 701 9 702"
         "M-41 718Q-22 718 -10 707Q-4 705 10 707", "none",
         stroke=shade, stroke_width=2.8, stroke_linecap="round", data_material_surface="shade")
    for weave in (
        "M-44 721l6 5m0 -11 14 12m-6 -14 16 14m-7 -17 18 17m-11 -20 20 19m-10 -21 18 18m-7 -18 10 10",
        "M-42 725l11 -12m-4 14 18 -18m-9 18 24 -21m-15 22 24 -22m-14 22 22 -18m-12 17 15 -12",
    ):
        path(parent, weave, "none", stroke=shade, stroke_width=1.6, stroke_linecap="round",
             data_material_surface="shade")
    path(parent, "M-42 724q20 0 32 -2t26 -3", "none", stroke=light, stroke_width=1.5,
         data_material_surface="light")


def _draw_shoe_decoration(parent, style):
    if style == "openwork_porshni":
        for x, y in ((-36, 718), (-28, 716), (-20, 712), (-12, 709), (-4, 710), (4, 712), (12, 713)):
            path(parent, f"M{x - 2.5} {y}l2.5 -3 2.5 3 -2.5 3Z", "#34282a",
                 stroke="#b48368", stroke_width=.7, data_material_surface="fixed")
    if style in {"embroidered_porshni", "embroidered_town_shoes"}:
        path(parent, "M-38 720q8 -5 15 -4t12 -4q5 -3 11 0t14 -1", "none",
             stroke="#dbb98c", stroke_width=1.7, stroke_linecap="round", data_material_surface="fixed")
        path(parent, "M-30 717l-1 5 5 -2m6 -4 2 3 4 -3m5 -5 1 4 5 -2m7 1 2 4 5 -4", "none",
             stroke="#9fbe9b", stroke_width=1.35, stroke_linecap="round", data_material_surface="fixed")
    if style == "embroidered_town_shoes":
        path(parent, "M-42 722Q-21 729 16 720", "none", stroke="#71918b", stroke_width=3,
             data_material_surface="fixed")
        for x, y in ((-34, 720), (-24, 718), (-14, 716), (-4, 713), (6, 716)):
            node(parent, "circle", cx=x, cy=y, r=1.3, fill="#f3e7c8", data_material_surface="trim")
    if style == "embroidered_high_boots":
        path(parent, "M-21 643Q-8 640 0 644Q9 646 17 643M-17 653Q-6 649 1 653Q9 655 17 651",
             "none", stroke="#dfb68c", stroke_width=1.65, data_material_surface="fixed")
        path(parent, "M-4 656Q-10 664 -3 670T-4 683Q-8 690 -2 697M-5 662l6 -2m-7 12 -6 -2m6 11 7 -3"
             "m-7 12 -6 -2M-39 722q9 -7 20 -3t28 -1", "none", stroke="#b6b987", stroke_width=1.8,
             stroke_linecap="round",
             data_material_surface="fixed")
        for x, y in ((-17, 647), (-5, 646), (7, 649), (15, 648), (-3, 664), (-3, 675), (-4, 686),
                     (-31, 720), (-21, 719), (-11, 721), (-1, 720)):
            node(parent, "circle", cx=x, cy=y, r=1.55, fill="#f5e8c8", data_material_surface="trim")
        for x, y in ((-11, 647), (1, 648), (11, 648)):
            path(parent, f"M{x} {y - 2}l2 2 -2 2 -2 -2Z", "#c39e68", stroke="#624938",
                 stroke_width=.6, data_material_surface="fixed")


_FOOT_OUTLINE = "L16 717Q17 726 1 728L-29 728Q-43 727 -40 720Q-43 716 -34 713Q-20 708 -13 702"


def _draw_foot_lining(parent, style):
    base, light, shade = _FOOT_LININGS[style]
    top = 675 if style == "footcloth" else 664
    outline = (f"M-15 {top}Q-2 {top - 4} 13 {top + 1}Q10 687 12 699"
               f"{_FOOT_OUTLINE}Q-9 694 -15 {top}Z")
    path(parent, outline, base, class_="edge", data_material_surface="base")
    path(parent, f"M-13 {top + 3}Q-4 {top} -2 {top + 3}Q-7 690 -4 704"
         "Q-5 713 -31 724L-38 722Q-35 717 -23 714Q-11 711 -12 704Z",
         light, opacity=".76", data_material_surface="light")
    if style == "footcloth":
        seams = ("M-13 682Q-6 681 11 686M-12 692Q-4 690 11 696"
                 "M-11 700Q-5 698 12 704M-13 709Q-3 707 13 711")
    else:
        seams = "M-13 668Q0 665 12 670M-10 673Q3 670 12 674"
        for y in range(677, 716, 5):
            seams += f"M-8 {y}q2 -3 4 0t4 0 4 0 4 0"
    path(parent, seams, "none", stroke=shade, stroke_width=1.35, stroke_linecap="round",
         data_material_surface="shade")


def _draw_shoe_accessory(parent, style):
    if style == "image_bone_skates":
        image_daily_art.draw_shoe_accessory(parent, style)
        return
    if style == "ice_grip":
        path(parent, "M-25 727Q-18 722 -16 714Q-10 712 -5 716Q-9 725 -11 729Z",
             "#887359", stroke="#442e2a", stroke_width=1, data_material_surface="fixed")
        path(parent, "M-32 725Q-14 725 -5 724L-4 728L-9 729L-10 733L-13 730"
             "L-22 730L-25 733L-27 730L-33 729Z",
             "#686b6c", stroke="#442e2a", stroke_width=1, data_material_surface="base")
        path(parent, "M-29 727Q-18 728 -8 726", "none", stroke="#a9aaab",
             stroke_width=1.25, data_material_surface="light")
    elif style == "spur":
        path(parent, "M10 710Q6 716 11 723L17 723L17 719Q12 717 15 711Z",
             "#897357", stroke="#442e2a", stroke_width=1, data_material_surface="fixed")
        path(parent, "M11 720Q16 718 20 720L27 722L31 720L29 726L23 725L16 723L12 724Z",
             "#77777b", stroke="#442e2a", stroke_width=1, data_material_surface="base")
        path(parent, "M15 721Q20 721 25 723", "none", stroke="#b2ada7",
             stroke_width=1.15, data_material_surface="light")


def draw_mitten(parent, style, *, left, right, y_offset=0):
    base, light, shade = _MITTENS[style]
    mitten = node(parent, "g", transform=f"translate({number(left)} {number(y_offset)}) scale({number((right - left) / 30)} 1)",
                  data_part="gloves", data_style=style, data_material_slot="gloves")
    outline = ("M3 441Q14 440 27 442L27 450Q31 452 32 457Q34 462 29 463L27 462"
               "Q27 471 23 474Q15 478 8 474Q2 472 2 465L1 450Z")
    path(mitten, outline, base, class_="edge", data_material_surface="base")
    path(mitten, "M4 447L11 448Q8 457 10 467Q12 472 17 473Q10 476 6 471Q3 468 4 447Z",
         light, data_material_surface="light")
    path(mitten, "M22 451Q20 456 23 462L27 462Q27 470 23 474L19 475Q22 470 21 462Z",
         shade, data_material_surface="shade")
    if style == "wool_mittens":
        for y in (451, 455, 459, 463, 467):
            path(mitten, f"M8 {y}q3 4 6 0m0 0q3 4 6 0", "none",
                 stroke=light, stroke_width=1.15, stroke_linecap="round", data_material_surface="light")
    elif style == "work_mittens":
        path(mitten, "M4 452Q14 454 26 452M7 469Q13 474 22 470M22 458Q24 455 28 454",
             class_="etch")
    else:
        path(mitten, "M3 450Q14 451 28 449L29 453Q17 456 3 454Z",
             shade, stroke="#442e2a", stroke_width=1, data_material_surface="shade")
        path(mitten, "M8 453l2 -1m3 2 2 -1m3 0 2 -1m3 0 2 -1M9 465Q15 468 22 465",
             "none", stroke=light, stroke_width=1.15, data_material_surface="light")


def fit_held_mitten(parent, style):
    palette = dict(zip(("base", "light", "shade"), _MITTENS[style], strict=True))
    for shape in parent.findall(".//*[@data-hand-tone]"):
        tone = shape.get("data-hand-tone")
        paint = "stroke" if shape.get("fill") == "none" else "fill"
        shape.attrib.update({paint: palette[tone], "data-material-slot": "gloves", "data-material-surface": tone})


def draw_detail(parent, slot, item):
    if slot == "footwear":
        shoe = node(parent, "g", data_part="footwear", data_style=item, data_material_slot=slot,
                    transform="translate(180 -1062) scale(1.7)")
        _draw_shoe(shoe, item)
        return
    if slot != "insole" or item not in _INSOLES:
        return
    detail = node(parent, "g", data_part="insole-detail", data_style=item, data_material_slot=slot)
    _draw_insole(detail, item)


def _draw_insole(parent, style):
    base, light, shade = _INSOLES[style]
    outline = ("M49 94Q50 65 85 63Q116 59 155 76Q180 87 207 79"
               "Q234 71 254 84Q278 100 274 121Q271 147 243 149"
               "Q209 151 176 139Q140 127 118 141Q91 153 68 140Q46 126 49 94Z")
    path(parent, outline, base, stroke="#46372f", stroke_width=2.2,
         data_material_surface="base")
    path(parent, "M55 111Q61 138 83 139Q103 143 121 134Q145 122 181 135Q219 149 247 143"
         "Q264 141 269 123Q248 134 225 129Q205 125 187 123Q155 112 134 119Q74 139 55 111Z",
         shade, data_material_surface="shade")
    path(parent, "M58 94Q66 69 92 70Q122 66 153 84Q179 96 208 88Q234 82 250 90"
         "Q236 83 204 102Q178 110 153 98Q95 75 58 94Z",
         light, data_material_surface="light")
    if style == "needlebound_insole":
        for y, left, right in ((84, 75, 122), (94, 65, 141), (104, 64, 259),
                               (114, 67, 264), (124, 75, 125), (124, 190, 255)):
            loops = "t8 0" * ((right - left - 8) // 8)
            path(parent, f"M{left} {y}q4 -6 8 0{loops}", "none", stroke=shade, stroke_width=2,
                 stroke_linecap="round", data_material_surface="shade")
    else:
        for x, y in ((74, 90), (80, 111), (89, 82), (90, 119), (104, 93), (110, 106),
                     (127, 87), (139, 108), (151, 114), (168, 104), (188, 113), (198, 96),
                     (215, 113), (228, 93), (234, 114), (252, 102), (256, 119)):
            path(parent, f"M{x} {y}l5 -2m-2 5 4 1", "none", stroke=light, stroke_width=1.7,
                 stroke_linecap="round", opacity=".8", data_material_surface="light")


def _draw_bare_leg(parent, outer_hip, inner_hip, skin, *, barefoot, geometry_only=False):
    outside = f"Q-18 658 -22 612Q{number(outer_hip)} 541 {number(outer_hip)} 469Z"
    ankle = _FOOT_OUTLINE if barefoot else "Q10 704 10 711H-13"
    contour = (f"M{number(outer_hip)} 469Q0 462 {number(inner_hip)} 469Q23 531 20 584"
               f"Q17 625 12 697{ankle}{outside}")
    if geometry_only:
        return contour
    path(parent, contour, skin.base, class_="edge")
    path(parent, "M-14 589Q-9 598 -6 620Q-1 657 -5 684L-10 696Q-12 642 -18 614Z", skin.light)
    path(parent, "M-15 595q9 5 17 2m-12 14q8 1 12 -2", class_="etch")
    if barefoot:
        path(parent, "M-39 719q6 -2 9 2m-3 -5q6 -1 8 2m-1 -5 7 2", class_="etch")


@dataclass(frozen=True)
class LowerLimbFit:
    width: float
    ankle: float
    outer_hip: float
    inner_hip: float

    @property
    def transforms(self):
        return (f"translate({number(self.ankle)} 0) scale({number(self.width)} 1)",
                f"translate({number(320 - self.ankle)} 0) scale({number(-self.width)} 1)")


def lower_limb_fit(body, *, dress=False, trousers="straight"):
    """Одна ось щиколотки и ширина для штанов, обуви и защиты каждой ноги."""
    width = min(1.06, max(.80, .78 + (body.waist - 45) * .008))
    ankle = (129 if dress else 120) + max(-4, min(4, round((70 - body.waist) * .14)))
    outer_hip = (162 - min(72, body.waist) - ankle) / width
    if trousers == "hose":
        outer_hip += 7
    inner_hip = (154 - ankle) / width
    return LowerLimbFit(width, ankle, outer_hip, inner_hip)


def lower_limb_surfaces(fit, *, trousers, leg_wraps, footwear, foot_lining="none"):
    """Фактические замкнутые контуры нижних слоёв в координатах одной ноги."""
    if trousers == "none":
        contours = [_draw_bare_leg(None, fit.outer_hip, fit.inner_hip, None,
                                  barefoot=False, geometry_only=True)]
    else:
        contours = [_draw_trousers(None, trousers, fit.outer_hip, fit.inner_hip,
                                  wrapped=leg_wraps != "none", geometry_only=True)]
    if leg_wraps == "image_leather_footrags":
        from xml.etree.ElementTree import Element
        sketch = Element("g")
        image_daily_art._leather_wrap(sketch)
        contours.append((sketch[0].get("d"), -120))
    elif leg_wraps != "none":
        # The same envelope is shared by both cloth-wrap styles.
        contours.append(_WRAP_OUTLINE)
    if foot_lining != "none":
        top = 675 if foot_lining == "footcloth" else 664
        contours.append(f"M-15 {top}Q-2 {top - 4} 13 {top + 1}Q10 687 12 699"
                        f"{_FOOT_OUTLINE}Q-9 694 -15 {top}Z")
    if footwear != "barefoot":
        cut, _ = _SHOE_CUTS.get(footwear, (footwear, None))
        contours.append(_SHOES[cut][3])
        if footwear == "protective_porshni":
            contours.append(_PROTECTIVE_SHOE_OUTLINE)
    return contours


def draw_lower_wear(parent, body, *, trousers, leg_wraps, footwear, dress, skin,
                    foot_lining="none", insole="none", shoe_accessory="none"):
    fit = lower_limb_fit(body, dress=dress, trousers=trousers)
    outer_hip, inner_hip, transforms = fit.outer_hip, fit.inner_hip, fit.transforms
    legs = node(parent, "g", data_part="trousers", data_style=trousers,
                data_material_slot="trousers" if trousers != "none" else None)
    for transform in transforms:
        leg = node(legs, "g", transform=transform)
        if trousers == "none":
            _draw_bare_leg(leg, outer_hip, inner_hip, skin,
                           barefoot=footwear == "barefoot" and foot_lining == "none")
        else:
            _draw_trousers(leg, trousers, outer_hip, inner_hip, wrapped=leg_wraps != "none")
    if foot_lining != "none":
        lining = node(parent, "g", data_part="foot-lining", data_style=foot_lining, data_material_slot="foot_lining")
        for transform in transforms:
            _draw_foot_lining(node(lining, "g", transform=transform), foot_lining)
    if leg_wraps != "none":
        wraps = node(parent, "g", data_part="leg-wraps", data_style=leg_wraps, data_material_slot="leg_wraps")
        for transform in transforms:
            _draw_wrap(node(wraps, "g", transform=transform), leg_wraps)
    if footwear != "barefoot" and insole != "none":
        soles = node(parent, "g", data_part="insole", data_style=insole, data_material_slot="insole")
        for transform in transforms:
            group = node(soles, "g", transform=transform)
            # The insert sits inside the opaque sole of every shoe cut.
            group = node(group, "g", transform="translate(-42 712) scale(.2 .09)")
            _draw_insole(group, insole)
    shoes = node(parent, "g", data_part="footwear", data_style=footwear,
                 data_material_slot="footwear" if footwear != "barefoot" else None)
    if footwear == "barefoot" and (trousers == "none" or foot_lining != "none"):
        return
    for transform in transforms:
        shoe = node(shoes, "g", transform=transform)
        if footwear == "barefoot":
            path(shoe, f"M-13 702Q0 704 12 697{_FOOT_OUTLINE}Z", skin.base, class_="edge")
            path(shoe, "M-39 719q6 -2 9 2m-3 -5q6 -1 8 2", class_="etch")
        else:
            _draw_shoe(shoe, footwear)
    if footwear != "barefoot" and shoe_accessory != "none":
        details = node(parent, "g", data_part="shoe-accessory", data_style=shoe_accessory,
                       data_material_slot="shoe_accessory")
        for transform in transforms:
            _draw_shoe_accessory(node(details, "g", transform=transform), shoe_accessory)
