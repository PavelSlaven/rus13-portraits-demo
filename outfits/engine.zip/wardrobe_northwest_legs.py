from common import node, number, path


OPTIONS = {
    "trousers": {
        "straight": "Прямые порты",
        "gathered": "Порты с напуском",
        "hose": "Раздельные шерстяные шоссы",
    },
    "leg_wraps": {
        "none": "Без обмоток",
        "wool": "Шерстяные обмотки",
        "siksala": "Синие обмотки Сиксаля",
    },
    "footwear": {
        "porshni": "Поршни",
        "novgorod_shoes": "Новгородские мягкие туфли",
        "novgorod_ankle_boots": "Новгородские полусапожки",
        "novgorod_high_boots": "Новгородские сапоги",
        "oslo_strap_shoes": "Туфли с ремешком из Осло",
    },
}
LABELS = {
    "trousers": "Порты и шоссы",
    "leg_wraps": "Обмотки",
    "footwear": "Обувь",
}

_CLOTH = {
    "straight": ("#655b4c", "#82745e", "#514940"),
    "gathered": ("#6d6154", "#8a7a65", "#574a43"),
    "hose": ("#60615b", "#79796b", "#494c48"),
}
_WRAP = {
    "wool": ("#96816b", "#71604e", "#b09a7b", "#635243"),
    "siksala": ("#526572", "#3e4e5a", "#76858a", "#384752"),
}
_SHOES = {
    "porshni": (
        "#8c634c", "#ab8061", "#614735",
        "M-18 702Q-17 695 -12 694Q0 690 15 696Q19 706 19 719"
        "Q16 728 1 729L-33 728Q-45 727 -45 720Q-45 713 -35 710Z",
        "M-43 720Q-37 715 -22 713Q-5 707 13 710L15 720"
        "Q-12 730 -34 725Z",
    ),
    "novgorod_shoes": (
        "#694b3e", "#8b654e", "#4c3731",
        "M-17 695Q-8 689 4 694Q11 696 17 694Q18 707 21 718"
        "Q21 725 11 727Q-9 730 -33 728Q-45 727 -44 720"
        "Q-42 711 -29 708Q-22 705 -17 695Z",
        "M-42 720Q-36 711 -23 711Q-13 708 -8 700"
        "Q3 705 13 704Q8 712 16 721Q-13 729 -34 725Z",
    ),
    "novgorod_ankle_boots": (
        "#61463b", "#795845", "#48342d",
        "M-23 665Q-14 659 1 664Q14 668 21 664Q20 676 18 686"
        "Q17 697 22 718Q23 725 10 727Q-11 730 -34 728"
        "Q-44 727 -43 721Q-42 714 -31 709Q-24 704 -21 696"
        "Q-18 685 -23 665Z",
        "M-19 668Q-5 662 4 670Q-7 690 -5 701Q-3 711 12 724"
        "Q-17 729 -38 724Q-34 716 -25 712Q-12 701 -17 682Z",
    ),
    "novgorod_high_boots": (
        "#5e483c", "#7b5a46", "#47352f",
        "M-26 637Q-11 631 1 636Q12 639 21 636Q22 654 20 666"
        "Q16 681 18 697Q18 706 22 718Q25 725 13 727"
        "Q-12 731 -36 728Q-45 726 -43 721Q-41 713 -31 709"
        "Q-22 705 -19 697Q-17 680 -21 666Q-24 651 -26 637Z",
        "M-23 640Q-8 634 2 641Q-5 655 -8 676Q-10 689 -7 699"
        "Q0 713 13 724Q-21 728 -38 724Q-35 715 -27 712"
        "Q-18 704 -16 691Q-14 676 -20 658Z",
    ),
    "oslo_strap_shoes": (
        "#78543f", "#a27756", "#563b2f",
        "M-18 698Q-15 692 -8 692Q-4 695 0 700Q8 704 16 695"
        "Q20 704 21 718Q20 725 11 727Q-13 730 -37 728"
        "Q-45 726 -43 720Q-41 714 -33 710Q-23 705 -18 698Z",
        "M-41 720Q-36 714 -27 712Q-18 711 -10 705"
        "Q-2 711 12 709L16 722Q-12 729 -34 725Z",
    ),
}


def _draw_trousers(parent, style, outer_hip, inner_hip, *, wrapped):
    base, light, shade = _CLOTH[style]
    outer = number(outer_hip)
    inner = number(inner_hip)
    outer_fall = number(outer_hip + 7)
    inner_fall = number(min(28, inner_hip))
    ankle_outer, ankle_inner = (-11, 11) if wrapped or style == "hose" else (-13, 12)
    if style == "gathered":
        if wrapped:
            outside = (
                f"Q-15 666 -21 623Q-32 628 -30 619Q-37 614 -31 606"
                f"Q-34 597 -30 579Q{outer} 544 {outer} 465"
            )
            inside = f"Q{inner_fall} 535 22 567Q20 586 20 600Q25 611 16 626Q11 662 11 708"
            highlight = (
                f"M{outer_fall} 482Q-13 536 -14 573Q-15 601 -10 615"
                "Q-16 625 -23 615Q-21 605 -24 599Q-25 586 -23 579Z"
            )
            folds = "M-22 562Q-19 593 -24 605M-27 614Q-19 616 -14 607M12 590Q16 607 10 617"
        else:
            outside = (
                f"Q-20 686 -21 671Q-28 673 -25 662Q-35 663 -29 647"
                f"Q-35 639 -31 626Q-33 601 -30 579Q{outer} 544 {outer} 465"
            )
            inside = (
                f"Q{inner_fall} 535 22 567Q21 593 19 608Q24 623 19 633Q23 644 17 654"
                f"Q22 662 16 671Q10 682 {ankle_inner} 708"
            )
            highlight = (
                f"M{outer_fall} 482Q-13 536 -14 573Q-15 601 -10 617"
                "Q-13 635 -8 646Q-6 656 -14 667Q-16 651 -22 644"
                "Q-19 622 -23 610Q-25 592 -23 579Z"
            )
            folds = (
                "M-22 562Q-19 593 -24 614M-14 608Q-15 625 -22 638"
                "M-27 651Q-19 649 -16 642M-22 662Q-15 659 -12 652"
                "M12 590Q16 621 10 637M14 642Q13 656 8 662"
            )
    elif style == "hose":
        outside = f"Q-16 650 -19 621Q-22 604 -25 580Q{outer_fall} 544 {outer} 465"
        inside = f"Q{inner_fall} 519 23 554Q19 581 15 607Q10 651 {ankle_inner} 708"
        highlight = (
            f"M{outer_fall} 477Q-13 512 -10 553Q-10 580 -6 608"
            "Q-7 647 -3 687L-8 702Q-12 652 -17 621Q-17 593 -19 574Z"
        )
        folds = "M11 503Q11 560 7 585Q4 623 4 665M-13 602q8 8 17 8M-12 625q7 4 10 9"
    else:
        outside = f"Q-19 655 -22 622Q-25 600 -26 575Q{outer} 532 {outer} 465"
        inside = f"Q{inner_fall} 527 22 564Q21 593 17 626Q13 664 {ankle_inner} 708"
        highlight = (
            f"M{outer_fall} 477Q-13 537 -11 578Q-15 608 -9 634"
            "Q-9 666 -4 695L-9 702Q-18 654 -18 626Q-18 605 -22 590Z"
        )
        folds = "M13 517Q16 558 10 579M-19 567Q-13 585 -8 589M-17 608q7 15 17 21M8 643Q5 667 8 690"
    outline = (
        f"M{outer} 465Q{number((outer_hip + inner_hip) / 2)} 461 {inner} 465{inside}"
        f"Q0 711 {ankle_outer} 708{outside}Z"
    )
    path(parent, outline, base)
    path(parent, f"M{inner} 465{inside}Q7 709 5 708Q1 664 5 629"
         f"Q11 566 {number(inner_hip - 10)} 466Z", shade, opacity=".76")
    path(parent, highlight, light, opacity=".78")
    path(parent, outline, "none", class_="edge")
    path(parent, folds, class_="etch")


def _draw_wrap(parent, style):
    base, shade, light, seam = _WRAP[style]
    outline = (
        "M-23 623Q-13 617 -5 619Q5 624 17 625Q14 645 15 669"
        "Q14 685 15 708Q1 712 -15 708Q-14 691 -18 667Q-22 645 -23 623Z"
    )
    path(parent, outline, base, stroke="#392c2a", stroke_width=2.4, stroke_linejoin="round")
    path(parent, "M-20 625Q-14 625 -10 628Q-8 651 -4 672Q-2 692 2 708L-13 708"
         "Q-13 685 -16 669Q-20 647 -20 625Z", shade)
    for index, (y, left, right) in enumerate((
        (627, -22, 16), (639, -21, 15), (651, -19, 15),
        (663, -17, 14), (675, -16, 14), (687, -14, 14), (699, -14, 14),
    )):
        drop = (9, 10, 8)[index % 3]
        curve = f"M{left} {y}Q-5 {y + 2} {right} {y + drop}"
        path(parent, curve, "none", stroke=seam, stroke_width=1.65, stroke_linecap="round")
        path(parent, f"M{left + 3} {y + 3}Q-3 {y + 5} {right - 2} {y + drop + 2}",
             "none", stroke=light, stroke_width=1.05, stroke_linecap="round", opacity=".78")
        if style == "siksala":
            path(parent, f"M{left + 7} {y + 3}l3 5m2 -4 3 5m2 -3 3 5m2 -4 3 5",
                 "none", stroke=light, stroke_width=.65, opacity=".65")
    if style == "siksala":
        path(parent, "M-19 624Q-18 634 -17 638Q-16 647 -15 657",
             "none", stroke="#a48a67", stroke_width=1.4, stroke_linecap="round")
        for x, y in ((-19, 634), (-17, 645), (-15, 656)):
            path(parent, f"M{x} {y}v3q-3 1 -3 4a3.25 3.25 0 1 0 5 -2"
                 "q-2 -1 -3 1t2 2", "none", stroke="#483a33", stroke_width=2.9,
                 stroke_linecap="round")
            path(parent, f"M{x} {y}v3q-3 1 -3 4a3.25 3.25 0 1 0 5 -2"
                 "q-2 -1 -3 1t2 2", "none", stroke="#b79868", stroke_width=1.2,
                 stroke_linecap="round")


def _draw_shoe(parent, style):
    base, light, shade, outline, highlight = _SHOES[style]
    path(parent, outline, base, class_="edge")
    path(parent, highlight, light, opacity=".84")
    if style == "porshni":
        path(parent, "M-43 718Q-37 717 -28 716Q-21 713 -17 702Q-6 699 3 701L14 704"
             "Q5 705 2 706Q-17 707 -18 716Q-36 723 -43 718Z", shade)
        path(parent, "M-39 716q4 1 8 4m-3 -8q5 2 7 5m-1 -7q5 2 7 4m-2 -6q5 1 7 3"
             "m-1 -11q1 4 2 5m4 -7 2 5m5 -6 1 5m5 -5v5m5 -3v5", class_="etch")
        path(parent, "M-19 704Q-13 696 0 699Q9 700 15 703", "none",
             stroke="#c59770", stroke_width=1.5, stroke_linecap="round")
    elif style == "novgorod_shoes":
        path(parent, "M-15 697Q-5 697 2 701Q11 702 16 698L18 705Q5 711 -4 706Q-9 702 -17 704Z",
             shade)
        path(parent, "M-38 717Q-28 713 -20 714Q-13 712 -8 707", class_="etch")
        path(parent, "M-34 717l1 2m4 -4 1 2m4 -3 1 2m4 -3 1 2m3 -4 1 2m3 -5 1 2",
             "none", stroke="#c49773", stroke_width=1.05, stroke_linecap="round")
        path(parent, "M-5 704q-7 -4 -8 -1q0 3 8 1q8 -5 9 -2q0 3 -9 2q-2 3 -3 6m3 -6 5 4",
             "none", stroke="#c49b76", stroke_width=1.5, stroke_linecap="round")
    elif style == "novgorod_ankle_boots":
        path(parent, "M-19 668Q-6 663 7 668Q12 670 18 668M-16 693q13 -5 28 3"
             "M-19 703Q-9 702 -2 710Q7 715 16 716", class_="etch")
        path(parent, "M9 670Q4 685 12 697L15 706", "none",
             stroke="#a68060", stroke_width=1.4, stroke_linecap="round")
        path(parent, "M9 676l2 1m-4 4 3 1m-3 4 3 1m-1 4 3 1", class_="etch")
    elif style == "novgorod_high_boots":
        path(parent, "M-21 640Q-14 637 -6 640Q7 644 17 640"
             "M-20 658q6 1 14 6m-11 8q7 1 9 4m-5 13q10 -5 24 0"
             "M-17 701Q-4 695 14 706M-22 709Q-9 708 -3 715", class_="etch")
        path(parent, "M13 643Q13 662 10 676Q9 683 12 688", "none",
             stroke="#a47b5e", stroke_width=1.4, stroke_linecap="round")
    else:
        path(parent, "M-16 696Q-9 696 -5 701Q5 707 16 697L18 708"
             "Q8 717 -2 716Q-11 715 -21 707Z", "#a9855e",
             stroke="#3c2924", stroke_width=2.05, stroke_linejoin="round")
        path(parent, "M-16 700l-2 5m4-4 -2 5M-37 719q8 -2 13 -4", class_="etch")
        node(parent, "circle", cx=13, cy=705.5, r=1.55, fill="#d4ad76", stroke=shade, stroke_width=.85)
    path(parent, "M-39 724Q-15 730 16 723", class_="seam")


def draw_lower_wear(parent, body, *, trousers, leg_wraps, footwear, dress):
    # All three layers use the same local x=0 at the ankle and the same stage y coordinates.
    width = min(1.06, max(.80, .78 + (body.waist - 45) * .008))
    ankle = (129 if dress else 120) + max(-4, min(4, round((70 - body.waist) * .14)))
    outer_hip = (162 - min(72, body.waist) - ankle) / width
    if trousers == "hose":
        outer_hip += 7
    inner_hip = (154 - ankle) / width
    transforms = (
        f"translate({ankle} 0) scale({number(width)} 1)",
        f"translate({320 - ankle} 0) scale({number(-width)} 1)",
    )
    legs = node(parent, "g", data_part="trousers", data_style=trousers)
    for transform in transforms:
        _draw_trousers(node(legs, "g", transform=transform), trousers, outer_hip, inner_hip,
                       wrapped=leg_wraps != "none")
    if leg_wraps != "none":
        wraps = node(parent, "g", data_part="leg-wraps", data_style=leg_wraps)
        for transform in transforms:
            _draw_wrap(node(wraps, "g", transform=transform), leg_wraps)
    shoes = node(parent, "g", data_part="footwear", data_style=footwear)
    for transform in transforms:
        _draw_shoe(node(shoes, "g", transform=transform), footwear)
