from common import node, number, path


OPTIONS = {
    "rus_gold_yoke_gown": "Рубаха с расшитым шёлковым оплечьем",
    "rus_checked_panel": "Рубаха с клетчатым поясным полотнищем",
    "naumburg_clasp_mantle": "Наумбургская накидка с парными застёжками",
    "song_pheasant_robe": "Сунское платье с вышитыми фазанами",
}


def draw_gold_yoke_gown(art):
    front, cloth, body = art.front, art.cloth, art.body
    shoulder = 160 - body.shoulder
    left_neck = number(156 - art.neck)
    right_neck = number(164 + art.neck)
    left_end = shoulder + 8
    right_end = 320 - left_end
    yoke = node(front, "g", data_part="embroidered-silk-yoke")
    path(
        yoke,
        f"M{left_neck} 271 Q160 305 {right_neck} 271 "
        f"Q{right_end + 8} 279 {right_end} 294 L{right_end - 10} 317 "
        f"Q160 350 {left_end + 10} 317 L{left_end} 294 Q{left_end - 8} 279 {left_neck} 271Z",
        "#713d38", class_="edge",
    )
    path(
        yoke,
        f"M{left_neck} 277 Q160 316 {right_neck} 277 "
        f"M{left_end + 4} 297 Q{left_end + 9} 312 {left_end + 12} 313 "
        f"Q160 344 {right_end - 12} 313 Q{right_end - 9} 312 {right_end - 4} 297",
        "none", stroke="#d8af73", stroke_width=2.5,
    )
    step = (body.shoulder - 14) / 4
    for index in range(-3, 4):
        x = number(160 + step * index)
        y = 317 - round(index * index * 1.45)
        motif = node(yoke, "g", transform=f"translate({x} {y}) rotate({-index * 7})")
        path(motif, "M0 -9 8 0 0 9 -8 0Z", "#a46949", stroke="#edc88a", stroke_width=1.8)
        path(motif, "M0 -4 3 0 0 4 -3 0Z", "#f0d4a1")
        path(motif, "M-10 0h-2 M10 0h2", "none", stroke="#d6a76c", stroke_width=1.4)

    # The gathered cloth draws towards the separate woven waist tie.
    for index in range(-3, 4):
        x = 160 + round(index * body.waist / 5)
        offset = index * 3
        path(
            front,
            f"M{x + offset - 2} {339 - abs(offset)} Q{x - 7} 379 {x - 1} 402 "
            f"Q{x - 2} 416 {x - 6} 430 L{x + 1} 427 Q{x + 6} 414 {x + 3} 399 "
            f"Q{x - 3} 373 {x + offset - 2} {339 - abs(offset)}Z",
            cloth.shade, opacity=.72,
        )
        path(front, f"M{x + 3} 359 Q{x - 2} 384 {x + 5} 398 M{x + 5} 414l-2 11",
             "none", stroke=cloth.light, stroke_width=1.5, opacity=.66)

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{shoulder + 4} 307 Q{outside + 18} 325 {outside + 6} 349 "
             f"M{shoulder - 5} 319 Q{outside + 21} 329 {outside + 16} 350", class_="seam")
        path(sleeve, f"M{outside - 1} 415 Q{outside + 24} 423 {shoulder + 26} 414",
             "none", stroke="#713d38", stroke_width=8.5)
        path(sleeve, f"M{outside - 1} 414 Q{outside + 24} 422 {shoulder + 26} 413",
             "none", stroke="#e1b67d", stroke_width=1.9, stroke_dasharray="2 2.8")


def draw_checked_panel(art):
    front, cloth, body = art.front, art.cloth, art.body
    left_neck = number(159 - art.neck)
    right_neck = number(161 + art.neck)
    path(
        front,
        f"M{left_neck} 273 Q160 308 {right_neck} 273 Q174 288 167 297 "
        f"L166 314 158 321 150 314 152 295Q141 288 {left_neck} 273Z",
        "#72534b", class_="edge",
    )
    path(front, f"M{left_neck} 274 Q147 291 156 296L154 313l4 4 M{right_neck} 274Q173 291 163 296l-2 16",
         "none", stroke="#bd9275", stroke_width=1.6)
    path(front, "M157 289 Q161 297 158 306", "none", stroke=cloth.light, stroke_width=2.4)
    path(
        front,
        f"M{160 - body.chest + 19} 326 Q{160 - body.waist + 16} 354 {160 - body.waist + 32} 388 "
        f"M{160 + body.chest - 20} 331 Q{160 + body.waist - 22} 373 {160 + body.waist - 34} 388 "
        "M149 329Q149 352 143 366 M173 340Q176 360 165 385",
        "none", stroke=cloth.shade, stroke_width=2, opacity=.75,
    )
    left, right = 149 - body.waist, 171 + body.waist
    overlap = 160 + round(body.waist * .47)
    fabric = node(art.waist, "g", data_part="checked-wool")
    outline = f"M{left - 24} 388 Q160 400 {right + 24} 387 V450 H{left - 24}Z"
    path(fabric, outline, "#88605c", class_="edge")
    for y in (401, 425, 449):
        stripe = f"M{left - 25} {y - 5} Q160 {y + 7} {right + 25} {y - 5}"
        path(fabric, stripe, "none", stroke="#53404a", stroke_width=8)
        path(fabric, stripe, "none", stroke="#ba9181", stroke_width=1.4, opacity=.78)
    for x in range(160 - 5 * 22, 160 + 6 * 22, 22):
        flare = round((x - 160) / 8)
        path(fabric, f"M{x} 391 Q{x - 2} 421 {x + flare - 2} 450",
             "none", stroke="#4d3c43", stroke_width=7, opacity=.73)
        path(fabric, f"M{x + 4} 393 Q{x + 2} 421 {x + flare + 2} 450",
             "none", stroke="#d6aa92", stroke_width=1.25, opacity=.75)
    path(fabric, f"M{overlap} 391Q{overlap - 3} 420 {overlap - 13} 449H{overlap + 2}"
         f"Q{overlap + 10} 412 {overlap + 7} 391Z", "#3f2e37", opacity=.4)
    belt = node(art.waist, "g", data_part="belt", clip_path="url(#wardrobe-torso-mask)")
    bindings = (
        (belt, f"M{left - 19} 388Q160 401 {right + 19} 387"),
        (art.waist, f"M{overlap + 3} 395Q{overlap + 1} 420 {overlap - 9} 446"),
    )
    for parent, contour in bindings:
        path(parent, contour, "none", stroke="#54373a", stroke_width=8.6, stroke_linecap="round")
        path(parent, contour, "none", stroke="#c39972", stroke_width=4, stroke_linecap="round")
        path(parent, contour, "none", stroke="#78534a", stroke_width=1.6, stroke_dasharray="2.2 3.6")

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        path(sleeve, f"M{outside + 10} 359 Q{outside + 9} 390 {outside + 27} 419 "
             f"Q{outside + 22} 393 {outside + 26} 374Z", cloth.light, opacity=.78)
        contour = f"M{outside - 4} 421 Q{outside + 24} 425 {160 - body.waist + 14} 418"
        path(sleeve, contour, "none", stroke="#765a54", stroke_width=6)
        path(sleeve, contour, "none", stroke="#d4aa83", stroke_width=1.7, stroke_dasharray="2 2.8")


def draw_naumburg_clasp_mantle(art):
    front, outer, cloth, body = art.front, art.outer, art.cloth, art.body
    shoulder = 160 - body.shoulder
    outside = 160 - body.sleeve
    left_neck = number(160 - art.neck)
    right_neck = number(160 + art.neck)
    path(front, f"M{left_neck} 273Q160 308 {right_neck} 273 Q180 295 160 297 Q140 295 {left_neck} 273Z",
         "#83694f", class_="seam")
    path(front, "M149 340Q155 368 147 404 M171 357Q177 398 172 426", class_="etch")

    for sleeve in art.sleeves:
        path(sleeve, f"M{outside + 24} 353 Q{outside + 31} 382 {outside + 24} 407 "
             f"Q{outside + 22} 426 {outside + 28} 439", "none", stroke="#866c54", stroke_width=2.2)
        path(sleeve, f"M{outside + 21} 387l11 6 M{outside + 21} 398l9 5 M{outside + 22} 410l8 4", class_="etch")
        path(sleeve, f"M{outside - 6} 430 Q{outside + 25} 437 {160 - body.waist + 9} 428",
             "none", stroke="#927252", stroke_width=3)

    clasp_x = round(144 - body.shoulder * .18)
    for side, transform, drop in (("left", None, 432), ("right", "translate(320 0) scale(-1 1)", 451)):
        wing = node(outer, "g", transform=transform, data_part="mantle-drape")
        contour = (
            f"M{left_neck} 271 C{shoulder + 14} 272 {outside - 8} 289 {outside - 4} 328 "
            f"C{outside + 3} 353 {shoulder - 15} 390 {shoulder - 2} {drop - 7} "
            f"Q{shoulder + 9} {drop + 4} {clasp_x - 15} {drop - 2} "
            f"Q{clasp_x - 28} 380 {clasp_x - 17} 344 Q{clasp_x + 11} 321 {clasp_x} 302 Q{clasp_x + 3} 284 {left_neck} 271Z"
        )
        mask = f"wardrobe-naumburg-{side}-mask"
        path(node(wing, "clipPath", id=mask), contour)
        path(wing, contour, cloth.base)
        folds = node(wing, "g", clip_path=f"url(#{mask})")
        path(
            folds,
            f"M{left_neck} 277Q{shoulder + 5} 278 {outside + 7} 315 Q{outside + 10} 345 {outside + 17} 362 "
            f"Q{outside + 11} 320 {clasp_x - 3} 298 Q{clasp_x} 286 {left_neck} 277Z "
            f"M{clasp_x - 4} 311Q{shoulder + 6} 338 {shoulder + 3} 383 Q{shoulder + 2} 404 {shoulder + 10} {drop - 8} "
            f"Q{shoulder - 15} 399 {shoulder - 6} 369 Q{shoulder - 1} 336 {clasp_x - 4} 311Z",
            cloth.light, opacity=.86,
        )
        path(
            folds,
            f"M{clasp_x - 3} 309Q{shoulder + 9} 340 {shoulder + 13} 373 Q{shoulder + 12} 399 {clasp_x - 15} {drop - 2} "
            f"L{clasp_x - 25} {drop - 2} Q{shoulder + 3} 379 {shoulder + 7} 357Z",
            cloth.shade,
        )
        path(folds, f"M{clasp_x - 4} 314 Q{shoulder - 12} 355 {shoulder - 2} 401 "
             f"M{clasp_x - 2} 318 Q{shoulder + 2} 360 {shoulder + 10} 398", class_="seam")
        path(folds, f"M{left_neck} 274Q{clasp_x - 1} 285 {clasp_x} 298", "none",
             stroke=cloth.light, stroke_width=3.8, stroke_linecap="round")
        path(wing, contour, "none", class_="edge")

    cord = f"M{clasp_x} 301Q160 322 {320 - clasp_x} 301"
    path(outer, cord, "none", stroke="#452e2b", stroke_width=5.1, stroke_linecap="round")
    path(outer, cord, "none", stroke="#dcb678", stroke_width=2.65, stroke_linecap="round")
    for x in (clasp_x, 320 - clasp_x):
        clasp = node(outer, "g", transform=f"translate({x} 301)", data_part="mantle-clasp")
        node(clasp, "circle", r=10.4, fill="#b68a5b", class_="edge")
        node(clasp, "circle", r=6.5, fill="#765044", stroke="#e2bc7d", stroke_width=1.7)
        path(clasp, "M0 -4 4 0 0 4 -4 0Z", "#edcb92")


def _pheasant(parent, transform):
    bird = node(parent, "g", transform=transform, data_part="embroidered-pheasant")
    path(bird, "M-4 17Q-14 16-28 29 Q-22 23-35 31 Q-29 21-16 13 L-8 11Z",
         "#d39b64", stroke="#263748", stroke_width=1.1)
    path(bird, "M-10 16Q-20 18-30 27 M-12 13Q-23 15-30 23", "none", stroke="#813f44", stroke_width=1.7)
    path(bird, "M-19 13 Q-10 5-4 7 Q2 7 1-1 Q0-6 5-8 Q10-9 12-5L17-3 12-1 "
         "Q8 0 9 8 Q10 14 3 17 Q-10 25-19 13Z", "#c2a76f", stroke="#272f3d", stroke_width=1.2)
    path(bird, "M-19 13Q-13 8-5 9 Q0 10 0 13 Q-8 20-16 17Z", "#8aa598")
    path(bird, "M2 -1Q1 4 7 5L8 9Q5 11 1 8 Q3 4 2-1Z", "#a54c43")
    path(bird, "M4 -7 Q1-10-4-11 Q0-12 5-10 M7 -8L5-13", "none", stroke="#ead29e", stroke_width=1.5)
    node(bird, "circle", cx=8.7, cy=-4.7, r=1, fill="#352a2e")
    path(bird, "M-5 8Q-11 11-13 14 M-2 10Q-6 14-12 16 M-3 19l-2 4-5 1 M3 17l-3 6-4 2",
         "none", stroke="#e5c59b", stroke_width=1.4, stroke_linecap="round")


def draw_song_pheasant_robe(art):
    front, cloth, body = art.front, art.cloth, art.body
    left_neck = number(156 - art.neck)
    right_neck = number(164 + art.neck)
    wrap = 160 - round(body.waist * .57)
    path(front, f"M{right_neck} 277Q173 302 154 321Q{wrap + 21} 369 {wrap + 3} 384 "
         f"L{wrap + 25} 400Q{wrap + 40} 369 177 324Q185 302 {right_neck} 277Z", cloth.shade)
    path(front, f"M{left_neck} 273Q143 292 176 304L169 318Q136 307 {left_neck} 283Z", "#a94f43", class_="edge")
    path(front, f"M{left_neck} 277Q144 299 173 308", "none", stroke="#e0a579", stroke_width=2.4)
    path(
        front,
        f"M{right_neck} 271Q184 302 161 322 Q{wrap + 44} 345 {wrap + 8} 378 L{wrap + 1} 392 "
        f"L{wrap - 13} 387 Q{wrap + 3} 357 {wrap + 18} 344 Q160 312 {right_neck} 271Z",
        "#ab5046", class_="edge",
    )
    path(front, f"M{right_neck} 279 Q177 310 157 325 Q{wrap + 39} 342 {wrap + 4} 378 L{wrap - 3} 391",
         "none", stroke="#e2ab78", stroke_width=2.6)
    path(front, f"M185 292Q176 310 167 323 Q{wrap + 37} 355 {wrap + 13} 379",
         "none", stroke="#63383a", stroke_width=1.7, stroke_dasharray="2 3")

    bird_x = round(146 - body.chest * .29)
    _pheasant(front, f"translate({bird_x} 318) scale(.88)")
    _pheasant(front, f"translate({320 - bird_x} 318) scale(-.88 .88)")
    path(front, "M103 357q12 -8 24 -2 M192 355q15 -9 27 -1 M139 381q10 -7 23 -3 M173 368q11 -6 23 1",
         "none", stroke=cloth.light, stroke_width=2, stroke_linecap="round", opacity=.64)

    outside = 160 - body.sleeve
    for sleeve in art.sleeves:
        _pheasant(sleeve, f"translate({outside + 29} 364) scale(.63)")
        path(sleeve, f"M{outside - 6} 414Q{outside + 26} 423 {160 - body.waist + 13} 409",
             "none", stroke="#a24d43", stroke_width=12)
        path(sleeve, f"M{outside - 6} 412Q{outside + 26} 421 {160 - body.waist + 13} 407",
             "none", stroke="#dfaa79", stroke_width=2.5)

    left, right = 152 - body.waist, 168 + body.waist
    belt = node(art.waist, "g", data_part="medallion-belt", transform="translate(0 2)")
    path(belt, f"M{left} 383 Q160 394 {right} 383 L{right} 401 Q160 414 {left} 401Z", "#77504b", class_="edge")
    path(belt, f"M{left} 386 Q160 396 {right} 386 M{left} 398 Q160 409 {right} 398",
         "none", stroke="#c08f68", stroke_width=1.5)
    for x in range(160 - 19 * (body.waist // 19), 160 + body.waist + 1, 19):
        y = 398 - round(6 * ((x - 160) / body.waist) ** 2)
        node(belt, "ellipse", cx=x, cy=y, rx=6.4, ry=5.3, fill="#e4cda0", stroke="#5b4642", stroke_width=1.05)
        path(belt, f"M{x} {y - 3}l2 3-2 3-2-3Z", "#a87458")


DRAWERS = {
    "rus_gold_yoke_gown": draw_gold_yoke_gown,
    "rus_checked_panel": draw_checked_panel,
    "naumburg_clasp_mantle": draw_naumburg_clasp_mantle,
    "song_pheasant_robe": draw_song_pheasant_robe,
}
