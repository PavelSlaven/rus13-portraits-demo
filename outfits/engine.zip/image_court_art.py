"""Eight distinct court objects from the local image index.

The Delhi, Iranian and Song belt references are analogues, not exact evidence
for every detail. ITEM_METADATA preserves that distinction for gallery captions.
This module imports drawing leaves only; registry wiring belongs to the caller.
"""

from dataclasses import replace
from xml.etree.ElementTree import Element

from common import node, number, path
from wardrobe_eurasia import _steppe_robe, _tiraz_robe


OUTFITS = {
    "court_delhi_khilat": "Делийское царское узорное одеяние",
    "court_georgia_kabacha": "Грузинская кабача с тёмным бортом",
    "court_georgia_khufu": "Грузинское одеяние с вышитыми рукавами хуфи",
}
HEADGEAR = {
    "court_delhi_jewel_hat": "Делийский угловатый драгоценный убор",
    "court_georgia_pearl_hat": "Грузинская княжеская шапка с жемчужным рядом",
    "court_iran_lotus_diadem": "Персидская диадема с бутоном лотоса",
}
BELTS = {"court_song_gold_plaques": "Сунский пояс с рельефными золотыми накладками"}
BELT_POUCHES = {"court_song_fish_pouch": "Сунский служебный рыбный мешок с золотой накладкой"}

# Paint values are also supplied separately so registry wiring need not inspect paths.
OUTFIT_COLORS = {
    "court_delhi_khilat": ("#c89787", "#e3b9a1", "#a76e68", "#75434b"),
    "court_georgia_kabacha": ("#c9afa0", "#ead2b6", "#aa887d", "#704a46"),
    "court_georgia_khufu": ("#854348", "#ad6560", "#642f38", "#45232d"),
}
OUTFIT_HEMS = {"court_delhi_khilat": 634, "court_georgia_kabacha": 650, "court_georgia_khufu": 645}
HEADGEAR_HAIR_ROOT_HALF = dict.fromkeys(HEADGEAR, 70)
OPEN_HEADGEAR = {"court_iran_lotus_diadem"}
HEADGEAR_EXPOSED = {
    "court_delhi_jewel_hat": {"ears": True, "neck": True, "hair": True},
    "court_georgia_pearl_hat": {"ears": True, "neck": True, "hair": True},
    "court_iran_lotus_diadem": {"ears": True, "neck": True, "hair": True},
}


def _meta(slot, item, culture, materials, note, **extra):
    return {"selection": {slot: item}, "slot": slot, "item": item, "culture": culture,
            "age": "adult", "cast": "men", "materials": materials,
            "source_note": note, **extra}


ITEM_METADATA = {
    "new_delhi_khilat_padshahi": _meta(
        "outfit", "court_delhi_khilat", "south_asia", ("silk", "gold"),
        "Поздний аналог: индийская миниатюра XV века с Ала ад-Дином Халджи; название хиляти-падшахи изображением не удостоверено."),
    "new_delhi_official_jewel_headgear": _meta(
        "headgear", "court_delhi_jewel_hat", "south_asia", ("silk", "gold", "pearl"),
        "Поздний аналог XV века: у сидящего султана виден угловатый тёмный убор. Точное четырёхугольное устройство и драгоценная отделка реконструированы."),
    "new_georgia_kabacha": _meta(
        "outfit", "court_georgia_kabacha", "caucasus", ("silk", "gold"),
        "Фреска Георгия IV Лаши в Бертубани, первая половина XIII века; утраченные части борта и подола дополнены условно."),
    "new_georgia_khufu_sleeves": _meta(
        "outfit", "court_georgia_khufu", "caucasus", ("silk", "gold"),
        "Фреска Шергила Дадиани и реконструкция фрески Рати Сурамили; даты выходят за 1200–1250 годы. Геометрия вышивки передана условно."),
    "new_georgia_pearl_rank_hat": _meta(
        "headgear", "court_georgia_pearl_hat", "caucasus", ("silk", "pearl", "gold"),
        "Реконструкция портрета Шергила Дадиани по фреске Хоби: высокий красный убор и один жемчужный ряд."),
    "new_iran_court_diadem_lotus": _meta(
        "headgear", "court_iran_lotus_diadem", "iraq_iran", ("gold", "silk"),
        "Условная реконструкция по описанию Iranica. На приложенной миниатюре Китаб ад-Дирьяк 1198–1199 годов бутон лотоса неразличим."),
    "song_fish_pendant": _meta(
        "belt_pouch", "court_song_fish_pouch", "song", ("silk", "gold"),
        "Золотая накладка рыбьего мешка из погребения Южной Сун, XII–XIII века, музей Ланьси; тканевый футляр и крепление реконструированы.",
        trim_materials=("gold",), detail=True),
    "song_gold_belt_plaque": _meta(
        "belt", "court_song_gold_plaques", "song", ("leather", "gold"),
        "Аналог: 13 рельефных позолоченных серебряных пластин Северной Сун XI–XII веков. Золотой материал и число видимых пластин условны.",
        trim_materials=("gold",), detail=True),
}

_INK = "#382721"
_GOLD = "#bf904d"
_GOLD_LIGHT = "#edd09a"
_GOLD_SHADE = "#81572e"


def _line(parent, d, color, width=1.5, surface="fixed", **attrs):
    return path(parent, d, "none", stroke=color, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round",
                data_material_surface=surface, **attrs)


def _shape(parent, d, color, width=1.6, surface="fixed", **attrs):
    return path(parent, d, color, stroke=_INK, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round",
                data_material_surface=surface, **attrs)


def _pearl(parent, x, y, r=2.7):
    node(parent, "circle", cx=x, cy=y, r=r, fill="#dbcba7", stroke="#6e5842",
         stroke_width=.75, data_material_surface="fixed")
    node(parent, "circle", cx=x-.65*r, cy=y-.46*r, r=.3*r, fill="#fff1d0",
         data_material_surface="fixed")


def _jewel(parent, x, y, size=4, color="#8e514d"):
    _shape(parent, f"M{x} {y-size}l{size} {size} -{size} {size} -{size} -{size}Z", _GOLD, .8)
    node(parent, "ellipse", cx=x, cy=y, rx=size*.5, ry=size*.65, fill=color,
         stroke=_GOLD_LIGHT, stroke_width=.65, data_material_surface="fixed")


def _rosette(parent, x, y, scale=1, color=_GOLD_SHADE):
    ornament = node(parent, "g", transform=f"translate({number(x)} {number(y)}) scale({scale})")
    for angle in range(0, 360, 60):
        node(ornament, "ellipse", cx=0, cy=-3.3, rx=1.6, ry=2.9,
             transform=f"rotate({angle})", fill=color, data_material_surface="fixed")
    node(ornament, "circle", cx=0, cy=0, r=1.5, fill=_GOLD_LIGHT,
         data_material_surface="fixed")


def _embroidered_panel(parent, x, y, width=35, height=29, tilt=-14):
    panel = node(parent, "g", transform=f"translate({number(x)} {number(y)}) rotate({tilt})",
                 data_part="khufu-embroidered-panel")
    _shape(panel, f"M0 0h{width}v{height}H0Z", _GOLD, 1.5)
    _line(panel, f"M3 3h{width-6}v{height-6}H3Z", _GOLD_SHADE, 1)
    _line(panel, f"M5 5h{width-10}v{height-10}H5Z", _GOLD_LIGHT, 1)
    for x1 in range(9, int(width)-5, 7):
        _line(panel, f"M{x1} 6v{height-12}", "#724247", 1.6)
        _line(panel, f"M{x1-2.2} 10l2.2-2.5 2.2 2.5-2.2 2.5Z", _GOLD_LIGHT, .7)
        _line(panel, f"M{x1-2.2} {height-10}l2.2-2.5 2.2 2.5-2.2 2.5Z", _GOLD_LIGHT, .7)


def _patterned_trim(parent, d, *, width=15, color="#68403b"):
    _line(parent, d, _INK, width+2)
    _line(parent, d, color, width)
    _line(parent, d, _GOLD, max(1.5, min(3, width*.16)), stroke_dasharray="2 5")
    _line(parent, d, _GOLD_LIGHT, .9)


def draw_delhi_khilat(art):
    """Figured robe, dark tiraz bands and a broad sash with hanging tails."""
    _tiraz_robe(art)
    body = art.body
    bottom = art.hem_y or 445
    half = art.hem_half or body.hem
    for row, y in enumerate(range(317, bottom+5, 32)):
        for x in range(160-half-5, 160+half+8, 30):
            _rosette(art.front, x+(14 if row%2 else 0), y, .87, "#955454")
            _line(art.front, f"M{x+7} {y+5}q5-8 11-7m-7 4q2 5 6 4", "#a2635c", 1)
    for sleeve in art.sleeves:
        shoulder = 160-body.shoulder
        for y in range(338, 435, 28):
            _rosette(sleeve, 177-body.sleeve+(y-338)*.13, y, .8, "#985453")
        band = node(sleeve, "g", data_part="delhi-dark-sleeve-band")
        _shape(band, f"M{shoulder-32} {body.shoulder_y+10}l43 8-3 29-46-10Z", "#454d42")
        _line(band, f"M{shoulder-31} {body.shoulder_y+15}l40 8m-43 16 40 9", _GOLD_LIGHT, 1.7)
        for i in range(4):
            _pearl(band, shoulder-26+i*10, body.shoulder_y+25+i*1.9, 1.4)
    _patterned_trim(art.front, f"M{number(160-art.neck)} 277Q154 310 {number(160+art.neck)} 277", width=7)
    target = art.waist if art.waist is not None else art.front
    left, right = 157-body.waist, 163+body.waist
    belt = node(target, "g", data_part="belt")
    _shape(belt, f"M{left} 390Q160 405 {right} 391v18Q160 421 {left} 408Z", "#6d7457")
    _line(belt, f"M{left+2} 395Q160 409 {right-2} 396M{left+2} 405Q160 417 {right-2} 405", _GOLD_LIGHT, 1.9)
    for x, end in ((134, 481), (183, 503)):
        tail = node(belt, "g", data_part="sash-tail")
        _shape(tail, f"M{x} 401h13l5 {end-415}q-10 7-24 1Z", "#d5bd83")
        _line(tail, f"M{x+3} 411l-3 {end-424}m7 2 1-{end-426}", "#877453", 1.1)
        for y in (end-17, end-11, end-5):
            _line(tail, f"M{x-4} {y}l20 1", "#6a6347", 1.35)
        for xx in range(x-6, x+18, 4):
            _line(tail, f"M{xx} {end+1}l-1 6", _GOLD_SHADE, 1)


def draw_georgia_kabacha(art):
    """Pale Georgian long coat with a dark asymmetric opening and split skirt."""
    # Retain the shared wrap/fold construction, without its steppe textile sash.
    _steppe_robe(replace(art, waist=Element("g")))
    body, cloth = art.body, art.cloth
    hem = art.hem_y or 445
    half = art.hem_half or body.hem
    left, right = 160-half, 160+half
    # Replace the steppe lapel and sash on the clipped torso, keeping its folds.
    _shape(art.front, f"M{number(160-art.neck)} 274Q142 287 159 306L185 333"
           f"L190 {hem+10}H{left-9}L{160-body.waist} 400L{160-body.chest} 330Z",
           cloth.base, 0, "base")
    path(art.front, f"M104 322Q120 363 119 408Q102 {(hem+415)//2} {left+10} {hem+3}"
         f"L{left+25} {hem+3}Q136 432 126 348Z", cloth.light, opacity=".48")
    path(art.front, f"M187 319Q206 375 202 415L{right+4} {hem+8}H{right-19}Q196 441 179 359Z",
         cloth.shade, opacity=".62")
    opening = f"M{number(153-art.neck)} 278Q153 304 180 325L188 407L179 {hem+8}"
    _patterned_trim(art.front, opening, width=18, color="#613d3e")
    _line(art.front, f"M{number(149-art.neck)} 282Q148 307 173 331L181 410L172 {hem+7}", "#ddbb83", 1.8)
    # The inner skirt is shown at the short front split, not as trousers.
    if art.hem_y is not None:
        _shape(art.front, f"M178 {hem-96}L174 {hem+17}H202L189 {hem-96}Z", "#846f65", 1)
        _line(art.front, f"M185 {hem-81}l3 88", "#d3b89b", 1.2)
        _patterned_trim(art.front, f"M{left+2} {hem-8}Q123 {hem+5} 173 {hem-5}M190 {hem-5}Q219 {hem} {right-2} {hem-10}", width=8)
    for sleeve in art.sleeves:
        # A narrow, patterned wrist, rather than an upper-arm tiraz panel.
        outer, inner = 169-body.sleeve, 171-body.hem
        _patterned_trim(sleeve, f"M{outer} 426Q{(outer+inner)//2} 436 {inner+3} 426", width=11)
        _line(sleeve, f"M{outer+9} 349Q{outer+3} 383 {outer+12} 411", cloth.light, 1.4)
    target = art.waist if art.waist is not None else art.front
    _line(target, f"M{162-body.waist} 402Q159 415 {158+body.waist} 401", "#856856", 4.4)
    _line(target, f"M{162-body.waist} 401Q159 414 {158+body.waist} 400", "#cbae80", 1.2)


def draw_georgia_khufu(art):
    """Maroon court gown with large rectangular gold embroidered arm panels."""
    _tiraz_robe(art)
    body = art.body
    for sleeve in art.sleeves:
        shoulder = 160-body.shoulder
        # Cover the generic horizontal tiraz before drawing rectangular khufu.
        path(sleeve, f"M{shoulder-39} {body.shoulder_y+1}l61 9v53l-69-11Z", art.cloth.base)
        _embroidered_panel(sleeve, shoulder-29, body.shoulder_y+15, 40, 36, 17)
        outer, inner = 160-body.sleeve, 171-body.hem
        _patterned_trim(sleeve, f"M{outer+6} 426Q{(outer+inner)//2} 438 {inner+1} 430", width=10)
    end = art.hem_y or 446
    trim = f"M{number(160-art.neck)} 278Q157 307 {number(160+art.neck)} 278M176 294L174 {end+5}"
    _patterned_trim(art.front, trim, width=14, color="#aa7949")
    for y in range(320, end, 24):
        _line(art.front, f"M170 {y}l4-4 4 4-4 4Z", "#f0c785", 1)
    if art.hem_y is not None:
        half = art.hem_half or body.hem
        _patterned_trim(art.front, f"M{163-half} {end-8}Q160 {end+8} {157+half} {end-8}", width=11)


def draw_delhi_jewel_hat(parent, look, fit):
    crown = fit.crown(parent, minimum_y=31)
    group = node(crown, "g", data_part="delhi-angular-court-hat")
    _shape(group, "M119 62Q127 40 151 32Q162 29 175 38Q194 47 204 65L196 89H125Z", "#55513f")
    path(group, "M127 59Q137 40 153 36Q149 50 152 69Z", "#928568")
    _line(group, "M155 34Q159 47 158 64M171 39Q181 49 183 65", _GOLD_LIGHT, 1.2)
    _shape(group, "M71 64L249 64L231 111Q160 116 89 111Z", "#3f493e", 2.2)
    path(group, "M77 68L111 71L117 103L91 106Z", "#65705a")
    path(group, "M204 69L244 68L229 106L209 103Z", "#2c342e")
    _line(group, "M74 65L247 65M88 108Q160 112 232 108", _GOLD_LIGHT, 3.1)
    _line(group, "M80 72L241 72M89 101Q160 107 231 101", _GOLD, 1.6)
    for i, x in enumerate(range(94, 234, 14)):
        _pearl(group, x, 68, 1.5)
        if i%2 == 0:
            _jewel(group, x, 88, 4, "#7b4d47" if i%4 else "#54756c")
    rim = fit.sides(parent)
    _line(rim, "M90 112Q160 117 230 112", "#b6a475", 3)


def draw_georgia_pearl_hat(parent, look, fit):
    crown = fit.crown(parent, minimum_y=18)
    group = node(crown, "g", data_part="georgia-high-red-princely-hat")
    # Narrow upper peak, wider lower skullcap; no Chinese floral crown parts.
    _shape(group, "M97 110L102 71L120 42L151 18L173 29L203 57L221 109Z", "#79353d", 2.2)
    path(group, "M106 70L150 24L145 83L111 100Z", "#a14c4c")
    path(group, "M158 22L175 32L203 61L215 102L181 97L170 56Z", "#512a32")
    _line(group, "M153 24L148 84M171 35L179 84M107 73L116 100", "#c57964", 1.2)
    _shape(group, "M99 91Q160 80 219 92L221 110Q160 119 97 110Z", "#353333")
    _line(group, "M102 94Q160 84 216 94", _GOLD, 1.5)
    for x in range(104, 218, 8):
        y = 104-5*(1-((x-160)/60)**2)
        _pearl(group, x, y, 3.15)
    _jewel(group, 160, 88, 5.1)
    sides = fit.sides(parent)
    _line(sides, "M99 111Q159 119 220 111", "#95674a", 2)


def draw_iran_lotus_diadem(parent, look, fit):
    # Thin open circlet, leaving hair and both ears visible.
    circlet = fit.sides(parent)
    _shape(circlet, "M86 106Q160 93 234 106L232 115Q160 105 88 115Z", "#b4874a", 1.4)
    _line(circlet, "M90 108Q160 96 231 108", _GOLD_LIGHT, 1.3)
    for x in (106, 132, 188, 214):
        _jewel(circlet, x, 105, 2.65, "#637564")
    crest = fit.crown(parent, minimum_y=58)
    lotus = node(crest, "g", data_part="iran-rounded-lotus-bud", transform="translate(160 84)")
    _shape(lotus, "M-4 21L-6 9H6L4 21Z", _GOLD)
    _shape(lotus, "M0-24C17-20 23-7 18 7Q10 20 0 20Q-11 19-18 7C-23-7-16-20 0-24Z", _GOLD, 1.8)
    path(lotus, "M0-21Q-10-11-9 1Q-7 11 0 17Q-14 12-16 3Q-20-10-8-18Z", "#e1b774")
    for direction in (-1, 1):
        _line(lotus, f"M0 17Q{13*direction} 6 {12*direction}-7Q{8*direction}-18 0-21", _GOLD_SHADE, 1.1)
        _line(lotus, f"M0 15Q{6*direction} 5 {5*direction}-8", _GOLD_LIGHT, 1.4)
    _line(lotus, "M0-19V16", _GOLD_SHADE, 1.2)
    _shape(lotus, "M-13 10Q-5 12 0 20Q6 12 13 10L9 22H-9Z", "#8e7445", 1)


def _song_plaque(parent, width=24, height=19):
    """Raised rectangular plaque with framed scrolling floral relief."""
    w, h = width/2, height/2
    _shape(parent, f"M{-w} {-h}Q0 {-h-1} {w} {-h}V{h}Q0 {h+1} {-w} {h}Z", _GOLD, 1.1, "trim")
    _line(parent, f"M{-w+1.6} {-h+1.8}H{w-1.6}V{h-1.6}H{-w+1.6}Z", _GOLD_LIGHT, .75, "trim-light")
    _line(parent, f"M{-w+3} {h-3}Q{-w+2} {-h+4} 0 {-h+3}Q{w-2} {-h+4} {w-3} {h-3}", _GOLD_SHADE, .95, "trim-shade")
    _rosette(parent, 0, 0, min(width/21, height/17), "#835b30")
    for mirror in (None, "scale(-1 1)"):
        branch = node(parent, "g", transform=mirror)
        _line(branch, f"M0 {h-2}Q-2 3 {-w+3} 3q-3-3 .2-4Q-2-4-3 {-h+3}", _GOLD_LIGHT, .9, "trim-light")


def draw_song_gold_belt(parent, body):
    belt = node(parent, "g", data_part="belt", data_style="court_song_gold_plaques",
                data_material_slot="belt", clip_path="url(#wardrobe-torso-mask)")
    half = body.waist+6
    waist = f"M{160-half} 398Q160 423 {160+half} 398"
    _line(belt, waist, _INK, 24)
    _line(belt, waist, "#644333", 21, "base")
    count = max(4, round(half/13))
    for i in range(count):
        x = 160+(i-(count-1)/2)*25
        y = 410-12*((x-160)/half)**2
        tilt = -16*(x-160)/half
        plaque = node(belt, "g", transform=f"translate({number(x)} {number(y)}) rotate({number(tilt)})")
        _song_plaque(plaque, 23, 20)
    # An elongated end fitting below the plate row distinguishes the official set.
    fitting = node(belt, "g", transform=f"translate({number(160+.62*body.waist)} 426) rotate(-8)")
    _song_plaque(fitting, 15, 28)


def _fish(parent, mirror=False):
    fish = node(parent, "g", transform="translate(0 0) scale(-1 1)" if mirror else None)
    _shape(fish, "M-3 0Q-14-14-32-7Q-42-7-45 0Q-36 12-23 10Q-12 8-3 0Z", "#cda357", .9, "trim")
    _shape(fish, "M-41-1L-54-12L-51 1L-55 11L-40 4Z", "#bd8b45", .8, "trim")
    _line(fish, "M-9-5Q-15 0-11 6M-16-7Q-20-13-26-10M-17 8Q-22 14-30 11", _GOLD_LIGHT, 1.1, "trim-light")
    node(fish, "circle", cx=-9, cy=-1.6, r=1.35, fill="#61472b", data_material_surface="trim-shade")
    for x in (-18, -25, -32):
        _line(fish, f"M{x}-5q-4 3-1 6m-1-3q-4 4-1 7", _GOLD_SHADE, .8, "trim-shade")
    _line(fish, "M-39 1Q-27-7-16-4M-50-7L-43 0L-50 7", _GOLD_LIGHT, .9, "trim-light")


def _fish_fitting(parent):
    """Metal fitting only; the photographed cloth bag has not survived."""
    _shape(parent, "M-62-20Q0-12 62-20V23Q0 32-62 23Z", "#b98a45", 1.4, "trim")
    _line(parent, "M-59-17Q0-10 59-17M-59 20Q0 29 59 20", _GOLD_LIGHT, 1.4, "trim-light")
    _line(parent, "M-58-13Q0-6 58-13M-59 16Q0 25 59 16", _GOLD_SHADE, 1, "trim-shade")
    for x in range(-50, 42, 17):
        _line(parent, f"M{x}-9q8-8 13-1m-11 25q8-7 13-1", _GOLD_LIGHT, 1, "trim-light")
    _fish(parent)
    _fish(parent, mirror=True)
    _shape(parent, "M-4-7Q0-13 4-7L5 7Q0 12-5 7Z", "#dfb772", .8, "trim-light")
    _line(parent, "M0-7V7", _GOLD_SHADE, .85, "trim-shade")


def draw_song_fish_pouch_local(parent):
    """Optional native pouch-registry adapter: origin is the waist attachment."""
    _shape(parent, "M-4-1H4L6 19H-6Z", "#9e6b4b", 1.1, "base")
    _shape(parent, "M-19 14Q0 10 20 14L24 55Q21 69 0 72Q-22 70-24 56Z", "#8e443e", 1.5, "base")
    path(parent, "M4 17L18 17L22 53Q24 64 9 68L4 63Z", "#602e32", data_material_surface="shade")
    _line(parent, "M-17 20Q-10 43-15 61M-7 56Q0 68 10 61", "#bf7661", 1.1, "light")
    plate = node(parent, "g", transform="translate(0 38) scale(.37)", data_part="song-paired-fish-fitting")
    _fish_fitting(plate)
    _line(parent, "M-17 17Q0 23 17 17", _GOLD, 1.2)


def draw_song_fish_pouch(parent, body):
    anchor = 160-.46*body.waist
    pouch = node(parent, "g", data_part="belt-pouch", data_style="court_song_fish_pouch",
                 data_material_slot="belt_pouch", transform=f"translate({number(anchor)} 404)")
    draw_song_fish_pouch_local(pouch)


def draw_song_belt_detail(parent):
    """320 by 260: a row of three plaques and the long terminal fitting."""
    _shape(parent, "M26 64Q160 77 294 64V126Q160 143 26 126Z", "#614334", 2, "base")
    for x, angle in ((74, 7), (160, 0), (246, -7)):
        plaque = node(parent, "g", transform=f"translate({x} 102) rotate({angle}) scale(2.65)")
        _song_plaque(plaque, 27, 23)
    terminal = node(parent, "g", transform="translate(214 194) rotate(-8) scale(2.1)")
    _song_plaque(terminal, 21, 33)
    clasp = node(parent, "g", transform="translate(104 196)")
    _shape(clasp, "M-25-19Q0-31 25-19L29 9Q0 30-29 9Z", _GOLD, 2, "trim")
    _line(clasp, "M-19-13Q0-22 19-13L21 7Q0 20-21 7Z", _GOLD_LIGHT, 1.6, "trim-light")
    _rosette(clasp, 0, -1, 2)


def draw_song_fish_detail(parent):
    """320 by 260: enlarged surviving metal fitting, without an invented bag."""
    fitting = node(parent, "g", transform="translate(160 125) scale(2.08)",
                   data_part="song-fish-fitting-detail", data_material_slot="belt_pouch")
    _fish_fitting(fitting)


OUTFIT_DRAWERS = {
    "court_delhi_khilat": draw_delhi_khilat,
    "court_georgia_kabacha": draw_georgia_kabacha,
    "court_georgia_khufu": draw_georgia_khufu,
}
HEADGEAR_DRAWERS = {
    "court_delhi_jewel_hat": draw_delhi_jewel_hat,
    "court_georgia_pearl_hat": draw_georgia_pearl_hat,
    "court_iran_lotus_diadem": draw_iran_lotus_diadem,
}
BELT_DRAWERS = {"court_song_gold_plaques": draw_song_gold_belt}
POUCH_DRAWERS = {"court_song_fish_pouch": draw_song_fish_pouch}
LOCAL_POUCH_DRAWERS = {"court_song_fish_pouch": draw_song_fish_pouch_local}
DETAIL_DRAWERS = {
    "court_song_gold_plaques": draw_song_belt_detail,
    "court_song_fish_pouch": draw_song_fish_detail,
}
