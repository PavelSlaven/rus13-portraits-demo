"""Additional protections drawn from the owner's illustrated item index."""

from common import brow_top, eye_height, node, number, path
from face_features import eye_layout
from face_shape import make_head
from wardrobe_northwest_military import draw_mail_hauberk


INK = "#342c29"
STEEL = "#81877c"
LIGHT = "#c9c8b3"
SHADE = "#4d5651"
LEATHER = "#785340"
OUTFITS = {"index_flat_ring_mail": "Кольчуга с крупными плоскими кольцами",
           "index_padded_tunic": "Стёганая поддоспешная одежда"}
HEADGEAR = {
    "index_lipovets_mask": "Шлем с антропоморфной личиной",
    "index_western_nasal": "Куполовидный шлем с наносником",
    "index_mail_coif": "Отдельный кольчужный капюшон",
    "index_padded_liner": "Стёганый подшлемник",
}
COVERAGE = {
    "index_lipovets_mask": {"ears": False, "neck": False, "hair": False},
    "index_western_nasal": {"ears": True, "neck": True, "hair": False},
    "index_mail_coif": {"ears": False, "neck": False, "hair": False},
    "index_padded_liner": {"ears": False, "neck": True, "hair": False},
}
OPTIONS = {
    "arm_protection": {"none": "Без защиты рук", "index_plate_bracers": "Створчатые наручи",
                       "index_archer_bracer": "Кожаный щиток лучника",
                       "rus_nerev_archer_bracer": "Роговой щиток лучника из Новгорода"},
    "leg_protection": {"none": "Без защиты ног", "index_splint_greaves": "Шинные поножи",
                       "index_mail_chausses": "Кольчужные нагавицы"},
    "neck_protection": {"none": "Без отдельного ворота", "index_mail_gorget": "Отдельное кольчужное оплечье"},
}
LABELS = {"arm_protection": "Защита предплечий", "leg_protection": "Защита ног",
          "neck_protection": "Отдельная защита шеи"}
ITEM_METADATA = {
    "wp_arm_guards": {"selection": {"arm_protection": "index_plate_bracers"}},
    "wp_archer_bracer": {"selection": {"arm_protection": "index_archer_bracer"}},
    "wp_leg_guards": {"selection": {"leg_protection": "index_splint_greaves"}},
    "wp_mail_chausses": {"selection": {"leg_protection": "index_mail_chausses"}},
    "wp_mail_collar": {"selection": {"neck_protection": "index_mail_gorget"}},
    "wp_mail_flat_ring": {"selection": {"outfit": "index_flat_ring_mail"}},
    "wp_helmet_full_mask": {"selection": {"headgear": "index_lipovets_mask"}},
    "wp_helmet_western": {"selection": {"headgear": "index_western_nasal"}},
    "wp_mail_coif": {"selection": {"headgear": "index_mail_coif"}},
    "wp_helmet_liner": {"selection": {"headgear": "index_padded_liner"}},
    "wp_padded": {"selection": {"outfit": "index_padded_tunic"}},
}
for item in ITEM_METADATA.values():
    item.update(cast="men", age="adult", cultures=["rus", "steppe"], materials=["iron"], automatic=False)
ITEM_METADATA["wp_helmet_western"]["cultures"] = ["western", "nordic"]
ITEM_METADATA["wp_helmet_liner"]["materials"] = ["linen", "wool"]
ITEM_METADATA["wp_padded"]["materials"] = ["linen", "wool"]
ITEM_METADATA["wp_archer_bracer"]["materials"] = ["leather"]


def _shape(parent, d, fill=STEEL, width=2.4, **attrs):
    return path(parent, d, fill, stroke=INK, stroke_width=width, stroke_linejoin="round", **attrs)


def _line(parent, d, color=LIGHT, width=1.5, **attrs):
    return path(parent, d, "none", stroke=color, stroke_width=width, stroke_linecap="round", **attrs)


def draw_flat_mail(art):
    draw_mail_hauberk(art)
    defs = node(art.front, "defs")
    pattern = node(defs, "pattern", id="index-flat-rings", patternUnits="userSpaceOnUse", width=13, height=11)
    for x, y in ((0, 1), (13, 1), (6.5, 6.5)):
        node(pattern, "ellipse", cx=x, cy=y, rx=4.7, ry=3.5, fill="none", stroke="#252c29", stroke_width=2.7)
        path(pattern, f"M{number(x-3)} {number(y-1.4)}q3-2 6 0", "none", stroke="#bdc1ad", stroke_width=1.25)
    for parent in (art.front, *art.sleeves):
        for element in parent.iter():
            if element.get("fill") == "url(#mail-rings)":
                element.set("fill", "url(#index-flat-rings)")
    _line(art.front, f"M{number(160-art.neck)} 281Q160 311 {number(160+art.neck)} 281", LEATHER, 5)


def draw_padded_tunic(art):
    hem = art.hem_y or 446
    quilt = node(node(art.front, "defs"), "pattern", id="index-quilting", width=17, height=30,
                 patternUnits="userSpaceOnUse")
    _line(quilt, "M0 0L17 30M17 0L0 30", art.cloth.deep, .85)
    _line(quilt, "M1 0L18 30M18 0L1 30", art.cloth.light, .5)
    for panel in (art.front, *art.sleeves):
        path(panel, f"M0 270H320V{hem+8}H0Z", "url(#index-quilting)", opacity=".8")
    neck = art.neck
    _line(art.front, f"M{160-neck} 276Q160 308 {160+neck} 276", art.cloth.deep, 7)
    _line(art.front, f"M{160-neck} 276Q160 308 {160+neck} 276", art.cloth.light, 3)
    _shape(art.front, f"M155 296H165V{hem}H155Z", art.cloth.shade, 1)
    for y in (315, 352, 389):
        _line(art.front, f"M151 {y}h18", LEATHER, 4.3)
        node(art.front, "circle", cx=166, cy=y, r=1.5, fill="#d7b782")


def draw_western_helmet(parent, look, fit):
    crown = fit.fitted_crown(parent, top=40, clearance=24)
    _shape(crown, "M77 114C77 66 105 38 160 39C212 40 241 70 243 114Z")
    path(crown, "M90 108Q89 65 146 45Q116 72 112 109Z", LIGHT)
    path(crown, "M172 43Q224 58 238 110L200 109Q198 64 172 43Z", SHADE)
    _line(crown, "M160 41V112", SHADE, 2.1)
    _shape(crown, "M76 106Q160 115 244 106L244 118Q160 126 76 118Z", "#71766c")
    for x in range(86, 242, 22):
        node(crown, "circle", cx=x, cy=114, r=2, fill=LIGHT, stroke=INK, stroke_width=.8)
    head = make_head(look)
    nasal = node(parent, "g", data_part="nasal")
    width = min(6, max(3.4, eye_layout(look, head).bridge_half - 5))
    top, bottom = fit.brim_y, 180 + eye_height(look)
    _shape(nasal, f"M{number(160-width)} {number(top)}H{number(160+width)}L{number(160+width-1)} {bottom}Q160 {bottom+4} {number(161-width)} {bottom}Z", "#9b9f8f", 1.8)
    _line(nasal, f"M158 {number(top+2)}V{bottom-2}", LIGHT, 1.6)


def draw_full_mask(parent, look, fit):
    head = make_head(look)
    outer = head.temple_half + 12
    top, rim = max(22, head.top_y - 48), fit.brim_y
    drape = f"M{160-outer} 170L{140-outer} {head.chin_y+54}Q160 {head.chin_y+73} {180+outer} {head.chin_y+54}L{160+outer} 170Z"
    _shape(parent, drape, SHADE, 2.8)
    path(parent, drape, "url(#mail-rings)")
    shell = f"M{160-outer} {rim}Q{162-outer} {top+42} 160 {top}Q{158+outer} {top+42} {160+outer} {rim}Z"
    _shape(parent, shell, "#858779", 3.3)
    _line(parent, f"M{number(160-outer+14)} {number(rim-6)}Q127 {number(top+31)} 159 {number(top+6)}", LIGHT, 4)
    _line(parent, f"M160 {top+4}V{rim-2}", SHADE, 2)
    bottom = head.chin_y + 7
    cheek = head.cheek_half + 9
    mask = node(parent, "g", data_part="full-face-mask")
    _shape(mask, f"M{160-outer} {rim-3}Q160 {rim+5} {160+outer} {rim-3}L{160+cheek} 197Q{160+cheek-9} {bottom-7} 160 {bottom}Q{160-cheek+9} {bottom-7} {160-cheek} 197Z", "#ac9d77", 3.2)
    path(mask, f"M160 {rim+6}L{160+outer-9} {rim+1}L{160+cheek-2} 194Q{160+cheek-13} {bottom-15} 161 {bottom-3}Z", "#757763")
    eyes = eye_layout(look, head)
    eye_y = 157 + eyes.height_offset
    for side in (-1, 1):
        x = 160 + side * eyes.spacing
        _shape(mask, f"M{x-17} {eye_y}Q{x} {eye_y-9} {x+17} {eye_y}Q{x} {eye_y+6} {x-17} {eye_y}Z", "#262824", 2.2)
        _line(mask, f"M{x-17} {eye_y-5}Q{x} {eye_y-14} {x+17} {eye_y-6}", "#d5c49c", 2)
    _shape(mask, f"M155 {eye_y-6}L163 {eye_y-5}L171 194Q160 202 150 194Z", "#bbae84", 1.7)
    _line(mask, "M139 219Q160 211 180 219M146 225Q160 230 175 224", "#494d40", 2.4)
    _line(mask, f"M{160-cheek+12} 181Q{160-cheek+18} 203 144 209", "#d5c8a6", 2)
    for x in (160-outer+6, 160+outer-6):
        node(mask, "circle", cx=x, cy=rim+9, r=2.6, fill=LIGHT, stroke=INK, stroke_width=1)


def draw_mail_coif(parent, look, fit):
    head = make_head(look)
    brow = brow_top(look, include_standard=True) - 8
    half = head.temple_half + 17
    chin = head.chin_y
    eyes = eye_layout(look, head)
    clear = max(head.temple_half - 3, eyes.spacing + eyes.outer + 6)
    opening = (f"M{160-clear} {brow}Q160 {brow-9} {160+clear} {brow}V174"
               f"Q{160+clear} 182 {160+head.cheek_half-3} 187"
               f"Q{160+head.jaw_half} {chin+2} 160 {chin+2}"
               f"Q{160-head.jaw_half} {chin+2} {160-head.cheek_half+3} 187"
               f"Q{160-clear} 182 {160-clear} 174Z")
    outer = f"M{160-half} 145Q{160-half-6} {head.top_y-18} 160 {head.top_y-19}Q{160+half+6} {head.top_y-18} {160+half} 145L{160+half+20} {chin+52}Q160 {chin+77} {140-half} {chin+52}Z"
    _shape(parent, outer + opening, SHADE, 3.2, fill_rule="evenodd")
    path(parent, outer + opening, "url(#mail-rings)", fill_rule="evenodd")
    _line(parent, opening, "#b3b09b", 2.3)


def draw_liner(parent, look, fit):
    head = make_head(look)
    top, brow = head.top_y - 14, fit.brim_y + 2
    half = head.temple_half + 6
    eyes = eye_layout(look, head)
    clear = max(head.temple_half - 6, eyes.spacing + eyes.outer + 6)
    cap = node(parent, "g", data_part="padded-liner")
    contour = (f"M{160-half} {brow+30}Q{154-half} {top+14} 160 {top}"
               f"Q{166+half} {top+14} {160+half} {brow+30}L{160+head.cheek_half+6} 205"
               f"Q{160+clear+2} 208 {160+clear} 180V{brow}Q160 {brow-13} {160-clear} {brow}V180"
               f"Q{160-clear-2} 208 {154-head.cheek_half} 205Z")
    _shape(cap, contour, "#a79a77", 3.2)
    for offset in (-40, -20, 0, 20, 40):
        x = 160 + offset * fit.x_scale
        _line(cap, f"M160 {top+4}Q{number(x)} {top+18} {number(x)} {brow-3}", "#625b48", 1.2)
        _line(cap, f"M{number(x+2)} {top+21}V{brow-6}", "#d7c6a0", 1.1)
    _line(cap, f"M{160-half+4} {brow-2}Q160 {brow-23} {160+half-4} {brow-2}", "#e3d2ab", 2.4)


def _outline_points(contour):
    """Снять опоры с настоящих линий кроя; погрешность кривой меньше 0,1 px."""
    import re
    tokens = re.findall(r"[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?", contour)
    points, current, first = [], (0., 0.), (0., 0.)
    index, command = 0, None
    counts = {"M": 2, "L": 2, "H": 1, "V": 1, "Q": 4, "C": 6}
    while index < len(tokens):
        if tokens[index].isalpha():
            command = tokens[index]
            index += 1
            if command.upper() == "Z":
                points.append(first)
                current = first
                continue
        upper = command.upper()
        count = counts[upper]
        values = list(map(float, tokens[index:index + count]))
        index += count
        relative = command.islower()
        if upper in {"H", "V"}:
            value = values[0] + (current[0 if upper == "H" else 1] if relative else 0)
            current = (value, current[1]) if upper == "H" else (current[0], value)
            points.append(current)
            continue
        controls = [(values[i] + (current[0] if relative else 0),
                     values[i + 1] + (current[1] if relative else 0)) for i in range(0, count, 2)]
        if upper in {"M", "L"}:
            current = controls[0]
            points.append(current)
            if upper == "M":
                first = current
                command = "l" if relative else "L"
        else:
            curve = [current, *controls]
            for step in range(1, 49):
                t = step / 48
                level = curve
                while len(level) > 1:
                    level = [((1 - t) * a[0] + t * b[0], (1 - t) * a[1] + t * b[1])
                             for a, b in zip(level, level[1:])]
                points.append(level[0])
            current = controls[-1]
    return points


def _surface_sections(contours, rows, *, padding=0):
    polygons = []
    for contour in contours:
        if isinstance(contour, tuple):
            shape, offset = contour
            polygons.append([(x + offset, y) for x,y in _outline_points(shape)])
        else:
            polygons.append(_outline_points(contour))
    sections = []
    for y in rows:
        hits = []
        for polygon in polygons:
            for a, b in zip(polygon, polygon[1:]):
                if min(a[1], b[1]) <= y < max(a[1], b[1]):
                    hits.append(a[0] + (y - a[1]) * (b[0] - a[0]) / (b[1] - a[1]))
        if hits:
            sections.append((y, min(hits) - padding, max(hits) + padding))
    return sections


def _section_contour(sections, *, left=0, right=1, caps=True):
    outer = [(y, a + (b - a) * left) for y, a, b in sections]
    inner = [(y, a + (b - a) * right) for y, a, b in sections]
    top, bottom = sections[0][0], sections[-1][0]
    start, end = outer[0][1], inner[0][1]
    d = f"M{number(start)} {number(top)}"
    if caps:
        d += f"Q{number((start + end) / 2)} {number(top - 4)} {number(end)} {number(top)}"
    else:
        d += f"L{number(end)} {number(top)}"
    d += "".join(f"L{number(x)} {number(y)}" for y, x in inner[1:])
    start, end = inner[-1][1], outer[-1][1]
    if caps:
        d += f"Q{number((start + end) / 2)} {number(bottom + 4)} {number(end)} {number(bottom)}"
    else:
        d += f"L{number(end)} {number(bottom)}"
    return d + "".join(f"L{number(x)} {number(y)}" for y, x in reversed(outer[:-1])) + "Z"


def _forearm_strap(parent, section, y):
    _, left, right = section(y)
    _, bottom_left, bottom_right = section(y + 5)
    middle = number((left + right) / 2)
    strap = f"M{number(left)} {y}Q{middle} {y + 6} {number(right)} {y}"
    contour = (f"{strap}L{number(bottom_right)} {y + 5}"
               f"Q{middle} {y + 11} {number(bottom_left)} {y + 5}Z")
    _shape(parent, contour, LEATHER, 1.2, data_part="bracer-strap")
    _line(parent, f"M{number(left + 2)} {y + 1.35}Q{middle} {y + 7} {number(right - 2)} {y + 1.35}",
          "#c6976c", 0.85)


def _draw_nerev_archer_bracer(parent, section):
    # Неревский раскоп, Медведев 1959, рис. 11:2, и 1966, табл. 10:7.
    group = node(parent, "g", data_part="arm-protection", data_style="rus_nerev_archer_bracer",
                 data_material_surface="fixed")

    def point(y, fraction):
        _, left, right = section(y)
        return f"{number(left + (right - left) * fraction)} {y}"

    for y in (404, 426):
        _forearm_strap(group, section, y)

    contour = (
        f"M{point(393, .57)}C{point(393, .74)} {point(399, .82)} {point(408, .84)}"
        f"C{point(422, .86)} {point(439, .78)} {point(442, .62)}"
        f"C{point(445, .45)} {point(436, .34)} {point(422, .34)}"
        f"C{point(405, .33)} {point(395, .41)} {point(393, .57)}Z"
    )
    _shape(group, contour, "#b89b73", 1.75, data_part="bracer-shell")
    path(group, f"M{point(396, .55)}C{point(402, .43)} {point(423, .42)} {point(438, .53)}"
         f"C{point(431, .56)} {point(404, .53)} {point(396, .65)}Q{point(395, .59)} {point(396, .55)}Z",
         "#e2cba3", opacity=".84")
    _line(group, f"M{point(399, .71)}C{point(409, .80)} {point(433, .79)} {point(438, .65)}",
          "#76583c", .85)
    triangles = " ".join(
        f"M{point(y, edge)}L{point(y + 2, edge - .07)} {point(y + 4, edge)}Z"
        for y, edge in ((404, .75), (411, .78), (418, .79), (425, .77), (432, .72))
    )
    _line(group, triangles, "#6b5238", .75, data_part="bracer-ornament")
    return group


def draw_arm_protection(parent, look, body):
    style = look.get("arm_protection", "none")
    if style == "none":
        return
    from wardrobe import sleeve_section
    archer = style == "index_archer_bracer"
    top, bottom = (375, 433) if archer else (379, 431)
    def section(y):
        left, right = sleeve_section(body, look["outfit"], y)
        return y, left - .7, right + .7
    if style == "rus_nerev_archer_bracer":
        # Лук находится в кисти слева на рисунке.
        sleeve = parent.find(".//*[@data-part='sleeve-left']")
        bracer = _draw_nerev_archer_bracer(sleeve if sleeve is not None else parent, section)
        if sleeve is None:
            cloak = parent.find("./*[@data-part='cloak-fabric']")
            if cloak is not None:
                parent.remove(bracer)
                parent.insert(list(parent).index(cloak), bracer)
        return
    sections = [section(y) for y in [*range(top, bottom, 4), bottom]]
    for side in (("left",) if archer else ("left", "right")):
        sleeve = parent.find(f".//*[@data-part='sleeve-{side}']")
        surface = parent if sleeve is None else sleeve
        group = node(surface, "g", data_part="arm-protection", data_style=style,
                     transform="translate(320 0) scale(-1 1)" if side == "right" and sleeve is None else None)
        contour = _section_contour(sections, left=.08 if archer else 0, right=.91 if archer else 1)
        if archer:
            for y in (385, 421):
                _forearm_strap(group, section, y)
        _shape(group, contour, "#9b7550" if archer else STEEL, 2 if archer else 2.6,
               data_part="bracer-shell")
        path(group, _section_contour(sections, left=.06, right=.46, caps=False),
             "#cba878" if archer else LIGHT, opacity=".67")
        if not archer:
            path(group, _section_contour(sections, left=.74, caps=False), SHADE, opacity=".55")
            for y in (385, 419):
                _forearm_strap(group, section, y)
                _, left, right = section(y)
                node(group, "circle", cx=left + (right - left) * .67, cy=y + 5.4, r=1.6,
                     fill=LIGHT, stroke=INK, stroke_width=.7)


def draw_leg_protection(parent, look, body, *, dress=False, lower_wear=None):
    style = look.get("leg_protection", "none")
    if style == "none":
        return
    from wardrobe_northwest_legs import lower_limb_fit, lower_limb_surfaces
    wear = {"trousers": "straight", "leg_wraps": "none", "footwear": "novgorod_shoes",
            "foot_lining": "none", **(lower_wear or {})}
    wear.update({key: look[key] for key in wear if key in look})
    fit = lower_limb_fit(body, dress=dress, trousers=wear["trousers"])
    surfaces = lower_limb_surfaces(fit, **wear)
    mail = style == "index_mail_chausses"
    top, bottom = (480, 705) if mail else (594, 686)
    sections = _surface_sections(surfaces, [*range(top, bottom, 4), bottom], padding=.8)
    for side, transform in enumerate(fit.transforms):
        group = node(parent, "g", data_part="leg-protection", data_style=style,
                     transform=transform)
        contour = _section_contour(sections)
        if mail:
            _shape(group, contour, SHADE, 2.2, data_part="chausse-shell")
            # Keep links round in stage space even on a narrower body.
            rings = node(group, "g", transform=f"scale({number(1 / fit.width)} 1)")
            scaled = [(y, a*fit.width, b*fit.width) for y,a,b in sections]
            path(rings, _section_contour(scaled), "url(#mail-rings)")
            path(group, _section_contour(sections, left=.06, right=.30, caps=False), LIGHT, opacity=".2")
            _line(group, _section_contour(sections), "#3f4038", 1.6)
        else:
            _shape(group, contour, "#776e56", 2.4, data_part="greave-shell")
            for i in range(7):
                _shape(group, _section_contour(sections, left=(i+.18)/7, right=(i+.82)/7, caps=False),
                       STEEL if i%2 else LIGHT, .7)
            for y in (605, 641, 676):
                _, left, right = _surface_sections(surfaces, [y], padding=.8)[0]
                _line(group, f"M{number(left)} {y}Q{number((left+right)/2)} {y+4} {number(right)} {y}", LEATHER, 4)
                _shape(group, f"M{number(right-7)} {y-2}h6v6h-6Z", "#bda36c", 1)


def draw_neck_protection(parent, look, head):
    if look.get("neck_protection", "none") != "index_mail_gorget":
        return
    chin, half = head.chin_y, head.neck_half + 12
    group = node(parent, "g", data_part="neck-protection", data_style="index_mail_gorget")
    d = f"M{160-half} {chin+4}Q160 {chin+14} {160+half} {chin+4}L218 309L160 334L102 309Z"
    _shape(group, d, SHADE, 2.8)
    path(group, d, "url(#mail-rings)")
    _line(group, f"M{160-half} {chin+4}Q160 {chin+14} {160+half} {chin+4}", LEATHER, 4)


OUTFIT_DRAWERS = {"index_flat_ring_mail": draw_flat_mail, "index_padded_tunic": draw_padded_tunic}
HEADGEAR_DRAWERS = {"index_western_nasal": draw_western_helmet, "index_lipovets_mask": draw_full_mask,
                    "index_mail_coif": draw_mail_coif, "index_padded_liner": draw_liner}
