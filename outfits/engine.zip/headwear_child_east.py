"""Детские головные уборы Сун, Цзинь и Ирака в координатах HeadwearFit."""

from common import node, path
from hair_length import SCALP_STYLES


OPTIONS = {
    "child_song_soft_cap": "Мягкая шапочка",
    "child_iraq_school_wrap": "Обмотка ученика",
    "child_song_pearl_ribbons": "Шёлковые ленты с жемчугом",
}
COVERAGE = {gear: {"ears": True, "neck": True, "hair": True} for gear in OPTIONS}
HAIR_ROOT_HALF = {"child_song_soft_cap": 68, "child_iraq_school_wrap": 68}
OPEN_CROWNS = {"child_song_pearl_ribbons"}
BRAID_HEMS = {}


def draw_song_soft_cap(parent, look, fit):
    crown = fit.crown(parent, minimum_y=62)
    path(crown, "M83 109 C84 94 93 81 109 73 C121 65 139 64 157 63 "
         "C176 62 192 64 209 72 Q231 81 238 108 Q235 114 227 113 "
         "C200 107 181 106 158 107 C131 106 108 109 94 113 Q87 114 83 109 Z",
         "#637483", class_="edge")
    path(crown, "M90 104 Q95 86 114 76 C128 69 145 66 161 66 "
         "Q140 74 132 87 Q129 94 127 102 Q104 103 90 108 Z", "#85939a")
    path(crown, "M169 65 C198 64 226 78 235 107 Q216 106 201 104 "
         "Q194 76 169 65 Z", "#465562")
    path(crown, "M202 74 Q227 83 233 104 L220 102 Q215 84 202 74 Z",
         "url(#ink-lines)", opacity=".65")
    path(crown, "M164 66 C147 73 138 83 135 98 M203 78 Q213 86 216 94", class_="seam", opacity=".72")
    path(crown, "M105 93 l5-5 m2 5 6-5 M196 84 l4 4 m6 5 3 4", class_="etch", opacity=".65")
    path(crown, "M88 107 Q114 101 139 101 Q172 100 194 101 Q213 102 232 107",
         "none", stroke="#3f4e59", stroke_width=2.25, stroke_linecap="round")
    path(crown, "M94 105 Q123 99 149 100 M154 99 l12 0 m5 0 14 1",
         "none", stroke="#a3a8a4", stroke_width=1.25, stroke_linecap="round", opacity=".83")


def draw_iraq_school_wrap(parent, look, fit):
    crown = fit.crown(parent, minimum_y=61)
    path(crown, "M82 104 Q80 94 89 86 Q97 76 111 70 C127 62 142 64 156 62 "
         "C172 63 183 61 199 66 Q220 72 231 87 Q240 97 238 107 L225 113 "
         "Q197 109 157 108 Q117 108 93 113 Z", "#477370", class_="edge")
    path(crown, "M94 85 Q114 65 151 66 Q179 63 197 69 Q164 72 141 81 "
         "Q117 84 94 90 Z", "#65938a")
    path(crown, "M198 67 Q216 73 230 87 L217 92 Q212 78 198 67 Z", "#365952")
    path(crown, "M84 95 Q104 86 127 85 Q164 80 192 70 Q204 67 214 75 "
         "Q198 79 186 84 Q137 101 90 103 Q85 101 84 95 Z", "#73968a",
         stroke="#334847", stroke_width=2.45, stroke_linejoin="round")
    path(crown, "M89 96 Q120 91 146 87 Q171 82 196 73", "none",
         stroke="#a4b1a0", stroke_width=1.8, stroke_linecap="round")
    path(crown, "M85 99 C107 101 133 96 154 94 Q199 88 227 81 Q235 85 238 95 "
         "Q203 105 164 107 Q115 111 87 108 Q81 104 85 99 Z", "#527e77",
         stroke="#334847", stroke_width=2.45, stroke_linejoin="round")
    path(crown, "M173 99 Q212 93 232 85 Q236 90 237 96 Q208 105 182 105 Z",
         "url(#ink-lines)", opacity=".72")
    path(crown, "M91 102 Q112 105 142 100 M195 94 Q213 91 225 87 M214 95 l10-4",
         class_="etch", opacity=".76")
    path(crown, "M87 104 C108 107 133 105 155 102 Q200 100 236 93 Q242 98 237 105 "
         "Q230 112 218 111 C200 112 176 111 155 112 C132 111 116 113 95 113 "
         "Q85 113 87 104 Z", "#d9caaa", class_="edge")
    path(crown, "M94 109 Q123 108 150 106 M159 106 Q201 106 234 98", "none",
         stroke="#f2dfbc", stroke_width=2.25, stroke_linecap="round")
    path(crown, "M183 109 q20 1 35-3 m4 1 7-3", class_="etch", opacity=".7")


def draw_song_pearl_ribbons(parent, look, fit):
    if look["hair_style"] == "adult_latin_tonsure" or look["hair_style"] in SCALP_STYLES:
        band = fit.sides(parent)
        path(band, "M92 108Q161 89 228 108L228 115Q162 100 92 115Z", "#883d3b", class_="edge")
        path(band, "M98 109Q159 94 222 109", "none", stroke="#ca6351", stroke_width=2.2)
        silk = node(band, "g", transform="translate(137 106) scale(.62) translate(-137 -84)")
    elif look["hair_style"] == "child_song_forelock":
        silk = node(fit.hair(parent), "g", transform="translate(157 86) scale(.64) translate(-137 -84)")
    elif look["hair_style"] == "child_jin_three_knots":
        silk = node(fit.hair(parent), "g", transform="translate(161 76) scale(.58) translate(-137 -84)")
    elif look["hair_style"] in {"adult_steppe_long_braids", "adult_steppe_folded_braids"}:
        silk = node(fit.hair(parent), "g", transform="translate(156 94) scale(.72) translate(-137 -84)")
    else:
        silk = fit.crown(parent, minimum_y=66)
    # The short ends fold back beside the knot.
    path(silk, "M136 82 Q149 84 159 87 Q175 92 187 84 Q183 92 186 95 "
         "C170 103 150 94 135 89 Z", "#a3403e", class_="edge")
    path(silk, "M138 85 C152 86 160 90 161 94 Q154 95 150 98 Q153 93 136 91 Z",
         "#c8584d", stroke="#6b3436", stroke_width=2.45, stroke_linejoin="round")
    path(silk, "M137 85 C127 81 112 83 101 92 Q109 85 102 83 Q97 80 94 84 "
         "C104 72 123 72 139 80 Z", "#a8433b", class_="edge")
    path(silk, "M101 80 Q115 73 132 81 Q113 78 104 84 Z", "#cd6150")
    path(silk, "M133 81 C143 73 153 68 166 67 Q176 66 174 73 Q171 82 157 84 "
         "Q146 83 140 88 Z", "#ae423a", class_="edge")
    path(silk, "M141 81 Q152 72 169 70 Q167 77 157 79 Z", "#d76c55")
    path(silk, "M145 82 Q154 81 163 76 M109 78 Q118 77 123 79 M166 95 Q175 96 180 92",
         class_="etch", opacity=".83")
    path(silk, "M129 78 Q135 74 144 78 L149 84 Q146 91 137 92 Q129 91 127 86 Z",
         "#c34f44", class_="edge")
    path(silk, "M130 83 Q136 79 143 82", "none", stroke="#ed9d72", stroke_width=1.75, stroke_linecap="round")

    # The irregular pearl beads are sewn to the knot and its upper fold.
    for pearl, gleam in (
        ("M124 78 Q124 73 129 73 Q134 74 134 78 Q132 82 128 82 Q124 81 124 78 Z",
         "M126 77 q1-2 3-2"),
        ("M136 75 Q137 69 142 69 Q148 70 148 75 Q148 80 142 81 Q136 80 136 75 Z",
         "M139 74 q1-3 4-2"),
        ("M144 84 Q145 79 150 79 Q155 80 155 85 Q154 89 149 89 Q144 89 144 84 Z",
         "M147 84 q1-2 3-2"),
    ):
        path(silk, pearl, "#e9d8b7", stroke="#613e3c", stroke_width=1.9, stroke_linejoin="round")
        path(silk, gleam, "none", stroke="#fff1d6", stroke_width=1.45, stroke_linecap="round")


DRAWERS = {
    "child_song_soft_cap": draw_song_soft_cap,
    "child_iraq_school_wrap": draw_iraq_school_wrap,
    "child_song_pearl_ribbons": draw_song_pearl_ribbons,
}
