"""Cultural wardrobes for the automatic Rus13 costume selection."""

from clothing_catalog import REFERENCE_CULTURES


CULTURES = {
    "rus": "Русь",
    "song": "Китай эпохи Сун",
    "steppe": "Степь",
    "bandiagara": "Бандиагара",
    "karelia": "Карелия",
    "baltic": "Восточная Балтика",
    "nordic": "Скандинавия",
    "western": "Западная Европа",
    "castile": "Кастилия",
    "iraq_iran": "Ирак и Иран",
    "japan": "Япония",
    "tang": "Китай эпохи Тан",
    "caucasus": "Кавказ",
    "south_asia": "Южная Азия",
    "angkor": "Ангкор",
}
PROFILE_CULTURES = {
    "novgorod": ("rus",),
    "east_eurasia": ("song", "steppe"),
    "sub_saharan": ("bandiagara",),
}
AUTO_CULTURES = tuple(culture for cultures in PROFILE_CULTURES.values() for culture in cultures)

_ALL = tuple(CULTURES)
_NORTH = ("rus", "karelia", "baltic", "nordic")
_WEST = (*_NORTH, "western", "castile")
_EAST = ("song", "steppe", "iraq_iran", "japan", "tang")

# Shared cuts and generic accessories are listed together. Named finds are
# limited to the culture or cultures they were drawn for.
_GROUPS = {
    "outfit": (
        (_NORTH, "shirt"),
        (("rus",), "svita cloak kozukh armor izyaslav_kaftan korzno ryazan_sleeves rus_mantle rus_child_svita "
         "rus_gilt_cuff_tunic rus_gold_yoke_gown rus_checked_panel nw_nov_svita nw_nov_sofia_tunic "
         "nw_nov_womens_rubakha nw_nov_womens_fur_coat nw_nov_trimmed_gown nw_nov_lamellar nw_nov_scale "
         "nw_nov_copper_mail nw_gomel_lamellar"),
        (("karelia",), "nw_karel_tunic nw_karel_apron_gown"),
        (("baltic",), "nw_baltic_mens_coat nw_baltic_spiral_kuub"),
        (("nordic",), "norse_child_tunic nw_nordic_gored_tunic nw_nordic_pleated_gown "
         "nw_gotland_mens_cloak nw_gotland_womens_mantle"),
        (("western",), "naumburg_clasp_mantle nw_mail_surcoat nw_magdeburg_plate_coat"),
        (_WEST, "nw_mail_hauberk"),
        (("castile",), "pellote castile_royal_pellote castile_laced_saya"),
        (("steppe",), "steppe_robe steppe_dress yuan_fur_hunt_robe yuan_brocade_coat"),
        (("song",), "song_child_jacket song_plain_jacket song_round_robe song_pheasant_robe"),
        (("tang",), "tang_jacket"),
        (("japan",), "kariginu"),
        (("iraq_iran",), "tiraz_robe iraq_school_robe"),
        (("bandiagara",), "tellem_tunic tellem_wrap"),
    ),
    "headgear": (
        (_NORTH, "cap fur_cap felt_cap child_felt_turnup"),
        ((*_NORTH, "western", "castile"), "wrap shoulder_veil linen_coif"),
        (("rus",), "helmet tall_helmet temple_rings rus_wedge_cap rus_diamond_band child_rus_browband "
         "nw_nov_round_cap nw_nov_seamed_cap nw_nov_plain_veil nw_nov_povoy nw_nov_rhombic_band "
         "nw_rus_half_mask nw_duboshin_helm nw_lykovo_helm"),
        (("karelia",), "nw_karel_veil"),
        (("baltic",), "nw_baltic_cloth_cap nw_baltic_spiral_band nw_pakalniskiai_helm"),
        (("nordic",), "nw_nordic_hood nw_nordic_linen_veil nw_gjermundbu_helm"),
        (("western", "castile"), "wimple"),
        (("western",), "naumburg_linen_cap nw_iron_hat nw_great_helm"),
        (("castile",), "child_castile_cofia castile_biretta castile_pleated_tocado"),
        (("steppe",), "bocca yuan_hunting_cap"),
        (("song",), "child_song_soft_cap child_song_pearl_ribbons song_futou song_pearl_crown"),
        (("tang",), "weimao"),
        (("japan",), "eboshi"),
        (("iraq_iran",), "wrapped_turban child_iraq_school_wrap"),
        (("bandiagara",), "tellem_cap"),
    ),
    "cloth_color": (
        (_ALL, "natural"),
        ((*_WEST, *_EAST), "madder ochre"),
        (_WEST, "moss woad"),
        ((*_EAST, "bandiagara"), "indigo"),
    ),
    "accessory": (
        (_WEST, "brooch pendant pouch"),
    ),
    "trousers": (
        (_NORTH, "straight gathered"),
        (("western", "castile", "nordic"), "hose"),
        ((*_WEST, *_EAST), "plain_trousers"),
    ),
    "leg_wraps": (
        (_NORTH, "wool"),
        (("baltic",), "siksala"),
    ),
    "footwear": (
        (_NORTH, "porshni"),
        (("rus",), "novgorod_shoes novgorod_ankle_boots novgorod_high_boots"),
        (("nordic",), "oslo_strap_shoes"),
        (("song", "tang", "japan", "iraq_iran", "western", "castile"), "cloth_shoes"),
        (("steppe",), "steppe_boots"),
        (("bandiagara",), "barefoot"),
    ),
    "belt": (
        ((*_WEST, *_EAST), "leather woven"),
        (("baltic",), "saaremaa"),
    ),
    "belt_pouch": (
        (_WEST, "drawstring pleated"),
        (("rus",), "novgorod_flap"),
    ),
    "jewelry": (
        (("rus", "nordic", "western", "castile"), "cross quadrifoil"),
        (_NORTH, "glass_beads"),
        (("rus", "karelia"), "noisy_horse"),
    ),
    "cloak": (
        (("rus",), "novgorod_mantle rus_korzno"),
        (("baltic",), "siksala_shawl"),
        (("nordic",), "gotland_open"),
    ),
    "weapon": (
        (_WEST, "sheathed_sword sword axe spear"),
        (("rus",), "eur_steppe_nefedyevo_flail eur_steppe_zagorye_mace eur_steppe_zaryadye_mace "
         "eur_steppe_seltso_hammer_axe eur_steppe_grigorovo_dart"),
        (("rus", "steppe"), "eur_steppe_yaroslavl_sabre"),
        (("steppe",), "eur_steppe_vienna_sabre"),
        (("caucasus",), "eur_steppe_dargavs_double_axe"),
        (("nordic", "western"), "eur_west_lobed_sword eur_west_seax eur_west_broad_axe"),
        (("western",), "eur_west_oval_sword eur_west_francisca eur_west_winged_spear "
         "eur_west_bayeux_club eur_west_drosten_crossbow"),
        (("baltic",), "eur_west_scalvian_spear"),
        (("castile",), "eur_west_taull_sling"),
        (("iraq_iran",), "eur_steppe_samanid_khanjar eur_steppe_ghaznavid_feline_mace"),
        (("song",), "eur_east_song_crescent_sword eur_east_china_dragon_ring"),
        (("steppe",), "eur_east_liao_guduo"),
        (("japan",), "eur_east_japan_tachi"),
        (("south_asia",), "eur_east_chola_chakra eur_east_punjab_gada eur_east_chola_trishula eur_east_bengal_ankusha"),
        (("angkor",), "eur_east_angkor_spear eur_east_angkor_phkak"),
    ),
    "shield": (
        (_WEST, "round kite"),
        (("western", "castile"), "triangular"),
        (("rus",), "novgorod_george novgorod_dish yuriev_lion"),
        (("nordic",), "gokstad lewis"),
        (("baltic",), "szczecin_painted"),
    ),
    "bow": (
        (_NORTH, "northern_wood"),
        (("rus",), "novgorod_composite"),
    ),
    "bow_case": (
        (("rus",), "plain_leather bone_trim"),
    ),
    "quiver": (
        (("rus",), "birchbark leather_covered"),
    ),
}
ITEM_CULTURES = {
    field: {item: cultures for cultures, items in groups for item in items.split()}
    for field, groups in _GROUPS.items()
}


def cultures_for_item(field, item):
    if item in {"auto", "none"} or field in {"background", "carry", "shield_carry"}:
        return _ALL
    assigned = ITEM_CULTURES.get(field, {}).get(item)
    return assigned or REFERENCE_CULTURES.get((field, item), _ALL)


def compatible_cultures(cultures, gear):
    return tuple(culture for culture in cultures
                 if all(culture in cultures_for_item(field, item) for field, item in gear.items()))
