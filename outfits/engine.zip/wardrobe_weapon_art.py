from common import path


INK = "#2c2120"
STEEL = "#96998c"
STEEL_SHADE = "#62675c"
STEEL_LIGHT = "#cdcaba"
LEATHER = "#79513e"


def shape(parent, contour, fill, width=2.6, **attrs):
    path(parent, contour, fill, stroke=INK, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def line(parent, contour, color, width):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round")


def hatch(parent, contour, opacity):
    path(parent, contour, "url(#ink-lines)", opacity=opacity)
