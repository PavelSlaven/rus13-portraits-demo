from common import node, path


INK = "#2c2120"
STEEL = "#96998c"
STEEL_SHADE = "#62675c"
STEEL_LIGHT = "#cdcaba"
LEATHER = "#79513e"


def shape(parent, contour, fill, width=2.6, **attrs):
    path(parent, contour, fill, stroke=INK, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def line(parent, contour, color, width):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round")


def hatch(parent, contour, opacity):
    path(parent, contour, "url(#ink-lines)", opacity=opacity)


def draw_disc_sword_hilt(parent, *, grip_part=None):
    # The plain disk and straight crossguard follow the silhouette of GIM 4566 or.
    shape(parent, "M-4.5-18Q0-19 4.5-18L4 16H-4Z", "#694b3c", 1.9,
          data_part=grip_part)
    line(parent, "M-3-15l6 2m-6 5 6 2m-6 5 6 2m-6 5 6 2m-6 4 6 2", "#aa8363", .95)
    node(parent, "circle", cx=0, cy=-24, r=8.7, fill=STEEL_SHADE, stroke=INK, stroke_width=2.2)
    path(parent, "M-6.2-25Q-5.6-30.5 0-30.5Q4.6-30.5 6.2-26Q2.2-28-1.7-25.3"
         "Q-3.6-24-5.2-21.6Q-6.1-23-6.2-25Z", STEEL)
    line(parent, "M-4.5-26.7Q-2.4-29.4 1.5-28.9", STEEL_LIGHT, .95)
    shape(parent, "M-23 15.5H23V20.2H-23Z", STEEL_SHADE, 2)
    line(parent, "M-21 16.8H21", STEEL_LIGHT, 1.1)


def draw_disc_sword(parent):
    shape(parent, "M-7.2 18H7.2C6.6 90 5.9 177 4 230Q3.4 242 0 247"
          "Q-3.4 242-4 230C-5.9 177-6.6 90-7.2 18Z", STEEL, 2.5)
    shade = "M.9 21H6C5.3 102 5.1 180 3.2 230Q2.9 241 0 244Q1.9 156 .9 21Z"
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .41)
    line(parent, "M-5.7 23Q-5.2 134-3.3 214Q-3 229-1.4 237", STEEL_LIGHT, 1.15)
    line(parent, "M-1.9 25Q-1.9 130-1.1 183", "#626358", 1.5)
    draw_disc_sword_hilt(parent, grip_part="weapon-grip")


def draw_polovtsian_sabre_hilt(parent, *, grip_part=None):
    # A short arched crossguard and an oval pommel follow Novyi I, fig. 3:2.
    shape(parent, "M-7-20Q-2-21 2-19L4.4 13H-4.6Z", "#685042", 1.9,
          data_part=grip_part)
    line(parent, "M-5-14l6 1m-5.5 5 6 1m-5.6 5 6 1m-5.8 5 6.2 1", "#ad8565", .95)
    shape(parent, "M-10-20Q-12-22-10-25Q-7-28-2-27Q3-27 5-24Q7-21 4-19"
          "L1-18-1-21H-5L-7-18Z", STEEL_SHADE, 1.7)
    line(parent, "M-8.8-23.2Q-5.8-26.1 .3-24.6", STEEL_LIGHT, .9)
    shape(parent, "M-15 16Q-10 13-6 13Q0 9 6 13Q10 13 15 16L14 20"
          "Q8 17 5 17H-5Q-8 17-14 20Z", STEEL_SHADE, 1.9)
    for x in (-14, 14):
        node(parent, "circle", cx=x, cy=18.5, r=3, fill=STEEL, stroke=INK, stroke_width=1.4)
    line(parent, "M-10 15.5Q-4 13 0 12.8Q4 13 10 15.5", STEEL_LIGHT, .95)


def draw_polovtsian_sabre(parent):
    shape(parent, "M-6.5 17H6.5C7.2 71 12 133 15 188Q17 227 10 244"
          "Q6.7 227 3.8 191C.5 143-6 74-6.5 17Z", STEEL, 2.55)
    shade = ("M-.6 20H5.4C6.7 79 11.4 139 14 188Q15.8 224 10 241"
             "Q11.1 212 8.1 186C4.3 137 .5 77-.6 20Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .44)
    line(parent, "M-4.9 22C-4.3 79 1.2 137 5.5 191Q7.2 213 9.4 228", STEEL_LIGHT, 1.2)
    line(parent, "M-2.4 24C-1.9 75 2.3 121 4.5 152", "#66685e", .95)
    draw_polovtsian_sabre_hilt(parent, grip_part="weapon-grip")
