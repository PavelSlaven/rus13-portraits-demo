import argparse
import json
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from generate import APPEARANCE, EQUIPMENT, _catalog, render_svg, resolve_appearance, resolve_equipment, save_recipe
from profiles import DEFAULT_PROFILE, PROFILES, weights_for

ROOT = Path(__file__).resolve().parent
STATIC = {
    "/": ("editor.html", "text/html; charset=utf-8"),
    "/editor.html": ("editor.html", "text/html; charset=utf-8"),
    "/editor.css": ("editor.css", "text/css; charset=utf-8"),
    "/editor.js": ("editor.js", "text/javascript; charset=utf-8"),
}
MAX_REQUEST_BYTES = 32768


def catalog():
    memberships = {}
    for field, options in {**APPEARANCE, **EQUIPMENT}.items():
        by_profile = {profile: weights_for(profile, field, options) for profile in PROFILES}
        memberships[field] = {
            value: [profile for profile, weights in by_profile.items() if weights[value] > 0]
            for value in options
        }
    return {
        **_catalog(),
        "profiles": PROFILES,
        "default_profile": DEFAULT_PROFILE,
        "memberships": memberships,
    }


def render_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError("Ожидается объект с параметрами портрета.")
    seed = payload.get("seed")
    if not isinstance(seed, str) or not 1 <= len(seed) <= 256:
        raise ValueError("Seed должен содержать от 1 до 256 символов.")
    profile = payload.get("profile", DEFAULT_PROFILE)
    if not isinstance(profile, str) or profile not in PROFILES:
        raise ValueError("Выберите профиль из списка.")
    extended = payload.get("extended", True)
    if not isinstance(extended, bool):
        raise ValueError("Для extended ожидается true или false.")
    expanded_hair = payload.get("expanded_hair", extended)
    if not isinstance(expanded_hair, bool):
        raise ValueError("Для expanded_hair ожидается true или false.")
    distinct_bases = payload.get("distinct_bases", extended)
    if not isinstance(distinct_bases, bool):
        raise ValueError("Для distinct_bases ожидается true или false.")
    cast_traits = payload.get("cast_traits", distinct_bases)
    if not isinstance(cast_traits, bool):
        raise ValueError("Для cast_traits ожидается true или false.")
    for key in ("appearance", "equipment"):
        values = payload.get(key, {})
        if not isinstance(values, dict) or any(not isinstance(value, str) for value in values.values()):
            raise ValueError(f"Поле {key} должно содержать пары «параметр — вариант».")
    appearance = resolve_appearance(
        seed, payload.get("appearance"), profile=profile, extended=extended, expanded_hair=expanded_hair,
        distinct_bases=distinct_bases, cast_traits=cast_traits,
    )
    equipment = resolve_equipment(payload.get("equipment"), appearance=appearance)
    return {
        "full": render_svg(appearance, equipment, view="full", title="Rus13 · В полный рост"),
        "portrait": render_svg(appearance, equipment),
        "card": render_svg(appearance, equipment, view="card", title="Карточка Rus13"),
        "recipe": save_recipe(seed, appearance, equipment, profile=profile),
    }


class EditorHandler(BaseHTTPRequestHandler):
    def _send(self, status, payload, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' blob:; object-src 'none'; frame-ancestors 'none'",
        )
        self.end_headers()
        self.wfile.write(payload)

    def _json(self, status, payload):
        self._send(status, json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def do_GET(self):
        route = urlsplit(self.path).path
        if route == "/api/catalog":
            self._json(200, catalog())
            return
        asset = STATIC.get(route)
        if not asset:
            self._json(404, {"error": "Страница не найдена."})
            return
        name, content_type = asset
        self._send(200, (ROOT / name).read_bytes(), content_type)

    def do_POST(self):
        if urlsplit(self.path).path != "/api/render":
            self._json(404, {"error": "Страница не найдена."})
            return
        if self.headers.get_content_type() != "application/json":
            self._json(415, {"error": "Отправьте параметры в формате JSON."})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if not 1 <= size <= MAX_REQUEST_BYTES:
                raise ValueError("Неверный размер запроса.")
            try:
                payload = json.loads(self.rfile.read(size).decode("utf-8"))
            except (UnicodeError, json.JSONDecodeError) as exc:
                raise ValueError("Не удалось прочитать параметры JSON.") from exc
            result = render_payload(payload)
        except ValueError as exc:
            self._json(400, {"error": str(exc)})
            return
        self._json(200, result)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Локальный редактор внешности Rus13")
    parser.add_argument("--port", type=int, default=0, help="Номер порта, по умолчанию выбирается свободный")
    parser.add_argument("--no-open", action="store_true", help="Напечатать адрес без открытия браузера")
    args = parser.parse_args(argv)
    if not 0 <= args.port <= 65535:
        parser.error("Порт должен быть от 0 до 65535.")
    with ThreadingHTTPServer(("127.0.0.1", args.port), EditorHandler) as server:
        url = f"http://127.0.0.1:{server.server_port}/"
        print(url, flush=True)
        if not args.no_open:
            webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
