from functools import partial

from common import BROW_TAILS, brow_geometry, eye_height, node, number, path
from nose_mouth import draw_mouth, draw_nose


OPTIONS = {
    "eye_shape": {"almond": "Вытянутые", "open": "Округлые открытые", "narrow": "Узкие"},
    "eye_spacing": {"balanced": "Средняя", "close": "Сближенная", "wide": "Широкая"},
    "eye_tilt": {"level": "Вровень", "down": "Наружный угол ниже", "up": "Наружный угол выше"},
    "eyelid": {"crease": "Открытая складка", "hooded": "Нависшее веко", "smooth": "Гладкое веко"},
    "inner_fold": {"open": "Открытый угол", "folded": "Угол под складкой"},
    "brow_shape": {
        "arched": "Дугообразные", "straight": "Прямые", "angular": "С изломом",
        "heavy_ridge": "Прямые на выступающем надбровье", "soft_arch": "Плавная дуга с тонким хвостом",
    },
    "brow_weight": {"medium": "Средние", "thin": "Тонкие", "thick": "Густые"},
    "brow_height": {"medium": "Средняя", "low": "Низкая", "high": "Высокая"},
    "iris": {"brown": "Карие", "hazel": "Ореховые", "gray": "Серые", "blue": "Голубые", "green": "Зелёные"},
    "nose_bridge": {"straight": "Прямая", "convex": "Выпуклая", "concave": "Слегка вогнутая"},
    "nose_length": {"medium": "Средний", "short": "Короткий", "long": "Длинный"},
    "nose_width": {"medium": "Среднее", "narrow": "Узкое", "wide": "Широкое"},
    "nose_tip": {"round": "Округлый", "defined": "Очерченный узкий", "broad": "Широкий"},
    "mouth_width": {"medium": "Средний", "narrow": "Узкий", "wide": "Широкий"},
    "lip_volume": {"medium": "Средние", "thin": "Тонкие", "full": "Полные"},
    "lip_shape": {"soft": "Мягкий контур", "bow": "Выраженная дуга верхней губы", "lower": "Акцент на нижней губе"},
    "expression": {"neutral": "Нейтральное", "smile": "Лёгкая улыбка", "tense": "Напряжение", "open": "Открытый рот"},
    "gaze": {"direct": "Прямо", "left": "Влево", "right": "Вправо"},
}

LABELS = {
    "eye_shape": "Контур глаз",
    "eye_spacing": "Посадка глаз",
    "eye_tilt": "Наклон глаз",
    "eyelid": "Верхнее веко",
    "inner_fold": "Внутренний угол глаза",
    "brow_shape": "Форма бровей",
    "brow_weight": "Густота бровей",
    "brow_height": "Высота бровей",
    "iris": "Цвет радужки",
    "nose_bridge": "Спинка носа",
    "nose_length": "Длина носа",
    "nose_width": "Ширина основания носа",
    "nose_tip": "Кончик носа",
    "mouth_width": "Ширина рта",
    "lip_volume": "Объём губ",
    "lip_shape": "Контур губ",
    "expression": "Выражение лица",
    "gaze": "Направление взгляда",
}

EYE_DETAILS = {
    "eye_width": {"standard": "Обычная", "narrow": "Узкая", "wide": "Широкая"},
    "eye_height": {"standard": "Средняя", "high": "Высокая", "low": "Низкая"},
    "iris_size": {"standard": "Обычный", "small": "Малый", "large": "Большой"},
    "lower_lid": {"standard": "Обычное", "soft": "Мягкое", "defined": "Очёрченное"},
    "brow_length": {"standard": "Средняя", "short": "Короткие", "long": "Длинные"},
    "brow_gap": {"standard": "Средний", "close": "Малый", "wide": "Большой"},
    "brow_tail": {"standard": "Обычный", "lifted": "Приподнятый", "drooped": "Опущенный"},
}

EYE_DETAIL_LABELS = {
    "eye_width": "Ширина глазной щели",
    "eye_height": "Высота посадки глаз",
    "iris_size": "Размер радужки",
    "lower_lid": "Нижнее веко",
    "brow_length": "Длина бровей",
    "brow_gap": "Промежуток между бровями",
    "brow_tail": "Хвост брови",
}

_EYE_CURVES = {
    "almond": ("C-16 -6 -9 -14 0 -14 C9 -14 15 -7 19.5 0", "C14 8 7 12 -1 12 C-11 12 -17 8 -21 0Z", -19),
    "open": ("C-19 -12 -11 -18 -0.5 -18 C9 -18 17 -11 19.5 0", "C17 12 9 16 -1 16 C-12 16 -19 11 -21 0Z", -23),
    "narrow": ("C-15 -5 -9 -8.5 0 -8.5 C9 -8.5 15 -4.5 19.5 0", "C14 5 6 7.5 -1 7.5 C-11 7.5 -17 5 -21 0Z", -15),
}

_WOMEN_EYE_CURVES = {
    "almond": ("C-16 -8 -10 -15 -3 -15 C6 -15 14 -8 19.5 0", "C14 7 7 11 -1 11 C-11 11 -18 7 -21 0Z", -20),
    "open": ("C-19 -13 -12 -19 -3 -19 C7 -19 16 -12 19.5 0", "C16 11 8 15 -1 15 C-12 15 -19 10 -21 0Z", -24),
    "narrow": ("C-16 -6 -10 -10 -3 -10 C6 -10 14 -5 19.5 0", "C14 5 6 7 -1 7 C-11 7 -18 5 -21 0Z", -16),
}

_SOFT_LOWER_LIDS = {
    "almond": "C13 6 7 10 -1 10 C-11 10 -17 6 -21 0Z",
    "open": "C16 10 9 13 -1 13 C-12 13 -18 9 -21 0Z",
    "narrow": "C14 4 6 6 -1 6 C-11 6 -17 4 -21 0Z",
}

_EYE_HOOD_CLEARANCE = {"close": 58, "balanced": 60, "wide": 65}

_IRIS_COLORS = {
    "brown": "#785641",
    "hazel": "#947342",
    "gray": "#737879",
    "blue": "#577c8a",
    "green": "#687c54",
}

_BROW_COLORS = {
    "dark_chestnut": ("#382625", "#835c4b"),
    "black": ("#292325", "#6c5753"),
    "chestnut": ("#513027", "#956748"),
    "light_brown": ("#604935", "#a0815e"),
    "blond": ("#735536", "#bc9a66"),
    "red": ("#6a392d", "#ae6850"),
}

def _choice(look, field):
    return look.get(field, next(iter(OPTIONS[field])))


def _eye_width_transform(look, head, spacing):
    width = look.get("eye_width", "standard")
    if width == "standard":
        return None
    if width == "narrow":
        return "scale(.81 1)"
    # Limits reserve room for the widest nose root and the fixed fabric openings.
    hood_edge = _EYE_HOOD_CLEARANCE[_choice(look, "eye_spacing")]
    outer = min(26, min(.95 * head.temple_half, hood_edge) - spacing - 2.5)
    inner = min(23.5, spacing - 13.5)
    scale = (inner + outer) / 40.5
    return f"matrix({number(scale)} 0 0 1 {number(21 * scale - outer)} 0)"


def _draw_eye(parent, defs, look, skin, side, center, height, width_transform):
    slope = {"level": 0, "down": -.12, "up": .12}[_choice(look, "eye_tilt")]
    eye_scale = 1.04 if look.get("age") == "child" else 1
    eye = node(parent, "g", transform=f"matrix({side} {number(slope)} 0 {number(eye_scale)} {number(center)} {160 + height})")
    eye_path = partial(path, transform=width_transform)
    shape = _choice(look, "eye_shape")
    women = look.get("cast") == "women"
    curves = _WOMEN_EYE_CURVES if women else _EYE_CURVES
    upper, lower, fold = curves[shape]
    lower_lid = look.get("lower_lid", "standard")
    if lower_lid == "soft":
        lower = _SOFT_LOWER_LIDS[shape]
    aperture = f"M-21 0 {upper} {lower}"
    clip_id = "face-features-eye-left" if side == 1 else "face-features-eye-right"
    clip = node(defs, "clipPath", id=clip_id)
    eye_path(clip, aperture)

    lid = _choice(look, "eyelid")
    old = look.get("age") == "old"
    if lid == "hooded" or old:
        opacity = (".78" if women else ".94") if lid == "hooded" else ".64"
        eye_path(eye, f"M-21 0 C-18 {fold + 2} -9 {fold + 1} -1 {fold} Q12 {fold} 19.5 0Z", skin.shade, opacity=opacity)
    if lid == "crease":
        eye_path(eye, f"M-16 {fold + 7} Q-7 {fold - 2} 4 {fold} Q11 {fold + 1} 15 {fold + 6}", class_="etch", opacity=".86")
    elif lid == "hooded":
        eye_path(eye, f"M-16 {fold + 8} Q-4 {fold - 1} 8 {fold + 2} L13 {fold + 5}", class_="etch", opacity=".72")
    else:
        eye_path(eye, f"M-14 {fold + 6} Q-7 {fold + 1} 5 {fold + 3} L13 {fold + 7}", skin.light, opacity=".65")

    edge = {"soft": "stroke-width:1.5", "defined": "stroke-width:3.35"}.get(
        lower_lid, "stroke-width:2.15" if women else None,
    )
    eye_path(eye, aperture, class_="white", style=edge)
    contents = node(eye, "g", clip_path=f"url(#{clip_id})")
    gaze = {"direct": 0, "left": -3.4, "right": 3.4}[_choice(look, "gaze")]
    iris_transform = f"translate({number(gaze * side)} 0) scale({side} 1)"
    iris_scale = {"standard": "1", "small": ".76", "large": "1.25"}[look.get("iris_size", "standard")]
    if iris_scale != "1":
        iris_transform += f" scale({iris_scale})"
    iris = node(contents, "g", transform=iris_transform)
    path(iris, "M-9.8 0 C-10.4 -7 -6.6 -10.9 0 -11.1 C6.1 -11.2 10.5 -7 10.1 -.3 C10.2 5.9 6.4 11 0 10.8 C-6.1 10.7 -9.7 7.2 -9.8 0Z", _IRIS_COLORS[_choice(look, "iris")], stroke="#352526", stroke_width="1.4")
    path(iris, "M-5.8 -.2C-5.9-3.8-3.5-6 .1-6 3.8-6 6-3.6 6 .1 6 3.9 3.3 6.3-.2 6.2-3.9 6.1-6 3.3-5.8-.2Z", "#2a2020")
    path(iris, "M-4.7-4.1Q-4.4-7.4-1.1-7.6 .9-6.3-.3-3.9-2.9-2-4.7-4.1Z", "#f3e4bd")
    tense = _choice(look, "expression") == "tense"
    upper_weight = "3.7" if tense else ("2.65" if women else "3.15")
    eye_path(eye, f"M-21 0 {upper}", "none", stroke="#2a1d1c", stroke_width=upper_weight, stroke_linecap="round")
    if _choice(look, "inner_fold") == "folded":
        eye_path(eye, "M18.8 -3.8 Q14.2 -3.4 15 1.4 Q16.5 3.2 19.8 .6Z", skin.shade)
        eye_path(eye, "M18.8 -3.8 Q14.2 -3.4 15 1.4", class_="etch")
    lower_crease = {"almond": 13.5, "open": 16.5, "narrow": 10}[shape]
    if old:
        eye_path(eye, f"M-20 8 Q-13 {lower_crease} -5 {lower_crease}", class_="etch", opacity=".76")
    elif lower_lid == "defined":
        eye_path(eye, f"M-15 {lower_crease - 4} Q-6 {lower_crease + 4} 9 {lower_crease - 0.5}", class_="etch", opacity=".72")


def _draw_brow(parent, look, head_geometry, side, center, spacing, eye_height):
    height, weight, (tail, arc, peak, inside, head), tip_scale = brow_geometry(look)
    tilt = .10 if _choice(look, "expression") == "tense" else 0
    brow = node(parent, "g", transform=f"matrix({side} {number(tilt)} 0 1 {number(center)} {number(height + eye_height)})")
    tip = tip_scale * weight
    length = look.get("brow_length", "standard")
    tail_drop = BROW_TAILS[look.get("brow_tail", "standard")]
    outer = {"standard": 22, "short": 16.5, "long": 27}[length]
    if length == "long":
        hood_edge = _EYE_HOOD_CLEARANCE[_choice(look, "eye_spacing")]
        clearance = 1.8 + 1.3 * max(0, tail_drop)
        outer = min(outer, min(.95 * head_geometry.temple_half, hood_edge) - spacing - clearance)
    gap = {"standard": 0, "close": 3.5, "wide": -4.5}[look.get("brow_gap", "standard")]
    inside_tip = 20 + gap
    tail += tail_drop * .55
    tail_end = 3 + tail_drop
    silhouette = (
        f"M{number(-outer)} {tail_end} C{number(-17 * outer / 22)} {tail - tip} -10 {arc - weight} -4 {peak - weight} "
        f"C3 {inside - weight} {number(14 + gap * .6)} {head - weight} {number(inside_tip)} {-1 - tip} "
        f"Q{number(inside_tip + 1)} -1 {number(inside_tip)} {-1 + tip} "
        f"C{number(14 + gap * .6)} {head + weight} 3 {inside + weight} -4 {peak + weight} "
        f"C-10 {arc + weight} {number(-17 * outer / 22)} {tail + tip} {number(-outer)} {tail_end}Z"
    )
    color, light = _BROW_COLORS.get(look.get("hair_color"), _BROW_COLORS["dark_chestnut"])
    gray = look.get("graying")
    if gray == "full":
        color, light = "#5d5754", "#a79a8a"
    elif gray == "mixed":
        light = "#a39686"
    ridge = look.get("brow_shape")
    if ridge == "heavy_ridge":
        path(brow, f"M{number(-outer)} {tail_end - 1} Q-13 -9 -4 {peak - weight - 4} "
             f"Q8 {inside - weight - 4} {number(inside_tip)} -2 Q-4 {peak + 1} {number(-outer)} {tail_end - 1}Z",
             head_geometry.skin.shade, opacity=".64")
    elif ridge == "soft_arch":
        path(brow, f"M{number(-outer)} {tail_end - 1} Q-11 -11 -4 {peak - weight - 4} "
             f"Q5 {inside - weight - 4} {number(inside_tip)} -2 Q-1 {peak} {number(-outer)} {tail_end - 1}Z",
             head_geometry.skin.light, opacity=".75")
    path(brow, silhouette, color)
    path(brow, f"M{number(-14 * outer / 22)} {(tail + arc) / 2} Q-7 {arc - .7} -4 {peak - .6} Q1 {inside - .7} 8 {inside}", "none", stroke=light, stroke_width="1.1", stroke_linecap="round")


def draw_features(parent, defs, look, head):
    eyes = node(parent, "g", data_part="eyes")
    brows = node(parent, "g", data_part="brows")
    nose = node(parent, "g", data_part="nose")
    mouth = node(parent, "g", data_part="mouth")
    spacing = {"balanced": 32.5, "close": 30.5, "wide": 37.5}[_choice(look, "eye_spacing")]
    # У острия века остаётся участок кожи даже в проёме платка на узком лице.
    spacing = min(spacing, head.temple_half - 29)
    eye_height_offset = eye_height(look)
    width_transform = _eye_width_transform(look, head, spacing)
    for side in (1, -1):
        center = 160 - side * spacing
        _draw_eye(eyes, defs, look, head.skin, side, center, eye_height_offset, width_transform)
        _draw_brow(brows, look, head, side, center, spacing, eye_height_offset)
    if look.get("age") == "child":
        nose.set("transform", "translate(160 160) scale(.82 .82) translate(-160 -160)")
        mouth.set("transform", "translate(160 160) scale(.82 .82) translate(-160 -160)")
    draw_nose(nose, defs, look, head.skin)
    draw_mouth(mouth, look, head.skin)
