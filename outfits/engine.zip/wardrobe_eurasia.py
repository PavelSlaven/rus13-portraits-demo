from common import node, number, path


def _steppe_robe(art):
    body, cloth = art.body, art.cloth
    left_neck = number(160 - art.neck - 4)
    right_neck = number(160 + art.neck + 2)
    left_waist = 157 - body.waist
    right_waist = 163 + body.waist
    closure = 172 - body.waist

    path(
        art.front,
        f"M{left_neck} 274 Q128 286 166 304 L{closure} 391 "
        f"Q{left_waist + 19} 346 {left_waist + 14} 306Z",
        cloth.shade,
    )
    path(
        art.front,
        f"M{left_neck} 274 Q135 289 163 301 L156 313 Q130 296 {left_neck} 282Z",
        cloth.deep, class_="edge",
    )
    path(
        art.front,
        f"M{right_neck} 273 Q168 308 149 334 Q{closure + 23} 371 {closure} 394 "
        f"Q{closure + 21} 366 {closure + 30} 355 Q171 320 {number(171 + art.neck)} 277Z",
        "#c3a578", class_="edge",
    )
    path(
        art.front,
        f"M{number(165 + art.neck)} 278 Q169 316 148 342 Q{closure + 20} 377 {closure + 4} 392",
        class_="etch",
    )
    path(
        art.front,
        f"M{closure + 9} 379 q15 1 23 8 M{closure + 6} 385 q12 1 21 7",
        fill="none", stroke=cloth.deep, stroke_width=2.4, stroke_linecap="round",
    )

    if art.hem_y is not None:
        tip = 171 - art.hem_half
        bend = round((408 + art.hem_y) * .5)
        path(art.front, f"M{closure + 2} 406 Q{closure + 5} {bend} {tip} {art.hem_y + 6} "
             f"H{tip - 10} Q{closure - 10} {bend} {closure - 7} 405Z", cloth.shade)

    for fraction in (.14, .29, .43, .57, .72, .86):
        fold = round(left_waist + (right_waist - left_waist) * fraction)
        drift = round((fraction - .5) * 24)
        if art.hem_y is None:
            tip = fold + 2 * drift
            bottom, bend, seam_bottom = 446, 424, 445
        else:
            tip = round(160 + (2 * fraction - 1) * (art.hem_half - 9))
            bottom = art.hem_y + 12
            bend = round((407 + bottom) * .5)
            seam_bottom = art.hem_y + 3 - abs(drift) // 2
        path(
            art.front,
            f"M{fold} 407 Q{fold + drift} {bend} {tip - 6} {bottom} "
            f"H{tip + 1} Q{fold + drift + 4} {bend} {fold + 3} 408Z",
            cloth.light,
        )
        path(
            art.front,
            f"M{fold + 4} 412 Q{fold + drift + 2} {bend + 3} {tip + 4} {seam_bottom}",
            class_="seam",
        )

    path(
        art.waist,
        f"M{left_waist} 387 Q160 399 {right_waist} 386 L{right_waist} 406 "
        f"Q160 420 {left_waist} 407Z",
        cloth.deep, class_="edge",
    )
    for offset in (0, 4, 8, 12):
        path(
            art.waist,
            f"M{left_waist} {391 + offset} Q160 {404 + offset} {right_waist} {390 + offset}",
            fill="none", stroke="#ba9a6f", stroke_width=1.6, stroke_linecap="round",
        )

    sleeve_end = 169 - body.hem
    sleeve_outer = 172 - body.sleeve
    for sleeve in art.sleeves:
        path(
            sleeve,
            f"M{sleeve_outer} 399 Q{sleeve_end - 15} 407 {sleeve_end + 8} 406 "
            f"M{sleeve_outer} 410 Q{sleeve_end - 16} 417 {sleeve_end + 5} 416 "
            f"M{sleeve_outer + 1} 421 Q{sleeve_end - 15} 429 {sleeve_end + 9} 424",
            class_="seam",
        )


def _kariginu(art):
    body, cloth = art.body, art.cloth
    left_neck = number(160 - art.neck)
    right_neck = number(160 + art.neck)
    left_join = 172 - body.shoulder
    right_join = 320 - left_join
    crest = body.shoulder_y
    left_hem = 168 - body.hem
    right_hem = 320 - left_hem
    left_drape = left_join - 7
    right_drape = right_join + 7
    bottom, shoulder_bend, shade_bend = 445, 341, 369
    if art.hem_y is not None:
        left_hem = 160 - art.hem_half
        right_hem = 160 + art.hem_half
        bottom = art.hem_y + 12
        shoulder_bend = round(crest + (bottom - crest) * .42)
        shade_bend = round(crest + (bottom - crest) * .55)

    for sleeve in art.sleeves:
        outer = 160 - body.sleeve
        path(
            sleeve,
            f"M{left_join - 8} {crest + 3} Q{outer + 10} 307 {outer + 10} 330 "
            f"Q{outer + 12} 350 {outer + 24} 369 Q{outer + 18} 343 {outer + 26} 327 "
            f"Q{left_join - 10} 311 {left_join - 8} {crest + 3}Z",
            cloth.light,
        )
        path(
            sleeve,
            f"M{outer + 19} 343 Q{outer + 20} 317 {left_join - 12} {crest + 14} "
            f"M{outer + 23} 373 Q{outer + 11} 356 {outer + 11} 345",
            class_="seam",
        )
        if art.hem_y is not None:
            inner = 160 - body.hem + 11
            path(sleeve, f"M{outer + 15} 376 Q{outer + 28} 421 {inner - 6} 437 "
                 f"Q{outer + 22} 430 {outer + 12} 403Z", cloth.light, opacity=".58")
            path(sleeve, f"M{outer + 9} 415 Q{outer + 31} 437 {inner} 437 "
                 f"M{outer + 22} 388 Q{outer + 32} 411 {inner - 8} 420", class_="seam")

    path(
        art.outer,
        f"M{left_neck} 273 Q{left_join + 11} 276 {left_join} {crest} "
        f"Q{left_drape - 5} {shoulder_bend} {left_hem} {bottom} H{right_hem} "
        f"Q{right_drape + 5} {shoulder_bend} {right_join} {crest} "
        f"Q{right_join - 11} 276 {right_neck} 273 Q160 307 {left_neck} 273Z",
        cloth.base, class_="edge",
    )
    path(
        art.outer,
        f"M{right_join} {crest} Q{right_drape + 5} {shoulder_bend} {right_hem} {bottom} H{right_hem - 25} "
        f"Q{right_drape - 23} {shade_bend} {right_join - 17} 332 Q{right_join - 20} 300 181 295Z",
        cloth.shade,
    )
    path(
        art.outer,
        f"M{left_join + 4} {crest + 9} Q{left_join + 10} 300 136 295 "
        f"Q{left_join + 22} 327 {left_hem + 19} 390 Q{left_join + 2} 376 {left_join + 4} {crest + 9}Z",
        cloth.light,
    )
    path(
        art.outer,
        f"M{left_join + 4} 347 Q{left_join + 16} {shade_bend + 23} {left_hem + 25} {bottom} "
        f"M{right_join - 7} 348 Q{right_join - 6} {shade_bend + 32} {right_hem - 16} {bottom}",
        class_="seam",
    )
    if art.hem_y is not None:
        hem = art.hem_y
        bend = (390 + hem) // 2
        path(art.outer, f"M{left_join + 17} 333 Q128 393 {left_hem + 45} {hem + 4} "
             f"H{left_hem + 36} Q{left_hem + 38} {bend} {left_join + 17} 333Z",
             cloth.light, opacity=".54")
        path(art.outer, f"M177 380 Q180 {bend} {right_hem - 39} {hem + 8} "
             f"H{right_hem - 53} Q175 {bend} 177 380Z", cloth.shade, opacity=".50")
        path(art.outer, f"M131 350q-6 34 -2 55 M179 344q7 24 8 45 M146 394Q142 {bend} 138 {hem - 6} "
             f"M166 438Q162 {bend + 24} 165 {hem + 1}", class_="etch")
        path(art.outer, f"M{left_hem + 5} {hem - 6}Q160 {hem + 12} {right_hem - 5} {hem - 6}",
             class_="seam")

    opening = art.neck + 5
    path(
        art.outer,
        f"M{left_neck} 273 Q160 303 {right_neck} 273 L{number(160 + opening)} 280 "
        f"Q{number(181 + art.neck)} 311 160 310 Q{number(139 - art.neck)} 311 "
        f"{number(160 - opening)} 280Z",
        cloth.deep, class_="edge",
    )
    path(
        art.outer,
        f"M{number(158 - art.neck)} 280 C{number(149 - art.neck)} 310 "
        f"{number(171 + art.neck)} 310 {number(162 + art.neck)} 280",
        fill="none", stroke="#d7be8e", stroke_width=3.2, stroke_linecap="round",
    )
    path(art.outer, "M169 302 q3 9 1 17", class_="seam")

    for direction, join in ((-1, left_join), (1, right_join)):
        for y in (crest + 8, crest + 20, crest + 32):
            out = join + direction * (5 + (y - crest) // 8)
            inside = out - direction * 12
            path(
                art.outer,
                f"M{out} {y} q{direction * -5} 3 {inside - out} 1",
                fill="none", stroke="#ccb084", stroke_width=2.7, stroke_linecap="round",
            )


def _tiraz_robe(art):
    body, cloth = art.body, art.cloth

    for sleeve in art.sleeves:
        shoulder = 160 - body.shoulder
        crest = body.shoulder_y
        stripe = (
            f"M{shoulder - 33} {crest + 2} Q{shoulder - 7} {crest + 12} {shoulder + 15} {crest + 9} "
            f"L{shoulder + 15} {crest + 38} Q{shoulder - 11} {crest + 38} {shoulder - 36} {crest + 28}Z"
        )
        band = node(sleeve, "g", data_part="sleeve-band")
        path(band, stripe, "#d2ae78", class_="edge")
        path(
            band,
            f"M{shoulder - 33} {crest + 9} Q{shoulder - 8} {crest + 20} {shoulder + 15} {crest + 16} "
            f"M{shoulder - 36} {crest + 21} Q{shoulder - 9} {crest + 33} {shoulder + 15} {crest + 30}",
            fill="none", stroke="#7b4b42", stroke_width=2.7, stroke_linecap="round",
        )

    left = number(154 - art.neck)
    right = number(166 + art.neck)
    path(
        art.front,
        f"M{left} 278 Q160 327 {right} 278 L{number(160 + art.neck)} 273 "
        f"Q160 306 {number(160 - art.neck)} 273Z",
        cloth.deep, class_="edge",
    )
    path(
        art.front,
        f"M{left} 280 Q160 323 {right} 280",
        fill="none", stroke=cloth.light, stroke_width=2.3, stroke_linecap="round",
    )
    path(art.front, "M160 302 q-3 20 1 36", class_="seam")


def _full_pellote(art, inner_left, inner_right, left_bridge, right_bridge, left_turn, right_turn):
    front, body, cloth = art.front, art.body, art.cloth
    left, right = 160 - art.hem_half, 160 + art.hem_half
    hem = art.hem_y
    bottom = hem + 13
    bend = (435 + hem) // 2
    left_fold, right_fold = 166 - body.hem, 154 + body.hem
    left_edge = (f"Q{left_turn - 2} 390 {left_fold} 435 "
                 f"Q{left_fold - 12} {bend} {left - 8} {bottom}")
    right_edge = (f"Q{right_turn + 2} 390 {right_fold} 435 "
                  f"Q{right_fold + 12} {bend} {right + 8} {bottom}")
    path(front, f"M{inner_left} 273 Q142 295 160 333 Q178 295 {inner_right} 273 "
         f"Q{number(176 + art.neck)} 275 {right_bridge} 282 "
         f"Q{right_turn} 328 {right_turn} 365 {right_edge} H{left - 8} "
         f"Q{left_fold - 12} {bend} {left_fold} 435 Q{left_turn - 2} 390 {left_turn} 365 "
         f"Q{left_turn} 328 {left_bridge} 282 Q{number(144 - art.neck)} 275 {inner_left} 273Z",
         cloth.base, class_="edge")
    path(front, f"M{right_bridge} 283 Q{right_turn} 328 {right_turn} 365 {right_edge} "
         f"H{right - 24} Q{right_fold - 22} {bend} 170 368 Q176 330 {right_bridge} 283Z", cloth.shade)
    path(front, f"M{left_bridge} 284 Q{left_turn} 332 {left_turn} 365 {left_edge} "
         f"H{left + 24} Q{left_fold + 15} {bend} 152 367 Q149 320 {left_bridge} 284Z", cloth.light)
    path(front, f"M{number(154 - art.neck)} 281 Q142 305 160 339 Q178 305 {number(166 + art.neck)} 281 "
         f"M{number(134 - art.neck)} 285 Q{left_turn + 2} 335 {left_turn + 4} 365 "
         f"Q{left_turn + 3} 390 {left_fold + 5} 435 Q{left_fold - 7} {bend} {left - 3} {bottom} "
         f"M{number(186 + art.neck)} 285 Q{right_turn - 2} 335 {right_turn - 4} 365 "
         f"Q{right_turn - 3} 390 {right_fold - 5} 435 Q{right_fold + 7} {bend} {right + 3} {bottom}",
         "none", stroke="#d3af7e", stroke_width=2.35, stroke_linecap="round")
    path(front, f"M{left_turn + 9} 384 Q{left_turn + 10} 412 {left_fold + 18} 443 "
         f"Q{left_fold + 7} {bend} {left + 21} {hem - 6} "
         f"M{right_turn - 10} 379 Q{right_turn - 8} 411 {right_fold - 24} 443 "
         f"Q{right_fold - 11} {bend} {right - 25} {hem - 8}", class_="seam")
    path(front, f"M148 457 Q145 {bend + 28} {left + 46} {hem - 14} "
         f"M176 476 Q184 {bend + 38} {right - 50} {hem - 8}", class_="etch")


def _pellote(art):
    body, cloth = art.body, art.cloth
    inner_left = number(158 - art.neck)
    inner_right = number(162 + art.neck)
    left_bridge = number(131 - art.neck)
    right_bridge = number(189 + art.neck)
    left_turn = 159 - round(body.waist * .31)
    right_turn = 320 - left_turn
    if art.hem_y is not None:
        _full_pellote(art, inner_left, inner_right, left_bridge, right_bridge, left_turn, right_turn)
        return
    left_hem = 154 - body.hem
    right_hem = 320 - left_hem

    path(
        art.front,
        f"M{inner_left} 273 Q142 295 160 333 Q178 295 {inner_right} 273 "
        f"Q{number(176 + art.neck)} 275 {right_bridge} 282 "
        f"Q{right_turn} 328 {right_turn} 365 Q{right_turn + 2} 390 {right_hem} 441 "
        f"L{right_hem} 447 H{left_hem} V441 Q{left_turn - 2} 390 {left_turn} 365 "
        f"Q{left_turn} 328 {left_bridge} 282 Q{number(144 - art.neck)} 275 {inner_left} 273Z",
        cloth.base, class_="edge",
    )
    path(
        art.front,
        f"M{right_bridge} 283 Q{right_turn} 328 {right_turn} 365 "
        f"Q{right_turn + 3} 398 {right_hem} 441 L{right_hem} 446 H{right_hem - 24} "
        f"Q{right_turn - 16} 407 170 368 Q176 330 {right_bridge} 283Z",
        cloth.shade,
    )
    path(
        art.front,
        f"M{left_bridge} 284 Q{left_turn} 332 {left_turn} 366 Q{left_turn - 1} 398 {left_hem + 6} 441 "
        f"L{left_hem + 21} 441 Q{left_turn + 15} 402 152 367 Q149 320 {left_bridge} 284Z",
        cloth.light,
    )
    path(
        art.front,
        f"M{number(154 - art.neck)} 281 Q142 305 160 339 Q178 305 {number(166 + art.neck)} 281 "
        f"M{number(134 - art.neck)} 285 Q{left_turn + 2} 335 {left_turn + 4} 365 "
        f"Q{left_turn + 3} 390 {left_hem + 5} 442 "
        f"M{number(186 + art.neck)} 285 Q{right_turn - 2} 335 {right_turn - 4} 365 "
        f"Q{right_turn - 3} 390 {right_hem - 5} 442",
        fill="none", stroke="#d3af7e", stroke_width=2.35, stroke_linecap="round",
    )
    path(
        art.front,
        f"M{left_turn + 9} 384 Q{left_turn + 10} 412 {left_hem + 26} 444 "
        f"M{right_turn - 10} 379 Q{right_turn - 8} 411 {right_hem - 32} 444",
        class_="seam",
    )


def _full_tang_skirt(art, left_band, right_band):
    cloth = art.cloth
    hem = art.hem_y
    bottom = hem + 12
    edge = art.body.hem + 5
    left, right = 160 - edge, 160 + edge
    skirt = node(art.front, "g", data_part="tang-skirt")
    path(skirt, f"M{left_band - 2} 349 Q160 361 {right_band + 2} 349 "
         f"L{right + 18} {bottom}H{left - 18}Z", cloth.base)
    path(skirt, f"M{left_band - 2} 351 L{left_band + 22} 361 "
         f"Q{left_band + 15} 488 {left + 20} {bottom}H{left - 20}Z", cloth.shade)
    path(skirt, f"M{right_band - 25} 361 L{right_band + 2} 351 L{right + 20} {bottom}H{right - 32} "
         f"Q{right_band - 39} 493 {right_band - 25} 361Z", cloth.shade)
    for index, x in enumerate(range(110, 217, 16)):
        drift = round((x - 160) * .38)
        path(skirt, f"M{x} 365 Q{x + drift // 2} 502 {x + drift} {hem - 6}",
             "none", stroke=cloth.light if index in (1, 4) else cloth.deep,
             stroke_width=1.65, stroke_linecap="round", opacity=".77")
    path(skirt, f"M{left + 3} {hem - 8}Q160 {hem + 11} {right - 3} {hem - 8}", class_="seam")


def _tang_jacket(art):
    body, cloth = art.body, art.cloth
    left_neck = number(157 - art.neck)
    right_neck = number(163 + art.neck)
    left_slope = 173 - body.shoulder
    right_slope = 147 + body.shoulder
    crest = body.shoulder_y
    left_band = 159 - body.chest
    right_band = 161 + body.chest

    path(
        art.front,
        f"M{left_slope} {crest} L{left_neck} 273 Q160 307 {right_neck} 273 "
        f"L{right_slope} {crest} Q{right_slope + 5} 324 {right_band} 348 "
        f"Q160 367 {left_band} 348 Q{left_slope - 5} 324 {left_slope} {crest}Z",
        cloth.light,
    )
    path(
        art.front,
        f"M{left_neck} 273 Q143 299 160 315 Q177 298 {right_neck} 273 "
        f"L{number(174 + art.neck)} 276 Q183 303 160 335 Q137 308 {number(146 - art.neck)} 276Z",
        "#71515a", class_="edge",
    )
    path(art.front, "M159 330 Q156 341 151 352", class_="seam")

    if art.hem_y is not None:
        _full_tang_skirt(art, left_band, right_band)
    else:
        path(
            art.front,
            f"M{left_band} 349 Q160 361 {right_band} 349 L{right_band + 18} 447 "
            f"H{left_band - 18}Z",
            cloth.shade,
        )
        for x in range(112, 217, 15):
            drift = round((x - 160) / 4)
            path(
                art.front,
                f"M{x} 365 Q{x + drift // 2} 409 {x + drift} 446",
                fill="none", stroke=cloth.light, stroke_width=2.2, stroke_linecap="round",
            )

    path(
        art.waist,
        f"M{left_band} 343 Q160 356 {right_band} 343 "
        f"L{right_band} 360 Q160 373 {left_band} 360Z",
        cloth.base, class_="edge",
    )
    path(
        art.waist,
        f"M{left_band} 347 Q160 360 {right_band} 347 "
        f"M{left_band} 356 Q160 369 {right_band} 356",
        fill="none", stroke=cloth.light, stroke_width=2.1, stroke_linecap="round",
    )

    path(
        art.outer,
        f"M{left_slope} {crest} Q{left_slope + 6} {crest - 8} {left_slope + 15} {crest - 7} "
        f"Q{left_slope + 10} 311 130 342 Q154 389 159 445 H138 "
        f"Q142 397 117 358 Q{left_slope + 2} 323 {left_slope} {crest}Z",
        "#a16157", class_="edge",
    )
    path(
        art.outer,
        f"M{right_slope - 18} {crest - 8} Q{right_slope - 7} {crest - 8} {right_slope} {crest} "
        f"Q{right_slope - 8} 319 195 344 Q179 384 193 445 H173 "
        f"Q156 395 181 344 Q{right_slope - 21} 310 {right_slope - 18} {crest - 8}Z",
        "#8e5754", class_="edge",
    )
    path(
        art.outer,
        f"M{left_slope + 4} {crest + 1} Q{left_slope + 8} 320 122 351 Q149 393 146 444 "
        f"M{right_slope - 5} {crest + 1} Q{right_slope - 14} 320 188 345 Q170 390 187 444",
        fill="none", stroke="#d8ae83", stroke_width=2.6, stroke_linecap="round",
    )
    for x, y in ((133, 357), (141, 376), (147, 396), (151, 417), (153, 435),
                 (186, 355), (180, 374), (179, 394), (181, 414), (186, 433)):
        node(
            art.outer, "circle", cx=x, cy=y, r=2.45, fill="none", stroke="#e4c4a0",
            stroke_width=1.05, stroke_dasharray=".75 2.3", stroke_linecap="round",
        )
        node(art.outer, "circle", cx=x, cy=y, r=.91, fill="#e4c4a0")


def _steppe_dress(art):
    body, cloth = art.body, art.cloth
    inner_left = number(156 - art.neck)
    inner_right = number(164 + art.neck)
    left_waist = 174 - body.waist
    left_hem = 170 - body.hem
    bottom, bend, highlight_bend, highlight_end = 445, 423, 429, 444
    if art.hem_y is not None:
        left_hem = 176 - art.hem_half
        bottom = art.hem_y + 11
        bend = round((398 + bottom) * .5)
        highlight_bend = bend + 6
        highlight_end = art.hem_y + 5

    path(
        art.front,
        f"M{inner_left} 273 Q160 305 {inner_right} 273 "
        f"Q184 316 153 345 Q122 312 {inner_left} 273Z",
        "#d8bc93",
    )
    path(
        art.front,
        f"M{number(150 - art.neck)} 276 Q128 309 158 330 L150 344 "
        f"Q124 317 {inner_left} 273Z",
        cloth.deep, class_="edge",
    )
    path(
        art.front,
        f"M{inner_right} 273 Q180 314 151 343 Q{left_waist + 15} 377 {left_waist} 398 "
        f"Q{left_hem + 6} {bend} {left_hem} {bottom} L{left_hem + 18} {bottom} "
        f"Q{left_waist + 4} {bend - 3} {left_waist + 18} 394 Q158 352 172 335 "
        f"Q192 306 {number(177 + art.neck)} 277Z",
        cloth.shade, class_="edge",
    )
    path(
        art.front,
        f"M{number(171 + art.neck)} 279 Q185 312 156 347 Q{left_waist + 27} 376 {left_waist + 7} 405 "
        f"Q{left_hem + 13} {highlight_bend} {left_hem + 7} {highlight_end}",
        fill="none", stroke="#ce9b78", stroke_width=3.3, stroke_linecap="round",
    )


DRAWERS = {
    "steppe_robe": _steppe_robe,
    "kariginu": _kariginu,
    "tiraz_robe": _tiraz_robe,
    "pellote": _pellote,
    "tang_jacket": _tang_jacket,
    "steppe_dress": _steppe_dress,
}
