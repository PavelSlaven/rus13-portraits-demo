"""Вещи, подходящие для автоматического подбора в игровых сословиях Rus13."""


ESTATES = {
    "dynastic_elite": "Правящая династическая элита",
    "church_elite": "Церковная элита",
    "urban_elite": "Городская элита",
    "landowners": "Знатные землевладельцы",
    "free_commons": "Свободные простолюдины",
    "dependent_commons": "Зависимые простолюдины",
    "unfree_dependents": "Несвободные зависимые",
    "captives": "Пленные и невольники",
    "foreigners": "Иностранцы и чужеземцы",
    "outcasts": "Маргиналы и изгои",
}

_ALL = tuple(ESTATES)
_ELITES = ("dynastic_elite", "church_elite", "urban_elite", "landowners")
_LAY_ELITES = ("dynastic_elite", "urban_elite", "landowners")
_COMFORTABLE = (*_ELITES, "free_commons", "foreigners")
_EVERYDAY = (*_COMFORTABLE, "dependent_commons", "unfree_dependents", "outcasts")
_MILITARY = (*_LAY_ELITES, "foreigners")
_TOOLS = (*_MILITARY, "free_commons", "dependent_commons", "outcasts")
_REGALIA = ("dynastic_elite", "foreigners")
_RURAL_NOBLES = ("dynastic_elite", "landowners")
_FOREIGN = ("foreigners",)


_GROUPS = {
    "outfit": (
        (_ALL, "shirt"),
        (_EVERYDAY, "svita kozukh nw_nov_svita nw_nov_womens_rubakha rus_checked_panel"),
        ((*_COMFORTABLE, "dependent_commons"), "cloak rus_mantle rus_child_svita nw_nov_womens_fur_coat"),
        (_COMFORTABLE, "ryazan_sleeves nw_karel_tunic nw_karel_apron_gown nw_baltic_mens_coat nw_nordic_gored_tunic"),
        ((*_ELITES, "foreigners"), "nw_nov_sofia_tunic naumburg_clasp_mantle"),
        (_MILITARY, "izyaslav_kaftan"),
        (_RURAL_NOBLES, "korzno"),
        ((*_LAY_ELITES, "foreigners"), "rus_gold_yoke_gown rus_gilt_cuff_tunic nw_nov_trimmed_gown nw_baltic_spiral_kuub"),
        (_COMFORTABLE, "nw_nordic_pleated_gown nw_gotland_mens_cloak nw_gotland_womens_mantle"),
        (("free_commons", "dependent_commons", "unfree_dependents", "captives", "foreigners", "outcasts"),
         "norse_child_tunic song_child_jacket"),
        (("church_elite", "urban_elite", "foreigners"), "iraq_school_robe"),
        (("urban_elite", "free_commons", "foreigners"), "pellote steppe_robe tang_jacket"),
        (("urban_elite", "landowners", "foreigners"), "tiraz_robe steppe_dress castile_laced_saya"),
        (_REGALIA, "kariginu castile_royal_pellote yuan_brocade_coat song_round_robe song_pheasant_robe"),
        (("dynastic_elite", "landowners", "foreigners"), "yuan_fur_hunt_robe"),
        (_MILITARY, "armor nw_mail_hauberk nw_mail_surcoat nw_nov_copper_mail nw_nov_scale"),
        (("dynastic_elite", "landowners", "foreigners"), "nw_nov_lamellar nw_gomel_lamellar nw_magdeburg_plate_coat"),
    ),
    "headgear": (
        (_ALL, "cap wrap felt_cap linen_coif child_felt_turnup child_song_soft_cap"),
        (_EVERYDAY, "nw_nov_round_cap nw_baltic_cloth_cap nw_nordic_hood nw_nov_plain_veil nw_nordic_linen_veil"),
        (_COMFORTABLE, "fur_cap nw_nov_seamed_cap shoulder_veil wimple nw_karel_veil nw_nov_povoy"),
        (("church_elite", "urban_elite", "landowners", "foreigners"), "naumburg_linen_cap castile_biretta"),
        ((*_LAY_ELITES, "free_commons", "foreigners"), "rus_wedge_cap rus_diamond_band nw_baltic_spiral_band"),
        (_MILITARY, "temple_rings child_rus_browband nw_nov_rhombic_band"),
        (_REGALIA, "child_castile_cofia child_song_pearl_ribbons eboshi song_futou song_pearl_crown"),
        (("urban_elite", "church_elite", "foreigners"), "wrapped_turban child_iraq_school_wrap"),
        (("dynastic_elite", "urban_elite", "landowners", "foreigners"), "bocca yuan_hunting_cap castile_pleated_tocado"),
        (_FOREIGN, "weimao"),
        (_MILITARY, "helmet tall_helmet nw_iron_hat nw_duboshin_helm nw_pakalniskiai_helm"),
        (("dynastic_elite", "landowners", "foreigners"), "nw_rus_half_mask nw_great_helm nw_gjermundbu_helm"),
        (_REGALIA, "nw_lykovo_helm"),
    ),
    "cloth_color": (
        (_ALL, "natural ochre"),
        (_EVERYDAY, "moss"),
        (_COMFORTABLE, "madder woad"),
    ),
    "accessory": (
        (_EVERYDAY, "pouch"),
        (_COMFORTABLE, "brooch pendant"),
    ),
    "trousers": (
        (_ALL, "straight"),
        (_EVERYDAY, "gathered"),
        (_COMFORTABLE, "hose"),
    ),
    "leg_wraps": (
        (_ALL, "wool"),
        ((*_LAY_ELITES, "free_commons", "foreigners"), "siksala"),
    ),
    "footwear": (
        (_ALL, "porshni"),
        (_EVERYDAY, "novgorod_shoes"),
        (_COMFORTABLE, "novgorod_ankle_boots oslo_strap_shoes"),
        (_MILITARY, "novgorod_high_boots"),
    ),
    "belt": (
        (_ALL, "woven"),
        (_EVERYDAY, "leather"),
        (_MILITARY, "saaremaa"),
    ),
    "belt_pouch": (
        (_EVERYDAY, "drawstring"),
        (_COMFORTABLE, "pleated"),
        (_MILITARY, "novgorod_flap"),
    ),
    "jewelry": (
        (_EVERYDAY, "cross"),
        (_COMFORTABLE, "glass_beads noisy_horse"),
        ((*_ELITES, "foreigners"), "quadrifoil"),
    ),
    "cloak": (
        ((*_COMFORTABLE, "dependent_commons"), "novgorod_mantle siksala_shawl"),
        (_RURAL_NOBLES, "rus_korzno"),
        (_COMFORTABLE, "gotland_open"),
    ),
    "weapon": (
        (_TOOLS, "axe spear eur_west_seax eur_west_bayeux_club eur_west_taull_sling eur_steppe_grigorovo_dart"),
        (_MILITARY, "sheathed_sword sword eur_west_lobed_sword eur_west_oval_sword eur_west_broad_axe "
         "eur_west_francisca eur_west_winged_spear eur_west_scalvian_spear eur_west_drosten_crossbow "
         "eur_steppe_nefedyevo_flail eur_steppe_zagorye_mace eur_steppe_zaryadye_mace eur_steppe_seltso_hammer_axe "
         "eur_steppe_yaroslavl_sabre eur_steppe_vienna_sabre"),
        (_FOREIGN, "eur_steppe_dargavs_double_axe eur_steppe_samanid_khanjar eur_steppe_ghaznavid_feline_mace "
         "eur_east_japan_tachi eur_east_song_crescent_sword eur_east_china_dragon_ring eur_east_liao_guduo "
         "eur_east_chola_chakra eur_east_punjab_gada eur_east_chola_trishula eur_east_bengal_ankusha "
         "eur_east_angkor_spear eur_east_angkor_phkak"),
    ),
    "shield": (
        ((*_MILITARY, "free_commons"), "round kite novgorod_george novgorod_dish"),
        (_MILITARY, "triangular gokstad szczecin_painted lewis"),
        (_RURAL_NOBLES, "yuriev_lion"),
    ),
    "bow": (
        (_TOOLS, "northern_wood"),
        (_MILITARY, "novgorod_composite"),
    ),
    "bow_case": (
        (_MILITARY, "plain_leather bone_trim"),
    ),
    "quiver": (
        (_TOOLS, "birchbark"),
        (_MILITARY, "leather_covered"),
    ),
}

ITEM_ESTATES = {
    field: {item: estates for estates, items in groups for item in items.split()}
    for field, groups in _GROUPS.items()
}


def estates_for_item(field, item):
    if item in {"auto", "none"} or field in {"background", "carry", "shield_carry"}:
        return _ALL
    return ITEM_ESTATES[field][item]
