from common import node, path
from wardrobe_weapon_art import INK, LEATHER, STEEL, STEEL_LIGHT, STEEL_SHADE, hatch, line, shape


_BRONZE = "#a28350"
_BRONZE_SHADE = "#6e5838"
_BRONZE_LIGHT = "#d9b878"
_WOOD = "#89684d"
_WOOD_LIGHT = "#bc976c"


def _draw_tachi(parent):
    shape(parent, "M-6 23C-8 60-16 96-24 131Q-33 178-33 211"
          "Q-25 206-24 195C-17 145-1 106 7 25Z", STEEL, 2.7)
    bevel = "M4 27C-2 94-16 132-25 192L-31 207Q-29 169-20 134C-11 95-5 60-3 27Z"
    path(parent, bevel, STEEL_SHADE)
    hatch(parent, bevel, .33)
    line(parent, "M6 30C.5 87-13 133-21 177Q-25 205-31 208", STEEL_LIGHT, 1.25)
    line(parent, "M4 35Q1 60-3 76M-16 136l-3 15", "#e1dcc8", .65)
    shape(parent, "M-4-23Q0-26 5-22L5 20H-5Z", LEATHER, 1.9, data_part="weapon-grip")
    line(parent, "M-3-19l6 2m-6 5 6 2m-6 5 6 2m-6 5 6 2m-7 5 7 2m-7 5 7 2", "#bf986e", 1)
    shape(parent, "M-5-23Q-3-27 5-25L6-20Q0-20-5-21Z", _BRONZE_SHADE, 1.55)
    shape(parent, "M-13 21Q-8 17 5 18Q14 18 15 21Q12 25 1 26Q-10 26-13 23Z", _BRONZE, 2)
    line(parent, "M-10 21Q0 19 11 21", _BRONZE_LIGHT, .8)


def _draw_song_sword(parent):
    shape(parent, "M-9-17L-31-145Q-32-158-30-173Q-20-163-17-149L10-19Z", STEEL, 2.7)
    flat = "M1-21L-26-154L-30-169Q-22-162-19-148L8-21Z"
    path(parent, flat, STEEL_SHADE)
    hatch(parent, flat, .5)
    line(parent, "M-7-24L-29-146L-30-168M-25-123l2.5 15", STEEL_LIGHT, 1.15)
    line(parent, "M-26-153L.5-24", "#ddd8c4", .72)
    shape(parent, "M-4-19Q0-23 4-19Q2.8-7 3.1 7L5 24Q0 27-5 24L-3.1 7"
          "Q-2.8-7-4-19Z", _BRONZE_SHADE, 1.8, data_part="weapon-grip")
    line(parent, "M-2-13Q3-9-1-6Q-4-3 1-1M-2 10Q4 13-.5 16Q-4 18 2 21", _BRONZE_LIGHT, .95)
    shape(parent, "M-23-31Q-13-24-1-24Q13-24 22-32Q22-21 13-18Q4-14-6-16"
          "Q-21-17-23-31Z", _BRONZE, 2.25)
    line(parent, "M-20-26Q0-15 19-27M-12-20q3-3 5 1m10 0q2-4 6-2", _BRONZE_LIGHT, .85)
    shape(parent, "M-7 24Q0 22 7 23L8 28Q1 31-8 29Z", _BRONZE, 1.65)


def _draw_dragon_ring_sword(parent):
    shape(parent, "M-7 21L-17 185Q-18 200-22 209Q-13 206-10 193L7 22Z", STEEL, 2.6)
    flat = "M4 25L-11 193Q-13 203-19 207L-14 182-1 25Z"
    path(parent, flat, STEEL_SHADE)
    hatch(parent, flat, .52)
    line(parent, "M-5 26l-9 150m-.5 7-3 16", STEEL_LIGHT, 1.2)
    shape(parent, "M-4-24Q0-26 4-24Q2.9-7 3.1 6L4.5 20H-4.5L-3.1 6"
          "Q-2.9-7-4-24Z", "#694b3a", 1.8, data_part="weapon-grip")
    line(parent, "M-3-17l5-2m-4.5 8 4.5-2m-4 9 4-2m-4 9 4-2m-4.5 9 5-2m-5.5 9 6-2", "#bd9973", .85)
    shape(parent, "M-9 18Q0 17 9 19L10 23Q1 26-10 23Z", _BRONZE_SHADE, 2)
    rim = "M-5-23C-17-26-20-43-12-51Q-8-56 0-56Q9-56 13-50C20-40 15-26 5-23Z"
    opening = ("M-8-48Q-11-45-11-42Q-9.8-44.6-8.3-44.6Q-7.1-44.3-7.2-43.3"
               "Q-5.6-44.2-5-42.2C-2.4-42-2.1-39.6-4.6-38.9Q-5.4-38.6-6.2-39"
               "Q-6.1-37.2-9.6-37.7Q-8.7-31 0-30Q8-30 9.8-37.7Q6.2-37.4 6.4-39"
               "Q5.6-38.6 4.7-38.9C2.1-39.6 2.5-42 5.1-42.2Q5.7-44.2 7.3-43.3"
               "Q7.2-44.3 8.4-44.6Q10.1-44.6 11-42Q11-49 2-50Q-5-51-8-48Z")
    path(parent, rim + opening, _BRONZE, fill_rule="evenodd")
    line(parent, rim, INK, 1.85)
    line(parent, opening, INK, 1.15)
    line(parent, "M-11-48Q-6-54 2-53Q8-53 11-48M-13-40Q-14-33-8-28M13-40Q14-33 8-28",
         _BRONZE_LIGHT, 1.05)
    line(parent, "M-8-42.6Q-9-41-8.3-39.7M8.1-42.6Q9.1-41 8.4-39.7", _BRONZE_LIGHT, .8)
    node(parent, "circle", cx=-6.7, cy=-41.3, r=.95, fill=INK)
    node(parent, "circle", cx=6.8, cy=-41.3, r=.95, fill=INK)
    line(parent, "M-12-36l2 1m-1 3 3 .5m20-5-2 1m1 3-3 .5", _BRONZE_SHADE, 1.15)


def _draw_liao_guduo(parent):
    shape(parent, "M-12-106L-7-107L7 48Q6 52 2 51L-5 20Z", STEEL_SHADE, 1.9,
          data_part="weapon-grip")
    line(parent, "M-10-101L-1-10M1 14l3 32", STEEL_LIGHT, 1)
    head = node(parent, "g", transform="translate(1 20)")
    shape(head, "M-13-124C-22-132-23-150-18-160Q-16-165-13-166"
          "Q-6-164-2-155C4-142-1-128-8-124Z", STEEL, 2.4)
    shade = "M-12-163C-4-156 1-141-7-127Q-3-146-12-163Z"
    path(head, shade, STEEL_SHADE)
    hatch(head, shade, .65)
    line(head, "M-15-162Q-22-146-15-130M-10-161Q-5-143-10-128", STEEL_LIGHT, 1.7)
    line(head, "M-13-162Q-14-153-14-147Q-14-136-11-127M-8-160Q-1-144-7-129", STEEL_SHADE, 1.4)


def _draw_chakra(parent):
    circle = ("M-31-60Q-26-64-21-64Q-18-75-12-76Q-15-70-14-64"
              "Q2-61 6-46Q12-49 14-54Q14-42 7-38Q7-23-3-15"
              "Q-1-10 4-11Q-2-6-12-10Q-27-6-36-17Q-42-24-41-34"
              "Q-41-43-39-46Q-45-52-37-60Q-39-54-34-54Z")
    shape(parent, circle, _BRONZE, 2.2)
    shade = "M-39-30Q-29-13-8-20Q1-24 5-35Q7-23-5-14Q-15-6-28-12Q-39-17-39-30Z"
    path(parent, shade, _BRONZE_SHADE)
    hatch(parent, shade, .58)
    node(parent, "ellipse", cx=-17, cy=-37, rx=15, ry=18, fill="#8c724a", stroke=_BRONZE_LIGHT, stroke_width=1.05)
    node(parent, "ellipse", cx=-17, cy=-37, rx=7.1, ry=8, fill=_BRONZE_SHADE, stroke=INK, stroke_width=1)
    line(parent, "M-34-51l10 8m11 14 9 10m-12-44-.5 17m0 17-.2 15m-20-20 12-2"
         "m16-1 11-1m-3-16-11 11m-10 13-10 9M-21-38q1-5 4-4", _BRONZE_LIGHT, .95)
    shape(parent, "M-13-16Q-8-18-4-19L5 8Q1 12-5 10Z", _BRONZE, 1.8, data_part="weapon-grip")
    line(parent, "M-9-15L.5 7", _BRONZE_LIGHT, 1)


def _draw_gada(parent):
    shape(parent, "M-25-153L-11-155L3.2-9L3.6 8L21 117Q18 125 10 121"
          "L-2.8 12L-3.2-8Z",
          _WOOD, 2.05, data_part="weapon-grip")
    line(parent, "M-21-150L-5-16M-1 17L12 118M-4-33l2 15", _WOOD_LIGHT, 1.15)
    line(parent, "M-15-149L-1-28M3 33l10 74", "#614732", 1)
    head = node(parent, "g", transform="translate(-10 -23) scale(.86 1)")
    shape(head, "M-17-132L-18-141Q-35-145-35-155Q-36-168-14-171Q10-175 20-166"
          "Q33-154 15-145L1-142L1-133Q-7-129-17-132Z", _BRONZE, 2.55)
    shade = ("M-34-154Q-15-144 10-151Q19-153 22-163Q26-157 16-147Q4-141-1-142"
             "L0-134Q-6-131-15-133L-16-141Q-30-145-34-154Z")
    path(head, shade, _BRONZE_SHADE)
    hatch(head, shade, .52)
    line(head, "M-29-162Q-10-175 12-166M-28-160q-3 5 0 10M-21-163q-3 7 0 14"
         "M-13-166q-4 8 0 16M-5-167q-4 7 0 16M4-167q-3 7 0 14M12-165q-3 6-1 11"
         "M-15-140q5 3 14 0M-15-135q7 2 14-1", _BRONZE_LIGHT, 1.15)
    shape(parent, "M-12-37Q-6-40 2-38L3-29Q-4-26-11-27Z", _BRONZE, 1.3)
    line(parent, "M-9-35q5-1 9-1m-9 5q5-1 9-1", _BRONZE_LIGHT, .8)


def _draw_trishula(parent):
    shape(parent, "M-22-198L-16-198L3.1-8L3.3 9L22 157Q21 162 15 161"
          "L-2.9 9L-3.1-8Z",
          _WOOD, 1.95, data_part="weapon-grip")
    line(parent, "M-19-195L-3-15M5 57l8 69m1 10 2 18", _WOOD_LIGHT, 1.15)
    shape(parent, "M-22-191L-24-216Q-44-224-40-246Q-37-257-30-267"
          "Q-30-261-34-251Q-42-229-27-232L-26-240Q-30-251-27-263L-25-278"
          "Q-20-269-22-259Q-18-251-22-240L-22-231Q-12-231-15-246"
          "Q-17-256-16-267Q-9-261-11-247Q-8-227-16-217L-15-193Z",
          STEEL, 2.5)
    shade = ("M-24-272Q-20-255-23-242L-23-230Q-11-230-14-248L-15-262"
             "Q-10-244-14-225L-18-217L-17-194L-20-194L-21-218Q-22-244-24-272Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .55)
    line(parent, "M-34-257Q-44-233-31-226M-26-268Q-28-252-25-239M-21-211l1 16", STEEL_LIGHT, 1)
    shape(parent, "M-23-196L-15-197L-14-190L-22-189Z", _BRONZE, 1.3)


def _draw_ankusha(parent):
    shape(parent, "M-9-70L-4-70L8 52Q6 58 1 55L-4 27Z", _WOOD, 2, data_part="weapon-grip")
    line(parent, "M-7-63L-2-12M1 15l3 31", _WOOD_LIGHT, 1.05)
    shape(parent, "M-11-65L-16-106Q-16-115-13-127Q-7-115-8-108L-7-97"
          "Q5-111 20-105Q34-98 34-86Q28-73 14-73Q26-81 24-90"
          "Q22-100 10-96Q-4-92-3-67Z", STEEL, 2.3)
    shade = ("M-11-120L-8-106L-7-96Q8-110 21-104Q38-91 30-83Q25-77 18-76"
             "Q29-84 25-92Q20-104 6-96Q-6-88-5-70L-8-69Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .45)
    line(parent, "M-12-117l.5 17M-6-93Q5-106 16-104Q27-101 32-89", STEEL_LIGHT, .95)
    shape(parent, "M-12-71L-3-72L-2-65L-11-64Z", _BRONZE, 1.45)


def _draw_angkor_spear(parent):
    shape(parent, "M-35-246L-29-247L28 199Q27 205 22 203Z", _WOOD, 2.1,
          data_part="weapon-grip")
    line(parent, "M-31-237L-24-178M-21-155L-4-20M3 30l11 83m2 15 8 57", _WOOD_LIGHT, 1.15)
    head = node(parent, "g", transform="translate(-10 80)")
    shape(head, "M-26-313L-27-334Q-32-351-30-360L-26-384Q-15-367-14-354"
          "Q-14-345-19-334L-18-315Z", STEEL, 2.4)
    shade = "M-25-379Q-15-363-15-354Q-16-345-21-334L-19-317L-22-316L-25-335Z"
    path(head, shade, STEEL_SHADE)
    hatch(head, shade, .57)
    line(head, "M-27-373Q-30-351-26-339M-25-369L-25-339l2 21", STEEL_LIGHT, 1)
    line(head, "M-25-321l6-.6M-25-317l6-.6", INK, .75)


def _draw_angkor_phkak(parent):
    shape(parent, "M-6-96L1-96L2.9 6Q4 20 6.8 34L22 111Q21 116 14 114"
          "L-.8 34Q-3.3 20-5.65 6Z", _WOOD, 2,
          data_part="weapon-grip")
    line(parent, "M-3-91L-4-16M-2 16Q-.5 24 1.5 34L15.5 108M11 68l4.5 23", _WOOD_LIGHT, 1.1)
    shape(parent, "M-7-86Q-9-107-13-128C-19-153-24-174-36-202"
          "Q-39-209-39-218Q-30-219-22-209C-15-193-14-177-7-161Q-1-149 3-140"
          "Q3-116 2-88Z", STEEL, 2.6)
    shade = ("M-37-216Q-29-216-23-208Q-17-193-13-178L1-144L0-90L-3-90"
             "Q-2-129-10-159Q-18-187-37-216Z")
    path(parent, shade, STEEL_SHADE)
    hatch(parent, shade, .52)
    line(parent, "M-36-214Q-30-195-23-180Q-10-150-8-121l3 29M-20-170l4 10", STEEL_LIGHT, 1.15)
    shape(parent, "M-7-91L2-92L3-85L-7-84Z", _BRONZE_SHADE, 1.6)


WEAPONS = {
    "eur_east_japan_tachi": ("Японский тати", _draw_tachi),
    "eur_east_song_crescent_sword": ("Сунский меч с гардой-полумесяцем", _draw_song_sword),
    "eur_east_china_dragon_ring": ("Китайский меч с кольцом из драконов", _draw_dragon_ring_sword),
    "eur_east_liao_guduo": ("Ляоская булава гудо", _draw_liao_guduo),
    "eur_east_chola_chakra": ("Чакра Вишну", _draw_chakra),
    "eur_east_punjab_gada": ("Панджабская гада", _draw_gada),
    "eur_east_chola_trishula": ("Трезубец Чола", _draw_trishula),
    "eur_east_bengal_ankusha": ("Бенгальский анкуш", _draw_ankusha),
    "eur_east_angkor_spear": ("Копьё из Ангкор-Вата", _draw_angkor_spear),
    "eur_east_angkor_phkak": ("Кхмерский пхкак", _draw_angkor_phkak),
}
