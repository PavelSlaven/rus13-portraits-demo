"""Map the clothing list to selectable SVG layers and material finishes."""

import json
from collections import defaultdict
from pathlib import Path

from clothing_accessory_catalog import REFERENCES as ACCESSORIES
from clothing_garment_catalog import ARTISTIC_MATERIALS as GARMENT_STUDIES
from clothing_garment_catalog import EXTRA_EQUIPMENT as GARMENTS, EXTRA_LABELS as GARMENT_LABELS, REFERENCES as CLOTHES
from clothing_headwear_catalog import REFERENCES as HEADWEAR
from clothing_lower_catalog import EXTRA_EQUIPMENT as LOWER, EXTRA_LABELS as LOWER_LABELS, REFERENCES as LOWER_WEAR
from clothing_materials import MATERIAL_FIELDS, MATERIALS, SLOT_LABELS
import image_equipment


REFERENCE_ROWS = json.loads(Path(__file__).with_name("clothing-reference.json").read_text(encoding="utf-8"))
REFERENCES = {**CLOTHES, **HEADWEAR, **LOWER_WEAR, **ACCESSORIES}
EXTRA_EQUIPMENT = {**GARMENTS, **LOWER}
for slot, options in image_equipment.OPTIONS.items():
    EXTRA_EQUIPMENT[slot] = {**EXTRA_EQUIPMENT.get(slot, {}), **options}
EXTRA_LABELS = {**GARMENT_LABELS, **LOWER_LABELS, **image_equipment.LABELS}

_STUDY_FINISHES = {
    "outfit": ("linen", "wool"), "cloak": ("wool",), "headgear": ("linen", "wool"),
    "trousers": ("linen", "wool"), "leg_wraps": ("wool",), "footwear": ("leather",),
    "belt": ("leather",), "belt_pouch": ("leather",), "accessory": ("bronze",),
    "jewelry": ("bronze",), "apron": ("linen",), "vestment": ("silk",),
    "gloves": ("wool",), "shoe_accessory": ("iron",), "foot_lining": ("linen", "hemp"), "insole": ("felt",),
}
_RELATED_FINISHES = {
    "linen": ("plain_weave",), "wool": ("coarse_wool", "fine_wool"),
    "leather": ("yuft",), "silk": ("brocade",),
}
_STUDY_ROWS = {
    21, 24, 76, 86, 95, 103, 107, 119, 120, 121, 137, 138, 139, 140, 141, 142, 143,
    151, 152, 153, 156, 157, 159, 160, 162, 261, 263, 264, 265, 275, 286, 287, 288,
    290, 291, 292, 293, 296, 297, 299,
}
_STUDY_KEYS = {123: {"plain_weave"}, 154: {"bronze"}}


def finishes(reference, role, *, line=None):
    if role == "trim":
        return tuple((key, True) for key in reference.trim_materials)
    if not reference.materials:
        return tuple((key, False) for key in _STUDY_FINISHES[reference.slot])
    studies = {*GARMENT_STUDIES.get(line, ()), *_STUDY_KEYS.get(line, ())}
    source = tuple((key, line not in _STUDY_ROWS and key not in studies) for key in reference.materials)
    if len(source) != 1:
        return source
    return (*source, *((key, False) for key in _RELATED_FINISHES.get(source[0][0], ())))


def _index_references():
    item_cultures = defaultdict(set)
    item_ages, item_casts = defaultdict(set), defaultdict(set)
    material_choices = defaultdict(lambda: defaultdict(dict))
    for row in REFERENCE_ROWS:
        for reference in REFERENCES[row["line"]]:
            key = reference.slot, reference.item
            item_cultures[key].update(row["cultures"])
            item_ages[key].add(reference.age)
            item_casts[key].add(reference.cast)
            for role in ("base", "trim"):
                suffix = "_trim" if role == "trim" else ""
                choices = material_choices[f"{reference.slot}{suffix}_material"][reference.item]
                for finish, supplied in finishes(reference, role, line=row["line"]):
                    choices[finish] = choices.get(finish, False) or supplied
    return ({key: tuple(sorted(value)) for key, value in item_cultures.items()}, item_ages, item_casts,
            {field: dict(items) for field, items in material_choices.items() if any(items.values())})


REFERENCE_CULTURES, REFERENCE_AGES, REFERENCE_CASTS, MATERIAL_CHOICES = _index_references()
REFERENCE_CULTURES.update(image_equipment.CULTURES)
REFERENCE_AGES.update(image_equipment.AGES)
REFERENCE_CASTS.update(image_equipment.CASTS)
for field, choices in image_equipment.MATERIALS.items():
    if field in MATERIAL_FIELDS:
        MATERIAL_CHOICES.setdefault(field, {}).update(choices)
MATERIAL_OPTIONS = {
    field: {key: material.label for key, material in MATERIALS.items()
            if any(key in choices for choices in items.values())}
    for field, items in MATERIAL_CHOICES.items()
}
MATERIAL_LABELS = {
    field: f"{SLOT_LABELS[slot]} · {'отделка' if role == 'trim' else 'материал'}"
    for field, (slot, role) in MATERIAL_FIELDS.items() if field in MATERIAL_OPTIONS
}


def validate_materials(equipment):
    for field, items in MATERIAL_CHOICES.items():
        material = equipment.get(field)
        if material in {None, "auto"}:
            continue
        slot, _ = MATERIAL_FIELDS[field]
        if material not in items.get(equipment.get(slot), {}):
            raise ValueError(f"{MATERIAL_LABELS[field]} «{MATERIALS[material].label}» недоступен для выбранной вещи.")


def default_materials(equipment, manual_items):
    """Render newly added pieces in their catalogued material by default."""
    result = dict(equipment)
    for field, items in MATERIAL_CHOICES.items():
        slot, _ = MATERIAL_FIELDS[field]
        item = equipment.get(slot)
        if field not in result and (slot, item) in manual_items and items.get(item):
            result[field] = next(iter(items[item]))
    return result
