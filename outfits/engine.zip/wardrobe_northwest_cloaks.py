from common import node, number, path


OPTIONS = {
    "cloak": {
        "none": "Без плаща",
        "novgorod_mantle": "Новгородский мятель",
        "rus_korzno": "Корзно с застёжкой на плече",
        "siksala_shawl": "Плечевая накидка Сиксаля",
        "gotland_open": "Распашная накидка Готланда",
        "child_wool_cape": "Детский шерстяной плащ",
        "travel_wool_cloak": "Дорожная накидка из плотной шерсти",
        "travel_blanket": "Дорожное покрывало на плечах",
        "campaign_cloak": "Воинский походный плащ",
        "luda": "Луда",
        "votola": "Вотола поверх свиты",
        "rus_monk_mantle": "Монашеская мантия",
        "western_ring_cloak": "Западный плащ на кольцевой застёжке",
    },
}
LABELS = {"cloak": "Плащ или накидка"}
COVERAGE = {
    "novgorod_mantle": "Полы закрывают грудь, пояс, сумку и кисти.",
    "rus_korzno": "Пола прикрывает середину груди и часть пояса. Сумка и одна кисть видны на открытом боку.",
    "siksala_shawl": "Накидка прикрывает грудь. Пояс, сумка и кисти видны.",
    "gotland_open": "В разрезе видны грудь, середина пояса и сумка, боковые полы прикрывают кисти.",
    "child_wool_cape": "Накидка закрывает плечи и грудь до пояса.",
    "travel_wool_cloak": "Плотные полы закрывают грудь, пояс и кисти.",
    "travel_blanket": "Покрывало закрывает плечо и половину груди. Другой рукав и часть пояса видны.",
    "campaign_cloak": "Плащ перекинут через плечо. Доспех, пояс и кисти видны.",
    "luda": "Длинный плащ закрывает грудь, пояс и кисти.",
    "votola": "Безрукавный плащ прикрывает спину и бока. Свита и пояс видны в разрезе.",
    "rus_monk_mantle": "Длинная мантия закрывает грудь, пояс и кисти.",
    "western_ring_cloak": "Кольцо удерживает плащ на груди. Одна рука и часть пояса видны.",
}


def _cloth_layer(parent, style, contour, color, *, material=False):
    garment = node(parent, "g", data_part="cloak", data_style=style,
                   data_material_slot="cloak" if material else None)
    clip = f"cloak-{style}-clip"
    rule = "evenodd" if style == "votola" else None
    path(node(garment, "clipPath", id=clip), contour, clip_rule=rule)
    path(garment, contour, color, class_="edge", fill_rule=rule,
         data_material_surface="base" if material else None)
    return garment, node(garment, "g", clip_path=f"url(#{clip})")


def _stroke(parent, contour, color, width):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round")


def _novgorod_mantle(parent, body, neck, style):
    nl, nr = number(160 - neck), number(160 + neck)
    sl, sr = 155 - body.shoulder, 165 + body.shoulder
    left, right = max(8, 150 - body.sleeve), min(312, 170 + body.sleeve)
    hl, hr = 136 - body.hem, 181 + body.hem
    y = body.shoulder_y
    contour = (
        f"M{nl} 273C{number(146 - neck)} 271 {sl + 15} {y - 13} {sl + 2} {y - 2}"
        f"C{left - 4} {y + 5} {left - 2} 350 {left + 4} 407"
        f"C{left - 2} 469 {hl - 16} 530 {hl} 581"
        f"Q{hl + 20} 596 {hl + 47} 590Q141 606 178 595"
        f"Q{hr - 29} 607 {hr} 574C{hr + 13} 528 {right + 4} 456 {right - 2} 408"
        f"C{right + 2} 350 {right + 4} {y + 5} {sr - 2} {y - 2}"
        f"C{sr - 15} {y - 13} {number(174 + neck)} 271 {nr} 273"
        f"Q173 299 151 296Q139 290 {nl} 273Z"
    )
    _, cloth = _cloth_layer(parent, style, contour, "#875244")
    path(cloth, f"M{sl + 7} {y + 6}Q{left + 15} 388 {hl + 15} 475"
         f"Q{hl + 2} 549 {hl + 22} 598L{hl - 25} 597L{left - 14} 393Q{left} 314 {sl + 7} {y + 6}Z"
         f"M{sr - 1} {y + 10}Q{right - 35} 373 {right - 26} 455"
         f"Q{hr - 21} 527 {hr - 33} 594L{hr + 9} 594Q{right + 10} 441 {right + 2} 357Z",
         "#694038")
    path(cloth, f"M{nl} 277Q131 307 141 348C153 409 99 511 {hl + 52} 595"
         f"Q125 526 152 451C176 382 164 340 149 301Z",
         "#653831")
    path(cloth, f"M{nr} 277Q172 311 168 349C172 398 155 451 149 511"
         f"Q142 554 153 601L181 600C158 541 173 493 185 427Q198 336 {nr} 277Z"
         f"M{sl + 22} 304Q{left + 37} 350 {left + 35} 421"
         f"Q{left + 30} 474 {hl + 32} 518Q{hl + 39} 459 {left + 51} 412Q{left + 49} 351 {sl + 22} 304Z"
         f"M{sr - 22} 306Q{sr + 4} 351 {hr - 33} 398Q{hr - 49} 453 {hr - 38} 506"
         f"Q{hr - 57} 464 {hr - 54} 413Q{sr - 18} 350 {sr - 22} 306Z", "#a86d53")
    path(cloth, f"M{left + 14} 364Q{left + 26} 387 {hl + 14} 447"
         f"L{hl + 8} 519Q{left + 5} 464 {left + 14} 364Z"
         f"M{hr - 7} 426Q{hr + 4} 483 {hr - 7} 531L{hr - 20} 579"
         f"Q{hr - 11} 520 {hr - 7} 426Z", "url(#ink-lines)", opacity=".47")
    opening = f"M{nl} 274Q135 298 146 334C170 428 108 504 {hl + 51} 591"
    _stroke(cloth, opening, "#4b302c", 4.8)
    _stroke(cloth, f"M{nl} 281Q139 303 149 334C174 428 115 505 {hl + 56} 594",
            "#bd8563", 1.35)
    path(cloth, f"M{left + 25} 364Q{left + 18} 397 {left + 20} 419"
         f"M{hl + 29} 470Q{hl + 23} 511 {hl + 27} 533"
         f"M{hr - 39} 419Q{hr - 50} 455 {hr - 43} 477M175 502Q167 541 175 571",
         class_="seam")
    path(cloth, f"M{left + 13} 402l-1 13m6-7-1 12M{hl + 23} 552q0 10 3 18"
         f"M{hr - 18} 544l-5 16m10-13-4 13M159 526q-2 14-2 21", class_="etch")
    hem = (f"M{hl - 7} 566Q{hl + 16} 585 {hl + 47} 581Q141 596 178 586"
           f"Q{hr - 29} 597 {hr + 2} 565")
    _stroke(cloth, hem, "#523631", 3)
    _stroke(cloth, f"M{hl - 6} 571Q{hl + 16} 590 {hl + 46} 586Q141 601 178 591"
            f"Q{hr - 29} 602 {hr + 2} 570", "#ba8061", 1.35)


def _rus_korzno(parent, body, neck, style, *, lined=False):
    nl, nr = number(160 - neck), number(160 + neck)
    x, y = 172 - body.shoulder, body.shoulder_y + 10
    sl, crest = 160 - body.shoulder, body.shoulder_y
    sr, right = 168 + body.shoulder, min(311, 175 + body.sleeve)
    hr = 181 + body.hem
    opening = (
        f"M{x - 6} {y - 2}C{x + 18} {y + 2} 143 329 150 369"
        "C160 412 148 460 155 497Q155 531 176 550"
    )
    contour = (
        f"{opening}Q201 567 216 584Q{hr - 21} 592 {hr} 573"
        f"C{hr + 8} 532 {right + 2} 464 {right - 3} 407"
        f"C{right + 2} 349 {sr + 27} {crest + 10} {sr + 2} {crest - 2}"
        f"C{sr - 12} {crest - 16} {float(nr) + 14} 270 {nr} 273Q166 296 {nl} 273"
        f"C{float(nl) - 13} 273 {sl + 12} {crest - 11} {sl - 2} {crest}"
        f"Q{sl - 5} {crest + 10} {x - 6} {y - 2}Z"
    )
    base, shade, light = ("#3d5478", "#263b5a", "#647d9b") if lined else ("#75444d", "#563642", "#a56a64")
    _, cloth = _cloth_layer(parent, style, contour, base, material=lined)
    path(cloth, f"M{x} {y}C153 309 207 326 225 370Q263 437 {hr - 24} 588"
         f"L{hr + 11} 588Q{right - 10} 447 {right - 5} 402Q{sr - 7} 331 {x} {y}Z",
         shade, data_material_surface="shade" if lined else None)
    path(cloth, f"M{x + 5} {y + 3}C153 319 187 356 192 410"
         "Q194 490 218 553Q197 528 188 492Q179 471 181 419"
         f"Q174 349 {x + 5} {y + 3}Z"
         f"M{nr} 281Q{sr - 17} {y - 12} {sr + 4} {y + 20}"
         f"Q{sr - 29} 318 {x + 19} {y + 2}Q155 312 {nr} 281Z"
         f"M{sr - 3} 338Q{right - 23} 391 {right - 29} 440Q{hr - 14} 476 {hr - 11} 518"
         f"Q{hr - 28} 487 {right - 45} 445Q{right - 34} 379 {sr - 3} 338Z",
         light, data_material_surface="light" if lined else None)
    path(cloth, f"M{x + 23} {y + 11}Q173 338 183 371Q186 400 185 430"
         "Q179 403 175 381Q166 348 138 333Z"
         f"M{hr - 30} 505Q{hr - 20} 535 {hr - 24} 568L{hr - 33} 581"
         f"Q{hr - 25} 550 {hr - 30} 505Z", "url(#ink-lines)", opacity=".5")
    path(cloth, f"M{x + 12} {y + 5}C148 320 197 350 209 382Q225 423 221 468"
         "M190 440Q189 478 204 508"
         f"M{sr + 2} 346Q{right - 26} 377 {right - 28} 401"
         f"M{hr - 17} 488Q{hr - 11} 514 {hr - 14} 546", class_="seam")
    path(cloth, f"M{x + 18} {y + 11}l15 8m-12-2 10 5M202 384q4 11 5 19"
         f"M{hr - 25} 537l1 15m5-19 1 16M211 515l6 13", class_="etch")

    border = f"{opening}Q201 567 216 584Q{hr - 21} 592 {hr} 573"
    path(cloth, border, "none", stroke="#ae795b", stroke_width=17 if lined else 13, stroke_linecap="round",
         stroke_linejoin="round", data_material_surface="trim" if lined else None)
    path(cloth, border, "none", stroke="#68413f", stroke_width=4.1, stroke_linecap="round",
         stroke_linejoin="round", data_material_surface="trim-shade" if lined else None)
    path(cloth, border, "none", stroke="#e0af76", stroke_width=9.6,
         stroke_dasharray="1.2 5.2", stroke_linecap="butt", opacity=".72",
         data_material_surface="trim-light" if lined else None)

    clasp = node(cloth, "g", data_part="cloak-clasp",
                 transform=f"translate({x + 10} {y - 7}) rotate(-29)")
    node(clasp, "ellipse", rx=11.2, ry=8.4, fill="#c79e65", stroke="#322320", stroke_width=2.5)
    node(clasp, "ellipse", rx=7.3, ry=5.1, fill="#8a6447", stroke="#ead098", stroke_width=.95)
    path(clasp, "M0 -4.8Q.8 -1.2 4.9 0Q.8 1.2 0 4.8Q-.8 1.2-4.9 0Q-.8-1.2 0-4.8Z",
         "#e6be86")
    _stroke(clasp, "M-9 1Q-8-4-4-5.7M5 5.4l3-2", "#eed1a2", 1.05)


def _siksala_shawl(parent, body, neck, style):
    nl, nr = number(160 - neck), number(160 + neck)
    sl, sr = 158 - body.shoulder, 162 + body.shoulder
    left, right = max(15, 159 - body.sleeve), min(305, 161 + body.sleeve)
    y = body.shoulder_y
    contour = (
        f"M{nl} 273Q{sl + 17} 275 {sl} {y - 1}"
        f"Q{left + 8} 305 {left} 342Q{sl + 1} 350 {sl + 21} 354"
        f"Q132 377 153 371Q180 385 212 382Q{sr - 1} 371 {right} 347"
        f"Q{right - 9} 310 {sr} {y + 1}Q{sr - 19} 278 {nr} 273"
        f"Q176 296 152 295Q137 286 {nl} 273Z"
    )
    _, cloth = _cloth_layer(parent, style, contour, "#948065")
    path(cloth, f"M{sl + 1} 286Q90 308 121 319Q151 332 189 335"
         f"Q{sr - 4} 343 {right - 10} 321L{right + 5} 344Q{sr - 3} 368 211 377"
         f"Q151 362 116 343Q{sl - 14} 328 {left} 339Z", "#65574b")
    path(cloth, f"M{nl} 273Q143 298 160 301Q{sr - 31} 304 {sr - 3} {y + 3}"
         f"Q{sr - 29} 323 191 324Q125 326 {sl + 9} 302Z", "#b19b7c")

    # The crossed yarn bands follow the bend across the shoulders and down the chest.
    for x in range(10, 326, 23):
        drift = (x - 160) // 7
        warp = f"M{x - drift} 267Q{x} 317 {x + drift} 387"
        _stroke(cloth, warp, "#4e5655", 6.6)
        _stroke(cloth, f"M{x - drift + 5} 268Q{x + 5} 317 {x + drift + 5} 389",
                "#c0a784", 1.15)
    for offset in range(-21, 81, 18):
        cross = f"M{left - 14} {283 + offset}Q146 {324 + offset} 199 {321 + offset}Q260 {322 + offset} 320 {285 + offset}"
        _stroke(cloth, cross, "#73433e", 6.1)
        _stroke(cloth,
                f"M{left - 14} {287 + offset}Q146 {328 + offset} 199 {325 + offset}Q260 {326 + offset} 320 {289 + offset}",
                "#bd9b73", 1.1)

    fold = f"M{nl} 280C128 308 147 323 177 336Q199 346 {right - 12} 348"
    path(cloth, f"{fold}Q219 366 178 349C143 334 126 306 {nl} 280Z", "#4f3e37", opacity=".52")
    path(cloth, fold, class_="seam")
    path(cloth, f"M{sl + 3} 308Q{sl + 9} 326 108 340m19 2 9 10"
         f"M{sr + 3} 313Q{sr + 11} 324 {sr + 14} 333M191 354l11 3", class_="etch")
    hem = (f"M{left - 4} 338Q{sl + 1} 345 {sl + 21} 350Q132 373 153 367"
           f"Q180 381 212 378Q{sr - 1} 367 {right + 1} 342")
    _stroke(cloth, hem, "#51403a", 4.4)
    path(cloth, hem, "none", stroke="#c6aa82", stroke_width=1.15, stroke_dasharray="2 3.3")


def _gotland_open(parent, body, neck, style):
    nl, nr = number(160 - neck), number(160 + neck)
    sl, sr = 154 - body.shoulder, 166 + body.shoulder
    left, right = max(9, 150 - body.sleeve), min(312, 170 + body.sleeve)
    il, ir = 131 - body.waist // 3, 189 + body.waist // 3
    hl, hr = 143 - body.hem, 177 + body.hem
    y = body.shoulder_y
    inner_left = (f"M{nl} 273C127 304 {il + 9} 335 {il + 2} 373"
                  f"C{il - 7} 416 {il - 4} 473 {il - 15} 513"
                  f"Q{il - 24} 571 {il - 8} 597")
    inner_right = (f"M{nr} 273Q{ir - 1} 312 {ir + 2} 365"
                   f"C{ir + 3} 404 {ir - 5} 462 {ir + 14} 504"
                   f"Q{ir + 27} 551 {ir + 11} 611")
    contour = (
        f"{inner_left}Q{hl + 15} 607 {hl} 585"
        f"C{left + 9} 544 {left - 2} 472 {left + 5} 411"
        f"Q{left + 4} 330 {sl} {y + 7}Q{sl + 33} 279 {nl} 273Z"
        f" {inner_right}Q{hr - 32} 618 {hr} 590"
        f"C{right - 6} 550 {right + 2} 479 {right - 5} 411"
        f"Q{right - 4} 332 {sr} {y + 7}Q{sr - 33} 279 {nr} 273Z"
    )
    _, cloth = _cloth_layer(parent, style, contour, "#606c64")
    path(cloth, f"M{nl} 275Q{il + 2} 319 {il - 8} 378C{il - 21} 458 {il - 12} 513 {il - 23} 550"
         f"Q{il - 29} 578 {il - 13} 602L{il + 2} 608V324Z"
         f"M{nr} 275Q{ir + 23} 339 {ir + 15} 390C{ir + 13} 444 {ir + 11} 481 {ir + 27} 518"
         f"Q{ir + 39} 571 {ir + 20} 615L{ir + 4} 622L{ir - 11} 325Z", "#404b47")
    path(cloth, f"M{sl + 7} {y + 8}Q{left + 25} 354 {left + 31} 435"
         f"Q{left + 28} 509 {hl + 17} 590Q{hl + 4} 576 {hl} 559"
         f"Q{left + 17} 513 {left + 17} 429Q{left + 15} 358 {sl + 7} {y + 8}Z"
         f"M{sr - 8} {y + 8}Q{right - 20} 353 {right - 26} 435"
         f"Q{right - 18} 520 {hr - 8} 580Q{hr - 19} 595 {hr - 28} 600"
         f"Q{right - 36} 535 {right - 39} 438Q{right - 36} 372 {sr - 8} {y + 8}Z", "#899488")
    path(cloth, f"M{left + 5} 360Q{left + 20} 459 {left + 16} 503Q{hl + 7} 546 {hl + 5} 563"
         f"L{hl - 13} 567L{left - 2} 488Z"
         f"M{right - 9} 431Q{right + 3} 509 {right - 24} 555L{hr - 2} 540"
         f"Q{right - 24} 483 {right - 9} 431Z", "url(#ink-lines)", opacity=".46")
    for edge in (inner_left, inner_right):
        _stroke(cloth, edge, "#9a9b79", 8.5)
        _stroke(cloth, edge, "#3f4540", 4.25)
    path(cloth, f"M{sl + 4} 327Q{left + 20} 366 {left + 24} 405"
         f"M{left + 32} 446Q{left + 28} 509 {hl + 16} 546"
         f"M{il - 22} 488Q{il - 21} 511 {il - 26} 531"
         f"M{sr - 3} 324Q{right - 22} 367 {right - 24} 398"
         f"M{right - 37} 444Q{right - 33} 510 {hr - 19} 549"
         f"M{ir + 36} 553Q{ir + 39} 576 {ir + 32} 590", class_="seam")
    path(cloth, f"M{left + 14} 411v16m7-12v13m7 92 4 15"
         f"M{right - 17} 426l1 15m5-22 1 18M{hr - 14} 550q2 11-3 22", class_="etch")
    _stroke(cloth, f"M{hl - 3} 575Q{hl + 15} 598 {il - 8} 589"
            f"M{ir + 11} 603Q{hr - 32} 611 {hr + 3} 580", "#434941", 2.8)


_REFERENCE_CLOAK_COLORS = {
    "child_wool_cape": ("#8b615c", "#594445", "#b38a7f"),
    "travel_wool_cloak": ("#6b715f", "#484d43", "#929888"),
    "travel_blanket": ("#a1876a", "#6b5c53", "#cab092"),
    "campaign_cloak": ("#646b77", "#404956", "#89949d"),
    "luda": ("#92594d", "#5a3933", "#bd7e66"),
    "votola": ("#a29173", "#6f6354", "#c3b796"),
    "rus_monk_mantle": ("#494749", "#323036", "#6d6966"),
    "western_ring_cloak": ("#5d6c73", "#3e4652", "#8b9699"),
}


def _cloak_closed(body, left_neck, right_neck, style):
    hem = {"child_wool_cape": 397, "travel_wool_cloak": 613, "luda": 573, "rus_monk_mantle": 667}[style]
    short = style == "child_wool_cape"
    monk = style == "rus_monk_mantle"
    sl, sr = 160 - body.shoulder, 160 + body.shoulder
    left, right = max(8, 149 - body.sleeve), min(312, 171 + body.sleeve)
    width = min(137, body.hem + (16 if short else 29 if monk else 23))
    hleft, hright = 160 - width, 160 + width
    y = body.shoulder_y
    bend = (hem + 354) // 2
    # The neck carries the cloth; the shoulder crest changes with the underlying cut.
    contour = (f"M{left_neck} 273C{float(left_neck) - 13} 273 {sl + 12} {y - 11} {sl - 2} {y + 1}"
               f"C{sl - 24} {y + 17} {left + 8} 326 {left + 4} 355"
               f"C{left - 1} 396 {hleft + 10} {bend} {hleft} {hem - 9}"
               f"Q{hleft + 15} {hem + 2} {hleft + 32} {hem - 1}"
               f"Q{hleft + 52} {hem + 9} 158 {hem + 4}Q{hright - 48} {hem + 12} {hright - 29} {hem - 1}"
               f"Q{hright - 12} {hem + 3} {hright} {hem - 9}"
               f"C{hright - 10} {bend} {right + 1} 396 {right - 4} 355"
               f"C{right - 8} 326 {sr + 24} {y + 17} {sr + 2} {y + 1}"
               f"C{sr - 12} {y - 11} {float(right_neck) + 13} 273 {right_neck} 273"
               f"Q160 302 {left_neck} 273Z")
    opening = {
        "child_wool_cape": f"M{left_neck} 274Q149 297 148 314Q141 354 151 {hem + 3}",
        "travel_wool_cloak": f"M{left_neck} 275Q148 295 161 331C177 402 150 448 149 489Q142 554 151 {hem + 3}",
        "luda": f"M{right_neck} 277Q172 298 180 329C193 380 180 431 182 472Q178 534 187 {hem + 3}",
        "rus_monk_mantle": f"M{left_neck} 274Q145 298 154 324C159 406 155 469 156 516Q152 597 157 {hem + 4}",
    }[style]
    hemline = (f"M{hleft + 2} {hem - 16}Q{hleft + 18} {hem - 5} {hleft + 32} {hem - 8}"
               f"Q{hleft + 52} {hem + 2} 158 {hem - 3}Q{hright - 48} {hem + 5} {hright - 29} {hem - 8}"
               f"Q{hright - 12} {hem - 4} {hright - 2} {hem - 16}")
    return contour, opening, hemline, hem, hleft, hright


def _cloak_asymmetric(body, left_neck, right_neck, style):
    sl, sr = 160 - body.shoulder, 160 + body.shoulder
    left, right = max(8, 152 - body.sleeve), min(312, 168 + body.sleeve)
    y = body.shoulder_y
    shoulder_left = (f"C{float(left_neck) - 12} 273 {sl + 11} {y - 10} {sl - 2} {y + 1}"
                     f"C{sl - 25} {y + 20} {left + 5} 330 {left + 4} 356")
    shoulder_right = (f"C{right - 5} 330 {sr + 25} {y + 20} {sr + 2} {y + 1}"
                      f"C{sr - 11} {y - 10} {float(right_neck) + 12} 273 {right_neck} 273")
    if style == "travel_blanket":
        hem = 555
        hleft, hright = 137, min(302, 179 + body.hem)
        fold = (f"M{sl + 4} {y + 12}Q113 310 146 310C169 334 153 383 145 426"
                f"Q135 492 {hleft} {hem - 2}")
        contour = (f"M{left_neck} 273{shoulder_left}Q{sl + 11} 338 {sl + 35} 322Q132 316 146 310"
                   f"C169 334 153 383 145 426Q135 492 {hleft} {hem - 2}"
                   f"Q173 {hem + 10} 197 {hem - 2}Q{hright - 19} {hem + 2} {hright} {hem - 16}"
                   f"C{hright + 8} 499 {right + 1} 425 {right - 4} 356{shoulder_right}"
                   f"Q160 299 {left_neck} 273Z")
        hemline = (f"M{hleft + 1} {hem - 11}Q173 {hem + 1} 197 {hem - 11}"
                   f"Q{hright - 19} {hem - 7} {hright - 1} {hem - 25}")
    elif style == "votola":
        hem = 593
        hleft, hright = max(16, 146 - body.hem), min(304, 174 + body.hem)
        il, ir = 118, 202
        fold = (f"M{left_neck} 276Q130 307 126 348C118 420 121 496 {il} {hem - 3}"
                f"M{right_neck} 276Q190 307 194 348C202 420 199 496 {ir} {hem - 3}")
        contour = (f"M{left_neck} 273{shoulder_left}C{left + 1} 422 {hleft + 7} 508 {hleft} {hem - 14}"
                   f"Q{hleft + 20} {hem + 4} {il} {hem - 3}C121 496 118 420 126 348"
                   f"Q132 321 160 314Q188 321 194 348C202 420 199 496 {ir} {hem - 3}"
                   f"Q{hright - 20} {hem + 4} {hright} {hem - 14}"
                   f"C{hright - 7} 508 {right - 1} 422 {right - 4} 356{shoulder_right}"
                   f"Q160 297 {left_neck} 273Z")
        # Both the surface and its clip subtract the openings around the real cuffs.
        cuff_left, cuff_right = 166 - body.sleeve, 175 - body.hem
        for a, b in ((cuff_left, cuff_right), (320 - cuff_right, 320 - cuff_left)):
            contour += (f"M{a} 397Q{a - 2} 438 {a + 1} 477Q{(a+b)/2} 485 {b - 1} 477"
                        f"Q{b + 1} 435 {b} 394Q{(a+b)/2} 386 {a} 397Z")
        hemline = (f"M{hleft + 2} {hem - 23}Q{hleft + 20} {hem - 6} {il - 1} {hem - 12}"
                   f"M{ir + 1} {hem - 12}Q{hright - 20} {hem - 6} {hright - 2} {hem - 23}")
    elif style == "campaign_cloak":
        hem = 550
        hleft, hright = max(12, 150 - body.hem), 126
        fold = (f"M{right_neck} 275Q180 300 151 318C126 338 107 360 104 398"
                f"Q103 470 {hright} {hem - 4}")
        cuff = 177 - body.hem
        contour = (f"M{left_neck} 273{shoulder_left}C{left - 1} 385 {left + 5} 405 {left + 13} 418"
                   f"Q{cuff - 2} 416 {cuff} 438L{cuff} 477Q{left + 25} 485 {hleft + 8} 495"
                   f"Q{hleft + 3} 516 {hleft} {hem - 16}"
                   f"Q{hleft + 21} {hem + 10} {hright} {hem - 4}Q103 470 104 398"
                   f"C107 360 126 338 151 318Q180 300 {right_neck} 275Q160 295 {left_neck} 273Z")
        hemline = f"M{hleft + 1} {hem - 25}Q{hleft + 22} {hem} {hright - 4} {hem - 13}"
    else:
        hem = 614
        hleft, hright = 160 - body.hem, min(305, 179 + body.hem)
        fold = f"M{left_neck} 275Q153 293 156 316C164 382 153 414 153 459Q149 533 177 {hem - 1}"
        contour = (f"{fold}Q{hright - 25} {hem + 4} {hright} {hem - 22}"
                   f"C{hright + 7} 537 {right + 1} 424 {right - 4} 356{shoulder_right}"
                   f"Q160 307 {left_neck} 275Z")
        hemline = f"M177 {hem - 12}Q{hright - 30} {hem - 6} {hright - 1} {hem - 31}"
    return contour, fold, hemline, hem, hleft, hright


def _reference_cloak(parent, body, neck, style):
    left_neck, right_neck = number(160 - neck), number(160 + neck)
    closed = style in {"child_wool_cape", "travel_wool_cloak", "luda", "rus_monk_mantle"}
    shape = _cloak_closed if closed else _cloak_asymmetric
    contour, fold, hemline, hem, hleft, hright = shape(body, left_neck, right_neck, style)
    base, shade, light = _REFERENCE_CLOAK_COLORS[style]
    garment, cloth = _cloth_layer(parent, style, contour, base, material=True)
    bend = (hem + 340) // 2
    sl, sr = 160 - body.shoulder, 160 + body.shoulder
    y = body.shoulder_y
    # Long narrow ridges give the mantle weight without flattening it into a box.
    count = 9 if style == "rus_monk_mantle" else 6
    for index in range(count):
        t = (index + .5) / count
        start = sl + (sr - sl) * t
        end = hleft + (hright - hleft) * t
        drift = (t - .5) * 9
        top = y + 12 + 25 * (1 - abs(2 * t - 1))
        width = 5 + 5 * abs(2 * t - 1)
        path(cloth, f"M{number(start)} {number(top)}C{number(start + drift)} 373 {number(end - 7)} {bend} {number(end)} {hem + 9}"
             f"L{number(end + width)} {hem + 9}C{number(end + width - 1)} {bend} {number(start + 10)} 362 {number(start)} {number(top)}Z",
             shade, opacity=".74", data_material_surface="shade")
        path(cloth, f"M{number(start + 3)} {number(top + 5)}C{number(start + 13)} 381 {number(end + width + 3)} {bend} {number(end + width + 2)} {hem + 8}"
             f"L{number(end + width + 10)} {hem + 8}C{number(end + width + 8)} {bend} {number(start + 20)} 369 {number(start + 3)} {number(top + 5)}Z",
             light, opacity=".56", data_material_surface="light")
        if index % 2 == 0:
            path(cloth, f"M{number(start + 1)} 370Q{number(end - 3)} {bend} {number(end + 1)} {hem - 15}"
                 f"L{number(end + 5)} {hem - 13}Q{number(end + 5)} {bend} {number(start + 1)} 370Z",
                 "url(#ink-lines)", opacity=".40")
        path(cloth, f"M{number(start + 2)} {number(top + 21)}Q{number(start + drift + 7)} 362 {number((start+end)/2)} {bend - 6}", class_="seam")
    path(cloth, fold, "none", stroke=shade, stroke_width=4.6, data_material_surface="shade")
    path(cloth, hemline, "none", stroke=light, stroke_width=2.2,
         stroke_dasharray="3 2", data_material_surface="light")
    if style in {"travel_blanket", "votola"}:
        # A turned wool edge follows the shoulder rather than cutting across its volume.
        turn = (f"M{left_neck} 278Q{sl + 17} {y - 3} {sl - 1} {y + 17}"
                f"Q{sl + 18} {y + 9} 143 309Q160 319 177 309"
                f"Q{sr - 18} {y + 9} {sr + 1} {y + 17}Q{sr - 17} {y - 3} {right_neck} 278")
        path(cloth, turn, "none", stroke=shade, stroke_width=9, data_material_surface="shade")
        path(cloth, turn, "none", stroke=light, stroke_width=4.5, data_material_surface="light")
    if style == "travel_blanket":
        _stroke(cloth, hemline, "#635c59", 6.2)
        _stroke(cloth, hemline, "#d2b394", 1.55)
        for index in range(20):
            t = index / 19
            x = hleft + (hright - hleft) * t
            edge_y = hem - 1 - 14 * t + 5 * (1 - (2 * t - 1) ** 2)
            path(garment, f"M{number(x)} {number(edge_y - 1)}l1.5 7", "none", stroke="#a78d71", stroke_width=1.4,
                 stroke_linecap="round", data_material_surface="light")
    if style in {"western_ring_cloak", "campaign_cloak", "child_wool_cape", "luda"}:
        x, y = {"western_ring_cloak": (159, 317), "campaign_cloak": (148, 302),
                "child_wool_cape": (152, 314), "luda": (182, 322)}[style]
        clasp = node(cloth, "g", data_part="cloak-clasp", data_material_surface="fixed")
        if style == "western_ring_cloak":
            node(clasp, "circle", cx=x + 5, cy=y, r=8, fill="none", stroke="#45352c", stroke_width=5.2)
            node(clasp, "circle", cx=x + 5, cy=y, r=8, fill="none", stroke="#c3a270", stroke_width=2.6)
            _stroke(clasp, f"M{x - 3} {y + 1}l16 -5", "#dcc298", 1.4)
        else:
            _stroke(clasp, f"M{x - 10} {y}q9-6 20 0", "#3a2f30", 4.5)
            _stroke(clasp, f"M{x - 10} {y - 1}q9-6 20 0", "#b7a385", 1.8)


_DRAWERS = {
    "novgorod_mantle": _novgorod_mantle,
    "siksala_shawl": _siksala_shawl,
    "gotland_open": _gotland_open,
}


def draw_cloak(parent, body, neck, style, *, trim_material=None):
    if style in _REFERENCE_CLOAK_COLORS:
        _reference_cloak(parent, body, neck, style)
    elif style == "rus_korzno":
        _rus_korzno(parent, body, neck, style, lined=bool(trim_material))
    elif style != "none":
        _DRAWERS[style](parent, body, neck, style)
