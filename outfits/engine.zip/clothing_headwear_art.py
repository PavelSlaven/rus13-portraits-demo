from common import node, number, path
from face_shape import _outline_half, make_head


OPTIONS = {
    "rus_soft_wool_cap": "Мягкая шерстяная мужская шапка",
    "rus_mens_winter_fur_cap": "Мужская меховая зимняя шапка",
    "rus_high_fur_cap": "Высокая шапка с меховой опушкой",
    "rus_womens_winter_fur_cap": "Женская зимняя меховая шапка",
    "child_rus_cloth_cap": "Детская мягкая тканевая шапочка",
    "child_rus_winter_fur_cap": "Детская меховая зимняя шапка",
    "rus_povoy_coif": "Повой (нижний чепец)",
    "rus_work_headband": "Льняная рабочая повязка",
    "rus_folded_headband": "Очелье из сложенной ткани",
    "rus_maiden_ribbon": "Девичья налобная лента",
    "rus_monastic_hood": "Монашеский куколь (клобук)",
    "rus_early_mitre": "Архиерейская митра раннего типа",
    "rus_travel_hood": "Дорожный капюшон (куколь)",
    "west_short_cape_hood": "Западный капюшон с короткой пелериной",
}

ADULT_CASTS = {
    **dict.fromkeys((
        "rus_soft_wool_cap", "rus_mens_winter_fur_cap", "rus_high_fur_cap",
        "rus_monastic_hood", "rus_early_mitre", "rus_travel_hood",
    ), "men"),
    **dict.fromkeys((
        "rus_womens_winter_fur_cap", "rus_povoy_coif", "rus_folded_headband", "rus_maiden_ribbon",
    ), "women"),
}

OPEN_CROWNS = {"rus_work_headband", "rus_folded_headband", "rus_maiden_ribbon"}
HAIR_ROOT_HALF = {
    "rus_soft_wool_cap": 75,
    "child_rus_cloth_cap": 73,
    "rus_early_mitre": 72,
}

# A true flag draws the corresponding anatomy or hair. A fitted cap can show
# the hair at the temples while its crown is hidden by the hair reveal clip.
COVERAGE = {
    **dict.fromkeys(OPEN_CROWNS | HAIR_ROOT_HALF.keys(), {"ears": True, "neck": True, "hair": True}),
    **dict.fromkeys((
        "rus_mens_winter_fur_cap", "rus_high_fur_cap", "rus_womens_winter_fur_cap",
        "child_rus_winter_fur_cap", "rus_povoy_coif",
    ), {"ears": False, "neck": True, "hair": False}),
    **dict.fromkeys((
        "rus_monastic_hood", "rus_travel_hood", "west_short_cape_hood",
    ), {"ears": False, "neck": False, "hair": False}),
}


def _surface(parent, d, color, role="base", **attrs):
    return path(parent, d, color, data_material_surface=role, **attrs)


def _seam(parent, d):
    path(parent, d, class_="seam", data_material_surface="fixed")


def draw_soft_wool(parent, look, fit):
    cap = fit.fitted_crown(parent, top=60, clearance=12)
    _surface(cap, "M76 107Q78 82 99 70Q119 58 150 60Q165 64 182 62"
             "Q220 59 241 88Q253 104 240 115Q159 122 80 116Z", "#655b53", class_="edge")
    _surface(cap, "M83 108Q85 85 108 74Q130 62 155 66Q126 75 116 97L109 111Z",
             "#918072", "light")
    _surface(cap, "M178 64Q223 60 241 90Q248 103 238 112L201 115"
             "Q211 89 178 64Z", "#464042", "shade")
    _surface(cap, "M79 105Q122 99 153 106Q183 112 242 102L240 115"
             "Q159 124 81 116Z", "#77695b", class_="edge")
    _seam(cap, "M146 65Q177 69 182 84Q184 93 176 101M91 112Q130 106 156 112Q187 117 228 109")


def draw_child_cloth(parent, look, fit):
    cap = fit.fitted_crown(parent, top=64, clearance=8)
    _surface(cap, "M82 111Q83 90 104 77Q128 62 160 64Q197 63 217 78"
             "Q235 92 238 111Q229 120 221 113Q160 105 99 113Q90 120 82 111Z",
             "#8c6d59", class_="edge")
    _surface(cap, "M87 110Q102 78 153 67Q125 80 126 107L99 110Z", "#b79170", "light")
    _surface(cap, "M170 67Q221 70 233 108L200 107Q204 84 170 67Z", "#654a41", "shade")
    _seam(cap, "M156 66Q145 75 140 104M164 67Q180 79 185 105")
    _surface(cap, "M85 111Q125 101 161 104Q202 103 235 111L232 116"
             "Q186 111 161 111Q120 111 88 116Z", "#c39979", "light", class_="seam")


def _fur_flaps(parent, *, adult, trim=False):
    edge, light, shade = ("trim", "trim-light", "trim-shade") if trim else ("base", "light", "shade")
    tip = 211 if adult else 181
    coat = "#694c3e" if trim else "#7a644c"
    for transform in (None, "translate(320 0) scale(-1 1)"):
        side = node(parent, "g", transform=transform)
        _surface(side, f"M68 108Q82 100 94 107Q95 121 90 137Q87 152 96 {tip - 20}"
                 f"L96 {tip - 11}l-6 4-2 5-7-2-6 4L69 {tip - 6}l-7-1"
                 f"Q58 {tip - 18} 60 156Q56 123 68 108Z", coat, edge, class_="edge")
        _surface(side, f"M66 124Q70 109 85 112Q74 131 75 148Q73 171 77 {tip - 10}"
                 f"L67 {tip - 13}Q63 152 66 124Z", "#ad8a67", light)
        _surface(side, f"M91 119Q83 154 91 {tip - 12}l-7 6Q75 155 91 119Z", "#47352f", shade)
        path(side, f"M69 135l6-9m-6 28 6-9m-5 25 7-7m1 {tip - 178} 5-8",
             class_="etch", data_material_surface="fixed")


def draw_mens_winter_fur(parent, look, fit):
    sides = fit.sides(parent)
    _fur_flaps(sides, adult=True)
    crown = fit.fitted_crown(parent, top=53, clearance=20)
    _surface(crown, "M70 111l1-12 5-4 2-12 8-4 2-9 11-1 7-7 13 1 9-7 13 2 11-5"
             " 13 3 9-4 11 5 13-2 10 7 13 1 7 7 9 2 3 9 8 5 2 10 5 8-8 11"
             "Q163 103 77 120Z", "#7a644c", class_="edge")
    _surface(crown, "M80 101Q94 73 132 66Q154 60 171 65Q142 75 125 98"
             "Q105 96 80 105Z", "#a98b68", "light")
    _surface(crown, "M176 63Q213 66 238 91L246 108Q215 104 191 105"
             "Q203 88 176 63Z", "#4e4035", "shade")
    _surface(crown, "M74 108Q117 96 160 100Q211 97 248 107L245 116"
             "Q164 105 77 120Z", "#65523f", "shade", class_="edge")
    _seam(crown, "M89 104l7-6m7 4l8-7m10 4l9-7m12 6l8-7m16 7l8-7m19 8l7-5m12 5l8-4m10 7l6-3")


def draw_high_fur(parent, look, fit):
    _fur_flaps(fit.sides(parent), adult=True, trim=True)
    cap = fit.fitted_crown(parent, top=36, clearance=36)
    _surface(cap, "M77 107Q82 74 113 54Q137 42 159 36Q187 43 210 55"
             "Q235 74 243 107L227 115H93Z", "#8e3e42", class_="edge")
    _surface(cap, "M86 105Q105 58 151 43Q134 65 127 98Z", "#ba5d52", "light")
    _surface(cap, "M164 43Q206 51 234 92L239 104H193Q186 65 164 43Z", "#592d38", "shade")
    _seam(cap, "M158 42Q132 73 127 104M165 42Q186 72 191 104")
    band = fit.sides(parent)
    _surface(band, "M72 104Q72 95 82 96l5-5 12 2 9-5 13 2 11-4 12 2 15-3 13 2"
             " 13-2 11 4 13-2 10 5 13-1 8 6 8 1 3 13-8 8Q160 107 77 120Z",
             "#694c3e", "trim", class_="edge")
    _surface(band, "M79 106Q122 91 159 91Q191 90 222 96Q176 96 147 103"
             "Q110 101 79 110Z", "#ad8a67", "trim-light")
    _surface(band, "M78 113Q138 101 172 105Q216 106 242 110L239 116Q161 105 80 117Z",
             "#47352f", "trim-shade")
    _seam(band, "M87 112l7-6m11 3l7-5m11 3l8-7m14 6l8-6m16 5l6-4m13 5l7-5m13 6l5-3m15 5l6-4")


def draw_povoy_coif(parent, look, fit):
    cloth = fit.temples(parent)
    brim = fit.brim_y
    top = fit.top_y - 10
    y = number
    _surface(cloth, f"M71 152Q68 {y(top + 15)} 114 {y(top + 6)}Q139 {y(top - 1)} 161 {y(top)}"
             f"Q218 {y(top + 1)} 241 {y(top + 27)}Q252 146 244 162Q240 180 230 191"
             f"Q222 177 227 164Q229 134 218 {y(brim + 4)}"
             f"Q160 {y(brim - 13)} 102 {y(brim + 4)}Q91 137 94 163l4 27Q77 177 71 152Z",
             "#ae896e", class_="edge")
    _surface(cloth, f"M77 144Q88 {y(top + 13)} 152 {y(top + 4)}"
             f"Q117 {y(brim - 30)} 93 {y(brim + 15)}Q81 137 84 165Z", "#d7b897", "light")
    _surface(cloth, f"M178 {y(top + 6)}Q224 {y(top + 11)} 242 140Q246 160 232 183"
             f"Q236 142 214 {y(brim + 2)}Q199 {y(brim - 4)} 178 {y(top + 6)}Z",
             "#80604f", "shade")
    ties = fit.sides(parent)
    _surface(ties, "M81 158Q78 171 80 184l-4 13 11-6 8 6-4-16 4-15Z",
             "#927058", "shade", class_="edge")
    _seam(ties, "M79 135q3-18 15-33m6 1l10-8m8 3l11-7m57 2l12 6m15 5l9 10m14 18l2 21")


def draw_womens_winter_fur(parent, look, fit):
    undercap = node(parent, "g", data_material_surface="fixed")
    draw_povoy_coif(undercap, look, fit)
    cap = fit.fitted_crown(parent, top=48, clearance=23)
    _surface(cap, "M73 101Q81 61 123 52Q158 44 188 50Q230 58 245 103"
             "L234 110Q163 117 85 110Z", "#70566b", class_="edge")
    _surface(cap, "M84 96Q102 57 151 52Q133 69 122 96Z", "#a07c88", "light")
    _surface(cap, "M171 52Q224 55 241 102L196 104Q198 72 171 52Z", "#483b50", "shade")
    _seam(cap, "M158 53Q140 70 138 94M166 53Q186 70 187 93")
    roll = fit.sides(parent)
    _surface(roll, "M68 99l6-6 10 1 9-5 12 1 12-4 12 2 13-3 14 2 14-2 13 3"
             " 12-1 12 4 13-2 10 5 11 1 9 6 1 15-8 6Q212 114 181 120"
             "Q158 125 134 120Q105 116 76 125L66 119Z", "#624843", "trim", class_="edge")
    _surface(roll, "M72 105Q105 94 159 93Q202 91 236 102Q197 99 158 104"
             "Q113 100 73 112Z", "#a18268", "trim-light")
    _surface(roll, "M73 117Q105 107 136 113Q159 119 182 114Q214 108 243 113"
             "L241 119Q214 115 181 121Q158 126 135 121Q103 117 77 122Z", "#42312f", "trim-shade")
    _seam(roll, "M87 111l7-5m12 3l8-5m13 4l9-6m15 8l8-6m15 6l8-6m14 3l8-5m14 6l7-4")


def draw_child_winter_fur(parent, look, fit):
    _fur_flaps(fit.sides(parent), adult=False)
    crown = fit.fitted_crown(parent, top=62, clearance=14)
    _surface(crown, "M75 111l2-12 6-5 4-10 10-5 5-7 12-1 10-5 13-1 11-3 12 3"
             " 12-3 12 3 13 2 10 5 11 1 6 6 10 5 4 10 7 7 1 9-9 9"
             "Q157 109 82 120Z", "#8b7355", class_="edge")
    _surface(crown, "M84 107Q98 76 147 68Q163 65 173 69Q140 77 126 102Z",
             "#bb9e76", "light")
    _surface(crown, "M175 69Q216 70 237 101L239 109Q218 104 191 108Q197 88 175 69Z",
             "#5e4e3d", "shade")
    _surface(crown, "M79 108Q158 97 243 108L236 117Q160 109 84 119Z",
             "#70533f", "shade", class_="edge")
    _seam(crown, "M92 113l5-4m10 3l7-5m11 4l8-5m14 3l7-4m14 5l8-5m17 6l7-4m11 6l6-4m9 5l6-4")


def draw_work_headband(parent, look, fit):
    band = fit.sides(parent)
    _surface(band, "M228 107Q244 101 251 108L263 109L258 116L248 115"
             "L247 126L239 125Q243 117 233 118Z", "#9d8a6d", "shade", class_="edge")
    _surface(band, "M84 112Q119 100 154 99Q200 99 237 106L239 118"
             "Q202 108 158 115Q119 112 86 121Z", "#c5b08d", class_="edge")
    _surface(band, "M88 113Q159 94 234 109L236 112Q160 102 90 117Z", "#e7d5ad", "light")
    _seam(band, "M96 117Q129 110 158 111Q200 106 229 112M239 108q8-2 10 3")


def draw_folded_headband(parent, look, fit):
    band = fit.sides(parent)
    _surface(band, "M82 103Q112 89 159 90Q209 89 238 104L237 118"
             "Q202 110 160 109Q117 110 84 118Z", "#845152", class_="edge")
    _surface(band, "M86 104Q121 92 159 93Q209 92 235 105L234 108"
             "Q197 98 160 99Q119 98 87 108Z", "#b1776b", "light")
    _surface(band, "M86 114Q122 104 160 104Q207 104 236 113L235 117"
             "Q205 109 159 109Q118 109 86 117Z", "#543b44", "shade")
    _seam(band, "M90 110Q125 100 160 101Q207 101 231 110")


def draw_maiden_ribbon(parent, look, fit):
    band = fit.sides(parent)
    _surface(band, "M229 108Q245 101 251 110Q259 113 265 111L261 120"
             "Q251 119 244 114L247 127L240 129Q239 118 231 118Z",
             "#746459", "shade", class_="edge")
    _surface(band, "M86 107Q117 98 160 98Q201 98 235 107L234 115"
             "Q201 105 160 106Q118 105 87 115Z", "#886046", class_="edge")
    _surface(band, "M90 108Q121 100 160 100Q202 100 232 108L231 111"
             "Q200 104 160 103Q123 103 90 111Z", "#d1a678", "light")
    _seam(band, "M98 111Q160 100 222 111M236 110q7-3 9-1")


def _face_opening(look, fit):
    head = make_head(look)
    left = _outline_half(look, head, -1)
    right = _outline_half(look, head, 1)

    def coordinates(side, *points):
        return " ".join(
            f"{number(160 + side * x * 1.055 / fit.x_scale)} {number(y + 2)}" for x, y in points
        )

    brow = fit.brim_y
    x_right = 160 + head.temple_half / fit.x_scale - 1
    x_left = 320 - x_right
    opening = [
        f"M{x_left} {number(brow + 6)}Q160 {number(brow - 11)} {x_right} {number(brow + 6)}",
        f"L{coordinates(1, right[0][-1])}",
    ]
    opening.extend(f"C{coordinates(1, *curve)}" for curve in right[1:])
    for previous, (first, second, _) in reversed(list(zip(left, left[1:]))):
        opening.append(f"C{coordinates(-1, second, first, previous[-1])}")
    opening.append("Z")
    return " ".join(opening)


def draw_monastic_hood(parent, look, fit):
    hood = fit.temples(parent)
    top = fit.top_y - 17
    chin = fit.chin_y
    opening = _face_opening(look, fit)
    _surface(hood, f"M74 157C72 {number(top + 35)} 96 {number(top + 6)} 151 {number(top)}"
             f"Q209 {number(top - 5)} 235 {number(top + 28)}Q252 137 249 173"
             f"Q244 {number(chin - 20)} 263 {number(chin + 65)}Q205 {number(chin + 79)}"
             f" 163 {number(chin + 104)}Q115 {number(chin + 80)} 53 {number(chin + 71)}"
             f"Q72 {number(chin + 10)} 74 157Z {opening}",
             "#48424a", class_="edge", fill_rule="evenodd")
    _surface(hood, f"M80 145Q87 {number(top + 15)} 152 {number(top + 5)}"
             f"Q114 {number(fit.brim_y - 22)} 98 {number(fit.brim_y + 6)}Q84 121 80 145Z",
             "#6c6368", "light")
    _surface(hood, f"M108 {number(chin - 15)}Q124 {number(chin + 11)} 158 {number(chin + 19)}"
             f"Q133 {number(chin + 40)} 119 {number(chin + 79)}L89 {number(chin + 73)}"
             f"Q110 {number(chin + 29)} 108 {number(chin - 15)}Z", "#5e555e", "light")
    _surface(hood, f"M219 {number(chin - 16)}Q219 {number(chin + 18)} 247 {number(chin + 64)}"
             f"Q218 {number(chin + 64)} 180 {number(chin + 93)}Q180 {number(chin + 72)}"
             f" 219 {number(chin - 16)}Z", "#302d36", "shade")
    _seam(hood, opening)
    _seam(hood, f"M104 {number(chin + 13)}Q108 {number(chin + 42)} 96 {number(chin + 67)}"
          f"M149 {number(chin + 26)}Q167 {number(chin + 33)} 188 {number(chin + 24)}")


def draw_travel_hood(parent, look, fit):
    hood = fit.temples(parent)
    top, chin = fit.top_y - 27, fit.chin_y
    opening = _face_opening(look, fit)
    _surface(hood, f"M74 151Q66 {number(top + 23)} 137 {number(top + 8)}"
             f"Q161 {number(top + 6)} 184 {number(top)}Q195 {number(top + 17)} 229 {number(top + 34)}"
             f"Q257 113 247 174Q240 218 264 {number(chin + 38)}L281 {number(chin + 58)}"
             f"Q246 {number(chin + 83)} 166 {number(chin + 81)}Q100 {number(chin + 79)} 42 {number(chin + 55)}"
             f"Q80 222 74 151Z {opening}", "#645e4c", class_="edge", fill_rule="evenodd")
    _surface(hood, f"M82 136Q77 {number(top + 23)} 174 {number(top + 7)}"
             f"Q148 {number(top + 26)} 111 {number(fit.brim_y - 12)}L94 {number(fit.brim_y + 7)}Z",
             "#93866a", "light")
    _surface(hood, f"M80 {number(chin + 13)}Q108 {number(chin + 16)} 132 {number(chin + 8)}"
             f"Q121 {number(chin + 36)} 91 {number(chin + 61)}L62 {number(chin + 53)}Z", "#847960", "light")
    _surface(hood, f"M220 {number(chin - 13)}Q222 {number(chin + 24)} 269 {number(chin + 56)}"
             f"Q256 {number(chin + 63)} 236 {number(chin + 67)}Q212 {number(chin + 45)}"
             f" 210 {number(chin + 5)}Z", "#453f36", "shade")
    _seam(hood, opening)
    _seam(hood, f"M62 {number(chin + 58)}Q156 {number(chin + 91)} 263 {number(chin + 64)}"
          f"M116 {number(chin + 28)}Q144 {number(chin + 42)} 178 {number(chin + 34)}")


def draw_west_short_cape(parent, look, fit):
    hood = fit.temples(parent)
    top, chin = fit.top_y - 14, fit.chin_y
    opening = _face_opening(look, fit)
    _surface(hood, f"M74 159Q65 {number(top + 20)} 133 {number(top + 4)}Q192 {number(top - 8)}"
             f" 227 {number(top + 17)}Q255 {number(top + 48)} 271 {number(top + 47)}"
             f"Q261 {number(top + 63)} 245 {number(top + 61)}Q254 142 246 180"
             f"Q239 230 266 {number(chin + 39)}Q242 {number(chin + 57)} 209 {number(chin + 52)}"
             f"Q179 {number(chin + 57)} 160 {number(chin + 66)}Q141 {number(chin + 57)} 111 {number(chin + 52)}"
             f"Q73 {number(chin + 53)} 52 {number(chin + 37)}Q77 228 74 159Z {opening}",
             "#596a62", class_="edge", fill_rule="evenodd")
    _surface(hood, f"M81 138Q88 {number(top + 17)} 151 {number(top + 5)}"
             f"Q112 {number(top + 25)} 101 {number(fit.brim_y - 8)}L89 {number(fit.brim_y + 4)}Z",
             "#819084", "light")
    _surface(hood, f"M188 {number(top + 3)}Q222 {number(top + 8)} 260 {number(top + 50)}"
             f"L245 {number(top + 57)}Q224 {number(top + 31)} 188 {number(top + 3)}Z", "#3d514e", "shade")
    _surface(hood, f"M208 {number(chin + 1)}Q219 {number(chin + 18)} 252 {number(chin + 40)}"
             f"Q228 {number(chin + 48)} 214 {number(chin + 47)}Q197 {number(chin + 36)}"
             f" 208 {number(chin + 1)}Z", "#3d514e", "shade")
    _seam(hood, opening)
    _seam(hood, f"M160 {number(chin + 13)}V{number(chin + 61)}M66 {number(chin + 37)}"
          f"Q101 {number(chin + 51)} 114 {number(chin + 47)}Q142 {number(chin + 52)} 160 {number(chin + 59)}"
          f"Q188 {number(chin + 49)} 210 {number(chin + 47)}Q233 {number(chin + 51)} 252 {number(chin + 39)}")


def draw_early_mitre(parent, look, fit):
    cap = fit.fitted_crown(parent, top=39, clearance=29)
    _surface(cap, "M82 111Q86 85 99 54Q131 60 159 39Q183 58 220 55"
             "Q232 77 238 110Q201 119 161 116Q112 119 82 111Z", "#b49a77", class_="edge")
    _surface(cap, "M93 105Q100 87 105 63Q130 68 154 47Q132 77 124 109Z", "#ddc3a0", "light")
    _surface(cap, "M169 49Q188 64 215 63Q225 87 232 107L190 111Q183 72 169 49Z",
             "#86705c", "shade")
    _surface(cap, "M88 106Q143 111 154 108L154 48L159 42L166 48L166 108"
             "Q194 111 233 106L235 114Q160 124 85 114Z", "#83534d", "fixed", class_="edge")
    _seam(cap, "M159 52v58M96 111Q159 118 225 111")


# The older drawers have overlapping cloth, edging and jewellery. Annotating
# by their exact paints preserves their existing art when picking one material.
_LEGACY_SURFACES = {
    "fur_cap": {
        "base": ("#873a37",),
        "light": ("#b65b4a",),
        "shade": ("#592a2c",),
        "trim": ("#4b322c",),
        "trim-light": ("#76523e",),
        "trim-shade": ("#362624",),
    },
    "rus_wedge_cap": {
        "base": ("#49665b",),
        "light": ("#738476",),
        "shade": ("#334943",),
        "trim": ("#9b584b",),
        "trim-light": ("#c3896e",),
        "trim-shade": ("#653d37",),
    },
    "nw_nov_seamed_cap": {
        "base": ("#794849",),
        "light": ("#a26659",),
        "shade": ("#593139",),
        "trim": ("#56413a",),
    },
    "rus_diamond_band": {
        "base": ("#9b413c",),
        "light": ("#b45146",),
    },
    "child_rus_browband": {
        "base": ("#834745", "#b87653"),
    },
    "nw_nov_rhombic_band": {
        "base": ("#86544b",),
    },
    "temple_rings": {
        "base": ("#78534e",),
        "light": ("#a77d63",),
    },
    "shoulder_veil": {
        "base": ("#79434c", "#713e46", "#673945", "#69404a"),
        "light": ("#a05b5f", "#8d5057", "#8d4f54"),
        "shade": ("#562f39", "#54313c", "#492e38", "#572f3b"),
    },
}


def _mark_legacy_surfaces(artwork, gear):
    paints = {
        color: role for role, colors in _LEGACY_SURFACES.get(gear, {}).items() for color in colors
    }
    if paints:
        for element in artwork.iter():
            fill = element.get("fill")
            if fill or element.get("stroke"):
                element.set("data-material-surface", paints.get(fill, "fixed"))


def draw_scarf_pin(parent, *, x, y, metal):
    pin = node(parent, "g", transform=f"translate({x} {y}) rotate(-15)", data_part="headscarf-pin")
    if metal == "silver":
        d = ("M-4 4C-10 0-9-7-3-9Q3-10 6-5L8-6 10-2 6 0 3-3"
             "Q1-7-3-5Q-7-3-4 1Q-2 3 0 2L1 0 5 1 4 5Q0 8-4 4Z")
        _surface(pin, d, "#b7aea5", "trim", class_="edge")
        _surface(pin, "M-5-4Q-8 1-2 4Q-6 5-7 1Q-9-3-5-4Z", "#ede8d9", "trim-light")
        _surface(pin, "M-2-7Q2-9 4-5L6-2 0 5-1 4 4-2Q1-7-2-7Z", "#8d827a", "trim-shade")
    else:
        _surface(pin, "M-6-5Q-1-9 2-4Q4-2 0 1L-4 8-6 7-2 0Q-6 1-7-2Z",
                 "#a0774c", "trim", class_="edge")
        _surface(pin, "M-5-4Q-2-7 0-4L-1-2Q-3-4-5-2Z", "#d7ad6f", "trim-light")
        _surface(pin, "M-2 0L-5 7-4 8 0 1Z", "#6c4b35", "trim-shade")


def _draw_shoulder_veil_trim(parent, fit, metal):
    cloth = fit.sides(parent)
    for x, y in ((55, 312), (64, 309), (74, 308), (84, 309), (236, 317), (246, 315), (256, 313), (267, 313)):
        ornament = node(cloth, "g", transform=f"translate({x} {y})", data_part="veil-hem-metal")
        if metal == "tin_lead":
            _surface(ornament, "M-3-1L0-3 3-1 3 3 0 5-3 3Z",
                     "#a8a39a", "trim", stroke="#493e3b", stroke_width=.9)
            _surface(ornament, "M-2-1L0-2 2-1 0 0Z", "#d3cbc1", "trim-light")
        else:
            _surface(ornament, "M-3-2Q0-4 3-2L2 4Q0 6-2 4Z",
                     "#99704e", "trim", stroke="#49382d", stroke_width=.9)
            _surface(ornament, "M-2-1Q0-2 2-1L2 0Q0-1-2 0ZM-1 2H1V3H-1Z", "#d5ac72", "trim-light")


def prepare_legacy_materials(artwork, look, fit):
    trim = look.get("headgear_trim_material")
    if not trim and not look.get("headgear_material"):
        return
    gear = look["headgear"]
    _mark_legacy_surfaces(artwork, gear)
    if gear == "nw_karel_veil" and trim:
        shawl_paints = {"#c4b69a": "#526879", "#e2d4b8": "#7e919b", "#9a8870": "#364a58"}
        for element in artwork.iter():
            fill = element.get("fill")
            if fill in shawl_paints:
                element.set("fill", shawl_paints[fill])
        draw_scarf_pin(fit.sides(artwork), x=239, y=223, metal=trim)
    elif gear == "shoulder_veil" and trim:
        _draw_shoulder_veil_trim(artwork, fit, trim)


DRAWERS = {
    "rus_soft_wool_cap": draw_soft_wool,
    "rus_mens_winter_fur_cap": draw_mens_winter_fur,
    "rus_high_fur_cap": draw_high_fur,
    "rus_womens_winter_fur_cap": draw_womens_winter_fur,
    "child_rus_cloth_cap": draw_child_cloth,
    "child_rus_winter_fur_cap": draw_child_winter_fur,
    "rus_povoy_coif": draw_povoy_coif,
    "rus_work_headband": draw_work_headband,
    "rus_folded_headband": draw_folded_headband,
    "rus_maiden_ribbon": draw_maiden_ribbon,
    "rus_monastic_hood": draw_monastic_hood,
    "rus_early_mitre": draw_early_mitre,
    "rus_travel_hood": draw_travel_hood,
    "west_short_cape_hood": draw_west_short_cape,
}
