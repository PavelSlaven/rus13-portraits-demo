"""Авторские веса для генерации портретов. Исторические частоты не оценивались."""

from collections.abc import Iterable, Mapping


PROFILES = {
    "novgorod": "Новгород · местный набор",
    "east_eurasia": "Восточная Евразия",
    "sub_saharan": "Африка южнее Сахары",
    "free": "Свободный выбор",
}
DEFAULT_PROFILE = "novgorod"
PROFILE_VERSION = "rus13-style-pools-v1"
REGIONAL_HAIRSTYLES = {"steppe_braids", "high_knot"}

# These are drawing variants for Rus13. The surrounding options remain available on both bases.
CAST_TRAITS = {
    "jaw": {"heavy_set": "men", "soft_oval": "women"},
    "chin": {"flat_wide": "men", "small_round": "women"},
    "brow_shape": {"heavy_ridge": "men", "soft_arch": "women"},
}

_CAST_STYLE_WEIGHTS = {
    "men": {
        "jaw": {"round": 3, "tapered": 2, "angular": 4, "heavy_set": 8},
        "chin": {"round": 3, "square": 4, "pointed": 2, "flat_wide": 8},
        "brow_shape": {"arched": 2, "straight": 4, "angular": 3, "heavy_ridge": 12},
    },
    "women": {
        "jaw": {"round": 5, "tapered": 4, "angular": 2, "soft_oval": 10},
        "chin": {"round": 4, "square": 2, "pointed": 3, "small_round": 10},
        "brow_shape": {"arched": 5, "straight": 3, "angular": 2, "soft_arch": 12},
    },
}

_WOMENS_BASE_WEIGHTS = {
    "cheeks": {"medium": 5, "hollow": 2, "full": 4},
    "cheek_relief": {"standard": 4, "soft": 5, "sculpted": 2},
    "jaw": {"round": 6, "tapered": 6, "angular": 2},
    "jaw_width": {"standard": 5, "narrow": 4, "wide": 2},
    "chin": {"round": 5, "square": 2, "pointed": 4},
    "chin_height": {"medium": 5, "short": 4, "long": 2},
    "chin_mark": {"standard": 6, "cleft": 1, "dimple": 2},
    "ear_outset": {"medium": 4, "close": 4, "prominent": 2},
    "neck": {"medium": 5, "narrow": 4, "wide": 2},
    "brow_weight": {"medium": 6, "thin": 5, "thick": 2},
    "brow_height": {"medium": 5, "low": 2, "high": 4},
    "brow_shape": {"arched": 5, "straight": 4, "angular": 2},
    "lower_lid": {"standard": 3, "soft": 3, "defined": 1},
    "nose_length": {"medium": 5, "short": 4, "long": 3},
    "nose_tip": {"round": 5, "defined": 4, "broad": 3},
    "mouth_width": {"medium": 5, "narrow": 3, "wide": 3},
    "mouth_corners": {"standard": 3, "upturned": 2, "downturned": 1},
}

_WEIGHTS = {
    "novgorod": {
        "skin": {"warm": 5, "fair": 5, "olive": 2, "tan": 0, "brown": 0, "deep": 0},
        "hair_color": {"dark_chestnut": 3, "black": 2, "chestnut": 3, "light_brown": 4, "blond": 2, "red": 1},
        "hair_texture": {"straight": 3, "wavy": 3, "curly": 2, "coiled": 1},
        "iris": {"brown": 3, "hazel": 3, "gray": 3, "blue": 3, "green": 2},
        "nose_width": {"medium": 4, "narrow": 3, "wide": 2},
    },
    "east_eurasia": {
        "skin": {"warm": 3, "fair": 1, "olive": 5, "tan": 5, "brown": 2, "deep": 0},
        "hair_color": {"dark_chestnut": 4, "black": 5, "chestnut": 2, "light_brown": 1, "blond": 1, "red": 1},
        "hair_texture": {"straight": 5, "wavy": 3, "curly": 2, "coiled": 1},
        "iris": {"brown": 5, "hazel": 3, "gray": 1, "blue": 1, "green": 1},
        "eye_shape": {"almond": 5, "open": 2, "narrow": 3},
        "eye_tilt": {"level": 4, "up": 4, "down": 2},
        "eyelid": {"crease": 2, "hooded": 3, "smooth": 4},
        "inner_fold": {"open": 2, "folded": 3},
        "nose_width": {"medium": 4, "narrow": 2, "wide": 3},
    },
    "sub_saharan": {
        "skin": {"warm": 0, "fair": 0, "olive": 1, "tan": 3, "brown": 5, "deep": 5},
        "nose_width": {"medium": 3, "narrow": 2, "wide": 4},
        "hair_color": {"dark_chestnut": 4, "black": 5, "chestnut": 2, "light_brown": 1, "blond": 1, "red": 1},
        "hair_texture": {"straight": 1, "wavy": 2, "curly": 4, "coiled": 5},
        "iris": {"brown": 5, "hazel": 3, "gray": 1, "blue": 1, "green": 1},
    },
    "free": {},
}


def weights_for(profile: str, field: str, options: Iterable[str] | Mapping[str, object]) -> dict[str, int]:
    weights = _WEIGHTS[profile].get(field, {})
    if profile != "free" and field == "hair_style":
        weights = {**weights, **dict.fromkeys(REGIONAL_HAIRSTYLES, 0)}
    return {variant: weights.get(variant, 1) for variant in options}


def required_cast(field: str, value: str) -> str | None:
    if field in {"beard", "moustache"} and value != "none":
        return "men"
    return CAST_TRAITS.get(field, {}).get(value)


def weights_for_base(cast: str, field: str, weights: dict[str, int], *, cast_traits=False) -> dict[str, int]:
    preference = _WOMENS_BASE_WEIGHTS.get(field) if cast == "women" else None
    if cast_traits:
        preference = _CAST_STYLE_WEIGHTS[cast].get(field, preference)
    if preference is None:
        return weights
    return {variant: preference.get(variant, weight) if weight else 0 for variant, weight in weights.items()}
