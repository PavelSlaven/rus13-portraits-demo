"""Авторские веса для генерации портретов. Исторические частоты не оценивались."""

from collections.abc import Iterable, Mapping

from facial_hair_growth import GROWTH_OPTIONS
from hairstyle_shapes import ADULT_CASTS, CHILD_CASTS


PROFILES = {
    "novgorod": "Новгород · местный набор",
    "east_eurasia": "Восточная Евразия",
    "sub_saharan": "Африка южнее Сахары",
    "free": "Свободный выбор",
}
DEFAULT_PROFILE = "novgorod"
PROFILE_VERSION = "rus13-style-pools-v1"
REGIONAL_HAIRSTYLES = {"steppe_braids", "high_knot"}
_FITTED_HAIR_PROFILES = {
    "child_rus_crop": "novgorod",
    "child_iberian_curls": "novgorod",
    "child_rus_nape_braid": "novgorod",
    "child_rus_swept_loose": "novgorod",
    "child_song_forelock": "east_eurasia",
    "child_jin_three_knots": "east_eurasia",
    "child_song_twin_buns": "east_eurasia",
    "child_song_three_buns": "east_eurasia",
    "adult_rus_ordered_curls": "novgorod",
    "adult_rus_parted_waves": "novgorod",
    "adult_rus_temple_loops": "novgorod",
    "adult_rus_nape_twist": "novgorod",
    "adult_steppe_long_braids": "east_eurasia",
    "adult_song_high_bun": "east_eurasia",
    "adult_japan_long_hair": "east_eurasia",
    "adult_castile_short_fringe": None,
    "adult_steppe_folded_braids": "east_eurasia",
    "adult_rus_single_braid": "novgorod",
    "adult_rus_temple_braids": "novgorod",
    "adult_castile_shoulder_waves": None,
    "adult_iran_two_braids": None,
    "adult_song_side_buns": "east_eurasia",
    "adult_steppe_rolled_locks": "east_eurasia",
}
_CAST_HAIRSTYLES = {**CHILD_CASTS, **ADULT_CASTS}
_SHORT_HAIRSTYLES = {"short", "ear_length", "close_crop", "temple_locks", "combed_back", "steppe_braids"}

# These are drawing variants for Rus13. The surrounding options remain available on both bases.
CAST_TRAITS = {
    "jaw": {"heavy_set": "men", "soft_oval": "women"},
    "chin": {"flat_wide": "men", "small_round": "women"},
    "brow_shape": {"heavy_ridge": "men", "soft_arch": "women"},
}

_CAST_STYLE_WEIGHTS = {
    "men": {
        "jaw": {"round": 3, "tapered": 2, "angular": 4, "heavy_set": 8},
        "chin": {"round": 3, "square": 4, "pointed": 2, "flat_wide": 8},
        "brow_shape": {"arched": 2, "straight": 4, "angular": 3, "heavy_ridge": 12},
    },
    "women": {
        "jaw": {"round": 5, "tapered": 4, "angular": 2, "soft_oval": 10},
        "chin": {"round": 4, "square": 2, "pointed": 3, "small_round": 10},
        "brow_shape": {"arched": 5, "straight": 3, "angular": 2, "soft_arch": 12},
    },
}

_CHILD_FIXED = {"beard": "none", "moustache": "none", "graying": "none", "hair_density": "thick"}
_CHILD_WEIGHTS = {
    "cheeks": {"medium": 5, "hollow": 1, "full": 6},
    "cheek_relief": {"standard": 5, "soft": 6, "sculpted": 1},
    "jaw": {"round": 7, "tapered": 5, "angular": 2},
    "chin": {"round": 7, "square": 2, "pointed": 3},
    "chin_height": {"medium": 5, "short": 6, "long": 2},
    "nose_length": {"medium": 5, "short": 6, "long": 2},
    "brow_weight": {"medium": 5, "thin": 4, "thick": 2},
    "hairline": {"rounded": 5, "straight": 4, "receding": 1},
}
_CHILD_HAIR_WEIGHTS = {
    "men": {"short": 6, "close_crop": 7, "ear_length": 5, "temple_locks": 3, "combed_back": 2},
    "women": {"ear_length": 4, "long": 5, "braided": 7, "double_braids": 7, "nape_tie": 4, "tied": 3},
}

_WOMENS_BASE_WEIGHTS = {
    "cheeks": {"medium": 5, "hollow": 2, "full": 4},
    "cheek_relief": {"standard": 4, "soft": 5, "sculpted": 2},
    "jaw": {"round": 6, "tapered": 6, "angular": 2},
    "jaw_width": {"standard": 5, "narrow": 4, "wide": 2},
    "chin": {"round": 5, "square": 2, "pointed": 4},
    "chin_height": {"medium": 5, "short": 4, "long": 2},
    "chin_mark": {"standard": 6, "cleft": 1, "dimple": 2},
    "ear_outset": {"medium": 4, "close": 4, "prominent": 2},
    "neck": {"medium": 5, "narrow": 4, "wide": 2},
    "brow_weight": {"medium": 6, "thin": 5, "thick": 2},
    "brow_height": {"medium": 5, "low": 2, "high": 4},
    "brow_shape": {"arched": 5, "straight": 4, "angular": 2},
    "lower_lid": {"standard": 3, "soft": 3, "defined": 1},
    "nose_length": {"medium": 5, "short": 4, "long": 3},
    "nose_tip": {"round": 5, "defined": 4, "broad": 3},
    "mouth_width": {"medium": 5, "narrow": 3, "wide": 3},
    "mouth_corners": {"standard": 3, "upturned": 2, "downturned": 1},
}

_WEIGHTS = {
    "novgorod": {
        "skin": {"warm": 5, "fair": 5, "olive": 2, "tan": 0, "brown": 0, "deep": 0},
        "hair_color": {"dark_chestnut": 3, "black": 2, "chestnut": 3, "light_brown": 4, "blond": 2, "red": 1},
        "hair_texture": {"straight": 3, "wavy": 3, "curly": 2, "coiled": 1},
        "iris": {"brown": 3, "hazel": 3, "gray": 3, "blue": 3, "green": 2},
        "nose_width": {"medium": 4, "narrow": 3, "wide": 2},
    },
    "east_eurasia": {
        "skin": {"warm": 3, "fair": 1, "olive": 5, "tan": 5, "brown": 2, "deep": 0},
        "hair_color": {"dark_chestnut": 4, "black": 5, "chestnut": 2, "light_brown": 1, "blond": 1, "red": 1},
        "hair_texture": {"straight": 5, "wavy": 3, "curly": 2, "coiled": 1},
        "iris": {"brown": 5, "hazel": 3, "gray": 1, "blue": 1, "green": 1},
        "eye_shape": {"almond": 5, "open": 2, "narrow": 3},
        "eye_tilt": {"level": 4, "up": 4, "down": 2},
        "eyelid": {"crease": 2, "hooded": 3, "smooth": 4},
        "inner_fold": {"open": 2, "folded": 3},
        "nose_width": {"medium": 4, "narrow": 2, "wide": 3},
    },
    "sub_saharan": {
        "skin": {"warm": 0, "fair": 0, "olive": 1, "tan": 3, "brown": 5, "deep": 5},
        "nose_width": {"medium": 3, "narrow": 2, "wide": 4},
        "hair_color": {"dark_chestnut": 4, "black": 5, "chestnut": 2, "light_brown": 1, "blond": 1, "red": 1},
        "hair_texture": {"straight": 1, "wavy": 2, "curly": 4, "coiled": 5},
        "iris": {"brown": 5, "hazel": 3, "gray": 1, "blue": 1, "green": 1},
    },
    "free": {},
}


def weights_for(profile: str, field: str, options: Iterable[str] | Mapping[str, object]) -> dict[str, int]:
    weights = _WEIGHTS[profile].get(field, {})
    if field == "hair_style":
        weights = {**weights, "adult_latin_tonsure": 0}
        if profile != "free":
            regional = {style: int(region == profile) for style, region in _FITTED_HAIR_PROFILES.items()}
            weights = {**weights, **dict.fromkeys(REGIONAL_HAIRSTYLES, 0), **regional}
    return {variant: weights.get(variant, 1) for variant in options}


def required_cast(field: str, value: str) -> str | None:
    if field in GROWTH_OPTIONS or (field in {"beard", "moustache"} and value != "none"):
        return "men"
    if field == "hair_style":
        return _CAST_HAIRSTYLES.get(value)
    return CAST_TRAITS.get(field, {}).get(value)


def age_allows(age: str, field: str, value: str) -> bool:
    if field in GROWTH_OPTIONS:
        return age != "child"
    if field == "hair_style" and value in _CAST_HAIRSTYLES:
        return (age == "child") == (value in CHILD_CASTS)
    if age != "child":
        return True
    if field in _CHILD_FIXED:
        return value == _CHILD_FIXED[field]
    return value not in CAST_TRAITS.get(field, {})


def weights_for_child(cast: str, field: str, weights: dict[str, int]) -> dict[str, int]:
    if field == "hair_style":
        preference = {**_CHILD_HAIR_WEIGHTS[cast], **dict.fromkeys(CHILD_CASTS, 5)}
    else:
        preference = _CHILD_WEIGHTS.get(field, {})
    return {variant: preference.get(variant, weight) if weight else 0 for variant, weight in weights.items()}


def grooming_weights(profile, cast, age, field, weights):
    if cast == "women" and field == "hair_style":
        return {style: 0 if style in _SHORT_HAIRSTYLES else weight for style, weight in weights.items()}
    if cast == "women" and field == "hair_density" and "open_crown" in weights:
        return {**weights, "open_crown": 0}
    if profile == "novgorod" and cast == "men" and age in {"adult", "old"} and field in {"beard", "moustache"}:
        return {**weights, "none": 0}
    return weights


def weights_for_base(cast: str, field: str, weights: dict[str, int], *, cast_traits=False) -> dict[str, int]:
    preference = _WOMENS_BASE_WEIGHTS.get(field) if cast == "women" else None
    if cast_traits:
        preference = _CAST_STYLE_WEIGHTS[cast].get(field, preference)
    if preference is None:
        return weights
    return {variant: preference.get(variant, weight) if weight else 0 for variant, weight in weights.items()}
