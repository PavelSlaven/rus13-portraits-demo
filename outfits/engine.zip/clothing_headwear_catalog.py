"""Headwear from the numbered clothing list."""

from clothing_reference_types import ClothingReference


def _headgear(item, materials=(), *, cast=None, age="adult", trim=()):
    return ClothingReference("headgear", item, materials, cast, age, trim_materials=trim)


REFERENCES: dict[int, tuple[ClothingReference, ...]] = {
    68: (
        _headgear("felt_cap", ("felt",), cast="men"),
        _headgear("cap", ("felt",), cast="men"),
    ),
    69: (
        _headgear("child_felt_turnup", ("felt",), age="child"),
        _headgear("nw_nov_round_cap", ("wool",), cast="men"),
        _headgear("rus_wedge_cap", cast="men", trim=("fur",)),
    ),
    70: (_headgear("nw_nov_seamed_cap", ("felt",), cast="men", trim=("fur",)),),
    71: (_headgear("rus_soft_wool_cap", ("wool",), cast="men"),),
    72: (_headgear("rus_mens_winter_fur_cap", ("fur",), cast="men"),),
    73: (
        _headgear("rus_high_fur_cap", cast="men", trim=("fur", "sheepskin")),
        _headgear("fur_cap", cast="men", trim=("fur", "sheepskin")),
    ),
    74: (_headgear("rus_womens_winter_fur_cap", cast="women", trim=("fur",)),),
    75: (_headgear("child_rus_cloth_cap", age="child"),),
    76: (_headgear("child_rus_winter_fur_cap", ("fur",), age="child"),),
    77: (
        _headgear("nw_nov_plain_veil", cast="women"),
        _headgear("wrap", cast="women"),
        _headgear("shoulder_veil", cast="women"),
    ),
    78: (
        _headgear("rus_povoy_coif", cast="women"),
        _headgear("nw_nov_povoy", cast="women"),
    ),
    79: (_headgear("linen_coif", ("plant_fiber",), cast="women"),),
    80: (_headgear("rus_work_headband", ("linen", "plant_fiber")),),
    81: (
        _headgear("rus_folded_headband", cast="women"),
        _headgear("rus_maiden_ribbon", cast="women"),
    ),
    82: (
        _headgear("child_rus_browband", ("leather",), cast="women", age="child"),
        _headgear("nw_nov_rhombic_band", ("leather",), cast="women"),
        _headgear("temple_rings", ("leather",), cast="women"),
    ),
    83: (_headgear("rus_diamond_band", ("wool",), cast="women"),),
    84: (_headgear("rus_monastic_hood", cast="men"),),
    85: (_headgear("rus_early_mitre", cast="men"),),
    86: (_headgear("rus_travel_hood", ("wool",), cast="men"),),
    87: (_headgear("west_short_cape_hood"),),
    269: (_headgear("bocca", cast="women"),),
    270: (_headgear("cap"),),
    271: (_headgear("child_felt_turnup", ("felt",), age="child"),),
    272: (_headgear("felt_cap", ("felt",)),),
    273: (_headgear("fur_cap", trim=("fur",)),),
    274: (_headgear("linen_coif", ("linen",)),),
    275: (_headgear("naumburg_linen_cap", ("linen",), cast="women"),),
    276: (_headgear("nw_baltic_cloth_cap", cast="men"),),
    277: (_headgear("nw_baltic_spiral_band", cast="women"),),
    278: (_headgear("nw_karel_veil", cast="women", trim=("silver",)),),
    279: (_headgear("nw_nordic_hood", ("wool",), cast="men"),),
    280: (_headgear("nw_nordic_linen_veil", ("linen",), cast="women"),),
    281: (_headgear("shoulder_veil", ("wool",), cast="women", trim=("bronze", "tin_lead")),),
    282: (_headgear("wimple", cast="women"),),
    283: (_headgear("wrap", cast="women", trim=("bronze", "silver")),),
    284: (_headgear("yuan_hunting_cap", cast="men"),),
}
