from dataclasses import dataclass
from xml.etree import ElementTree as ET

SVG = "http://www.w3.org/2000/svg"
XLINK = "http://www.w3.org/1999/xlink"
ET.register_namespace("", SVG)
ET.register_namespace("xlink", XLINK)

EYE_HEIGHTS = {"standard": 0, "high": -4, "low": 5}
BROW_HEIGHTS = {"medium": 127.5, "low": 131, "high": 121.5}
BROW_WEIGHTS = {"medium": 2.7, "thin": 1.45, "thick": 4}
BROW_TAILS = {"standard": 0, "lifted": -5, "drooped": 6}
BROW_PROFILES = {
    "arched": (-.5, -4.6, -5, -5.4, -3),
    "straight": (.4, -1.1, -1.3, -1.5, -1),
    "angular": (.1, -2, -6.7, -4.4, -2.7),
}
_WOMEN_BROW_PROFILES = {
    "arched": (-2, -6.8, -7.2, -5.1, -2.1),
    "straight": (-.8, -2.7, -3, -2.5, -1.3),
    "angular": (-.8, -4, -7.8, -4.3, -1.9),
}


@dataclass(frozen=True)
class Skin:
    base: str
    light: str
    shade: str
    blush: str
    lip: str


@dataclass(frozen=True)
class HeadGeometry:
    cheek_half: float
    temple_half: float
    top_y: float
    jaw_half: float
    chin_y: float
    neck_half: float
    skin: Skin


def brow_geometry(look):
    height = BROW_HEIGHTS[look.get("brow_height", "medium")]
    weight = BROW_WEIGHTS[look.get("brow_weight", "medium")]
    shape = look.get("brow_shape", "arched")
    if look.get("cast") == "women":
        return height - 2, weight, _WOMEN_BROW_PROFILES[shape], .44
    return height, weight, BROW_PROFILES[shape], .68


def brow_top(look, *, include_standard=False):
    if not include_standard and look.get("cast") != "women" and all(
        look.get(field, "standard") == "standard"
        for field in ("eye_height", "brow_length", "brow_gap", "brow_tail")
    ):
        return None
    height, weight, (tail, arc, peak, inside, head), tip_scale = brow_geometry(look)
    baseline = height + EYE_HEIGHTS[look.get("eye_height", "standard")]
    tip = weight * tip_scale
    tail_offset = BROW_TAILS[look.get("brow_tail", "standard")]
    tilt = 2.7 if look.get("expression") == "tense" else 0
    return baseline + min(tail + tail_offset * .55 - tip,
                          arc - weight, peak - weight, inside - weight, head - weight,
                          -1 - tip, 3 + tail_offset) - tilt - .6


def tag(name):
    return f"{{{SVG}}}{name}"


def number(value):
    return f"{value:.3f}".rstrip("0").rstrip(".")


def node(parent, name, **attrs):
    attributes = {
        key.rstrip("_").replace("_", "-"): number(value) if isinstance(value, float) else str(value)
        for key, value in attrs.items()
        if value is not None
    }
    return ET.SubElement(parent, tag(name), attributes)


def path(parent, d, fill=None, **attrs):
    return node(parent, "path", d=d, fill=fill, **attrs)


def use(parent, identifier, **attrs):
    element = node(parent, "use", **attrs)
    element.set(f"{{{XLINK}}}href", "#" + identifier)
    return element
