from dataclasses import replace
from xml.etree import ElementTree as ET

from common import node, number, path, tag
from face_shape import _skin
from generate import _draw_figure
from wardrobe import (
    ARMORED_OUTFITS, BODIES, CHILD_BODY_SCALE, FULL_HEMS, HANDHELD_HIDDEN_BY, _body_fit, carried_bow_case, carried_waist_weapon,
    draw_back_equipment, draw_waist_accessories, sleeve_cuff,
)
from wardrobe_northwest_archery import draw_held_bow
from wardrobe_northwest_arms import draw_held_weapon, draw_shield
from wardrobe_northwest_legs import OPTIONS as LOWER_OPTIONS, draw_lower_wear


_REFLECT = "translate(320 0) scale(-1 1)"
_CHILD_LOWER_TRANSFORM = "matrix(1 0 0 .76 0 105.6)"
_GROUND_Y = 731
_CHILD_DRAWING_GROUND_Y = 661
_CHILD_FIGURE_SCALE = .53
_BUNDLED_GOTLAND_DRAPES = {
    "nw_gotland_mens_cloak": "gotland-shoulder-cloak",
    "nw_gotland_womens_mantle": "gotland-open-mantle",
}
_BACKGROUNDS = {"parchment": "umber", "ash": "ash", "rose": "rose"}
_LOWER_WEAR = {
    "nw_nov_svita": ("boot", "trousers"),
    "kozukh": ("boot", "trousers"),
    "nw_nov_sofia_tunic": ("halfboot", "trousers"),
    "nw_baltic_mens_coat": ("shoe", "bindings"),
    "nw_nordic_gored_tunic": ("strap", "hose"),
    "nw_nov_womens_fur_coat": ("halfboot", "trousers"),
    "nw_nordic_pleated_gown": ("strap", "hose"),
    "nw_gotland_mens_cloak": ("strap", "hose"),
    "nw_gotland_womens_mantle": ("strap", "hose"),
    "nw_mail_hauberk": ("halfboot", "hose"),
    "nw_nov_lamellar": ("boot", "trousers"),
    "nw_mail_surcoat": ("halfboot", "hose"),
    "nw_nov_scale": ("boot", "trousers"),
    "nw_nov_copper_mail": ("halfboot", "trousers"),
    "nw_gomel_lamellar": ("boot", "trousers"),
    "nw_magdeburg_plate_coat": ("halfboot", "hose"),
}
_TROUSERS_BY_CUT = {"trousers": "straight", "bindings": "gathered", "hose": "hose"}
_SHOES_BY_CUT = {"shoe": "novgorod_shoes", "strap": "oslo_strap_shoes", "boot": "novgorod_high_boots",
                 "halfboot": "novgorod_ankle_boots"}


def _leg(parent, *, hose, bindings, half, footwear):
    x = 160 - half
    sideline = x + 14 if hose else x
    knee = x + 28 if hose else x + 24
    ankle = {"boot": 644, "halfboot": 678}.get(footwear, 700)
    ankle_mid = round((598 + ankle) / 2)
    cloth = "#5b5950" if hose else "#62574d"
    path(parent, f"M{x - 3} 469 L158 469 Q158 548 143 598 Q135 {ankle_mid} 135 {ankle} H105 "
         f"Q{knee - 17} {ankle_mid + 5} {sideline - 1} 597 Q{x - 5} 548 {x - 3} 469Z", cloth, class_="edge")
    path(parent, f"M{x + 6} 514 Q{x + 19} 546 {knee} 595 Q{knee + 3} {ankle_mid} 131 {ankle - 6} "
         f"H108Q{knee - 13} {ankle_mid - 8} {sideline + 1} 592Z", "#8c7c69", opacity=".53")
    path(parent, f"M{x + 9} 556Q{x + 21} 592 {x + 37} 607 M{x + 12} 605Q{x + 23} 627 {x + 30} 635",
         class_="etch")
    if bindings:
        details = f"M{sideline - 1} 621 Q110 626 139 628L136 699H{sideline + 4}Z"
        path(parent, details, "#8c7555", class_="edge")
        for y in (637, 650, 663, 676, 689):
            path(parent, f"M{sideline + 2} {y}l{132 - sideline} 5", "none", stroke="#55463a", stroke_width=2)
        path(parent, "M136 642q6 21 4 37l6 8-2 5-7-8-6-14", "none", stroke="#b3976d", stroke_width=2.6)
        for x, y in ((141, 683), (144, 689)):
            node(parent, "circle", cx=x, cy=y, r=2.65, fill="#c7a978", stroke="#553c31", stroke_width="1.15")


def _shoe(parent, *, style, x):
    foot = node(parent, "g", transform=f"translate({x} 0)")
    if style in {"boot", "halfboot"}:
        top = 636 if style == "boot" else 669
        path(foot, f"M98 {top}Q116 {top - 5} 139 {top + 3}Q137 677 140 704"
             "L142 724Q123 731 88 728Q75 725 83 714L100 701Q104 677 98 " + str(top) + "Z",
             "#5b4034", class_="edge")
        path(foot, f"M102 {top + 5}Q117 {top} 136 {top + 6}M108 700Q124 701 135 709 "
             "M100 705Q104 710 117 715", "none", stroke="#96745a", stroke_width=2.15)
        path(foot, "M102 699Q108 695 119 697Q117 709 129 722Q99 728 85 722Z", "#72503e")
    else:
        path(foot, "M99 689Q119 683 138 691L142 718Q139 728 120 729H86"
             "Q72 728 77 717Q82 708 99 704Z", "#654939", class_="edge")
        path(foot, "M86 718Q108 706 137 711L139 720Q110 730 83 724Z", "#87624a")
        if style == "strap":
            path(foot, "M102 692Q110 700 136 699L139 704Q117 708 100 700Z", "#b18b65", class_="edge")
            node(foot, "circle", cx=130, cy=703, r=2.3, fill="#d8b986")
        else:
            path(foot, "M101 711L103 700Q115 704 136 707", class_="etch")
    path(foot, "M83 725Q108 731 137 724", class_="seam")


def _hand_edges(body, outfit):
    left, right = sleeve_cuff(body, outfit)
    return left - 1, right + 1


def _hands(parent, body, skin, outfit, *, child=False):
    left, right_edge = _hand_edges(body, outfit)
    if child:
        left, right_edge = (round(160 + (point - 160) * CHILD_BODY_SCALE) for point in (left, right_edge))
    middle = number((left + right_edge) / 2)
    for right in (False, True):
        arm = node(parent, "g", transform=_REFLECT) if right else node(parent, "g")
        path(arm, f"M{left + 3} 441 Q{left + 2} 454 {left + 3} 464 "
             f"Q{left + 5} 474 {middle} 473Q{right_edge + 3} 473 {right_edge + 1} 460 "
             f"L{right_edge - 2} 442Z", skin.base, class_="edge", data_part="hand")
        path(arm, f"M{middle} 458Q{right_edge - 4} 454 {right_edge} 460 M{left + 10} 464q5 4 8 3",
             class_="etch")


def _handheld(equipment, body, skin, *, child, hands=None):
    cloak = equipment.get("cloak", "none")
    weapon = equipment.get("weapon", "none")
    shield = equipment.get("shield", "none")
    bow = equipment.get("bow", "none")
    held = equipment.get("carry") == "held"
    show_bow = held and bow != "none" and cloak not in HANDHELD_HIDDEN_BY["bow"]
    show_weapon = (held and bow == "none" and weapon not in {"none", "sheathed_sword"}
                   and cloak not in HANDHELD_HIDDEN_BY["weapon"])
    show_shield = (shield != "none" and equipment.get("shield_carry") != "back"
                   and cloak not in HANDHELD_HIDDEN_BY["shield"])
    if hands is None and not (show_bow or show_weapon or show_shield):
        return None
    group = ET.Element(tag("g"), {"data-part": "handheld-equipment"})
    content = node(group, "g", transform=_CHILD_LOWER_TRANSFORM) if child else group
    if hands is not None:
        content.append(hands)
    left, right = _hand_edges(body, equipment["outfit"])
    center = (left + right) / 2
    if show_bow:
        draw_held_bow(content, bow, x=center, y=459, skin=skin)
    elif show_weapon:
        draw_held_weapon(content, weapon, x=center, y=459, skin=skin, child=child)
    if show_shield:
        draw_shield(content, shield, x=320 - center, y=459)
    return group


def _mask_for_bundled_drape(root, upper, outfit):
    # These drapes are drawn inside the outfit. Reuse their opaque contours for the waist layer.
    defs = root.find(tag("defs"))
    path_tag = tag("path")
    outer_clip = None
    if outfit == "cloak":
        panels = defs.findall(f"./*[@id='wardrobe-cloak-mask']/{path_tag}")
    else:
        outer_clip = "url(#wardrobe-outer-mask)"
        outer = upper.find(f".//*[@clip-path='{outer_clip}']")
        if outfit == "korzno":
            panels = outer.findall(f"./{path_tag}")[:2]
        elif outfit == "naumburg_clasp_mantle":
            panels = [group.find(f"./{path_tag}") for group in outer.findall("./*[@data-part='mantle-drape']")]
        elif outfit in _BUNDLED_GOTLAND_DRAPES:
            part = _BUNDLED_GOTLAND_DRAPES[outfit]
            panels = [outer.find(f"./*[@data-part='{part}']/{path_tag}")]
        else:
            return
    mask_id = "full-costume-bundled-drape"
    bounds = {"x": 0, "y": 0, "width": root.get("width"), "height": root.get("height")}
    mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse", **bounds)
    node(mask, "rect", fill="white", **bounds)
    clip_frame = node(mask, "g", clip_path="url(#portrait-frame)")
    child_wardrobe = upper.find("./*[@data-part='wardrobe']")
    transform = child_wardrobe.get("transform") if child_wardrobe is not None else None
    cloth = node(clip_frame, "g", transform=transform, clip_path=outer_clip)
    for index, panel in enumerate(panels):
        reflect = _REFLECT if outfit == "naumburg_clasp_mantle" and index == 1 else None
        path(cloth, panel.get("d"), "black", transform=reflect, stroke="black", stroke_width=2)
    return f"url(#{mask_id})"


def full_svg(appearance, equipment, *, title):
    child = appearance["age"] == "child"
    outfit = equipment["outfit"]
    adult_cut = _body_fit(BODIES[appearance["body"]], outfit)
    body = adult_cut
    if child:
        body = replace(body, **{part: round(getattr(body, part) * CHILD_BODY_SCALE)
                                for part in ("waist", "hem", "sleeve")})
    skin = _skin(appearance)
    has_hanging_gear = (
        carried_waist_weapon(equipment) != "none"
        or carried_bow_case(equipment)[0] != "none"
        or equipment.get("quiver", "none") != "none"
    )
    hands = None
    if has_hanging_gear or outfit not in FULL_HEMS:
        # The loose hem sits behind the hands. The cuff and cloak remain over the wrist.
        hands = ET.Element(tag("g"), {"data-part": "hands", "clip-path": "url(#full-costume-hands-clip)"})
        _hands(hands, adult_cut, skin, outfit, child=child)
    handheld = _handheld(equipment, body, skin, child=child, hands=hands)
    root = _draw_figure(appearance, {**equipment, "background": "transparent"}, view="full",
                        title=title, handheld=handheld)
    upper = root.find("./*[@clip-path='url(#portrait-frame)']")
    defs = root.find(tag("defs"))
    if hands is not None:
        clip = node(defs, "clipPath", id="full-costume-hands-clip")
        wrist_y = 440 if outfit in FULL_HEMS else (447 if child else 445)
        node(clip, "rect", x=0, y=wrist_y, width=320, height=752 - wrist_y)
    lower = ET.Element(tag("g"), {"data-part": "full-costume"})
    root.insert(list(root).index(upper), lower)
    gradient = _BACKGROUNDS.get(equipment["background"])
    if gradient:
        backdrop = ET.Element(tag("rect"), width=root.get("width"), height=root.get("height"),
                              fill=f"url(#{gradient})")
        if child:
            root.insert(list(root).index(lower), backdrop)
        else:
            lower.append(backdrop)
        node(lower, "ellipse", cx=160, cy=_CHILD_DRAWING_GROUND_Y if child else _GROUND_Y, rx=98 if child else 113,
             ry=10, fill="#261f20", opacity=".5")
    draw_back_equipment(lower, {**appearance, **equipment}, adult_cut)
    dress = appearance["cast"] == "women" and outfit not in ARMORED_OUTFITS
    footwear, legwear = _LOWER_WEAR.get(outfit, ("shoe", "trousers"))
    if child:
        lower = node(lower, "g", transform=_CHILD_LOWER_TRANSFORM)
    if LOWER_OPTIONS.keys() & equipment.keys():
        draw_lower_wear(lower, body, dress=dress,
                        trousers=equipment.get("trousers", _TROUSERS_BY_CUT[legwear]),
                        leg_wraps=equipment.get("leg_wraps", "wool" if legwear == "bindings" else "none"),
                        footwear=equipment.get("footwear", _SHOES_BY_CUT[footwear]))
    else:
        for right in (False, True):
            side = node(lower, "g", transform=_REFLECT) if right else node(lower, "g")
            if not dress:
                _leg(side, hose=legwear == "hose", bindings=legwear == "bindings", half=min(body.waist, 73),
                     footwear=footwear)
            _shoe(side, style=footwear, x=9 if dress else 0)
    if hands is None:
        _hands(lower, adult_cut, skin, outfit, child=child)
    if equipment.get("cloak", "none") == "none":
        waist = draw_waist_accessories(root, {**appearance, **equipment}, full=True)
        if "cloak" not in equipment and (has_hanging_gear or handheld is not None):
            mask = _mask_for_bundled_drape(root, upper, outfit)
            if mask is not None:
                if waist is not None and has_hanging_gear:
                    root.remove(waist)
                    node(root, "g", mask=mask).append(waist)
                if handheld is not None:
                    handheld.set("mask", mask)
        if handheld is not None:
            root.append(handheld)
    if child:
        layers = root.findall(tag("g"))
        figure = node(root, "g", data_part="child-figure",
                      transform=f"translate(160 {_GROUND_Y}) scale({_CHILD_FIGURE_SCALE}) "
                                f"translate(-160 {-_CHILD_DRAWING_GROUND_Y})")
        for layer in layers:
            root.remove(layer)
            figure.append(layer)
    return ET.tostring(root, encoding="unicode")
