from dataclasses import replace
from xml.etree import ElementTree as ET

from common import node, number, path, tag, use
from face_shape import _skin
from generate import _draw_figure
from wardrobe import (
    ARMORED_OUTFITS, BODIES, CHILD_BODY_SCALE, DYED, HANDHELD_HIDDEN_BY, NATURAL, NORTHWEST_ARMOR,
    _body_fit, draw_waist_accessories,
)
from wardrobe_northwest_archery import draw_held_bow
from wardrobe_northwest_arms import draw_held_weapon, draw_shield
from wardrobe_northwest_gotland import LOWER_DRAWERS
from wardrobe_northwest_legs import OPTIONS as LOWER_OPTIONS, draw_lower_wear


_REFLECT = "translate(320 0) scale(-1 1)"
_CHILD_LOWER_TRANSFORM = "matrix(1 0 0 .76 0 105.6)"
_BUNDLED_GOTLAND_DRAPES = {
    "nw_gotland_mens_cloak": ("gotland-shoulder-cloak", "gotland-cloak-free-end"),
    "nw_gotland_womens_mantle": ("gotland-open-mantle", "gotland-mantle-hanging-folds"),
}
_BACKGROUNDS = {"parchment": "umber", "ash": "ash", "rose": "rose"}
_LOWER_WEAR = {
    "nw_nov_svita": ("belted", "boot", "trousers"),
    "kozukh": ("frost", "boot", "trousers"),
    "nw_nov_sofia_tunic": ("dress", "halfboot", "trousers"),
    "nw_baltic_mens_coat": ("belted", "shoe", "bindings"),
    "nw_nordic_gored_tunic": ("nordic", "strap", "hose"),
    "nw_nov_womens_rubakha": ("checked", "shoe", "trousers"),
    "nw_nov_womens_fur_coat": ("frost", "halfboot", "trousers"),
    "nw_nov_trimmed_gown": ("ribbon", "shoe", "trousers"),
    "nw_karel_apron_gown": ("apron", "shoe", "trousers"),
    "nw_nordic_pleated_gown": ("pleats", "strap", "hose"),
    "nw_gotland_mens_cloak": ("belted", "strap", "hose"),
    "nw_gotland_womens_mantle": ("dress", "strap", "hose"),
    "nw_mail_hauberk": (None, "halfboot", "hose"),
    "nw_nov_lamellar": (None, "boot", "trousers"),
    "nw_mail_surcoat": (None, "halfboot", "hose"),
}
_TROUSERS_BY_CUT = {"trousers": "straight", "bindings": "gathered", "hose": "hose"}
_SHOES_BY_CUT = {"shoe": "novgorod_shoes", "strap": "oslo_strap_shoes", "boot": "novgorod_high_boots",
                 "halfboot": "novgorod_ankle_boots"}


def _leg(parent, *, hose, bindings, half, footwear):
    x = 160 - half
    sideline = x + 14 if hose else x
    knee = x + 28 if hose else x + 24
    ankle = {"boot": 644, "halfboot": 678}.get(footwear, 700)
    ankle_mid = round((598 + ankle) / 2)
    cloth = "#5b5950" if hose else "#62574d"
    path(parent, f"M{x - 3} 469 L158 469 Q158 548 143 598 Q135 {ankle_mid} 135 {ankle} H105 "
         f"Q{knee - 17} {ankle_mid + 5} {sideline - 1} 597 Q{x - 5} 548 {x - 3} 469Z", cloth, class_="edge")
    path(parent, f"M{x + 6} 514 Q{x + 19} 546 {knee} 595 Q{knee + 3} {ankle_mid} 131 {ankle - 6} "
         f"H108Q{knee - 13} {ankle_mid - 8} {sideline + 1} 592Z", "#8c7c69", opacity=".53")
    path(parent, f"M{x + 9} 556Q{x + 21} 592 {x + 37} 607 M{x + 12} 605Q{x + 23} 627 {x + 30} 635",
         class_="etch")
    if bindings:
        details = f"M{sideline - 1} 621 Q110 626 139 628L136 699H{sideline + 4}Z"
        path(parent, details, "#8c7555", class_="edge")
        for y in (637, 650, 663, 676, 689):
            path(parent, f"M{sideline + 2} {y}l{132 - sideline} 5", "none", stroke="#55463a", stroke_width=2)
        path(parent, "M136 642q6 21 4 37l6 8-2 5-7-8-6-14", "none", stroke="#b3976d", stroke_width=2.6)
        for x, y in ((141, 683), (144, 689)):
            node(parent, "circle", cx=x, cy=y, r=2.65, fill="#c7a978", stroke="#553c31", stroke_width="1.15")


def _shoe(parent, *, style, x):
    foot = node(parent, "g", transform=f"translate({x} 0)")
    if style in {"boot", "halfboot"}:
        top = 636 if style == "boot" else 669
        path(foot, f"M98 {top}Q116 {top - 5} 139 {top + 3}Q137 677 140 704"
             "L142 724Q123 731 88 728Q75 725 83 714L100 701Q104 677 98 " + str(top) + "Z",
             "#5b4034", class_="edge")
        path(foot, f"M102 {top + 5}Q117 {top} 136 {top + 6}M108 700Q124 701 135 709 "
             "M100 705Q104 710 117 715", "none", stroke="#96745a", stroke_width=2.15)
        path(foot, "M102 699Q108 695 119 697Q117 709 129 722Q99 728 85 722Z", "#72503e")
    else:
        path(foot, "M99 689Q119 683 138 691L142 718Q139 728 120 729H86"
             "Q72 728 77 717Q82 708 99 704Z", "#654939", class_="edge")
        path(foot, "M86 718Q108 706 137 711L139 720Q110 730 83 724Z", "#87624a")
        if style == "strap":
            path(foot, "M102 692Q110 700 136 699L139 704Q117 708 100 700Z", "#b18b65", class_="edge")
            node(foot, "circle", cx=130, cy=703, r=2.3, fill="#d8b986")
        else:
            path(foot, "M101 711L103 700Q115 704 136 707", class_="etch")
    path(foot, "M83 725Q108 731 137 724", class_="seam")


def _coat_lower(parent, body, cloth, tail):
    half = body.hem
    end = half + (15 if tail == "frost" else 5)
    hem = {"frost": 581, "dress": 555, "nordic": 555, "belted": 545}[tail]
    outline = (f"M{160 - half + 3} 435 Q{160 - end + 9} 474 {160 - end} {hem} "
               f"Q160 {hem + 21} {160 + end} {hem} Q{160 + end - 7} 477 {160 + half - 3} 435Z")
    path(parent, outline, cloth.base, class_="edge")
    path(parent, f"M{160 - half + 13} 435 Q137 470 119 {hem + 4} L{160 - end + 8} {hem - 3} "
         f"Q{160 - end + 10} 495 {160 - half + 3} 435Z", cloth.shade)
    path(parent, f"M184 442Q188 484 201 {hem + 8}Q220 {hem + 6} {160 + end - 10} {hem} "
         f"Q231 491 219 440Z", cloth.shade, opacity=".66")
    for x, y in ((117, hem - 11), (154, hem - 13), (202, hem - 15)):
        path(parent, f"M{x} 451Q{x - 5} 493 {x - 8} {y}", class_="etch")
    path(parent, f"M{160 - end + 5} {hem - 7}Q160 {hem + 13} {160 + end - 5} {hem - 7}", class_="seam")
    if tail == "nordic":
        path(parent, f"M127 439H189Q203 496 210 {hem + 6}Q162 {hem + 15} 103 {hem + 5}Z",
             cloth.shade)
        path(parent, f"M125 449Q117 511 103 {hem + 4}M189 446Q197 499 207 {hem + 5}",
             "none", stroke=cloth.light, stroke_width=1.35)
    elif tail == "frost":
        path(parent, f"M152 440 Q151 500 147 {hem + 7}L159 {hem + 8}Q160 492 157 440Z",
             "#bba281")
        path(parent, f"M155 454Q154 498 152 {hem - 3}", class_="etch")
    return outline


def _skirt(parent, body, cloth, tailoring):
    half = body.hem
    end = min(137, half + (30 if tailoring == "pleats" else 24))
    hem = 700 if tailoring != "frost" else 677
    if tailoring == "frost":
        path(parent, f"M{160 - half + 18} 443H{160 + half - 17}L{160 + end - 10} 704 "
             f"Q159 724 {170 - end} 704Z", "#aa987c", class_="edge")
    outline = (f"M{160 - half + 3} 435 Q{163 - half} 500 {160 - end} {hem} "
               f"Q159 {hem + 25} {160 + end} {hem} Q{157 + half} 495 {157 + half} 435Z")
    path(parent, outline, cloth.base, class_="edge")
    path(parent, f"M{168 - half} 437 Q{184 - half} 562 {204 - end} {hem + 5} L{164 - end} {hem - 2} "
         f"Q{158 - half} 522 {163 - half} 437Z", cloth.shade)
    path(parent, f"M208 439Q208 582 221 {hem + 10} L{156 + end} {hem - 1} "
         f"Q{165 + half} 499 {155 + half} 437Z", cloth.shade, opacity=".79")
    starts = range(96, 225, 16) if tailoring == "pleats" else (113, 147, 185, 217)
    for x in starts:
        flare = (x - 160) // 4
        path(parent, f"M{x} 447 Q{x + flare // 2} 550 {x + flare} {hem - 9}",
             "none", stroke=cloth.deep, stroke_width=1.55, stroke_linecap="round", opacity=".85")
    path(parent, f"M{166 - end} {hem - 7}Q160 {hem + 14} {154 + end} {hem - 7}", class_="seam")
    if tailoring == "frost":
        path(parent, f"M150 437H170Q175 556 181 {hem + 9}Q160 {hem + 12} 139 {hem + 9}Z", "#413032")
        path(parent, f"M156 437H164Q166 573 172 {hem + 10}H149Q155 543 156 437Z", "#b59a77")
        for reflection in ("", _REFLECT):
            side = node(parent, "g", transform=reflection) if reflection else parent
            path(side, f"M136 437H150Q146 562 140 {hem + 9}L128 {hem + 8}Q139 552 136 437Z",
                 "#a5876f", stroke="#503537", stroke_width=1.65)
            path(side, "M138 467l7 2m-7 33 7 2m-7 34 6 3m-8 43 7 4m-10 28 8 7",
                 class_="etch", opacity=".7")
    if tailoring == "ribbon":
        left = 153 - round(.46 * body.waist)
        for reflection in ("", _REFLECT):
            side = node(parent, "g", transform=reflection) if reflection else parent
            path(side, f"M{left} 435H{left + 13}Q{left + 8} 575 {left - 10} {hem - 12} "
                 f"L{left - 23} {hem - 13}Q{left - 3} 564 {left} 435Z", "#794944",
                 stroke="#553538", stroke_width=1.45)
        path(parent, f"M{164 - end} {hem - 16}Q160 {hem + 4} {156 + end} {hem - 16} "
             f"L{156 + end} {hem - 10}Q160 {hem + 10} {164 - end} {hem - 10}Z", "#ae845c")
    return outline


def _apron(parent, body, *, checked):
    if checked:
        # The upper panel widens by six units between y=403 and y=447.
        base_half = round(.69 * body.waist)
        start_half = base_half + 6 * (439 - 403) / (447 - 403)
        end = base_half + 16
        shape = (
            f"M{number(160 - start_half)} 439H{number(160 + start_half)} "
            f"Q{167 + base_half} 452 {160 + end} 646 Q160 655 {160 - end} 646 "
            f"Q{153 - base_half} 452 {number(160 - start_half)} 439Z"
        )
        path(parent, shape, "url(#wardrobe-nw-checked-waist-panel-weave)", stroke="#473331",
             stroke_width=2.45, stroke_linejoin="round")
        return
    half = round(.54 * body.waist) + 7
    end = half + 9
    hem = 663
    left, right = 160 - half, 160 + half
    shape = f"M{left} 434H{right}L{160 + end} {hem}Q160 {hem + 9} {160 - end} {hem}Z"
    path(parent, shape, "#a07552", class_="edge")
    path(parent, f"M{163 - end} {hem - 23}Q160 {hem - 16} {157 + end} {hem - 23} "
         f"L{157 + end} {hem - 4}Q160 {hem + 4} {163 - end} {hem - 4}Z", "#78543e")
    for x in range(176 - end, 155 + end, 16):
        y = hem - 11 + round(2 * (1 - ((x - 160) / end) ** 2))
        path(parent, f"M{x - 5} {y - 5}h10v10h-10Z m3 6q0 -5 5 -4q5 2 1 5q-4 1 -3 -2",
             "none", stroke="#c59863", stroke_width=1.3)


def _hand_edges(body, outfit):
    outside = 160 - body.sleeve + (18 if outfit == "rus_mantle" else 8)
    return outside, 160 - body.hem + 12


def _hands(parent, body, cloth, skin, outfit, *, full_sleeves):
    left, right_edge = _hand_edges(body, outfit)
    middle = number((left + right_edge) / 2)
    for right in (False, True):
        arm = node(parent, "g", transform=_REFLECT) if right else node(parent, "g")
        path(arm, f"M{left + 3} 441 Q{left + 2} 454 {left + 3} 464 "
             f"Q{left + 5} 474 {middle} 473Q{right_edge + 3} 473 {right_edge + 1} 460 "
             f"L{right_edge - 2} 442Z", skin.base, class_="edge", data_part="hand")
        path(arm, f"M{middle} 458Q{right_edge - 4} 454 {right_edge} 460 M{left + 10} 464q5 4 8 3",
             class_="etch")
        if not full_sleeves:
            path(arm, f"M{left - 2} 435H{right_edge + 1}L{right_edge + 1} 448Q{middle} 453 {left} 448Z",
                 cloth.shade if right else cloth.base, class_="edge")
            path(arm, f"M{left + 3} 443Q{middle} 447 {right_edge - 2} 443", class_="etch")


def _handheld(equipment, body, skin, *, child, hands=None):
    cloak = equipment.get("cloak", "none")
    weapon = equipment.get("weapon", "none")
    shield = equipment.get("shield", "none")
    bow = equipment.get("bow", "none")
    show_bow = bow != "none" and cloak not in HANDHELD_HIDDEN_BY["bow"]
    show_weapon = (bow == "none" and weapon not in {"none", "sheathed_sword"}
                   and cloak not in HANDHELD_HIDDEN_BY["weapon"])
    show_shield = shield != "none" and cloak not in HANDHELD_HIDDEN_BY["shield"]
    if hands is None and not (show_bow or show_weapon or show_shield):
        return None
    group = ET.Element(tag("g"), {"data-part": "handheld-equipment"})
    if child:
        group.set("transform", _CHILD_LOWER_TRANSFORM)
    if hands is not None:
        group.append(hands)
    left, right = _hand_edges(body, equipment["outfit"])
    center = (left + right) / 2
    if show_bow:
        draw_held_bow(group, bow, x=center, y=459, skin=skin)
    elif show_weapon:
        draw_held_weapon(group, weapon, x=center, y=459, skin=skin)
    if show_shield:
        draw_shield(group, shield, x=320 - center, y=459)
    return group


def _cover_waist_with_bundled_drape(root, upper, lower, waist, outfit):
    # These drapes are drawn inside the outfit. Reuse their opaque contours for the waist layer.
    defs = root.find(tag("defs"))
    path_tag = tag("path")
    outer_clip = None
    hem = None
    if outfit == "cloak":
        panels = defs.findall(f"./*[@id='wardrobe-cloak-mask']/{path_tag}")
    else:
        outer_clip = "url(#wardrobe-outer-mask)"
        outer = upper.find(f".//*[@clip-path='{outer_clip}']")
        if outfit == "korzno":
            panels = outer.findall(f"./{path_tag}")[:2]
        elif outfit == "naumburg_clasp_mantle":
            panels = [group.find(f"./{path_tag}") for group in outer.findall("./*[@data-part='mantle-drape']")]
        elif outfit in _BUNDLED_GOTLAND_DRAPES:
            top_part, hem_part = _BUNDLED_GOTLAND_DRAPES[outfit]
            panels = [outer.find(f"./*[@data-part='{top_part}']/{path_tag}")]
            hem = lower.find(f"./*[@data-part='{hem_part}']/{path_tag}")
        else:
            return
    mask_id = "full-costume-bundled-drape"
    bounds = {"x": 0, "y": 0, "width": root.get("width"), "height": root.get("height")}
    mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse", **bounds)
    node(mask, "rect", fill="white", **bounds)
    clip_frame = node(mask, "g", clip_path="url(#portrait-frame)")
    child_wardrobe = upper.find("./*[@data-part='wardrobe']")
    transform = child_wardrobe.get("transform") if child_wardrobe is not None else None
    cloth = node(clip_frame, "g", transform=transform, clip_path=outer_clip)
    for index, panel in enumerate(panels):
        reflect = _REFLECT if outfit == "naumburg_clasp_mantle" and index == 1 else None
        path(cloth, panel.get("d"), "black", transform=reflect, stroke="black", stroke_width=2)
    if hem is not None:
        path(mask, hem.get("d"), "black", transform=lower.get("transform"), stroke="black", stroke_width=2)
    root.remove(waist)
    node(root, "g", mask=f"url(#{mask_id})").append(waist)


def _join_fabric(parent, defs, upper, outline, *, seam_gap=0):
    # Carry the final strip of the portrait's folds into the drawn hem without a hard cut at y=440.
    upper.set("id", "full-costume-upper")
    clip = node(defs, "clipPath", id="full-costume-join-outline")
    if seam_gap:
        outline += f" M{160 - seam_gap} 436H{160 + seam_gap}V469H{160 - seam_gap}Z"
        path(clip, outline, clip_rule="evenodd")
    else:
        path(clip, outline)
    fade = node(defs, "linearGradient", id="full-costume-join-fade", x1=0, y1=0, x2=0, y2=1)
    node(fade, "stop", offset=0, stop_color="#fff")
    node(fade, "stop", offset=1, stop_color="#000")
    mask = node(defs, "mask", id="full-costume-join-mask", maskUnits="userSpaceOnUse",
                x=0, y=440, width=320, height=26)
    node(mask, "rect", x=0, y=440, width=320, height=26, fill="url(#full-costume-join-fade)")
    insert = node(parent, "g", clip_path="url(#full-costume-join-outline)", mask="url(#full-costume-join-mask)")
    use(insert, "full-costume-upper", transform="matrix(1 0 0 -4 0 2200)")


def full_svg(appearance, equipment, *, title):
    child = appearance["age"] == "child"
    outfit = equipment["outfit"]
    full_armor = outfit in NORTHWEST_ARMOR
    body = _body_fit(BODIES[appearance["body"]], outfit)
    if child:
        body = replace(body, **{part: round(getattr(body, part) * CHILD_BODY_SCALE)
                                for part in ("waist", "hem", "sleeve")})
    skin = _skin(appearance)
    cloth = DYED.get(equipment["cloth_color"], NATURAL[outfit])
    waist_archery = any(equipment.get(field, "none") != "none" for field in ("bow_case", "quiver"))
    hands = None
    if waist_archery:
        # An arm resting at the side passes in front of the hanging case and quiver.
        hands = ET.Element(tag("g"), {"data-part": "hands", "clip-path": "url(#full-costume-hands-clip)"})
        _hands(hands, body, cloth, skin, outfit, full_sleeves=full_armor)
    handheld = _handheld(equipment, body, skin, child=child, hands=hands)
    root = _draw_figure(appearance, {**equipment, "background": "transparent"}, view="full",
                        title=title, handheld=handheld)
    upper = root.find("./*[@clip-path='url(#portrait-frame)']")
    defs = root.find(tag("defs"))
    if hands is not None:
        clip = node(defs, "clipPath", id="full-costume-hands-clip")
        node(clip, "rect", x=0, y=440, width=320, height=312)
    lower = ET.Element(tag("g"), {"data-part": "full-costume"})
    root.insert(list(root).index(upper), lower)
    gradient = _BACKGROUNDS.get(equipment["background"])
    if gradient:
        node(lower, "rect", width=root.get("width"), height=root.get("height"), fill=f"url(#{gradient})")
        node(lower, "ellipse", cx=160, cy=661 if child else 731, rx=98 if child else 113,
             ry=10, fill="#261f20", opacity=".5")
    dress = appearance["cast"] == "women" and outfit not in ARMORED_OUTFITS
    tailoring, footwear, legwear = _LOWER_WEAR.get(outfit, ("dress" if dress else "belted", "shoe", "trousers"))
    if child:
        lower = node(lower, "g", transform=_CHILD_LOWER_TRANSFORM)
    if LOWER_OPTIONS.keys() & equipment.keys():
        draw_lower_wear(lower, body, dress=dress,
                        trousers=equipment.get("trousers", _TROUSERS_BY_CUT[legwear]),
                        leg_wraps=equipment.get("leg_wraps", "wool" if legwear == "bindings" else "none"),
                        footwear=equipment.get("footwear", _SHOES_BY_CUT[footwear]))
    else:
        for right in (False, True):
            side = node(lower, "g", transform=_REFLECT) if right else node(lower, "g")
            if not dress:
                _leg(side, hose=legwear == "hose", bindings=legwear == "bindings", half=min(body.waist, 73),
                     footwear=footwear)
            _shoe(side, style=footwear, x=9 if dress else 0)
    if not full_armor:
        if outfit in LOWER_DRAWERS:
            outline = LOWER_DRAWERS[outfit](lower, body, cloth, show_cloak="cloak" not in equipment)
        elif dress:
            outline = _skirt(lower, body, cloth, tailoring)
        else:
            outline = _coat_lower(lower, body, cloth, tailoring)
        seam_gap = round(.69 * body.waist) + 12 if tailoring == "checked" else 0
        _join_fabric(lower, defs, upper, outline, seam_gap=seam_gap)
        if dress and tailoring in {"checked", "apron"}:
            _apron(lower, body, checked=tailoring == "checked")
    if hands is None:
        _hands(lower, body, cloth, skin, outfit, full_sleeves=full_armor)
    if equipment.get("cloak", "none") == "none":
        waist = draw_waist_accessories(root, {**appearance, **equipment}, full=True)
        if ("cloak" not in equipment and waist is not None
                and any(item.get("data-part") in {"scabbard", "bow-case", "quiver"} for item in waist)):
            _cover_waist_with_bundled_drape(root, upper, lower, waist, outfit)
        if handheld is not None:
            root.append(handheld)
    return ET.tostring(root, encoding="unicode")
