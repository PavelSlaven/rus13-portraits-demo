from dataclasses import replace
from xml.etree import ElementTree as ET

import wardrobe_northwest_accessories
import image_armour_art
from common import node, number, path, tag
from face_shape import _skin
from generate import PORTRAIT, _draw_figure
from wardrobe import (
    ARMORED_OUTFITS, BODIES, BRACELET_COVERING_OUTFITS, CHILD_BODY_SCALE, FULL_HEMS, HANDHELD_HIDDEN_BY,
    _body_fit, carried_bow_case, carried_waist_weapon,
    draw_back_equipment, draw_waist_accessories,
)
from wardrobe_northwest_archery import draw_held_bow
from wardrobe_northwest_arms import draw_held_weapon, draw_shield
from wardrobe_northwest_legs import OPTIONS as LOWER_OPTIONS, draw_lower_wear, draw_mitten, fit_held_mitten


_REFLECT = "translate(320 0) scale(-1 1)"
_CHILD_LOWER_TRANSFORM = "matrix(1 0 0 .76 0 105.6)"
_GROUND_Y = 731
_CHILD_DRAWING_GROUND_Y = 661
_CHILD_FIGURE_SCALE = .53
_WAIST_CROP_BOTTOM = 408
_HIGH_WRIST_TRIM = {
    "rus_gilt_cuff_tunic": 392,
    "steppe_robe": 396,
    "song_pheasant_robe": 401,
    "nw_baltic_spiral_kuub": 402,
}
_BUNDLED_GOTLAND_DRAPES = {
    "nw_gotland_mens_cloak": "gotland-shoulder-cloak",
    "nw_gotland_womens_mantle": "gotland-open-mantle",
}
_BACKGROUNDS = {"parchment": "umber", "ash": "ash", "rose": "rose"}
_LOWER_WEAR = {
    "nw_nov_svita": ("boot", "trousers"),
    "kozukh": ("boot", "trousers"),
    "nw_nov_sofia_tunic": ("halfboot", "trousers"),
    "nw_baltic_mens_coat": ("shoe", "bindings"),
    "nw_nordic_gored_tunic": ("strap", "hose"),
    "nw_nov_womens_fur_coat": ("halfboot", "trousers"),
    "nw_nordic_pleated_gown": ("strap", "hose"),
    "nw_gotland_mens_cloak": ("strap", "hose"),
    "nw_gotland_womens_mantle": ("strap", "hose"),
    "nw_mail_hauberk": ("halfboot", "hose"),
    "nw_nov_lamellar": ("boot", "trousers"),
    "nw_mail_surcoat": ("halfboot", "hose"),
    "nw_nov_scale": ("boot", "trousers"),
    "nw_nov_copper_mail": ("halfboot", "trousers"),
    "nw_gomel_lamellar": ("boot", "trousers"),
    "nw_magdeburg_plate_coat": ("halfboot", "hose"),
    "tellem_tunic": ("barefoot", "bare"),
    "tellem_wrap": ("barefoot", "bare"),
    "song_plain_jacket": ("cloth_shoes", "plain"),
}
_TROUSERS_BY_CUT = {"trousers": "straight", "bindings": "gathered", "hose": "hose",
                    "bare": "none", "plain": "plain_trousers"}
_SHOES_BY_CUT = {"shoe": "novgorod_shoes", "strap": "oslo_strap_shoes", "boot": "novgorod_high_boots",
                 "halfboot": "novgorod_ankle_boots", "barefoot": "barefoot", "cloth_shoes": "cloth_shoes"}


def _leg(parent, *, hose, bindings, half, footwear):
    x = 160 - half
    sideline = x + 14 if hose else x
    knee = x + 28 if hose else x + 24
    ankle = {"boot": 644, "halfboot": 678}.get(footwear, 700)
    ankle_mid = round((598 + ankle) / 2)
    cloth = "#5b5950" if hose else "#62574d"
    path(parent, f"M{x - 3} 469 L158 469 Q158 548 143 598 Q135 {ankle_mid} 135 {ankle} H105 "
         f"Q{knee - 17} {ankle_mid + 5} {sideline - 1} 597 Q{x - 5} 548 {x - 3} 469Z", cloth, class_="edge")
    path(parent, f"M{x + 6} 514 Q{x + 19} 546 {knee} 595 Q{knee + 3} {ankle_mid} 131 {ankle - 6} "
         f"H108Q{knee - 13} {ankle_mid - 8} {sideline + 1} 592Z", "#8c7c69", opacity=".53")
    path(parent, f"M{x + 9} 556Q{x + 21} 592 {x + 37} 607 M{x + 12} 605Q{x + 23} 627 {x + 30} 635",
         class_="etch")
    if bindings:
        details = f"M{sideline - 1} 621 Q110 626 139 628L136 699H{sideline + 4}Z"
        path(parent, details, "#8c7555", class_="edge")
        for y in (637, 650, 663, 676, 689):
            path(parent, f"M{sideline + 2} {y}l{132 - sideline} 5", "none", stroke="#55463a", stroke_width=2)
        path(parent, "M136 642q6 21 4 37l6 8-2 5-7-8-6-14", "none", stroke="#b3976d", stroke_width=2.6)
        for x, y in ((141, 683), (144, 689)):
            node(parent, "circle", cx=x, cy=y, r=2.65, fill="#c7a978", stroke="#553c31", stroke_width="1.15")


def _shoe(parent, *, style, x):
    foot = node(parent, "g", transform=f"translate({x} 0)")
    if style in {"boot", "halfboot"}:
        top = 636 if style == "boot" else 669
        path(foot, f"M98 {top}Q116 {top - 5} 139 {top + 3}Q137 677 140 704"
             "L142 724Q123 731 88 728Q75 725 83 714L100 701Q104 677 98 " + str(top) + "Z",
             "#5b4034", class_="edge")
        path(foot, f"M102 {top + 5}Q117 {top} 136 {top + 6}M108 700Q124 701 135 709 "
             "M100 705Q104 710 117 715", "none", stroke="#96745a", stroke_width=2.15)
        path(foot, "M102 699Q108 695 119 697Q117 709 129 722Q99 728 85 722Z", "#72503e")
    else:
        path(foot, "M99 689Q119 683 138 691L142 718Q139 728 120 729H86"
             "Q72 728 77 717Q82 708 99 704Z", "#654939", class_="edge")
        path(foot, "M86 718Q108 706 137 711L139 720Q110 730 83 724Z", "#87624a")
        if style == "strap":
            path(foot, "M102 692Q110 700 136 699L139 704Q117 708 100 700Z", "#b18b65", class_="edge")
            node(foot, "circle", cx=130, cy=703, r=2.3, fill="#d8b986")
        else:
            path(foot, "M101 711L103 700Q115 704 136 707", class_="etch")
    path(foot, "M83 725Q108 731 137 724", class_="seam")


def _hand_edges(body, outfit):
    half = max(12, min(15, round(body.shoulder / 6)))
    return body.wrist_x - half, body.wrist_x + half


def _hands(parent, body, skin, equipment, *, child=False):
    outfit = equipment["outfit"]
    gloves = equipment.get("gloves", "none")
    left, right_edge = _hand_edges(body, outfit)
    if child:
        left, right_edge = (round(160 + (point - 160) * CHILD_BODY_SCALE) for point in (left, right_edge))
    middle = number((left + right_edge) / 2)
    for right in (False, True):
        arm = node(parent, "g", transform=_REFLECT) if right else node(parent, "g")
        if gloves != "none":
            draw_mitten(arm, gloves, left=left, right=right_edge)
            continue
        path(arm, f"M{left + 3} 441 Q{left + 2} 454 {left + 3} 464 "
             f"Q{left + 5} 474 {middle} 473Q{right_edge + 3} 473 {right_edge + 1} 460 "
             f"L{right_edge - 2} 442Z", skin.base, class_="edge", data_part="hand")
        path(arm, f"M{middle} 458Q{right_edge - 4} 454 {right_edge} 460 M{left + 10} 464q5 4 8 3",
             class_="etch")
        wrist_covered = outfit in BRACELET_COVERING_OUTFITS or equipment.get("vestment") == "epimanikia"
        if not wrist_covered or equipment.get("jewelry") == "signet_ring":
            wardrobe_northwest_accessories.draw_hand_jewelry(
                arm, equipment, left=left, right=right_edge, reflected=right,
            )


def _handheld(equipment, body, skin, *, child, hands=None):
    cloak = equipment.get("cloak", "none")
    weapon = equipment.get("weapon", "none")
    bow = equipment.get("bow", "none")
    held = equipment.get("carry") == "held"
    bundled_closed_hand = equipment["outfit"] == "cloak" and "cloak" not in equipment
    show_bow = (held and bow != "none" and cloak not in HANDHELD_HIDDEN_BY["bow"]
                and not bundled_closed_hand)
    show_weapon = (held and bow == "none" and weapon not in {"none", "sheathed_sword"}
                   and cloak not in HANDHELD_HIDDEN_BY["weapon"])
    if hands is None and not (show_bow or show_weapon):
        return None
    group = ET.Element(tag("g"), {"data-part": "handheld-equipment"})
    content = node(group, "g", transform=_CHILD_LOWER_TRANSFORM) if child else group
    if hands is not None:
        content.append(hands)
    left, right = _hand_edges(body, equipment["outfit"])
    center = (left + right) / 2
    if show_bow:
        draw_held_bow(content, bow, x=center, y=459, skin=skin)
    elif show_weapon:
        draw_held_weapon(content, weapon, x=center, y=459, skin=skin, child=child)
    gloves = equipment.get("gloves", "none")
    if gloves != "none" and (show_bow or show_weapon):
        fit_held_mitten(content, gloves)
    return group


def _mask_for_bundled_drape(root, upper, outfit):
    # These drapes are drawn inside the outfit. Reuse their opaque contours for the waist layer.
    defs = root.find(tag("defs"))
    path_tag = tag("path")
    outer_clip = None
    if outfit == "cloak":
        panels = defs.findall(f"./*[@id='wardrobe-cloak-mask']/{path_tag}")
    else:
        outer_clip = "url(#wardrobe-outer-mask)"
        outer = upper.find(f".//*[@clip-path='{outer_clip}']")
        if outfit == "korzno":
            panels = outer.findall(f"./{path_tag}[@data-part='korzno-cloth-panel']")
        elif outfit == "rus_mantle":
            panels = [outer.find(f"./{path_tag}")]
        elif outfit == "naumburg_clasp_mantle":
            panels = [group.find(f"./{path_tag}") for group in outer.findall("./*[@data-part='mantle-drape']")]
        elif outfit in _BUNDLED_GOTLAND_DRAPES:
            part = _BUNDLED_GOTLAND_DRAPES[outfit]
            panels = [outer.find(f"./*[@data-part='{part}']/{path_tag}")]
        else:
            return
    mask_id = "full-costume-bundled-drape"
    bounds = {"x": 0, "y": 0, "width": root.get("width"), "height": root.get("height")}
    mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse", **bounds)
    node(mask, "rect", fill="white", **bounds)
    clip_frame = node(mask, "g", clip_path="url(#portrait-frame)")
    child_wardrobe = upper.find("./*[@data-part='wardrobe']")
    transform = child_wardrobe.get("transform") if child_wardrobe is not None else None
    cloth = node(clip_frame, "g", transform=transform, clip_path=outer_clip)
    for index, panel in enumerate(panels):
        reflect = _REFLECT if outfit == "naumburg_clasp_mantle" and index == 1 else None
        # Match the ink outline of the cloth as well as its fill.
        path(cloth, panel.get("d"), "black", transform=reflect, class_="edge", style="stroke:black")
    return f"url(#{mask_id})"


def _cover_waist_with_vestment(root, upper):
    # The belt and its gear sit above the tunic but under the hanging stole.
    # Mask the assembled waist in scene coordinates so separate cloaks still cover both.
    panel = upper.find(".//*[@data-part='vestment-front']")
    waist = root.find(".//*[@data-part='waist-accessories']")
    if panel is None or waist is None:
        return
    parent = next(group for group in root.iter() if waist in group)
    index = list(parent).index(waist)
    defs = root.find(tag("defs"))
    mask_id = "full-costume-vestment-front"
    bounds = dict(x=0, y=0, width=root.get("width"), height=root.get("height"))
    mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse", **bounds)
    node(mask, "rect", fill="white", **bounds)
    path(mask, panel.get("d"), "black", class_="edge", style="stroke:black")
    parent.remove(waist)
    wrapper = ET.Element(tag("g"), mask=f"url(#{mask_id})")
    parent.insert(index, wrapper)
    wrapper.append(waist)


def _crop_at_waist(root, *, child, outfit):
    width, height, viewbox = PORTRAIT
    scale = _CHILD_FIGURE_SCALE if child else 1
    top = _GROUND_Y - _CHILD_DRAWING_GROUND_Y * scale if child else 0
    # Stop above tall wrist trim. Child costumes also have a local vertical fit.
    bottom = _HIGH_WRIST_TRIM.get(outfit, _WAIST_CROP_BOTTOM)
    if child:
        bottom = bottom * 1.08 - 35.6
    crop_height = bottom * scale
    crop_width = crop_height * width / height
    left = (int(root.get("width")) - crop_width) / 2
    camera = " ".join(number(value) for value in (left, top, crop_width, crop_height))
    artwork = [layer for layer in root if layer.tag not in {tag("title"), tag("defs")}]
    viewport = node(root, "svg", width=width, height=height, viewBox=camera, overflow="hidden")
    for layer in artwork:
        root.remove(layer)
        viewport.append(layer)
    root.attrib.update(width=str(width), height=str(height), viewBox=viewbox)


def full_svg(appearance, equipment, *, title, portrait=False):
    child = appearance["age"] == "child"
    outfit = equipment["outfit"]
    adult_cut = _body_fit(BODIES[appearance["body"]], outfit)
    body = adult_cut
    if child:
        body = replace(body, **{part: round(getattr(body, part) * CHILD_BODY_SCALE)
                                for part in ("waist", "hem", "sleeve")})
    skin = _skin(appearance)
    has_hanging_gear = (
        carried_waist_weapon(equipment) != "none"
        or carried_bow_case(equipment)[0] != "none"
        or equipment.get("quiver", "none") != "none"
    )
    hands = None
    if has_hanging_gear or outfit not in FULL_HEMS:
        # The loose hem sits behind the hands. The cuff and cloak remain over the wrist.
        hands = ET.Element(tag("g"), {"data-part": "hands", "clip-path": "url(#full-costume-hands-clip)"})
        _hands(hands, adult_cut, skin, equipment, child=child)
    handheld = _handheld(equipment, body, skin, child=child, hands=hands)
    root = _draw_figure(appearance, {**equipment, "background": "transparent"}, view="full",
                        title=title, handheld=handheld)
    upper = root.find("./*[@clip-path='url(#portrait-frame)']")
    defs = root.find(tag("defs"))
    if hands is not None:
        clip = node(defs, "clipPath", id="full-costume-hands-clip")
        wrist_y = 440 if outfit in FULL_HEMS else (447 if child else 445)
        node(clip, "rect", x=0, y=wrist_y, width=320, height=752 - wrist_y)
    lower = ET.Element(tag("g"), {"data-part": "full-costume"})
    root.insert(list(root).index(upper), lower)
    gradient = _BACKGROUNDS.get(equipment["background"])
    if gradient:
        backdrop = ET.Element(tag("rect"), width=root.get("width"), height=root.get("height"),
                              fill=f"url(#{gradient})")
        if child:
            root.insert(list(root).index(lower), backdrop)
        else:
            lower.append(backdrop)
        node(lower, "ellipse", cx=160, cy=_CHILD_DRAWING_GROUND_Y if child else _GROUND_Y, rx=98 if child else 113,
             ry=10, fill="#261f20", opacity=".5")
    draw_back_equipment(lower, {**appearance, **equipment}, adult_cut)
    work_shirt = appearance["cast"] == "women" and outfit == "rus_work_shirt"
    dress = appearance["cast"] == "women" and outfit not in ARMORED_OUTFITS and not work_shirt
    footwear, legwear = _LOWER_WEAR.get(outfit, ("shoe", "trousers"))
    if work_shirt:
        legwear = "hose"
    if child:
        lower = node(lower, "g", transform=_CHILD_LOWER_TRANSFORM)
    has_foot_details = any(equipment.get(slot, "none") != "none"
                           for slot in ("foot_lining", "shoe_accessory"))
    lower_wear = {
        "trousers": equipment.get("trousers", _TROUSERS_BY_CUT[legwear]),
        "leg_wraps": equipment.get("leg_wraps", "wool" if legwear == "bindings" else "none"),
        "footwear": equipment.get("footwear", _SHOES_BY_CUT[footwear]),
    }
    has_leg_protection = equipment.get("leg_protection", "none") != "none"
    if LOWER_OPTIONS.keys() & equipment.keys() or footwear in {"barefoot", "cloth_shoes"} or has_foot_details or has_leg_protection:
        draw_lower_wear(lower, body, dress=dress, skin=skin, **lower_wear,
                        foot_lining=equipment.get("foot_lining", "none"),
                        insole=equipment.get("insole", "none"),
                        shoe_accessory=equipment.get("shoe_accessory", "none"))
    else:
        for right in (False, True):
            side = node(lower, "g", transform=_REFLECT) if right else node(lower, "g")
            if not dress:
                _leg(side, hose=legwear == "hose", bindings=legwear == "bindings", half=min(body.waist, 73),
                     footwear=footwear)
            _shoe(side, style=footwear, x=9 if dress else 0)
    if hands is None:
        _hands(lower, adult_cut, skin, equipment, child=child)
    if not child and has_leg_protection:
        image_armour_art.draw_leg_protection(lower, {**appearance, **equipment}, body,
                                             dress=dress, lower_wear=lower_wear)
    if equipment.get("cloak", "none") == "none":
        waist = draw_waist_accessories(root, {**appearance, **equipment}, full=True)
        if "cloak" not in equipment and (waist is not None or handheld is not None):
            mask = _mask_for_bundled_drape(root, upper, outfit)
            if mask is not None:
                if waist is not None:
                    root.remove(waist)
                    node(root, "g", mask=mask).append(waist)
                if handheld is not None:
                    handheld.set("mask", mask)
        if handheld is not None:
            root.append(handheld)
    if equipment.get("vestment", "none") != "none":
        _cover_waist_with_vestment(root, upper)
    shield = equipment.get("shield", "none")
    if not child and shield != "none" and equipment.get("shield_carry") != "back":
        foreground = node(root, "g", data_part="held-shield-equipment", clip_path="url(#portrait-frame)")
        left, right = _hand_edges(adult_cut, outfit)
        grip_x = 320 - (left + right) / 2
        cloak = equipment.get("cloak", "none")
        bundled_cloak = outfit == "cloak" and "cloak" not in equipment
        if cloak in {*HANDHELD_HIDDEN_BY["weapon"], "rus_korzno"} or bundled_cloak:
            # Lift a small fold over the supporting forearm. The opening reveals
            # the actual underlying sleeve, including its armour and material;
            # the front of the shield still conceals the hand and grip.
            # Follow the local rim at x=-14, 0 and 17, rather than its highest
            # point: round shields slope down steeply beside the wrist.
            rim_left, rim_middle, rim_right = {
                "round": (-30, -28, -21), "kite": (-34, -33, -28),
                "triangular": (-31, -30, -28),
                "novgorod_george": (-40, -36, -26),
                "novgorod_dish": (-73, -70, -64),
                "yuriev_lion": (-71, -69, -63), "gokstad": (-53, -46, -31),
                "szczecin_painted": (-72, -65, -56), "lewis": (-65, -63, -58),
            }[shield]
            x = grip_x
            fold = (f"M{number(x - 14)} {452 + rim_left}"
                    f"Q{number(x)} {452 + 2 * rim_middle - (rim_left + rim_right) / 2} "
                    f"{number(x + 17)} {452 + rim_right}")
            opening = f"{fold}L{number(x + 17)} 471H{number(x - 14)}Z"
            mask_id = "held-shield-arm-opening"
            mask = node(defs, "mask", id=mask_id, maskUnits="userSpaceOnUse",
                        x=0, y=0, width=320, height=752)
            node(mask, "rect", x=0, y=0, width=320, height=752, fill="white")
            path(mask, opening, "black")
            fabrics = root.findall(".//*[@data-part='cloak']")
            if bundled_cloak:
                fabrics += root.findall(".//*[@data-part='cloak-fabric']")
                fabrics += root.findall(".//*[@clip-path='url(#wardrobe-cloak-mask)']")
            for fabric in fabrics:
                fabric.set("mask", f"url(#{mask_id})")
            path(foreground, fold, "none", stroke="#372923", stroke_width=1.8,
                 stroke_linecap="round", data_part="shield-arm-fold")
        draw_shield(foreground, shield, x=grip_x, y=459)
    if child:
        layers = root.findall(tag("g"))
        figure = node(root, "g", data_part="child-figure",
                      transform=f"translate(160 {_GROUND_Y}) scale({_CHILD_FIGURE_SCALE}) "
                                f"translate(-160 {-_CHILD_DRAWING_GROUND_Y})")
        for layer in layers:
            root.remove(layer)
            figure.append(layer)
    if portrait:
        _crop_at_waist(root, child=child, outfit=outfit)
    return ET.tostring(root, encoding="unicode")
