from common import node, number, path


def _woven_edge(parent, contour, width):
    path(parent, contour, "none", stroke="#402e2a", stroke_width=width + 3)
    path(parent, contour, "none", stroke="#b98e61", stroke_width=width)
    path(parent, contour, "none", stroke="#704735", stroke_width=width - 4)
    path(
        parent, contour, "none", stroke="#dfbe86", stroke_width=width - 6,
        stroke_dasharray="1.4 3.5",
    )


def draw_izyaslav(art):
    front, cloth, body = art.front, art.cloth, art.body
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    left, right = 160 - body.shoulder, 160 + body.shoulder
    crest = body.shoulder_y
    sleeve_join = (
        f"M{left + 9} {crest - 12} Q{left + 15} {crest + 13} {left + 5} 327 "
        f"Q{left - 1} 339 {left - 15} 350"
    )
    for sleeve in art.sleeves:
        _woven_edge(sleeve, sleeve_join, 11)
    _woven_edge(
        front,
        sleeve_join
        + f" M{right - 9} {crest - 12} Q{right - 15} {crest + 13} {right - 5} 327 "
        f"Q{right + 1} 339 {right + 15} 350",
        11,
    )
    path(
        front,
        f"M{neck_left} 273 Q157 304 {neck_right} 273 L{number(166 + art.neck)} 292 "
        f"Q159 326 {number(154 - art.neck)} 285Z",
        cloth.deep, class_="edge",
    )
    path(
        front,
        f"M{number(156 - art.neck)} 281 Q156 312 {number(163 + art.neck)} 280",
        "none", stroke="#ceaa76", stroke_width="2.8",
    )
    path(
        front,
        "M143 302 Q158 300 173 287 Q180 337 174 400 H132 Q153 361 143 302Z",
        cloth.light, opacity=".34",
    )
    path(
        front, "M172 290 Q185 337 183 373 L181 402 H195 Q200 346 183 288Z",
        cloth.deep, opacity=".56",
    )
    _woven_edge(front, "M173 291 Q182 331 181 354 L179 399", 14)
    path(front, "M160 316 Q162 327 160 337 M160 358 Q158 370 157 380", class_="etch")

    waist_left, waist_right = 160 - body.waist, 160 + body.waist
    folds = node(art.waist, "g", data_part="kaftan-gathers")
    if art.hem_y is None:
        path(folds, "M55 398 Q160 405 265 398 V445 H55Z", cloth.base)
    else:
        edge = max(112, art.hem_half + 4)
        path(folds, f"M{160 - edge} 398 Q160 405 {160 + edge} 398 V{art.hem_y + 12} H{160 - edge}Z",
             cloth.base)
    for index, x in enumerate(range(waist_left + 2, waist_right, 9)):
        flare = round((x - 160) / 7)
        end = 424 + 9 * (index % 3)
        if art.hem_y is not None:
            flare = round((x - 160) * (art.hem_half / body.waist - 1))
            end = art.hem_y - (3, 17, 9, 24)[index % 4]
            span = end - 403
            middle = x + flare // 2
            tip = x + flare
            path(folds, f"M{x} 403 C{middle - 7} {403 + span // 3} {tip - 3} {end - 21} {tip} {end} "
                 f"Q{tip + 6} {end - 26} {middle + 4} {403 + span // 2} "
                 f"Q{x + 2} 423 {x + 3} 403Z",
                 cloth.shade, opacity=".74")
            path(folds, f"M{x + 4} 407 Q{middle + 6} {403 + span // 2} {tip + 3} {end - 9}",
                 "none", stroke=cloth.light, stroke_width="1.7", opacity=".66")
            path(folds, f"M{x + 1} 406 Q{middle - 2} 419 {x + flare // 4} 433", class_="etch")
            continue
        path(
            folds,
            f"M{x} 403 Q{x + flare // 2 - 5} 419 {x + flare - 3} {end} "
            f"Q{x + flare + 5} 423 {x + 4} 403Z",
            cloth.shade,
        )
        path(
            folds,
            f"M{x + 4} 407 Q{x + flare // 2 + 5} 416 {x + flare + 7} {end - 4}",
            "none", stroke=cloth.light, stroke_width="1.7", opacity=".78",
        )
        path(folds, f"M{x} 406 Q{x + flare // 2 - 2} 415 {x + flare} {end - 8}", class_="etch")
    if art.hem_y is not None:
        path(folds, f"M{165 - art.hem_half} {art.hem_y - 7} Q160 {art.hem_y + 12} "
             f"{155 + art.hem_half} {art.hem_y - 7}", class_="seam", opacity=".74")
    _woven_edge(art.waist, f"M{waist_left - 8} 399 Q160 406 {waist_right + 8} 399", 9)


def _draw_korzno_full_panel(art, neck_right, far_right, clasp, edge, left_fold):
    outer, cloth = art.outer, art.cloth
    right = 160 + art.body.shoulder
    hem = art.hem_y
    hem_right = 160 + art.hem_half
    opening = f"C{clasp + 11} 377 {clasp + 5} {hem - 45} 160 {hem + 9.5}"
    panel = (
        f"M{clasp} 299 Q183 290 {neck_right} 273 "
        f"Q{right + 11} 272 {far_right} 326 C{far_right + 6} 369 {far_right + 7} 410 {far_right + 3} 428 "
        f"C{far_right - 2} 446 {right + 12} 461 {right + 10} 480 "
        f"Q{hem_right - 3} {hem - 26} {hem_right} {hem} "
        f"Q{number(160 + art.hem_half / 2)} {hem + 9.5} 160 {hem + 9.5} "
        f"C{clasp + 5} {hem - 45} {clasp + 11} 377 {clasp} 299Z"
    )
    path(outer, panel, cloth.base, class_="edge")
    path(outer, left_fold, cloth.light)
    path(node(outer, "clipPath", id="wardrobe-korzno-panel-mask"), panel)
    folds = node(outer, "g", clip_path="url(#wardrobe-korzno-panel-mask)")
    path(
        folds,
        f"M{neck_right} 277 Q{right - 17} 290 {right - 10} 322 "
        f"C{right + 5} 363 {right + 4} {hem - 55} {hem_right - 26} {hem + 4} "
        f"L{hem_right - 46} {hem + 6} Q{right - 16} 381 179 299Z",
        cloth.light,
    )
    path(
        folds,
        f"M{right + 11} 305 Q{far_right - 13} 329 {far_right} 344 "
        f"C{far_right + 21} 416 {hem_right + 4} 451 {hem_right + 16} {hem + 2} "
        f"L{hem_right - 15} {hem + 3} Q{right + 14} 388 {right + 11} 305Z "
        f"M{clasp + 11} 312 Q{clasp + 26} 371 {clasp + 19} {hem - 77} "
        f"Q{clasp + 16} {hem - 11} {clasp + 12} {hem + 11} L155 {hem + 12} "
        f"Q{clasp + 9} {hem - 58} {clasp + 11} 312Z",
        cloth.shade,
    )
    path(
        folds,
        f"M{right + 17} 331 Q{right + 29} 387 {right + 15} 444 "
        f"Q{right + 12} {hem - 48} {hem_right - 23} {hem - 4} "
        f"Q{right + 6} {hem - 47} {right + 4} 324Z",
        "url(#ink-lines)", opacity=".49",
    )
    path(
        folds,
        f"M{right - 21} 322 Q{right - 11} 350 {right - 14} 403 "
        f"M{right + 12} 377 Q{right + 16} 412 {right + 7} 438 "
        f"M{right - 35} 441 Q{right - 30} {hem - 58} {right - 34} {hem - 17}",
        class_="seam",
    )
    path(outer, edge + opening, "none", stroke="#d0a16a", stroke_width="6.2", stroke_linejoin="round")


def draw_korzno(art):
    outer, cloth, body = art.outer, art.cloth, art.body
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    left = 160 - body.shoulder
    far_left, far_right = 151 - body.sleeve, 170 + body.sleeve
    clasp = 169

    for sleeve in art.sleeves:
        path(
            sleeve, f"M{far_left} 346 q35 -10 79 -5 m-79 10 q35 -10 79 -5",
            "none", stroke="#a56f48", stroke_width="2.5",
        )
        path(
            sleeve, f"M{far_left} 421 q37 4 83 -3 m-83 9 q37 4 83 -3",
            "none", stroke="#a56f48", stroke_width="2.5",
        )

    # The short edge crosses one shoulder. The other hangs almost vertically from the clasp.
    upper_edge = f"M{neck_left} 273 Q148 296 {clasp} 299 Q180 285 {neck_right} 273"
    left_wing = (
        f"M{neck_left} 273 C{left + 17} 274 {far_left + 2} 283 {far_left} 321 "
        f"Q{left + 25} 320 {clasp} 299 Q145 288 {neck_left} 273Z"
    )
    path(outer, left_wing, cloth.base, class_="edge")
    edge = upper_edge + f" M{far_left} 319 Q{left + 25} 319 {clasp} 299 "
    left_fold = f"M{neck_left} 276 Q{left + 10} 276 {left - 8} 305 Q{left + 11} 296 139 292Z"
    if art.hem_y is None:
        _draw_korzno_portrait_panel(art, neck_right, far_right, clasp, edge, left_fold)
    else:
        _draw_korzno_full_panel(art, neck_right, far_right, clasp, edge, left_fold)
    pin = node(outer, "g", data_part="korzno-clasp")
    node(pin, "circle", cx=clasp, cy=299, r=10, fill="#b98b53", class_="edge")
    node(pin, "circle", cx=clasp, cy=299, r=4, fill="#634334", stroke="#e6bc79", stroke_width="1.8")
    path(pin, f"M{clasp - 6} 295q4 -6 10 -2", "none", stroke="#f3d69a", stroke_width="1.65")


def _draw_korzno_portrait_panel(art, neck_right, far_right, clasp, edge, left_fold):
    outer, cloth = art.outer, art.cloth
    right = 160 + art.body.shoulder
    hanging_panel = (
        f"M{neck_right} 273 Q{right + 11} 272 {far_right} 326 L{far_right + 3} 446 "
        f"H{clasp + 4} Q{clasp + 8} 374 {clasp} 299 Q183 290 {neck_right} 273Z"
    )
    path(outer, hanging_panel, cloth.base, class_="edge")
    path(
        outer,
        left_fold + " "
        f"M{neck_right} 277 Q{right - 17} 290 {right - 10} 322 "
        f"Q{right + 5} 363 {right + 4} 443 H{right - 9} Q{right - 17} 329 179 299Z",
        cloth.light,
    )
    path(
        outer,
        f"M{clasp + 9} 317 Q{right - 21} 355 {right - 19} 445 H{clasp + 5}Z "
        f"M{right + 11} 305 Q{far_right - 13} 329 {far_right} 344 L{far_right + 3} 446 "
        f"H{right + 6} Q{right + 16} 377 {right + 11} 305Z",
        cloth.shade,
    )
    path(
        outer,
        f"M{right + 17} 331 Q{right + 22} 388 {right + 15} 445 H{right + 4} "
        f"Q{right + 13} 374 {right + 4} 324Z",
        "url(#ink-lines)", opacity=".56",
    )
    path(
        outer,
        f"M{clasp + 2} 305 Q{clasp + 12} 373 {clasp + 6} 446 L{clasp + 15} 446 "
        f"Q{clasp + 22} 371 {clasp + 11} 304Z",
        cloth.deep, opacity=".6",
    )
    path(
        outer,
        edge + f"Q{clasp + 9} 373 {clasp + 5} 446",
        "none", stroke="#d0a16a", stroke_width="6.2", stroke_linejoin="round",
    )
    path(outer, f"M{right - 21} 322 Q{right - 11} 350 {right - 14} 403 M{right + 12} 377l-3 39", class_="seam")


def draw_ryazan_sleeves(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = number(160 - art.neck), number(160 + art.neck)
    path(
        front,
        f"M{left} 274 Q160 306 {right} 274 Q176 291 167 299 V318 "
        f"Q160 325 153 318 V299 Q143 292 {left} 274Z",
        cloth.deep, class_="edge",
    )
    path(
        front,
        f"M{left} 275 Q146 293 157 298 V316 Q160 318 163 316 V298 Q174 292 {right} 275",
        "none", stroke="#dfb985", stroke_width="3.4",
    )
    path(front, "M160 299v16", "none", stroke="#b99972", stroke_width="1.7")

    shoulder = 160 - body.shoulder
    outside = 160 - body.sleeve
    inner = 168 - body.waist
    for sleeve in art.sleeves:
        cuff_left = outside - 7
        billow = (
            f"M{shoulder + 5} 312 Q{outside + 18} 349 {outside + 5} 371 "
            f"Q{outside - 5} 400 {outside + 15} 425 L{inner} 436 "
            f"Q{inner - 4} 414 {inner + 4} 387 Q{shoulder + 23} 357 {shoulder + 18} 313Z"
        )
        path(sleeve, billow, cloth.base)
        path(
            sleeve,
            f"M{outside + 19} 350 Q{outside - 2} 394 {outside + 23} 424 L{outside + 11} 425 "
            f"Q{outside - 7} 397 {outside + 5} 377Z "
            f"M{inner - 8} 365 Q{inner - 12} 402 {inner + 2} 426 H{inner - 11} "
            f"Q{inner - 21} 404 {inner - 8} 365Z",
            cloth.shade,
        )
        path(
            sleeve,
            f"M{outside + 26} 363 Q{outside + 12} 402 {outside + 31} 427 "
            f"L{outside + 37} 424 Q{outside + 21} 408 {outside + 26} 363Z",
            cloth.light,
        )
        path(
            sleeve,
            f"M{outside + 6} 369 Q{outside - 7} 402 {outside + 16} 422 "
            f"L{outside + 24} 423 Q{outside + 7} 399 {outside + 13} 364Z",
            "url(#ink-lines)", opacity=".5",
        )
        path(
            sleeve,
            f"M{outside + 10} 382 Q{outside + 3} 407 {outside + 24} 424 "
            f"M{inner - 16} 386 Q{inner - 20} 407 {inner - 8} 426",
            class_="seam",
        )
        path(
            sleeve,
            f"M{outside + 14} 391 q-3 12 4 22 m0 -14 q0 8 5 15 "
            f"M{inner - 12} 394 q-2 10 3 18",
            class_="etch",
        )
        cuff = node(sleeve, "g", data_part="ryazan-bracer")
        if art.hem_y is not None:
            wrist = 171 - body.hem
            cuff_left = outside + 9
            path(
                cuff,
                f"M{cuff_left} 416 Q{outside + 26} 423 {wrist + 9} 416 "
                f"L{wrist} 445 H{outside + 24}Z",
                "#a3987b", class_="edge",
            )
            path(
                cuff,
                f"M{cuff_left + 3} 421 Q{outside + 27} 428 {wrist + 8} 421 "
                f"M{outside + 23} 440 Q{outside + 33} 444 {wrist + 1} 440",
                "none", stroke="#5d544c", stroke_width="1.8",
            )
            for x in range(outside + 24, wrist - 2, 7):
                path(cuff, f"M{x} 432l2 -2 2 2-2 2Z", "#e1d0a5", stroke="#66554a", stroke_width=".8")
            continue
        path(
            cuff,
            f"M{cuff_left} 414 Q{outside + 23} 423 {inner} 415 L{inner + 1} 438 "
            f"Q{outside + 24} 447 {cuff_left + 3} 437Z",
            "#a3987b", class_="edge",
        )
        path(
            cuff,
            f"M{cuff_left} 418 Q{outside + 24} 427 {inner} 419 "
            f"M{cuff_left + 2} 433 Q{outside + 24} 443 {inner} 434",
            "none", stroke="#5d544c", stroke_width="1.8",
        )
        for x in range(outside + 10, inner - 3, 7):
            path(
                cuff, f"M{x} 428l2 -2 2 2 -2 2Z",
                "#e1d0a5", stroke="#66554a", stroke_width=".8",
            )


def draw_rus_mantle(art):
    outer, cloth, body = art.outer, art.cloth, art.body
    left, right = 160 - body.shoulder, 160 + body.shoulder
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    outside_left, outside_right = 152 - body.sleeve, 168 + body.sleeve
    lower_left, lower_right = 160 - body.chest, 160 + body.chest
    for sleeve in art.sleeves:
        path(
            sleeve, f"M{outside_left} 418 Q{left - 10} 425 {left + 26} 414",
            "none", stroke="#936d51", stroke_width="8.5",
        )
        path(
            sleeve, f"M{outside_left} 418 Q{left - 10} 425 {left + 26} 414",
            "none", stroke="#c99c62", stroke_width="3.3",
        )
    cape = (
        f"M{neck_left} 272 Q{left - 19} 269 {outside_left} 322 "
        f"Q{outside_left + 7} 361 {lower_left} 366 Q117 389 145 378 "
        f"Q158 358 160 322 Q162 358 175 378 Q203 389 {lower_right} 366 "
        f"Q{outside_right - 7} 361 {outside_right} 322 "
        f"Q{right + 19} 269 {neck_right} 272 Q177 284 160 290 Q143 284 {neck_left} 272Z"
    )
    path(outer, cape, cloth.base, class_="edge")
    path(
        outer,
        f"M{neck_left} 279 Q{left + 2} 281 {left - 14} 312 "
        f"Q{left + 18} 293 147 301Z "
        f"M{neck_right} 279 Q{right - 2} 281 {right + 14} 312 "
        f"Q{right - 18} 293 173 301Z",
        cloth.light,
    )
    path(
        outer,
        f"M154 307 Q{left + 30} 326 {lower_left + 14} 369 Q125 381 143 375 "
        f"Q151 358 151 343Z M166 307 Q{right - 30} 326 {lower_right - 14} 369 "
        f"Q195 381 177 375 Q169 358 169 343Z",
        cloth.shade,
    )
    path(
        outer,
        f"M144 310 Q{left + 24} 319 {left + 16} 354 L{left + 5} 358 "
        f"Q{left + 7} 327 144 310Z M176 310 Q{right - 24} 319 {right - 16} 354 "
        f"L{right - 5} 358 Q{right - 7} 327 176 310Z",
        "url(#ink-lines)", opacity=".55",
    )
    path(
        outer,
        f"M151 306 Q127 318 {left + 15} 326 M148 313 Q130 332 123 365 "
        f"M169 306 Q193 318 {right - 15} 326 M172 313 Q190 332 197 365",
        class_="seam",
    )
    path(
        outer,
        f"M{neck_left} 277 Q144 295 160 303 Q176 295 {neck_right} 277",
        "none", stroke=cloth.light, stroke_width="4.6", stroke_linecap="round",
    )
    path(outer, "M144 297 Q153 307 160 304 Q167 307 176 297 M158 309l-7 12 m11 -12 7 12", class_="etch")
    path(outer, "M149 303 Q154 297 160 302 Q166 297 171 303 Q167 307 160 306 Q153 307 149 303Z", cloth.deep)


DRAWERS = {
    "izyaslav_kaftan": draw_izyaslav,
    "korzno": draw_korzno,
    "ryazan_sleeves": draw_ryazan_sleeves,
    "rus_mantle": draw_rus_mantle,
}
