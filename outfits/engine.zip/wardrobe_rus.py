from common import node, number, path


def izyaslav_neckline(neck):
    return (f"Q{number(163 + neck)} 269 {number(156 + neck)} 263 "
            f"Q160 282 {number(164 - neck)} 263 Q{number(157 - neck)} 269 {number(160 - neck)} 273")


def _izyaslav_wrap_x(waist):
    return 161 + round(.40 * waist)


def izyaslav_hem(hem, half, waist):
    # The right front (viewer left) hangs over the left front at the bottom of the opening.
    overlap = _izyaslav_wrap_x(waist) + 2
    outer = f"Q143 {hem + 18} {overlap} {hem + 10}"
    inner = f"Q{(overlap + 160 + half) // 2} {hem + 12} {160 + half} {hem}"
    return overlap, outer, inner


def _kaftan_edging(parent, contour, cloth, width, *, stitch=None):
    edge = node(parent, "g", data_part="kaftan-cotton-edging")
    path(edge, contour, "none", stroke=cloth.deep, stroke_width=width + 1.4)
    path(edge, contour, "none", stroke=cloth.shade, stroke_width=width)
    if stitch is not None:
        dx, dy = stitch
        path(edge, contour, "none", stroke="#c6ad90", stroke_width=.9, stroke_dasharray="1.8 1.25",
             opacity=".66", transform=f"translate({dx} {dy})", data_material_surface="fixed")


def _draw_izyaslav_gathers(art):
    folds = node(art.front, "g", data_part="kaftan-gathers")
    waist = art.body.waist
    left = 160 - waist
    bottom = art.hem_y or 445
    hem_half = art.hem_half or art.body.hem
    fine = []
    for index, x in enumerate(range(left + 3, 158 + waist, 4)):
        top = 403 - round(5 * ((x - 160) / (waist + 6)) ** 2)
        end = top + (8, 13, 10, 19, 11, 15)[index % 6]
        drift = round((x - 160) / 28)
        fine.append(f"M{x} {top}q-1 5 {drift} {end - top}")
    path(folds, " ".join(fine), "none", stroke=art.cloth.deep, stroke_width=.95,
         stroke_linecap="round", opacity=".53")

    for index, x in enumerate(range(left + 7, 157 + waist, 17)):
        drift = round((x - 160) * ((hem_half - 6) / waist - 1))
        start = 409 + (index % 3) * 3
        end = bottom - (11, 34, 20, 45)[index % 4] if art.hem_y else bottom + 5
        middle = round((start + end) / 2)
        tip = x + drift
        path(folds, f"M{x} {start} Q{x - 6 + drift // 2} {middle} {tip - 4} {end} "
             f"Q{tip + 8} {end - 13} {x + 4 + drift // 2} {middle} Q{x + 1} {start + 14} {x} {start}Z",
             art.cloth.shade, opacity=".42")
        path(folds, f"M{x + 6} {start + 8} Q{x + 8 + drift // 2} {middle} {tip + 6} {end - 6}",
             "none", stroke=art.cloth.light, stroke_width=1.5, stroke_linecap="round", opacity=".36")


def _draw_izyaslav_samite(art):
    samite = node(art.waist, "g", data_part="kaftan-samite", data_material_surface="fixed")
    left, right = 154 - art.body.waist, 166 + art.body.waist
    # The sewn waist seams of the two fronts meet at the same height when the kaftan is closed.
    seam = f"M{left} 397 Q160 407 {right} 397"
    path(samite, seam, "none", stroke="#524c4c", stroke_width=5.7)
    path(samite, seam, "none", stroke="#857268", stroke_width=4.2)
    path(samite, seam, "none", stroke="#9e9483", stroke_width=1.1, stroke_dasharray="1.4 2.4", opacity=".6")
    for dy, thread in ((-1.7, "#b29a85"), (1.7, "#aa8f79")):
        path(samite, seam, "none", stroke=thread, stroke_width=.7, transform=f"translate(0 {dy})", opacity=".72")


def draw_izyaslav(art):
    front, cloth, body = art.front, art.cloth, art.body
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    shoulders = node(art.outer, "g", data_part="kaftan-sleeve-trim")
    mirrored = node(shoulders, "g", transform="translate(320 0) scale(-1 1)")
    for side in (shoulders, mirrored):
        _kaftan_edging(side, art.armhole, cloth, 10, stitch=(2.8, -1.8))

    left, right = 160 - body.chest, 160 + body.chest
    path(front, f"M{neck_left} 277 Q{left + 17} 282 {left + 4} 309 Q{left + 17} 328 {left + 7} 373 "
         f"Q{left + 27} 350 {left + 34} 322 Q{left + 41} 301 {neck_left} 277Z", cloth.light, opacity=".36")
    path(front, f"M{neck_right} 278 Q{right - 12} 287 {right + 7} 314 "
         f"Q{right - 13} 349 {right - 4} 400 L{right - 25} 401 Q{right - 17} 327 {neck_right} 278Z",
         cloth.shade, opacity=".49")
    path(front, f"M{left + 17} 322 Q{left + 9} 342 {left + 8} 361 M{left + 19} 376q-5 9-7 19 "
         f"M{right - 20} 322q14 24 15 39 M149 361q-2 20 0 33 M138 380q-1 9 1 15",
         class_="etch", opacity=".75")

    collar = node(front, "g", data_part="kaftan-collar")
    path(collar, f"M{neck_right} 273 {izyaslav_neckline(art.neck)} Q160 302 {neck_right} 273Z", cloth.shade)
    path(collar, f"M{number(164 - art.neck)} 268 Q160 288 {number(156 + art.neck)} 268", "none",
         stroke=cloth.light, stroke_width=1.6, stroke_linecap="round")
    path(collar, f"M{neck_left} 273 Q160 302 {neck_right} 273", "none",
         stroke=cloth.deep, stroke_width=2.35)
    path(collar, "M164 272 Q161 278 164 285", "none", stroke=cloth.deep, stroke_width=1.9)

    _draw_izyaslav_gathers(art)
    x = _izyaslav_wrap_x(body.waist)
    if art.hem_y is not None:
        hem, half = art.hem_y, art.hem_half
        end_x, left_hem, right_hem = izyaslav_hem(hem, half, body.waist)
        edge = node(front, "g", data_part="kaftan-hem")
        _kaftan_edging(edge, f"M{160 - half} {hem} {left_hem}", cloth, 16)
        _kaftan_edging(edge, f"M{end_x} {hem + 4} {right_hem}", cloth, 16)
        end_y = hem + 10
    else:
        end_x, end_y = x + 1, 449
    opening = node(front, "g", data_part="kaftan-wrap")
    contour = f"M164 284 C167 323 {x - 6} 365 {x} 400 Q{x - 4} {(400 + end_y) // 2} {end_x} {end_y}"
    path(opening, f"{contour} l8 -5 Q{x + 2} {(400 + end_y) // 2} {x + 7} 396 "
         f"Q{x + 5} 364 164 284Z", cloth.deep, opacity=".42")
    _kaftan_edging(opening, contour, cloth, 10, stitch=(-2.8, .6))
    _draw_izyaslav_samite(art)


def _draw_korzno_full_panel(art, neck_right, far_right, clasp, edge, left_fold):
    outer, cloth = art.outer, art.cloth
    right = 160 + art.body.shoulder
    crest = art.body.shoulder_y
    hem = art.hem_y
    hem_right = 160 + art.hem_half
    opening = f"C{clasp + 11} 377 {clasp + 5} {hem - 45} 160 {hem + 9.5}"
    panel = (
        f"M{clasp} 299 Q183 290 {neck_right} 273 "
        f"C{float(neck_right) + 14} 270 {right - 12} {crest - 13} {right + 3} {crest - 2} "
        f"C{right + 28} {crest + 14} {far_right - 3} 323 {far_right + 1} 347 "
        f"C{far_right + 6} 375 {far_right + 7} 410 {far_right + 3} 428 "
        f"C{far_right - 2} 446 {right + 12} 461 {right + 10} 480 "
        f"Q{hem_right - 3} {hem - 26} {hem_right} {hem} "
        f"Q{number(160 + art.hem_half / 2)} {hem + 9.5} 160 {hem + 9.5} "
        f"C{clasp + 5} {hem - 45} {clasp + 11} 377 {clasp} 299Z"
    )
    path(outer, panel, cloth.base, class_="edge", data_part="korzno-cloth-panel")
    path(outer, left_fold, cloth.light)
    path(node(outer, "clipPath", id="wardrobe-korzno-panel-mask"), panel)
    folds = node(outer, "g", clip_path="url(#wardrobe-korzno-panel-mask)")
    path(
        folds,
        f"M{neck_right} 277 Q{right - 17} 290 {right - 10} 322 "
        f"C{right + 5} 363 {right + 4} {hem - 55} {hem_right - 26} {hem + 4} "
        f"L{hem_right - 46} {hem + 6} Q{right - 16} 381 179 299Z",
        cloth.light,
    )
    path(
        folds,
        f"M{right + 11} 305 Q{far_right - 13} 329 {far_right} 344 "
        f"C{far_right + 21} 416 {hem_right + 4} 451 {hem_right + 16} {hem + 2} "
        f"L{hem_right - 15} {hem + 3} Q{right + 14} 388 {right + 11} 305Z "
        f"M{clasp + 11} 312 Q{clasp + 26} 371 {clasp + 19} {hem - 77} "
        f"Q{clasp + 16} {hem - 11} {clasp + 12} {hem + 11} L155 {hem + 12} "
        f"Q{clasp + 9} {hem - 58} {clasp + 11} 312Z",
        cloth.shade,
    )
    path(
        folds,
        f"M{right + 17} 331 Q{right + 29} 387 {right + 15} 444 "
        f"Q{right + 12} {hem - 48} {hem_right - 23} {hem - 4} "
        f"Q{right + 6} {hem - 47} {right + 4} 324Z",
        "url(#ink-lines)", opacity=".49",
    )
    path(
        folds,
        f"M{right - 21} 322 Q{right - 11} 350 {right - 14} 403 "
        f"M{right + 12} 377 Q{right + 16} 412 {right + 7} 438 "
        f"M{right - 35} 441 Q{right - 30} {hem - 58} {right - 34} {hem - 17}",
        class_="seam",
    )
    path(outer, edge + opening, "none", stroke="#d0a16a", stroke_width="6.2", stroke_linejoin="round")


def draw_korzno(art):
    outer, cloth, body = art.outer, art.cloth, art.body
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    left = 160 - body.shoulder
    crest = body.shoulder_y
    far_left, far_right = 151 - body.sleeve, 170 + body.sleeve
    clasp = 169

    for sleeve in art.sleeves:
        path(
            sleeve, f"M{far_left} 346 q35 -10 79 -5 m-79 10 q35 -10 79 -5",
            "none", stroke="#a56f48", stroke_width="2.5",
        )
        path(
            sleeve, f"M{far_left} 421 q37 4 83 -3 m-83 9 q37 4 83 -3",
            "none", stroke="#a56f48", stroke_width="2.5",
        )

    # A broad shoulder fold rests on the upper arm and rises softly to the clasp.
    upper_edge = f"M{neck_left} 273 Q148 296 {clasp} 299 Q180 285 {neck_right} 273"
    left_wing = (
        f"M{neck_left} 273 C{float(neck_left) - 14} 271 {left + 12} {crest - 13} {left - 3} {crest - 2} "
        f"C{left - 25} {crest + 12} {far_left + 1} 315 {far_left - 2} 339 "
        f"Q{far_left + 3} 355 {left + 13} 361 "
        f"C{left + 39} 349 137 328 {clasp} 299 Q145 288 {neck_left} 273Z"
    )
    path(outer, left_wing, cloth.base, class_="edge", data_part="korzno-cloth-panel")
    edge = (upper_edge + f" M{far_left - 2} 339 Q{far_left + 3} 355 {left + 13} 361 "
            f"C{left + 39} 349 137 328 {clasp} 299 ")
    left_fold = (f"M{neck_left} 277 C{left + 12} 274 {left - 16} {crest + 11} {far_left + 8} 334 "
                 f"Q{left + 4} 326 {left + 20} 337 C{left + 45} 326 143 316 {clasp - 3} 302 "
                 f"Q145 286 {neck_left} 277Z")
    if art.hem_y is None:
        _draw_korzno_portrait_panel(art, neck_right, far_right, clasp, edge, left_fold)
    else:
        _draw_korzno_full_panel(art, neck_right, far_right, clasp, edge, left_fold)
    # The full-costume mask reads the first two paths: keep both opaque panels first.
    path(outer, f"M{clasp - 4} 303 Q{left + 30} 320 {left + 13} 356 "
         f"Q{left + 5} 346 {left + 11} 329 Q125 315 {clasp - 4} 303Z", cloth.shade)
    path(outer, f"M{left - 9} {crest + 28} Q{left + 3} 326 {left + 16} 347 "
         f"M{left + 23} {crest + 18} Q{left + 42} 319 {clasp - 12} 308", class_="seam")
    pin = node(outer, "g", data_part="korzno-clasp")
    node(pin, "circle", cx=clasp, cy=299, r=10, fill="#b98b53", class_="edge")
    node(pin, "circle", cx=clasp, cy=299, r=4, fill="#634334", stroke="#e6bc79", stroke_width="1.8")
    path(pin, f"M{clasp - 6} 295q4 -6 10 -2", "none", stroke="#f3d69a", stroke_width="1.65")


def _draw_korzno_portrait_panel(art, neck_right, far_right, clasp, edge, left_fold):
    outer, cloth = art.outer, art.cloth
    right = 160 + art.body.shoulder
    crest = art.body.shoulder_y
    hanging_panel = (
        f"M{neck_right} 273 C{float(neck_right) + 14} 270 {right - 12} {crest - 13} {right + 3} {crest - 2} "
        f"C{right + 28} {crest + 14} {far_right - 3} 323 {far_right + 1} 347 "
        f"C{far_right + 6} 375 {far_right + 7} 410 {far_right + 3} 446 "
        f"H{clasp + 4} Q{clasp + 8} 374 {clasp} 299 Q183 290 {neck_right} 273Z"
    )
    path(outer, hanging_panel, cloth.base, class_="edge", data_part="korzno-cloth-panel")
    path(outer, left_fold, cloth.light)
    path(node(outer, "clipPath", id="wardrobe-korzno-portrait-mask"), hanging_panel)
    folds = node(outer, "g", clip_path="url(#wardrobe-korzno-portrait-mask)")
    path(
        folds,
        f"M{neck_right} 277 Q{right - 17} 290 {right - 10} 322 "
        f"Q{right + 5} 363 {right + 4} 443 H{right - 9} Q{right - 17} 329 179 299Z",
        cloth.light,
    )
    path(
        folds,
        f"M{clasp + 9} 317 Q{right - 21} 355 {right - 19} 445 H{clasp + 5}Z "
        f"M{right + 11} 305 Q{far_right - 13} 329 {far_right} 344 L{far_right + 3} 446 "
        f"H{right + 6} Q{right + 16} 377 {right + 11} 305Z",
        cloth.shade,
    )
    path(
        folds,
        f"M{right + 17} 331 Q{right + 22} 388 {right + 15} 445 H{right + 4} "
        f"Q{right + 13} 374 {right + 4} 324Z",
        "url(#ink-lines)", opacity=".56",
    )
    path(
        folds,
        f"M{clasp + 2} 305 Q{clasp + 12} 373 {clasp + 6} 446 L{clasp + 15} 446 "
        f"Q{clasp + 22} 371 {clasp + 11} 304Z",
        cloth.deep, opacity=".6",
    )
    path(
        outer,
        edge + f"Q{clasp + 9} 373 {clasp + 5} 446",
        "none", stroke="#d0a16a", stroke_width="6.2", stroke_linejoin="round",
    )
    path(folds, f"M{right - 21} 322 Q{right - 11} 350 {right - 14} 403 M{right + 12} 377l-3 39", class_="seam")


def draw_ryazan_sleeves(art):
    front, cloth, body = art.front, art.cloth, art.body
    left, right = number(160 - art.neck), number(160 + art.neck)
    path(
        front,
        f"M{left} 274 Q160 306 {right} 274 Q176 291 167 299 V318 "
        f"Q160 325 153 318 V299 Q143 292 {left} 274Z",
        cloth.deep, class_="edge",
    )
    path(
        front,
        f"M{left} 275 Q146 293 157 298 V316 Q160 318 163 316 V298 Q174 292 {right} 275",
        "none", stroke="#dfb985", stroke_width="3.4",
    )
    path(front, "M160 299v16", "none", stroke="#b99972", stroke_width="1.7")

    shoulder = 160 - body.shoulder
    outside = 160 - body.sleeve
    inner = 168 - body.waist
    for sleeve in art.sleeves:
        cuff_left = outside - 7
        billow = (
            f"M{shoulder + 5} 312 Q{outside + 18} 349 {outside + 5} 371 "
            f"Q{outside - 5} 400 {outside + 15} 425 L{inner} 436 "
            f"Q{inner - 4} 414 {inner + 4} 387 Q{shoulder + 23} 357 {shoulder + 18} 313Z"
        )
        path(sleeve, billow, cloth.base)
        path(
            sleeve,
            f"M{outside + 19} 350 Q{outside - 2} 394 {outside + 23} 424 L{outside + 11} 425 "
            f"Q{outside - 7} 397 {outside + 5} 377Z "
            f"M{inner - 8} 365 Q{inner - 12} 402 {inner + 2} 426 H{inner - 11} "
            f"Q{inner - 21} 404 {inner - 8} 365Z",
            cloth.shade,
        )
        path(
            sleeve,
            f"M{outside + 26} 363 Q{outside + 12} 402 {outside + 31} 427 "
            f"L{outside + 37} 424 Q{outside + 21} 408 {outside + 26} 363Z",
            cloth.light,
        )
        path(
            sleeve,
            f"M{outside + 6} 369 Q{outside - 7} 402 {outside + 16} 422 "
            f"L{outside + 24} 423 Q{outside + 7} 399 {outside + 13} 364Z",
            "url(#ink-lines)", opacity=".5",
        )
        path(
            sleeve,
            f"M{outside + 10} 382 Q{outside + 3} 407 {outside + 24} 424 "
            f"M{inner - 16} 386 Q{inner - 20} 407 {inner - 8} 426",
            class_="seam",
        )
        path(
            sleeve,
            f"M{outside + 14} 391 q-3 12 4 22 m0 -14 q0 8 5 15 "
            f"M{inner - 12} 394 q-2 10 3 18",
            class_="etch",
        )
        cuff = node(sleeve, "g", data_part="ryazan-bracer")
        if art.hem_y is not None:
            wrist = 171 - body.hem
            cuff_left = outside + 9
            path(
                cuff,
                f"M{cuff_left} 416 Q{outside + 26} 423 {wrist + 9} 416 "
                f"L{wrist} 445 H{outside + 24}Z",
                "#a3987b", class_="edge",
            )
            path(
                cuff,
                f"M{cuff_left + 3} 421 Q{outside + 27} 428 {wrist + 8} 421 "
                f"M{outside + 23} 440 Q{outside + 33} 444 {wrist + 1} 440",
                "none", stroke="#5d544c", stroke_width="1.8",
            )
            for x in range(outside + 24, wrist - 2, 7):
                path(cuff, f"M{x} 432l2 -2 2 2-2 2Z", "#e1d0a5", stroke="#66554a", stroke_width=".8")
            continue
        path(
            cuff,
            f"M{cuff_left} 414 Q{outside + 23} 423 {inner} 415 L{inner + 1} 438 "
            f"Q{outside + 24} 447 {cuff_left + 3} 437Z",
            "#a3987b", class_="edge",
        )
        path(
            cuff,
            f"M{cuff_left} 418 Q{outside + 24} 427 {inner} 419 "
            f"M{cuff_left + 2} 433 Q{outside + 24} 443 {inner} 434",
            "none", stroke="#5d544c", stroke_width="1.8",
        )
        for x in range(outside + 10, inner - 3, 7):
            path(
                cuff, f"M{x} 428l2 -2 2 2 -2 2Z",
                "#e1d0a5", stroke="#66554a", stroke_width=".8",
            )


def draw_rus_mantle(art):
    outer, cloth, body = art.outer, art.cloth, art.body
    left, right = 160 - body.shoulder, 160 + body.shoulder
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    outside_left, outside_right = 152 - body.sleeve, 168 + body.sleeve
    lower_left, lower_right = 160 - body.chest, 160 + body.chest
    for sleeve in art.sleeves:
        path(
            sleeve, f"M{outside_left} 418 Q{left - 10} 425 {left + 26} 414",
            "none", stroke="#936d51", stroke_width="8.5",
        )
        path(
            sleeve, f"M{outside_left} 418 Q{left - 10} 425 {left + 26} 414",
            "none", stroke="#c99c62", stroke_width="3.3",
        )
    cape = (
        f"M{neck_left} 272 Q{left - 19} 269 {outside_left} 322 "
        f"Q{outside_left + 7} 361 {lower_left} 366 Q117 389 145 378 "
        f"Q158 358 160 322 Q162 358 175 378 Q203 389 {lower_right} 366 "
        f"Q{outside_right - 7} 361 {outside_right} 322 "
        f"Q{right + 19} 269 {neck_right} 272 Q177 284 160 290 Q143 284 {neck_left} 272Z"
    )
    path(outer, cape, cloth.base, class_="edge")
    path(
        outer,
        f"M{neck_left} 279 Q{left + 2} 281 {left - 14} 312 "
        f"Q{left + 18} 293 147 301Z "
        f"M{neck_right} 279 Q{right - 2} 281 {right + 14} 312 "
        f"Q{right - 18} 293 173 301Z",
        cloth.light,
    )
    path(
        outer,
        f"M154 307 Q{left + 30} 326 {lower_left + 14} 369 Q125 381 143 375 "
        f"Q151 358 151 343Z M166 307 Q{right - 30} 326 {lower_right - 14} 369 "
        f"Q195 381 177 375 Q169 358 169 343Z",
        cloth.shade,
    )
    path(
        outer,
        f"M144 310 Q{left + 24} 319 {left + 16} 354 L{left + 5} 358 "
        f"Q{left + 7} 327 144 310Z M176 310 Q{right - 24} 319 {right - 16} 354 "
        f"L{right - 5} 358 Q{right - 7} 327 176 310Z",
        "url(#ink-lines)", opacity=".55",
    )
    path(
        outer,
        f"M151 306 Q127 318 {left + 15} 326 M148 313 Q130 332 123 365 "
        f"M169 306 Q193 318 {right - 15} 326 M172 313 Q190 332 197 365",
        class_="seam",
    )
    path(
        outer,
        f"M{neck_left} 277 Q144 295 160 303 Q176 295 {neck_right} 277",
        "none", stroke=cloth.light, stroke_width="4.6", stroke_linecap="round",
    )
    path(outer, "M144 297 Q153 307 160 304 Q167 307 176 297 M158 309l-7 12 m11 -12 7 12", class_="etch")
    path(outer, "M149 303 Q154 297 160 302 Q166 297 171 303 Q167 307 160 306 Q153 307 149 303Z", cloth.deep)


DRAWERS = {
    "izyaslav_kaftan": draw_izyaslav,
    "korzno": draw_korzno,
    "ryazan_sleeves": draw_ryazan_sleeves,
    "rus_mantle": draw_rus_mantle,
}
