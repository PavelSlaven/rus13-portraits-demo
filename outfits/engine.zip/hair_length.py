HAIR_LENGTHS = {
    "shaved": "Сбрито",
    "stubble": "Ёжик",
    "short": "Короткие",
    "medium": "До ушей или шеи",
    "long": "До плеч и ниже",
}

SHAVED_STYLE = "scalp_shaved"
STUBBLE_STYLE = "scalp_stubble"
SCALP_STYLES = {SHAVED_STYLE: "Выбритая голова", STUBBLE_STYLE: "Волосы ёжиком"}

_STYLES_AT_MEDIUM_OR_LONG = ("tied", "nape_tie", "child_jin_three_knots")
STYLES_BY_LENGTH = {
    "shaved": (SHAVED_STYLE,),
    "stubble": (STUBBLE_STYLE,),
    "short": (
        "short", "close_crop", "temple_locks", "combed_back",
        "child_rus_crop", "child_iberian_curls", "child_song_forelock",
        "adult_rus_ordered_curls", "adult_latin_tonsure", "adult_castile_short_fringe",
    ),
    "medium": ("ear_length", "adult_rus_parted_waves", *_STYLES_AT_MEDIUM_OR_LONG),
    "long": (
        "long", "braided", "shoulder_locks", "double_braids", "steppe_braids", "high_knot",
        "child_rus_nape_braid", "child_rus_swept_loose", "child_song_twin_buns", "child_song_three_buns",
        "adult_steppe_long_braids", "adult_steppe_folded_braids", "adult_rus_temple_loops",
        "adult_rus_nape_twist", "adult_song_high_bun", "adult_japan_long_hair", "adult_rus_single_braid",
        "adult_rus_temple_braids", "adult_castile_shoulder_waves", "adult_iran_two_braids",
        "adult_song_side_buns", "adult_steppe_rolled_locks", *_STYLES_AT_MEDIUM_OR_LONG,
    ),
}


def length_allows(length, style):
    if length is None:
        return style not in SCALP_STYLES
    return style in STYLES_BY_LENGTH[length]
