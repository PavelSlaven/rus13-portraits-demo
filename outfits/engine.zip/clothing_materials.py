"""SVG surface finishes. A finish uses the existing outline and fold geometry."""

from dataclasses import dataclass
from xml.etree import ElementTree as ET

from common import node, path, tag


@dataclass(frozen=True)
class Material:
    label: str
    surface: str
    tint: str | None = None


MATERIALS = {
    "linen": Material("Лён", "linen"),
    "plain_weave": Material("Полотно простого переплетения", "weave"),
    "hemp": Material("Конопляное полотно", "hemp"),
    "wool": Material("Шерсть", "twill"),
    "coarse_wool": Material("Грубая шерсть", "coarse"),
    "fine_wool": Material("Тонкая шерсть", "herringbone"),
    "half_wool": Material("Полушерсть", "half_wool"),
    "check_wool": Material("Клетчатая пестрядь", "checked"),
    "stripe_wool": Material("Полосатая пестрядь", "striped"),
    "broadcloth": Material("Тонкое сукно", "broadcloth"),
    "felt": Material("Войлок", "felt"),
    "silk": Material("Шёлк", "silk"),
    "brocade": Material("Парча", "brocade"),
    "aksamit": Material("Аксамит", "velvet"),
    "cotton": Material("Хлопок", "cotton"),
    "plant_fiber": Material("Растительное волокно", "plant"),
    "plush": Material("Ворсистая ткань", "plush"),
    "sheepskin": Material("Овчина", "fleece", "#b7a688"),
    "squirrel": Material("Беличий мех", "squirrel", "#8b8178"),
    "ermine": Material("Горностай", "ermine", "#e3d9ba"),
    "fur": Material("Мех", "fur", "#8a6c54"),
    "leather": Material("Выделанная кожа", "leather"),
    "yuft": Material("Юфть", "yuft"),
    "bast": Material("Лыко", "basket", "#a9905e"),
    "gold": Material("Золото", "metal", "#cba557"),
    "silver": Material("Серебро", "metal", "#bac2c1"),
    "copper": Material("Медь", "metal", "#b77654"),
    "bronze": Material("Бронза", "metal", "#a78953"),
    "tin_lead": Material("Оловянисто-свинцовый сплав", "metal", "#949491"),
    "iron": Material("Железо", "metal", "#777e80"),
    "glass": Material("Стекло", "glass", "#458c93"),
    "enamel": Material("Синяя эмаль", "enamel", "#355b97"),
    "stone": Material("Камень", "stone", "#8c9185"),
    "carnelian": Material("Сердолик", "glass", "#ad5639"),
    "crystal": Material("Горный хрусталь", "glass", "#b9d6ce"),
    "amethyst": Material("Аметист", "glass", "#836a99"),
    "flint": Material("Кремень", "stone", "#646970"),
    "amber": Material("Янтарь", "glass", "#c48738"),
    "bone": Material("Кость", "bone", "#ccc0a0"),
    "pearl": Material("Речной жемчуг", "pearl", "#e5ddcb"),
}

SLOT_LABELS = {
    "outfit": "Одежда", "cloak": "Плащ", "headgear": "Головной убор",
    "trousers": "Штаны", "leg_wraps": "Обмотки", "footwear": "Обувь",
    "belt": "Пояс", "belt_pouch": "Поясная сумка", "accessory": "Принадлежность", "jewelry": "Украшение",
    "apron": "Передник", "vestment": "Облачение", "gloves": "Рукавицы",
    "shoe_accessory": "Оснастка обуви", "foot_lining": "Носки и онучи", "insole": "Стелька",
}
MATERIAL_FIELDS = {
    f"{slot}{suffix}_material": (slot, role)
    for slot in SLOT_LABELS for suffix, role in (("", "base"), ("_trim", "trim"))
}

_SELECTABLE_PARTS = {slot.replace("_", "-"): slot for slot in SLOT_LABELS if slot not in {"outfit", "headgear"}}
_FIXED_PARTS = {
    "belt-buckle", "cloak-clasp", "scabbard-cord", "pouch-cord", "archery-cord",
    "shield", "hands", "neck", "quiver", "bow-case",
}
_FILLED = {tag(shape) for shape in ("path", "rect", "circle", "ellipse", "polygon")}


def _rgb(color):
    return tuple(int(color[index:index + 2], 16) for index in (1, 3, 5))


def _mix(color, other, amount):
    return "#" + "".join(f"{round(a + (b - a) * amount):02x}" for a, b in zip(_rgb(color), _rgb(other)))


def _shade(color, amount):
    return _mix(color, "#241e20" if amount < 0 else "#fff0d6", abs(amount))


def _luma(color):
    red, green, blue = _rgb(color)
    return (red * .21 + green * .72 + blue * .07) / 255


def _material_color(color, material, role):
    if material.tint is None:
        return _shade(color, -.10) if material.surface in {"velvet", "broadcloth"} else color
    tone = _shade(material.tint, (_luma(color) - .49) * .6)
    return _shade(tone, {"base": 0, "light": .26, "shade": -.23}[role])


def _gradient(defs, identifier, base, stops, *, vertical=False):
    gradient = node(defs, "linearGradient", id=identifier, x1="14%", y1="0%",
                    x2="25%" if vertical else "88%", y2="100%" if vertical else "57%")
    for offset, amount in stops:
        node(gradient, "stop", offset=offset, stop_color=_shade(base, amount))


_SHINES = {
    "silk": ((0, -.20), (.30, -.04), (.46, .33), (.53, .55), (.64, .08), (1, -.24)),
    "velvet": ((0, -.34), (.35, -.06), (.59, .18), (.82, -.22), (1, -.35)),
    "metal": ((0, -.36), (.27, .06), (.40, .57), (.49, .21), (.52, -.20), (.77, .25), (1, -.38)),
    "glass": ((0, -.26), (.22, .36), (.38, .06), (.70, -.36), (.94, .35), (1, -.15)),
    "enamel": ((0, .22), (.25, .45), (.39, .03), (1, -.29)),
    "pearl": ((0, -.18), (.35, .72), (.54, .37), (.77, -.07), (1, -.25)),
}

# Each repeat has hand-drawn fibres, knit marks or nap. The two ink colours
# follow the dyed cloth so the same fabric can be compared in a single colour.
_PATTERNS = {
    "linen": (9, 8, "M0 2.5H9M0 6H9M2 0V8M6.8 0V8", "M0 4H9M4.5 0V8", .68, .24),
    "weave": (8, 8, "M0 1H8M0 5H8M1 0V8M5 0V8", "M3 0V8M7 0V8M0 7H8", .80, .20),
    "hemp": (15, 12, "M0 3l7 .4 8 -.4M1 8l6 -.4 8 .4M3 1l.5 5-.5 4M11 0l-.6 6 .6 6",
             "M4 4l6 .3M0 10l5 -.5 7 .3M7 0v2m0 4v4", 1.18, .34),
    "twill": (10, 10, "M-4 4l8 -8M-3 10L10 -3M0 15L15 0M6 16L16 6",
             "M1 5l2 -2M7 8l2 -2M3 9l1 -1", 1.02, .26),
    "coarse": (16, 13, "M-2 5l7 -7M0 12L12 0m-2 12 6 -7m-13 3 3 -3M9 10l4 -3",
               "M1 4l2 -1M6 10l3 -1m4 -7 2 1M0 12l2 -1", 1.44, .33),
    "herringbone": (12, 10, "M0 1l6 4 6 -4M0 6l6 4 6 -4", "M0 3l6 4 6 -4", .85, .26),
    "half_wool": (12, 9, "M0 2H12M0 6H12M3 0v9m5 -9v9", "M1 6l4 -4m4 7 3 -3", 1.12, .23),
    "broadcloth": (13, 11, "M1 4l2 -.7M8 8l2 -1M6 1l1 -.5", "M4 8l2 -.5m5 -4 1 -.4", 1.05, .18),
    "felt": (15, 12, "M2 3l1.2 -.5M6 8l1.8 .5M11 3l.6 1.5M13 9l.6 -1M4 1l.6 .2M1 10l.9 -.2",
             "M4 5l1.2 .4m4 3 1 .6m1 -4 2 -.2M1 8l1 .2", 1.7, .25),
    "cotton": (7, 7, "M0 2h7M0 5h7M2 0v3m3 1v3", "M0 0h5M1 4v2m4 -6v2", .56, .21),
    "plant": (17, 11, "M0 3l6 -1 6 1 5 -.5M0 8l6 -.3 8 .6M2 0v11m9 -11v11", "M5 5l4 -.4m4 4 3 -.3", .93, .30),
    "plush": (12, 12, "M2 9Q1 5 4 5M8 7Q9 4 10 5M6 12q2 -5 4 -4", "M1 2q3 -2 4 0m5 8 2 1", 1.45, .24),
    "fleece": (17, 14, "M0 4q3 4 7 0 3 4 7 0l3 1m-17 6q4 4 8 0 4 3 8 -1",
               "M1 1q2 3 5 0m4 7q3 3 6 -1", 1.52, .36),
    "fur": (16, 17, "M0 4q3 2 6 9m0 -12q3 3 6 9m-1 2q3 1 5 5M-2 12l3 5",
            "M4 1q2 3 3 7m3 2 2 6m1 -14 2 6", 1.36, .37),
    "squirrel": (15, 16, "M1 0q1 4 4 9m1 -5q2 5 5 10m2 -10 2 5", "M1 6l3 8m4 -13q1 4 3 7m1 4 2 4", 1.25, .39),
    "basket": (12, 12, "M0 3h12M0 9h12M3 0v6m6 0v6", "M1 1h6M7 7h5M5 2v3m6 3v3", 1.6, .37),
    "leather": (20, 17, "M2 5q2 -2 5 -1M12 8l3 -.5m-8 7 3 -1m6 2 2 -1",
                "M0 8q5 -2 10 -2m3 8 4 -1", 1.02, .26),
    "yuft": (17, 13, "M2 3q3 -2 6 -2M10 8l4 -2m-10 5 3 -.7", "M4 5q4 -2 8 -2m1 8 4 -1", .80, .27),
    "stone": (12, 11, "M2 2h.1m3 4h.1m5 -2h.1m-3 6h.1M1 10h.1", "M2 6h.1m7 -4h.1M11 10h.1", 1.25, .28),
    "bone": (11, 12, "M2 0q4 5 2 12m3 -12q3 6 2 12", "M5 0q4 7 2 12", .65, .22),
}


def _finish(defs, identifier, material, color):
    surface = material.surface
    if surface in _SHINES:
        _gradient(defs, identifier, color, _SHINES[surface], vertical=surface in {"silk", "velvet"})
        return
    if surface in {"brocade", "checked", "striped", "ermine"}:
        size = 20 if surface != "ermine" else 24
        tile = node(defs, "pattern", id=identifier, width=size, height=size, patternUnits="userSpaceOnUse")
        node(tile, "rect", width=size, height=size, fill=color)
        if surface == "brocade":
            path(tile, "M10 2l3.5 4 4.5 4-4.5 4-3.5 4-4-4-4-4 4-4Z M0 0l3 1-2 2ZM20 20l-3 -1 2 -2Z",
                 _shade(color, .30), stroke="#c8a563", stroke_width=.85)
            path(tile, "M10 5q6 5 0 10-6 -5 0 -10Z", "#ddbb77", opacity=".72")
        elif surface in {"checked", "striped"}:
            path(tile, "M4 0h5v20H4Z" + (" M0 4h20v5H0Z" if surface == "checked" else ""),
                 _shade(color, -.35), opacity=".66")
            path(tile, "M12 0h2v20h-2Z" + (" M0 12h20v2H0Z" if surface == "checked" else ""),
                 _shade(color, .39), opacity=".74")
        else:
            path(tile, "M6 3q2 3 .4 7l-2 2 .6 -3-1 -3Z M18 15q2 2 .3 6l-1.7 2 .6 -3-1 -3Z",
                 "#3d3533")
            path(tile, "M10 4q2 2 1 5m-8 4q2 2 1 5m15 -9 2 4", "none",
                 stroke=_shade(color, -.29), stroke_width=.85, opacity=".55")
        return

    width, height, dark, light, weight, opacity = _PATTERNS[surface]
    tile = node(defs, "pattern", id=identifier, width=width, height=height, patternUnits="userSpaceOnUse")
    node(tile, "rect", width=width, height=height, fill=color)
    if surface in {"leather", "yuft"}:
        gloss = identifier + "-gloss"
        _gradient(defs, gloss, color, ((0, -.17), (.28, .22), (.49, .04), (1, -.22)))
        node(tile, "rect", width=width, height=height, fill=f"url(#{gloss})", opacity=".62")
    path(tile, dark, "none", stroke=_shade(color, -.68), stroke_width=weight,
         stroke_linecap="round", stroke_linejoin="round", opacity=opacity)
    path(tile, light, "none", stroke=_shade(color, .62), stroke_width=weight * .72,
         stroke_linecap="round", stroke_linejoin="round", opacity=opacity * .89)


def apply_materials(root, equipment):
    selections = {
        (slot, role): equipment[field] for field, (slot, role) in MATERIAL_FIELDS.items()
        if equipment.get(field) in MATERIALS
    }
    if not selections:
        return
    defs = root.find(tag("defs"))
    if defs is None:
        defs = ET.Element(tag("defs"))
        root.insert(0, defs)
    defined = set()

    def repaint(element, material, role, attribute):
        color = element.get(attribute, "")
        if len(color) != 7 or not color.startswith("#") or _luma(color) < .105:
            return
        finish = MATERIALS[material]
        base = _material_color(color, finish, role)
        element.set("data-material", material)
        identifier = f"clothing-{material}-{base[1:]}"
        if identifier not in defined:
            _finish(defs, identifier, finish, base)
            defined.add(identifier)
        element.set(attribute, f"url(#{identifier})")

    def visit(element, slot=None, surface=None):
        part = element.get("data-part")
        marked_slot = element.get("data-material-slot")
        if marked_slot in SLOT_LABELS:
            slot, surface = marked_slot, None
        elif part in _SELECTABLE_PARTS:
            slot, surface = _SELECTABLE_PARTS[part], None
        elif part in _FIXED_PARTS:
            slot, surface = None, None
        surface = element.get("data-material-surface", surface)
        if surface == "fixed":
            return
        if slot is not None and element.tag in _FILLED:
            is_trim = surface is not None and surface.startswith("trim")
            key = selections.get((slot, "trim" if is_trim else "base"))
            role = surface.removeprefix("trim-") if surface not in {None, "trim"} else "base"
            if key is not None and role in {"base", "light", "shade"}:
                attribute = "stroke" if surface is not None and element.get("fill") == "none" else "fill"
                repaint(element, key, role, attribute)
        for item in element:
            visit(item, slot, surface)

    for child in list(root):
        if child is not defs:
            visit(child)
