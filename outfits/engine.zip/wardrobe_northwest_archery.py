from common import node, number, path
from wardrobe_northwest_arms import draw_grip_fingers


OPTIONS = {
    "bow": {
        "none": "Без лука",
        "novgorod_composite": "Новгородский составной лук",
        "steppe_composite": "Степной составной лук",
        "northern_wood": "Северный деревянный лук",
    },
    "bow_case": {
        "none": "Без налучья",
        "plain_leather": "Кожаное налучье",
        "bone_trim": "Налучье с костяной накладкой",
    },
    "quiver": {
        "none": "Без колчана",
        "birchbark": "Берестяной колчан",
        "leather_covered": "Колчан, обтянутый кожей",
        "steppe_novyi_quiver": "Степной колчан с резными накладками",
    },
}

LABELS = {"bow": "Лук", "bow_case": "Налучье", "quiver": "Колчан"}
CASED_BOWS = frozenset(("novgorod_composite", "steppe_composite"))

_INK = "#2c2120"
_CORD = "#ad9476"
_STRAP = "#8b6147"
_STRAP_LIGHT = "#c3986e"


def _shape(parent, contour, fill, width=1.7, **attrs):
    path(parent, contour, fill, stroke=_INK, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round", **attrs)


def _line(parent, contour, color, width):
    path(parent, contour, "none", stroke=color, stroke_width=width,
         stroke_linecap="round", stroke_linejoin="round")


def _hatch(parent, contour, opacity):
    path(parent, contour, "url(#ink-lines)", opacity=opacity)


def _string(parent, contour):
    _line(parent, contour, "#493b31", 1.6)
    _line(parent, contour, _CORD, .78)


def _draw_composite_bow(parent):
    _string(parent, "M-40 -135L-20 123")
    _shape(parent,
           "M-40 -135Q-28 -128-27 -111C-24 -91-6 -76 0 -54"
           "Q6 -35 3 -15Q2 -2 3 15C7 49-1 69-12 87"
           "Q-22 108-20 123Q-27 115-24 104C-23 91-16 77-12 59"
           "Q-6 38-5 18Q-8 1-5 -17Q-2 -38-8 -53"
           "C-16 -74-32 -92-32 -109Q-32 -125-40 -135Z",
           "#82583d", 1.9)
    shade = ("M-32 -119Q-27 -103-22 -94Q-3 -67 0 -54Q6 -35 3 -16"
             "L0 -17Q3 -40-3 -52C-10 -75-30 -94-32 -119Z"
             "M-1 17L3 16Q7 46-2 67Q-7 79-14 90Q-22 109-20 119"
             "Q-25 105-16 86C-3 64 .4 45-1 17Z")
    path(parent, shade, "#51362d")
    _hatch(parent, shade, .55)
    _line(parent, "M-30 -105Q-28 -91-17 -77M-13 -71Q-5 -60-3 -49"
          "M-1 -43Q1 -36.5.6 -27M-2.4 25Q-2.1 42-6 54M-8.6 64Q-12 76-17.2 84"
          "M-19 91l-2.6 6", "#c79a67", 1.04)
    _line(parent, "M-31 -109l3.5-.8m-2.7 4.5 3.2-.7m-1.8 4 3-.75"
          "M-22.3 101l3.2 1m-4 2.5 3.4.85m-3.8 2.4 3.35.7", "#bb8a61", .92)


def _draw_northern_bow(parent):
    _string(parent, "M-40.5 -158L-23 164")
    _shape(parent,
           "M-40.5 -159C-24 -144-13 -113-5 -81C5 -42 8 -19 4 8"
           "C2.2 13-2 20-4 29C-7.5 51-11 81-16 103Q-21 132-23 164"
           "Q-22 130-21.5 102C-17 76-15 47-11 27Q-9 16-5 6"
           "Q0 -23-9 -62C-15 -97-24 -135-40.5 -159Z",
           "#a27b50", 1.8)
    shade = ("M-36.4 -153Q-19 -130-8 -91C3 -55 7 -25 4 8"
             "C2.2 13-2 20-4 29C-7.5 51-11 81-16 103Q-21 132-23 161"
             "Q-21.1 129-19.4 103C-15 77-12.4 49-8.2 29Q-5.6 13-2.25 6"
             "C2 -13-.1 -36-7 -69Q-19 -123-36.4 -153Z")
    path(parent, shade, "#775339")
    _hatch(parent, shade, .49)
    _line(parent, "M-29 -139Q-18 -119-13 -96M-12 -92q6 19 9 39m1.4 7 2.4 13"
          "M-8.8 30Q-13.9 56-17.7 90m-1 8-1.7 18m-.3 9-.6 9", "#dab179", 1.12)
    _line(parent, "M-37.4 -154l2.3-1.25M-23 153.5l1.5.62", "#c39c6a", .9)


def draw_held_bow(parent, style, *, x, y, skin, half_width, child=False):
    if style == "none":
        return
    bow = node(parent, "g", data_part="bow", data_style=style, data_grip_x=x, data_grip_y=y,
               transform=f"translate({number(x)} {number(y)})")
    drawer, length = _BOWS[style]
    drawer(node(bow, "g", transform=f"scale({.88 if child else 1} {length})"))
    _shape(bow, "M-4 -16Q.1 -17.6 3.5 -15Q1.8 -2 4.5 13Q.2 17-4.7 14"
           "Q-7.4 .4-4 -16Z", "#624436", 1.45, data_part="bow-grip")
    _line(bow, "M-3.4 -14l5.6 1.5m-6.3 2.4 6 1.4M-3.8 10l6.3 1m-5.9 2.5 5.2 1",
          "#aa805c", .95)
    draw_grip_fingers(bow, skin, half_width)


def _draw_northern_back_bow(parent):
    _shape(parent, "M-60 -211C-57 -174-46 -129-34 -89C-23 -47-10 -11 8 25"
           "C30 70 52 103 75 137C110 188 147 240 175 303"
           "C140 244 103 193 68 141C45 107 23 73 1 29"
           "C-17 -7-31 -45-42 -86C-54 -132-63 -177-60 -211Z", "#a27b50", 1.85)
    shade = ("M-60 -204C-57 -170-44 -121-34 -89C-23 -47-10 -11 8 25"
             "C30 70 52 103 75 137C110 188 144 237 171 294"
             "C139 238 108 190 72 140C48 106 27 72 4 27"
             "C-15 -10-28 -46-39 -88C-50 -131-60 -176-60 -204Z")
    path(parent, shade, "#775339")
    _hatch(parent, shade, .42)
    _line(parent, "M-58 -190Q-53 -143-46 -121m2.5 9 4.5 17M-33 -74Q-24 -41-12 -15"
          "M46 104Q67 137 93 173m7 10 9 13M149 255l12 20", "#dab179", 1.07)


def _draw_composite_back_bow(parent):
    _shape(parent, "M-56 -166Q-62 -151-56 -137C-52 -125-44 -115-41 -104"
           "C-34 -82-39 -66-22 -37Q-11 -18 4 0Q21 20 33 46"
           "C44 71 49 97 68 121C88 149 114 156 130 182"
           "Q147 209 137 231Q139 212 122 188C104 163 81 155 61 127"
           "C42 103 37 78 26 50Q16 25-2 5Q-20 -16-30 -34"
           "C-46 -61-44 -80-49 -101C-53 -115-60 -123-63 -137"
           "Q-67 -153-56 -166Z", "#82583d", 1.9)
    shade = ("M-58 -160Q-64 -150-59 -136C-57 -125-48 -114-44 -102"
             "C-38 -82-42 -66-25 -36Q-13 -16 2 2L-2 5Q-20 -16-30 -34"
             "C-46 -61-44 -80-49 -101C-53 -115-60 -123-63 -137Q-67 -153-58 -160Z"
             "M66 123C85 148 112 158 128 185Q143 207 137 228Q139 212 122 188"
             "C104 163 81 155 61 127Z")
    path(parent, shade, "#51362d")
    _hatch(parent, shade, .55)
    _line(parent, "M-59 -151Q-59 -137-52 -128m3 5 4 9M-40 -97Q-36 -79-34 -63"
          "M-30 -54Q-23 -37-12 -23M91 147q14 10 24 20m5 6 4 5",
          "#c79a67", 1.03)
    _line(parent, "M-62 -143l4.1-.7m-3.4 4.6 3.8-1m-2.7 5.3 3.6-1"
          "M134 208l4.7-.8m-3.75 4.3 4.6-.8", "#bb8a61", .9)


def draw_back_bow(parent, style, body, *, child=False):
    if style == "none":
        return
    x = 160 - body.shoulder * (.74 if child else .86)
    y = body.shoulder_y + (-17 if child else 10)
    size = _BACK_BOW_SCALE[style]
    width, height = (size * .91, size * .87) if child else (size, size)
    transform = f"translate({number(x)} {number(y)}) scale({number(width)} {number(height)})"
    bow = node(parent, "g", data_part="back-bow", data_style=style, transform=transform)
    _BACK_BOWS[style](bow)


def _waist_accessory(parent, part, style, body, position, belt_offset):
    radius = body.waist + 8
    x = 160 + position * radius
    # Match the center curve of the belt and the fallback cord.
    y = 405 - 7 * position ** 2 + belt_offset
    return node(parent, "g", data_part=part, data_style=style,
                transform=f"translate({number(x)} {number(y)})")


def _draw_case_hanger(parent):
    hanger = node(parent, "g", data_part="bow-case-hanger")
    _shape(hanger, "M-1.5 -1.5L3 2Q1.9 7 1 11Q-.3 20-6 28L-11 25"
           "Q-6 18-4.4 9Q-4 4-1.5 -1.5Z", _STRAP, 1.5)
    _line(hanger, "M-1.3 4Q-1.9 9-3.2 14Q-4.8 20-7.8 23.9", _STRAP_LIGHT, .9)
    _shape(hanger, "M-4 3Q-7 .7-5 -2.6Q-3 -5.2 1 -2.7Q4-.7 1.9 2.6Z"
           "M-3.5 .2Q-2 2.6.1 .8Q.4 -1-1.3 -1.6Q-3.1 -2.3-3.5 .2Z",
           "#956e51", 1.1, fill_rule="evenodd")


def _draw_seated_bow(parent, style):
    limb = node(parent, "g", data_part="bow-case-bow", data_style=style)
    _shape(limb, "M-57 -71Q-62 -61-56 -50C-51 -40-42 -35-36 -24"
           "Q-30 -13-29 -1Q-27 13-15 28L-8 26"
           "Q-20 11-22 -3Q-23 -16-29 -28C-35 -39-45 -44-50 -51"
           "Q-57 -61-57 -71Z", "#82583d", 1.8)
    shade = ("M-57 -67Q-60 -58-54 -49C-49 -41-38 -36-32 -24"
             "Q-26 -13-25 0Q-23 13-13 27L-15 28Q-27 13-29 -1"
             "Q-30 -13-36 -24C-42 -35-51 -40-56 -50Q-62 -61-57 -67Z")
    path(limb, shade, "#51362d")
    _hatch(limb, shade, .54)
    _line(limb, "M-56 -59Q-55 -52-50 -47M-46 -43Q-34 -34-29 -22"
          "M-26 -14Q-23 -8-23 -2M-19 12l3 6", "#c79a67", .97)
    _line(limb, "M-58.8 -63l3.2-.55m-2.5 4.1 3.4-.6m-2 4.2 3.2-.65", "#bb8a61", .88)


def _draw_plain_case(parent, *, loaded):
    _shape(parent, "M-28 28Q-18 17 4 21C2 40 5 64 11 79"
           "C20 106 52 123 49 160Q48 168 43 170Q37 170 36 161"
           "C37 134 10 119-5 95Q-22 72-28 28Z", "#5d4134", 2.15)
    shade = ("M1 27C-.2 50 3 69 9 84C21 111 49 126 47 159Q46 165 42 167"
             "C47 139 19 117 4 96Q-7 76-10 35Z")
    path(parent, shade, "#453129")
    _hatch(parent, shade, .59)
    _line(parent, "M-24 35Q-19 71-3 94C12 116 37 134 38.7 155m.1 3q-.1 5 2.5 8",
          "#aa7b59", 1.16)
    _line(parent, "M-18 43l.4 4m.55 4 .6 4m.65 4 1 4M3 98l2.4 3.5m3.2 4 2.6 3.2"
          "m9 10 2.3 2.7m3.2 4 2.6 3", "#c19169", .72)
    _shape(parent, "M-28.4 26.5Q-18.5 17 4.6 19.5Q2.5 25-12.2 31Q-25.4 35-28.4 26.5Z",
           "#332722", 1.55)
    _line(parent, "M-21 24.1Q-13.9 20.7-2.7 20.8", "#967355", .75)
    if loaded:
        _draw_seated_bow(parent, loaded)
        _shape(parent, "M-27.7 27.4Q-24.5 33.6-12.4 30.2Q-1.5 26.7 3.7 21"
               "L3.3 25.4Q-8.8 34.9-20.2 35.3Q-26.5 35.1-27.7 27.4Z", "#76503c", 1.08)
    _line(parent, "M-27.7 27.4Q-24.5 33.6-12.4 30.2Q-1.5 26.7 3.7 21", "#b58a65", 1.6)


def _draw_bone_case(parent, *, loaded):
    _shape(parent, "M-35 24Q-20 13 5 17C3 42 6 64 14 86"
           "C27 111 62 131 54 163Q51 177 43 181Q37 181 35 175"
           "C44 157 31 139 16 125Q-26 92-35 24Z",
           "#785242", 2.25)
    shade = ("M2 23C0 47 3 65 11 88C26 113 59 133 52 162Q50 173 43 177"
             "C49 155 36 138 21 123Q-12 94-14 36Z")
    path(parent, shade, "#57382f")
    _hatch(parent, shade, .6)
    _line(parent, "M-30 34Q-22 87 10 114C26 129 41 140 43 155m.1 5q-.2 5-2.3 11",
          "#bb8a64", 1.13)
    _shape(parent, "M.6 68Q2.2 65.5 5 67.5Q9.3 88 22.2 101Q22 105.4 17.9 105.1Q4.6 92 .6 68Z",
           "#cdb591", 1.04)
    _line(parent, "M2.5 70Q6.5 89 19.1 102.2", "#f0d6af", .72)
    for x, y in ((4.1, 71), (9.1, 87), (19.8, 102)):
        node(parent, "circle", cx=x, cy=y, r=.66, fill="#73583f")
    _shape(parent, "M-35.4 22.7Q-21.9 12 5.6 15.8Q-.9 24.2-22.7 30.4Q-32.8 32-35.4 22.7Z",
           "#382920", 1.65)
    _line(parent, "M-31.5 22Q-18.5 15.7-3.5 16.3", "#96714e", .85)
    if loaded:
        _draw_seated_bow(parent, loaded)
        _shape(parent, "M-34.4 24.2Q-31.5 30.9-22.7 29.2Q-4.8 24.4 4.5 17.1"
               "L4.2 21.7Q-5.4 30.1-22 33.8Q-32.7 34.7-34.4 24.2Z", "#805941", 1.12)
    _line(parent, "M-34.4 24.2Q-31.5 30.9-22.7 29.2Q-4.8 24.4 4.5 17.1", "#a57752", 1.9)


def draw_bow_case(parent, style, body, *, bow="none", child=False, belt_offset=0):
    if style == "none":
        return
    case = _waist_accessory(parent, "bow-case", style, body, .87, belt_offset)
    _draw_case_hanger(case)
    container = node(case, "g", data_part="bow-case-body")
    loaded = bow if bow in CASED_BOWS else None
    if loaded:
        length_scale = 1.13 if child else 1.37
        container.set("transform", f"translate(0 20) scale(1 {length_scale}) translate(0 -20)")
    _CASES[style](container, loaded=loaded)


def _draw_quiver_hanger(parent):
    hanger = node(parent, "g", data_part="quiver-hanger")
    _shape(hanger, "M-1.6 1L3.6-.7Q4.2 10 5.7 19.8Q6.7 25.4 3.8 28.4L.3 27.2"
           "Q2.5 23.2 1.6 19.2Q-.1 10-1.6 1Z", _STRAP, 1.5)
    _line(hanger, "M1.1 4.5Q2.8 11.5 3.4 18.7Q4.3 22.7 3.1 24.8", _STRAP_LIGHT, .9)
    _shape(hanger, "M-2.8 3Q-5.4.7-3.4-2.6Q-1.1-5.8 3.3-3.3Q6.5-.8 4 2.9Z"
           "M-1.8.1Q-.2 2.2 2.1.8Q3.3-.8.9-1.8Q-1.1-2.5-1.8.1Z",
           "#956e51", 1.1, fill_rule="evenodd")


def _draw_birchbark(parent):
    _shape(parent, "M-17 28Q-9 23 3 26C3 50 11 77 16 102"
           "Q22 127 19 141Q9 148-4 141Q-6 118-11 89Q-17 58-17 28Z",
           "#c6aa7d", 2.1)
    shade = ("M-1 34Q4 63 13 99Q19 126 17 140Q13 143 8 143"
             "Q12 127 6 102Q-.8 72-5 37Z")
    path(parent, shade, "#a27d54")
    _hatch(parent, shade, .45)
    _line(parent, "M-13 38Q-12 65-7 88m1 5 3 17m1 5 1.6 13", "#eed0a4", 1.35)
    _line(parent, "M-13 47l5-.6m1.5 1.2 2.2-.3M-9 59l6-.8m-8 11 2-.3m3-.2 5-.7"
          "M-6 79l4-.65m-3 12 6-.8m1.7.65 2.1-.35M-2 105l5-.55m3-.75 3.6-.5"
          "M1 121l5-.6m3.2.3 2.5-.35M2 130l4-.3", "#6f523a", .9)
    _shape(parent, "M-4.8 134Q7 138 19.7 133.5L19 141Q9 148-4 141Z", "#8e6244", 1.45)
    _line(parent, "M-2 136.7q8 3.2 17.6.2", "#cca378", .94)


def _draw_leather_quiver(parent):
    _shape(parent, "M-18 27Q-8 22 4 25C5 52 11 72 17 101"
           "Q23 129 22 139Q12 147-3 142L-10 110Q-17 75-18 27Z",
           "#765045", 2.2)
    shade = ("M-.5 32Q3 63 12 99Q19 130 18.5 141Q13 144 8 143"
             "Q10 124 4 102Q-3 71-6 37Z")
    path(parent, shade, "#53392f")
    _hatch(parent, shade, .56)
    _line(parent, "M-14 37Q-13 71-7 94m1 6 6 30", "#b48062", 1.22)
    _line(parent, "M-11 46l.3 3m.25 4 .3 3m.3 4 .3 3m.5 4 .35 3m.5 4 .5 3"
          "m.6 4 .6 3m1 4 .6 3m.8 4 .7 3m.8 4 .6 3m.75 4 .65 3m.65 4 .7 3",
          "#c49a76", .85)
    _shape(parent, "M-4.6 134Q10 138 22 131l.2 8Q11 148-3 142Z", "#8e624b", 1.4)
    _line(parent, "M-1.5 136.8q9.6 2.6 19.8-1.8", "#c39670", .88)


def _draw_novyi_quiver(parent):
    _draw_leather_quiver(parent)
    _shape(parent, "M-3 119Q6 121.7 19 117.7L20 128Q9 132.2-1 129Z", "#b69a71", 1.1)
    _shape(parent, "M5 125L8.6 121.5L12.6 124.8L8.9 128.5Z", "#d6be91", .7)
    for x, y in ((1.4, 125.7), (16.2, 123.2)):
        node(parent, "circle", cx=x, cy=y, r=1.5, fill="#6a5139")
        node(parent, "circle", cx=x, cy=y, r=.63, fill="#dec79d")


def _draw_quiver_mouth(parent, style):
    rim = "#a67950" if style == "birchbark" else "#8c5f48"
    _shape(parent, "M-18.7 27.2Q-19.4 22.3-9 21.3Q2.3 20 5 24.7Q4 30-5.5 32"
           "Q-16.5 32.6-18.7 27.2Z", "#382a23", 1.6)
    _line(parent, "M-16.2 24.5Q-8.2 20.7 2.25 23.5", rim, 1.05)
    _shape(parent, "M-12.5 29Q-14.9 20-17.5 15Q-23.7 11.9-23.2 2.1"
           "Q-15.8 7.1-15.1 14.1Q-11.6 21.3-10.7 28.3Z", "#c4aa8e", 1)
    _shape(parent, "M-7.4 29Q-9 20-10 12.2Q-14 8.1-12.1 1Q-6.8 5.7-7.9 12.4"
           "Q-6.2 21.1-5.6 28.7Z", "#9b9a83", 1)
    _shape(parent, "M-4.4 29Q-4 22-5 17.4Q-8.4 12.4-5.7 7.8Q-1 12.1-2.9 17.1"
           "Q-2 23.1-2.6 29Z", "#d2b897", 1)
    _line(parent, "M-21.3 5.3Q-18.1 8.2-16.5 13.4m5.4-9.5 1.8 7.8m3.6-1.7 1.2 6.1",
          "#ece0be", .8)
    _shape(parent, "M-18.7 26Q-13 31.7-2.2 28Q2.1 26.8 5 24L5.1 30.8"
           "Q-4 37-17.4 33.9Z", rim, 1.45)
    _line(parent, "M-16.5 29.4Q-7.1 33.2 2.8 28.2", "#d8b58a", 1)


def draw_quiver(parent, style, body, *, child=False, belt_offset=0, clear_wrist=False):
    if style == "none":
        return
    position = -.77
    if clear_wrist:
        # Reserve the bow grip, the inner edge of the fist and the quiver rim.
        position = max(position, (body.wrist_x + 40 - 160) / (body.waist + 8))
    quiver = _waist_accessory(parent, "quiver", style, body, position, belt_offset)
    _draw_quiver_hanger(quiver)
    container = node(quiver, "g", data_part="quiver-body",
                     transform="translate(0 26) scale(.9 .82) translate(0 -26)" if child else None)
    _QUIVERS[style](container)
    _draw_quiver_mouth(container, style)


_BOWS = {"novgorod_composite": (_draw_composite_bow, 1.37), "steppe_composite": (_draw_composite_bow, 1.28),
         "northern_wood": (_draw_northern_bow, 1.52)}
_BACK_BOWS = {**dict.fromkeys(CASED_BOWS, _draw_composite_back_bow), "northern_wood": _draw_northern_back_bow}
_BACK_BOW_SCALE = {"novgorod_composite": .80, "steppe_composite": .75, "northern_wood": .88}
_CASES = {"plain_leather": _draw_plain_case, "bone_trim": _draw_bone_case}
_QUIVERS = {"birchbark": _draw_birchbark, "leather_covered": _draw_leather_quiver,
            "steppe_novyi_quiver": _draw_novyi_quiver}
