from common import node, number, path


_LINEN = "#d8c9aa"
_GOLD = "#d7b66f"
_GOLD_LIGHT = "#f0d99b"
_SILVER = "#d2c9b5"


def _body_shape(body, neck):
    shoulder, crest = body.shoulder, body.shoulder_y
    chest, waist, hem = body.chest, body.waist, body.hem
    return (
        f"M{number(160 - neck)} 273 "
        f"C{number(146 - neck)} 273 {173 - shoulder} {crest - 10} {160 - shoulder} {crest} "
        f"C{157 - shoulder} {crest + 15} {162 - chest} 322 {160 - chest} 346 "
        f"C{158 - chest} 370 {161 - waist} 386 {160 - waist} 400 "
        f"C{159 - waist} 415 {165 - hem} 431 {160 - hem} 445 "
        f"H{160 + hem} C{155 + hem} 431 {161 + waist} 415 {160 + waist} 400 "
        f"C{159 + waist} 386 {162 + chest} 370 {160 + chest} 346 "
        f"C{158 + chest} 322 {163 + shoulder} {crest + 15} {160 + shoulder} {crest} "
        f"C{147 + shoulder} {crest - 10} {number(174 + neck)} 273 {number(160 + neck)} 273 "
        f"Q160 307 {number(160 - neck)} 273Z"
    )


def _norse_child_tunic(art):
    body, cloth = art.body, art.cloth
    left_shoulder, right_shoulder = 160 - body.shoulder, 160 + body.shoulder
    left_chest, right_chest = 160 - body.chest, 160 + body.chest
    left_waist, right_waist = 160 - body.waist, 160 + body.waist
    left_hem, right_hem = 160 - body.hem, 160 + body.hem
    crest = body.shoulder_y
    path(art.front, _body_shape(body, art.neck), cloth.base)

    path(
        art.front,
        f"M{right_shoulder - 7} {crest + 5} Q{right_chest + 13} 320 {right_chest + 5} 349 "
        f"L{right_waist + 8} 397 Q{right_hem - 6} 425 {right_hem} 443 "
        f"L{right_waist + 17} 444 Q{right_waist + 3} 416 {right_waist - 4} 394 "
        f"Q{right_chest - 5} 345 {right_shoulder - 7} {crest + 5}Z",
        cloth.shade, opacity=".62",
    )
    path(
        art.front,
        f"M{left_shoulder + 8} {crest + 7} Q{left_chest + 14} 322 {left_chest + 18} 350 "
        f"Q{left_waist + 18} 390 {left_waist + 13} 421 L{left_hem + 17} 443 "
        f"Q{left_waist + 1} 419 {left_waist - 11} 395 Q{left_chest + 4} 348 {left_shoulder + 8} {crest + 7}Z",
        cloth.light, opacity=".48",
    )

    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    path(
        art.front,
        f"M{neck_left} 278 Q160 311 {neck_right} 278",
        "none", stroke=cloth.deep, stroke_width="2.1", stroke_linecap="round",
    )
    path(
        art.front,
        f"M{number(160 - art.neck - 4)} 286 Q{left_shoulder + 18} {crest + 14} {left_shoulder + 12} {crest + 20} "
        f"M{number(160 + art.neck + 4)} 286 Q{right_shoulder - 18} {crest + 14} {right_shoulder - 12} {crest + 20}",
        "none", stroke=cloth.deep, stroke_width="1.45", stroke_linecap="round",
    )

    for side, x in ((-1, left_chest), (1, right_chest)):
        path(
            art.front,
            f"M{x + side * 3} 337 Q{x + side * 10} 342 {x + side * 5} 351 "
            f"Q{x} 356 {x - side * 5} 351 Q{x - side * 10} 342 {x + side * 3} 337Z",
            cloth.shade, opacity=".52",
        )
        path(
            art.front,
            f"M{x - side * 3} 341 Q{x} 344 {x - side * 2} 349",
            "none", stroke=cloth.light, stroke_width="1.2", opacity=".85",
        )

    path(
        art.front,
        f"M{left_waist + 15} 375 Q160 391 {right_waist - 14} 376 "
        f"M{left_waist + 7} 402 Q{left_waist + 15} 419 {left_waist + 18} 440 "
        f"M{right_waist - 7} 402 Q{right_waist - 15} 419 {right_waist - 18} 440",
        "none", stroke=cloth.deep, stroke_width="1.5", opacity=".7", stroke_linecap="round",
    )
    path(
        art.front,
        f"M{left_hem + 10} 438 Q160 442 {right_hem - 10} 438",
        "none", stroke=cloth.deep, stroke_width="1.1", stroke_linecap="round",
    )
    patch_x = left_waist + 23
    path(art.front, f"M{patch_x} 418l8 -2 3 8-8 2Z", cloth.shade, opacity=".78")
    path(
        art.front,
        f"M{patch_x + 2} 419l6 5m-6 -1 5 -3",
        "none", stroke=cloth.light, stroke_width="1.1", stroke_linecap="round",
    )


def _rus_child_svita(art):
    body, cloth = art.body, art.cloth
    left_shoulder, right_shoulder = 160 - body.shoulder, 160 + body.shoulder
    left_chest, right_chest = 160 - body.chest, 160 + body.chest
    left_waist, right_waist = 160 - body.waist, 160 + body.waist
    left_hem, right_hem = 160 - body.hem, 160 + body.hem
    crest = body.shoulder_y
    path(art.front, _body_shape(body, art.neck), cloth.base)

    path(
        art.front,
        f"M{left_shoulder + 11} {crest + 7} Q{left_chest + 10} 333 {left_waist + 11} 398 "
        f"L{left_hem + 13} 443 H{160 - body.hem // 2} Q{left_waist + 1} 410 {left_chest + 2} 346Z",
        cloth.deep, opacity=".28",
    )
    path(
        art.front,
        f"M{right_shoulder - 9} {crest + 8} Q{right_chest - 5} 326 {right_waist - 7} 394 "
        f"Q{right_hem - 18} 420 {right_hem - 8} 443 H{right_hem - 22} "
        f"Q{right_waist - 23} 407 {right_chest - 13} 345Z",
        cloth.light, opacity=".38",
    )

    # The light insert remains visible at the throat beneath the soft standing collar.
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    path(
        art.front,
        f"M{number(160 - art.neck + 2)} 280 Q160 309 {number(160 + art.neck - 2)} 280 "
        f"L{number(160 + art.neck - 4)} 291 Q160 316 {number(160 - art.neck + 4)} 291Z",
        _LINEN,
    )
    path(
        art.front,
        f"M{neck_left} 273 Q160 307 {neck_right} 273 L{number(160 + art.neck + 4)} 280 "
        f"Q160 317 {number(160 - art.neck - 4)} 280Z",
        cloth.deep, class_="edge",
    )
    path(
        art.front,
        f"M{number(160 - art.neck + 2)} 279 Q160 309 {number(160 + art.neck - 2)} 279",
        "none", stroke=cloth.light, stroke_width="1.6", stroke_linecap="round",
    )

    left_edge = 160 - max(20, round(body.chest * .36))
    right_edge = 320 - left_edge
    path(
        art.front,
        f"M{left_edge} 290 Q{left_edge - 4} 337 {left_edge + 2} 390 "
        f"M{right_edge} 290 Q{right_edge + 4} 337 {right_edge - 2} 390",
        "none", stroke=cloth.deep, stroke_width="2.05", stroke_linecap="round",
    )
    path(
        art.front,
        f"M{left_edge + 3} 294 Q{left_edge} 337 {left_edge + 7} 389 "
        f"M{right_edge - 3} 294 Q{right_edge} 337 {right_edge - 7} 389",
        "none", stroke=cloth.light, stroke_width="1.1", opacity=".8", stroke_linecap="round",
    )

    braid_left, braid_right = 153, 167
    path(art.front, f"M{braid_left} 291H{braid_right}V393H{braid_left}Z", "#816849", class_="edge")
    path(
        art.front,
        f"M{braid_left + 2} 295H{braid_right - 2} M{braid_left + 2} 389H{braid_right - 2}",
        "none", stroke="#d7bc8e", stroke_width="1.1",
    )
    for y in range(301, 384, 12):
        path(
            art.front,
            f"M160 {y}l4 4-4 4-4 -4Z",
            "none", stroke="#e1c698", stroke_width="1.25", stroke_linejoin="round",
        )
        path(art.front, f"M160 {y + 2}l1.8 2-1.8 2-1.8 -2Z", "#dfc38f")

    for y in (303, 329, 355, 381):
        node(art.front, "circle", cx=176, cy=y, r=3.4, fill=cloth.deep, class_="edge")
        node(art.front, "circle", cx=176, cy=y, r=1.25, fill="#dfc79b")
    path(
        art.front,
        f"M{left_waist + 10} 397 Q160 407 {right_waist - 10} 397 "
        f"M{left_waist + 8} 407 Q{left_waist + 16} 423 {left_waist + 19} 443 "
        f"M{right_waist - 8} 407 Q{right_waist - 16} 423 {right_waist - 19} 443",
        "none", stroke=cloth.deep, stroke_width="1.4", opacity=".62", stroke_linecap="round",
    )

    cuff_outer = 160 - body.sleeve
    cuff_inner = 160 - body.hem + 11
    for sleeve in art.sleeves:
        path(
            sleeve,
            f"M{cuff_outer + 8} 421 Q{cuff_outer + 24} 425 {cuff_inner} 423 "
            f"M{cuff_outer + 7} 429 Q{cuff_outer + 22} 433 {cuff_inner + 1} 431 "
            f"M{cuff_outer + 7} 437 Q{cuff_outer + 22} 441 {cuff_inner + 2} 439",
            "none", stroke="#d3b77f", stroke_width="1.45", stroke_linecap="round",
        )


def _panel_half_at(y, shoulder_half, panel_half, waist_half, hem_half):
    if y <= 349:
        return round(shoulder_half + (panel_half - shoulder_half) * (y - 287) / 62)
    if y <= 394:
        return round(panel_half + (waist_half - panel_half) * (y - 349) / 45)
    return round(waist_half + (hem_half - waist_half) * (y - 394) / 50)


def _castile_royal_pellote(art):
    body, cloth = art.body, art.cloth
    neck_left, neck_right = number(160 - art.neck), number(160 + art.neck)
    shoulder_half = max(23, min(34, round(body.shoulder * .37)))
    panel_half = max(25, min(36, round(body.chest * .43)))
    waist_half = max(panel_half + 5, min(52, round(body.waist * .56)))
    hem_half = max(waist_half + 15, min(85, body.hem - 7))
    l_shoulder, r_shoulder = 160 - shoulder_half, 160 + shoulder_half
    l_panel, r_panel = 160 - panel_half, 160 + panel_half
    l_waist, r_waist = 160 - waist_half, 160 + waist_half
    l_hem, r_hem = 160 - hem_half, 160 + hem_half

    panel = (
        f"M{neck_left} 273 Q160 305 {neck_right} 273 "
        f"Q{160 + shoulder_half - 1} 276 {r_shoulder} 286 L{r_shoulder - 1} 310 "
        f"Q{r_panel + 4} 329 {r_panel} 349 Q{r_panel + 3} 373 {r_waist} 394 "
        f"Q{r_hem - 18} 419 {r_hem} 444 H{l_hem} "
        f"Q{l_hem + 18} 419 {l_waist} 394 Q{l_panel - 3} 373 {l_panel} 349 "
        f"Q{l_panel - 4} 329 {l_shoulder + 1} 310 L{l_shoulder} 286 "
        f"Q{160 - shoulder_half + 1} 276 {neck_left} 273Z"
    )
    # The narrow front panels leave the side openings uncovered so the LINEN underlayer reads through them.
    path(art.front, panel, cloth.base, class_="edge")

    path(
        art.front,
        f"M{l_shoulder + 7} 291 Q{l_panel + 5} 322 {l_panel + 8} 348 "
        f"Q{l_waist + 5} 391 {l_hem + 15} 438 L{l_hem + 29} 438 "
        f"Q{l_waist + 17} 391 {l_panel + 19} 347 Q{l_panel + 18} 319 {l_shoulder + 19} 291Z",
        cloth.light, opacity=".27",
    )
    path(
        art.front,
        f"M{r_shoulder - 5} 291 Q{r_panel - 4} 323 {r_panel - 5} 348 "
        f"Q{r_waist - 4} 390 {r_hem - 20} 438 L{r_hem - 31} 438 "
        f"Q{r_waist - 18} 391 {r_panel - 17} 347 Q{r_panel - 16} 318 {r_shoulder - 17} 291Z",
        cloth.deep, opacity=".31",
    )

    edge = (
        f"M{neck_left} 276 Q160 307 {neck_right} 276 "
        f"M{r_shoulder} 288 L{r_shoulder - 1} 310 Q{r_panel + 4} 329 {r_panel} 349 "
        f"M{l_shoulder} 288 L{l_shoulder + 1} 310 Q{l_panel - 4} 329 {l_panel} 349 "
        f"M{l_panel} 350 Q{l_panel - 3} 373 {l_waist} 394 Q{l_hem + 18} 419 {l_hem} 441 "
        f"M{r_panel} 350 Q{r_panel + 3} 373 {r_waist} 394 Q{r_hem - 18} 419 {r_hem} 441 "
        f"M{l_hem} 441 Q160 446 {r_hem} 441"
    )
    path(art.front, edge, "none", stroke=_GOLD, stroke_width="2.25", stroke_linecap="round", stroke_linejoin="round")
    path(
        art.front,
        f"M{number(162 - art.neck)} 278 Q160 304 {number(158 + art.neck)} 278 "
        f"M{r_shoulder - 2} 289 Q{r_shoulder - 3} 311 {r_panel + 2} 348 "
        f"M{l_shoulder + 2} 289 Q{l_shoulder + 3} 311 {l_panel - 2} 348",
        "none", stroke=_GOLD_LIGHT, stroke_width=".85", stroke_linecap="round",
    )

    for y in (315, 337, 360, 383, 407, 430):
        half = _panel_half_at(y, shoulder_half, panel_half, waist_half, hem_half) - 4
        left, right = 160 - half, 160 + half
        path(
            art.front,
            f"M{left} {y} Q160 {y + 1.6} {right} {y} L{right} {y + 2.7} "
            f"Q160 {y + 4.1} {left} {y + 2.7}Z",
            _GOLD,
        )
        path(
            art.front,
            f"M{left + 1} {y + 4.3} Q160 {y + 5.8} {right - 1} {y + 4.3}",
            "none", stroke=_SILVER, stroke_width="1.25", stroke_linecap="round",
        )

    for y, half in ((300, shoulder_half - 9), (369, panel_half - 8), (397, waist_half - 13)):
        for x in range(160 - half, 160 + half, 8):
            path(
                art.front,
                f"M{x} {y}l2.2 2m2.1 -2 2.2 2m2.1 -2 2.2 2",
                "none", stroke=cloth.light, stroke_width=".72", opacity=".58", stroke_linecap="round",
            )


DRAWERS = {
    "norse_child_tunic": _norse_child_tunic,
    "rus_child_svita": _rus_child_svita,
    "castile_royal_pellote": _castile_royal_pellote,
}
