from common import node, number, path
from face_shape import ear_fit
from hair_length import SCALP_STYLES
from headwear import HeadwearFit
import image_court_art
import image_daily_art


OPTIONS = {
    "belt": {
        "none": "Без пояса",
        "leather": "Мягкий кожаный пояс",
        "woven": "Тканый пояс с узлом",
        "saaremaa": "Пояс с бляшками Сааремаа",
        "child_braid": "Детский плетёный пояс",
        "plaque_set": "Пояс с набором накладок",
        "gold_plaques": "Пояс с золотыми накладками",
    },
    "belt_pouch": {
        "none": "Без поясной сумки",
        "drawstring": "Круглый кисет на завязке",
        "pleated": "Мягкий кошель со складками",
        "novgorod_flap": "Новгородская сумка с тиснёным клапаном",
        "cloth_drawstring": "Тканевый кошелёк с завязкой",
        "small_bag": "Мешочек для мелочей",
        "sheathed_belt_knife": "Поясной нож в ножнах",
        "knife_sheath": "Кожаные ножны",
        "fire_kit_bag": "Огнивный набор в мешочке",
    },
    "jewelry": {
        "none": "Без украшений",
        "cross": "Нательный крест",
        "quadrifoil": "Золотой четырёхлистник с синей эмалью",
        "glass_beads": "Разноцветные стеклянные бусы",
        "noisy_horse": "Конёк со звенящими подвесками",
        "ring_fibula": "Пластинчатая кольцевая фибула",
        "penannular_fibula": "Подковообразная фибула",
        "leaf_pendant": "Листовая подвеска",
        "amulet_cluster": "Амулетные подвески",
        "lunula": "Лунница",
        "riasna": "Рясна",
        "encolpion": "Крест-энколпион",
        "stone_icon": "Нательная иконка",
        "zmeevik": "Змеевик",
        "amber_drops": "Ожерелье с фигурной привеской",
        "ear_hoops": "Серьги-кольца",
        "shield_temple_ring": "Ромбощитковые височные кольца",
        "hair_spiral": "Височные спирали",
        "bracelet": "Браслет с перевитыми нитями",
        "glass_bracelet": "Стеклянный браслет",
        "plate_bracelet": "Пластинчатый браслет",
        "signet_ring": "Перстень-печатка",
        "kolt": "Колты",
        "chained_pins": "Длинные булавки с цепочкой",
        "neck_torc": "Шейная гривна",
        "bone_collar_button": "Костяная пуговица ворота",
        "bronze_collar_button": "Бронзовая пуговица ворота",
        "pilgrim_badge": "Паломнический знак",
    },
}

LABELS = {
    "belt": "Пояс",
    "belt_pouch": "Поясная сумка",
    "jewelry": "Украшение",
}

_TORSO_MASK = "url(#wardrobe-torso-mask)"
_INK = "#382721"
_BRONZE = "#ac8655"
_GLINT = "#ddbd80"


def _stroke(parent, contour, color, width, *, surface="fixed"):
    return path(parent, contour, "none", stroke=color, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round", data_material_surface=surface)


def _shape(parent, contour, fill, width=1.75, *, surface="fixed"):
    return path(parent, contour, fill, stroke=_INK, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round", data_material_surface=surface)


def _fill(parent, contour, color, surface):
    return path(parent, contour, color, data_material_surface=surface)


def _disc(parent, x, y, radius, color, *, surface="base"):
    return node(parent, "circle", cx=x, cy=y, r=radius, fill=color,
                stroke=_INK, stroke_width=.8, data_material_surface=surface)


def _wire(parent, contour, *, width=2.5, color=_BRONZE, light=_GLINT):
    _stroke(parent, contour, _INK, width + 1.45)
    _stroke(parent, contour, color, width, surface="base")
    _stroke(parent, contour, light, width * .34, surface="light")


def _waistline(body, y, inset=0):
    half = body.waist + 8 - inset
    return f"M{160 - half} {y - 7}Q160 {y + 7} {160 + half} {y - 7}"


def _waist_y(body, x):
    return 405 - 7 * ((x - 160) / (body.waist + 8)) ** 2


def _buckle(parent, x, y, scale=1):
    buckle = node(parent, "g", transform=f"translate({x} {number(y)}) scale({scale})")
    _shape(buckle, "M-7 -5Q-1 -6 4 -5Q9 -2 7 3Q4 7 -7 6Z", "#795637", 1.65)
    _stroke(buckle, "M-6 -4Q0 -5 4 -4Q8 -1 6 3Q3 5 -6 5Z", _BRONZE, 2.2)
    _stroke(buckle, "M-4 -5Q2 -5 5 -3M5 4l-4 1", _GLINT, .85)
    _stroke(buckle, "M-8 0q7 -1 13 1", _INK, 2.55)
    _stroke(buckle, "M-8 -.35q7 -.8 13 1", "#c9a76d", 1.15)


def _draw_leather(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 13.1)
    _stroke(parent, _waistline(body, 405), "#79523b", 10.1, surface="base")
    _stroke(parent, _waistline(body, 402.2, 2), "#a37955", 1.65, surface="light")
    _stroke(parent, _waistline(body, 408.3, 1), "#5e3c2e", 1.15, surface="shade")
    _shape(parent, "M160 400Q174 400 183 399l5 4-5 5-23 2Z", "#966746", 1.25, surface="base")
    _stroke(parent, "M167 402l15-1", "#ba8c61", 1.05, surface="light")
    for x, y in ((170, 405), (175, 404.8), (180, 404.5)):
        node(parent, "ellipse", cx=x, cy=y, rx=.85, ry=1.05, fill=_INK, data_material_surface="fixed")
    _buckle(parent, 156, 405)


def _draw_woven(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 9.1)
    _stroke(parent, _waistline(body, 405), "#80544d", 6.7, surface="base")
    _stroke(parent, _waistline(body, 403, 1), "#b39870", .8, surface="light")
    _stroke(parent, _waistline(body, 407, 1), "#9c805e", .75, surface="light")
    for x in range(161 - body.waist, 160 + body.waist, 7):
        motif = f"M{x} {number(_waist_y(body, x))}l2.35 -1.4 2.35 1.4-2.35 1.4Z"
        path(parent, motif, "#c3a77a", opacity=.87, data_material_surface="light")

    x = number(160 + .43 * body.waist)
    knot = node(parent, "g", transform=f"translate({x} 404)")
    _shape(knot, "M1 0Q6 10 4 16l2 12-6 3Q-4 18-4 7Z", "#8a5b51", 1.4, surface="base")
    _shape(knot, "M-2 0Q-9 5-10 19l6 3Q-2 11 3 6Z", "#a47763", 1.4, surface="base")
    _stroke(knot, "M-4 8q-3 6-4 11M2 9q-1 8 2 17", "#c4a27b", .9, surface="light")
    _stroke(knot, "M-9 22l-1 3m4-2-1 3m6 4 1 3m3-4 1 3m2-4 1 3", "#6c473c", .9, surface="shade")
    _shape(knot, "M-7 0Q-4 -4 1 -4q5 0 6 4l-3 5q-7 2-11-3Z", "#a87961", 1.35, surface="base")
    _stroke(knot, "M-4 -2Q-2 1 4 1M-4 2l3 1", "#d3af84", .9, surface="light")


def _draw_saaremaa(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 13.7)
    _stroke(parent, _waistline(body, 405), "#63463b", 10.9, surface="base")
    _stroke(parent, _waistline(body, 401.6, 1), "#977354", 1.05, surface="light")
    _stroke(parent, _waistline(body, 409, 1), "#4c332c", .85, surface="shade")
    for side in (-1, 1):
        for offset in range(22, body.waist, 6):
            x = 160 + side * offset
            y = _waist_y(body, x)
            node(parent, "circle", cx=x, cy=y, r=2.45, fill=_BRONZE,
                 stroke="#553d2c", stroke_width=.8, data_material_surface="fixed")
            _stroke(parent, f"M{x - 1.2} {number(y - .4)}q.5 -1.15 1.6 -1", _GLINT, .75)
            node(parent, "circle", cx=x + .35, cy=y + .35, r=.52, fill="#765537",
                 data_material_surface="fixed")

    for x in (150, 170):
        _shape(parent, f"M{x - 7} 401h12l1 7h-13Z", "#8c6047", 1.15, surface="base")
        _buckle(parent, x, _waist_y(body, x), .8)


def draw_belt(parent, body, style):
    if style in image_court_art.BELT_DRAWERS:
        image_court_art.BELT_DRAWERS[style](parent, body)
        return
    if style == "none":
        return
    belt = node(parent, "g", data_part="belt", data_style=style, clip_path=_TORSO_MASK,
                data_material_slot="belt")
    _BELTS[style](belt, body)


def _draw_drawstring(parent):
    _shape(parent, "M-3 0h6l1 15h-7Z", "#88604a", 1.35, surface="shade")
    outline = ("M-9 13Q-5 15-2 12q3 3 6 0l5 2-3 7q6 4 8 12"
               "q2 10-6 13-11 5-20-2-6-6-2-14 1-5 8-9Z")
    _shape(parent, outline, "#98735b", surface="base")
    _fill(parent, "M3 24q11 4 11 13-1 8-10 10-7 1-12-2 10 0 12-7q2-7-1-14Z", "#77543e", "shade")
    _fill(parent, "M-6 25q-7 5-7 11t4 8q-2-4-1-8t4-11Z", "#bf9674", "light")
    _stroke(parent, "M-4 23q-4 8-3 15m9-15q4 8 1 15m-3-24v4m4-4 1 4m-11-3 1 3",
            "#624332", .95, surface="shade")
    _stroke(parent, "M-8 20q9 3 16-1m-16 2q9 3 17-1m-5 3q10 1 8 9m-8-10q9 4 13 5",
            _INK, 1.5)
    _stroke(parent, "M-6 20q7 2 13-.5m0 3 7 4", "#d3ab7e", .8)


def _draw_pleated(parent):
    _shape(parent, "M-10 0h5l1 17h-6ZM5 0h5l1 17H5Z", "#8a614b", 1.3, surface="base")
    outline = ("M-15 14Q-12 10-8 13q4-3 8 0 4-3 8 0 4-3 7 1l-2 8"
               "q6 7 7 17l-1 9q-3 8-12 8-6 4-12 0-7 2-11-4-6-2-6-11"
               "q0-11 8-20Z")
    _shape(parent, outline, "#8a5f4d", surface="base")
    _fill(parent, "M7 21q11 10 12 21 1 9-7 12l-7 2q9-9 4-20Z", "#65483c", "shade")
    _fill(parent, "M-12 23q-9 10-8 20l3 6q-1-11 7-21l-4 15 3 10 2-6q-3-9 3-24Z", "#aa7f63", "light")
    _fill(parent, "M-1 25q-4 13-3 21l2 8q1-8 4-21ZM6 28l5 13-2 8-2-7Z", "#a77b60", "light")
    _stroke(parent, "M-10 22q-6 11-6 23m9-20q-5 15-3 25m9-25q1 7-3 15l1 9m7-23q6 12 4 21",
            "#5e4034", 1.25, surface="shade")
    _stroke(parent, "M-14 19q14 3 29 0M-13 21q12 4 27 0", _INK, 1.45)
    _stroke(parent, "M-13 19q13 3 27 0", "#d2a37b", .85)
    _stroke(parent, "M-14 48q6 6 12 6 9 3 16-4", "#bd9070", .8, surface="light")


def _draw_flap(parent):
    _shape(parent, "M-11 0h6v23h-6ZM6 0h6v23H6Z", "#76513c", 1.3, surface="base")
    _stroke(parent, "M-9 2v16M8 2v16", "#a67951", .8, surface="light")
    _shape(parent, "M-21 20q21-5 42 1l1 25q-1 6-11 7l-24-.5q-9-1-9-7Z", "#6b4938", surface="shade")
    _stroke(parent, "M-20 39v6q1 5 8 5.5l23 .5q7-1 8-5l-.3-8", "#ae8261", 1, surface="light")
    _fill(parent, "M-16 40q15 6 33-1l-1 4q-19 5-32 0Z", "#52362c", "shade")
    flap = "M-21 20q21-5 42 1l.5 12q-.5 6-9 8-17 4-30-2-4-2-4-5Z"
    _shape(parent, flap, "#9b6a47", surface="base")
    _stroke(parent, "M-19 22q19-4 38 1l.5 10q-.5 4-7 6-16 4-29-2-3-1-3-4Z", "#c3986b", .9, surface="light")
    vine = ("M0 36q-3-6-.5-13 3 0 4 3-4 5-3 8m0 3q-7-9-14-5 0 4 9 5"
            "m4-1q6-8 14-5-.4 4-9 6m-5-4q-7-4-8-8 5-2 8 4"
            "m3 4q6-4 7-8-5-1-7 4")
    _stroke(parent, vine, "#694731", 1.45, surface="shade")
    _stroke(parent, "M-11 33q3 .1 6 2m10-.4 5-2m-14-5 2 2m7-1 2-2m-7 0-.4 3",
            "#d1a677", .8, surface="light")
    _shape(parent, "M-3 37q3-2 6 0l.7 9-4 3-3.8-3Z", "#77513a", 1.25, surface="base")
    node(parent, "circle", cx=0, cy=44, r=2, fill=_BRONZE, stroke=_INK, stroke_width=.85,
         data_material_surface="fixed")
    _stroke(parent, "M-1 43l1.2-.5", _GLINT, .65)


def draw_support_cord(parent, body, *, part):
    support = node(parent, "g", data_part=part, clip_path=_TORSO_MASK)
    _stroke(support, _waistline(body, 405), _INK, 4.3)
    _stroke(support, _waistline(body, 404.6), "#ad8660", 2.25)
    _stroke(support, _waistline(body, 404.5, 1), "#ddbd90", .8)


def draw_pouch(parent, body, style, *, cord):
    drawer = {**image_daily_art.POUCH_DRAWERS, **image_court_art.POUCH_DRAWERS}.get(style)
    if drawer is not None:
        if cord:
            draw_support_cord(parent, body, part="pouch-cord")
        drawer(parent, body)
        return
    if style == "none":
        return
    if cord:
        draw_support_cord(parent, body, part="pouch-cord")

    anchor = number(160 - .42 * body.waist)
    pouch = node(parent, "g", data_part="belt-pouch", data_style=style, data_material_slot="belt_pouch",
                 transform=f"translate({anchor} 404)")
    _POUCHES[style](pouch)


def _pendant_cord(parent, neck, end_y, color):
    left = number(160 - neck)
    right = number(160 + neck)
    control_y = 273 + (end_y - 273) * .7
    curve = f"M{left} 273Q{left} {control_y} 160 {end_y}Q{right} {control_y - 1} {right} 273"
    _stroke(parent, curve, _INK, 2.45)
    _stroke(parent, curve, color, 1.12)


def _draw_cross(parent, neck):
    _pendant_cord(parent, neck, 327, "#a18364")
    node(parent, "circle", cx=160, cy=328, r=2.15, fill="none",
         stroke=_INK, stroke_width=1.65, data_material_surface="fixed")
    cross = "M157.2 330q2.8-1 5.6 0v6.5h6.6l-.2 5.2-6.5-.3v10.4l-5.4.2.2-10.5h-6.4v-5.2h6.2Z"
    _shape(parent, cross, "#ab9167", 1.45, surface="base")
    _stroke(parent, "M159.2 332v17m-6.3-10.3h13.9", "#e1cba1", .95, surface="light")
    _stroke(parent, "M161.3 341.5v7.6", "#80664a", .8, surface="shade")


def _draw_quadrifoil(parent, neck):
    _pendant_cord(parent, neck, 327, "#b69a67")
    node(parent, "circle", cx=160, cy=328, r=2.3, fill="none",
         stroke="#b1905e", stroke_width=1.3, data_material_surface="base")
    pendant = node(parent, "g", transform="translate(160 341)")
    motif = ("M-11 0q0-3.9 4.8-5v-1.4h1.4Q-3.8-11 0-11q3.9 0 5 4.6h1.4V-5"
             "Q11-3.9 11 0q0 3.9-4.6 5v1.4H5Q3.9 11 0 11q-3.9 0-4.8-4.6h-1.4V5"
             "Q-11 3.9-11 0Z")
    _shape(pendant, motif, "#c99e55", 1.35, surface="base")
    path(pendant, motif, "none", transform="scale(.89)", stroke="#efd090", stroke_width=.8,
         data_material_surface="light")
    for angle in (0, 90, 180, 270):
        relief = node(pendant, "g", transform=f"rotate({angle})")
        _stroke(relief, "M-2.6-6.1Q-1.4-8 0-6.7q1.4-1.3 2.6.6M0-6.7v-2.4", "#835e31", .9,
                surface="shade")
        _stroke(relief, "M-2.4-6.6Q-1.4-7.9 0-7.2q1.4-.7 2.4.6", "#ebcf8b", .62, surface="light")
    node(pendant, "circle", cx=0, cy=0, r=4.85, fill="#deb970",
         stroke="#886237", stroke_width=.85, data_material_surface="light")
    node(pendant, "circle", cx=0, cy=0, r=3.6, fill="#345874",
         stroke="#644a38", stroke_width=.85, data_material_surface="trim")
    path(pendant, "M0-2.2q1.9 0 1.4 1.8 1.1.3 1 1.3-1 .8-1.9.1L0 2.4-.5 1q-.9.7-1.9-.1-.1-1 1-1.3Q-1.9-2.2 0-2.2Z",
         "#b9c8bc", data_material_surface="fixed")


def _draw_beads(parent, neck):
    left, right = number(160 - neck), number(160 + neck)
    _stroke(parent, f"M{left} 273Q{left} 332 160 335Q{right} 332 {right} 273", _INK, 1.75)
    colors = (("#667b78", "#abd0c4"), ("#526d85", "#91aeba"), ("#a7714f", "#e0b079"),
              ("#795771", "#bc8d9d"), ("#688269", "#a8b78b"), ("#b69259", "#dfbd79"))
    beads = ((-.235, 1.8, 2.3), (-.328, 2, 2.6), (-.43, 2.25, 2.95),
             (-.557, 2.9, 3.1), (-.702, 2.6, 2.7), (-.86, 3.1, 3.35),
             (1, 3.8, 4.15), (.855, 2.9, 3), (.69, 2.65, 3.1),
             (.547, 2.95, 3), (.432, 2.15, 2.7), (.328, 2.05, 2.45),
             (.235, 1.7, 2.4))
    colors_in_order = (0, 1, 2, 3, 4, 5, 0, 2, 3, 4, 5, 0, 1)
    # Place the beads on the two quadratic halves of the thread.
    for (position, rx, ry), color in zip(beads, colors_in_order):
        t = abs(position)
        width = neck * (1 - t * t)
        x = 160 - width if position < 0 else 160 + width
        y = 273 + 118 * t - 56 * t * t
        fill, light = colors[color]
        node(parent, "ellipse", cx=x, cy=y, rx=rx, ry=ry, fill=fill,
             stroke=_INK, stroke_width=1, data_material_surface="base")
        _stroke(parent, f"M{number(x - rx / 2)} {number(y - ry / 5)}q0 -1 1.1 -1.3", light, .85,
                surface="light")


def _draw_horse(parent, neck):
    _pendant_cord(parent, neck, 327, "#ac9268")
    horse = ("M-15 7l3-5 1-4 1-3 2 3q5 .7 8 5 3-2 7-1 3-.2 4 1"
             "q3-3 5-2 3 2 0 5l-3 2q-1 4-5 5H-3q-3-1-3-5l-2-5-2 5q-2 2-5 1Z")
    pendant = node(parent, "g", transform="translate(160 332)")
    node(pendant, "circle", cx=0, cy=-1.5, r=3.15, fill="none",
         stroke=_INK, stroke_width=2.2, data_material_surface="fixed")
    _stroke(pendant, "M-2.8-1.7q.6-3.7 4-2.4", _GLINT, 1.05, surface="light")
    _shape(pendant, horse, "#a8814e", 1.45, surface="base")
    _fill(pendant, "M-5 5q5 2 8 0 5-2 9 .5l-1 3q-2 4-12 3-3-1-4-6.5Z", "#866440", "shade")
    _stroke(pendant, "M-13 6l2.5-5 1.1.1M-7-.5q4 2 6.3 5m1.9.1q5-2 9 .5", "#dbb877", .95,
            surface="light")
    node(pendant, "circle", cx=-10.25, cy=1.9, r=.85, fill=_INK, data_material_surface="fixed")
    for x, drop in ((-5, 5), (0, 7), (5, 6), (10, 4)):
        y = 13 + drop
        _stroke(pendant, f"M{x} 13q-2 {drop - 2} 0 {drop}", _INK, 1.9)
        _stroke(pendant, f"M{x} 13q-1.4 {drop - 2} 0 {drop}", _GLINT, .85, surface="light")
        _shape(pendant, f"M{x} {y}q1.8 1.2 2 4.5l-2 1.7-2-1.7q.2-3.3 2-4.5Z",
               _BRONZE, .9, surface="base")
        _stroke(pendant, f"M{x - .35} {y + 2}l-.45 1.8", _GLINT, .65, surface="light")


def is_chest_jewelry(style):
    return style in _CHEST_JEWELRY or style in image_daily_art.JEWELRY_DRAWERS


def draw_jewelry(parent, style, neck):
    if style in image_daily_art.JEWELRY_DRAWERS:
        image_daily_art.JEWELRY_DRAWERS[style](parent, neck)
        return
    draw = _CHEST_JEWELRY.get(style)
    if draw is None:
        return
    jewelry = node(parent, "g", data_part="jewelry", data_style=style, data_material_slot="jewelry")
    draw(jewelry, neck)


def _draw_child_braid(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 6.7)
    _stroke(parent, _waistline(body, 405), "#79534f", 4.8, surface="base")
    for x in range(159 - body.waist, 160 + body.waist, 4):
        y = number(_waist_y(body, x) - 1.3)
        _stroke(parent, f"M{x} {y}q1.1 2 3.1 2.55", "#b79177", .85, surface="light")
    knot = node(parent, "g", transform="translate(164 405)")
    _shape(knot, "M0 0Q-6 7-8 18l3.2 1.3Q-2 8 2 4Q4 11 3 21L7 21Q8 10 5 2Z",
           "#8e6358", 1.3, surface="base")
    _shape(knot, "M-4 1Q-3-3 2-3Q7-2 7 2Q3 6-4 1Z", "#ae876c", 1.1, surface="light")


def _plated_belt(parent, body, *, gilded):
    _stroke(parent, _waistline(body, 405), _INK, 17.1)
    _stroke(parent, _waistline(body, 405), "#75503d", 14.9, surface="base")
    _stroke(parent, _waistline(body, 399.6, 1), "#a47756", 1.15, surface="light")
    plate = "M-5-4h10l1.2 4L5 4H-5l-1.2-4Z" if gilded else "M-4.8-5.6h9.6v8l-4.8 4-4.8-4Z"
    metal = "#cea459" if gilded else "#a6835b"
    for offset in range(16, body.waist + 1, 14):
        for side in (-1, 1):
            x = 160 + offset * side
            plate_group = node(parent, "g", transform=f"translate({x} {number(_waist_y(body, x))})")
            _shape(plate_group, plate, metal, 1.05, surface="trim")
            _stroke(plate_group, "M-3 1.4L0-2.5 3 1.4 0 3Z", "#edd695", .8, surface="trim-light")
            _disc(plate_group, 0, 0, .65, "#705436", surface="trim-shade")
    _shape(parent, "M152 398h15l4 5-3 8h-15l-3-7Z", metal, 1.45, surface="trim")
    _shape(parent, "M155 401h10l2 3-2 4h-10l-2-4Z", "#4b312b", 1.05, surface="shade")
    _stroke(parent, "M151 404h14", "#f0ca82", 1.65, surface="trim-light")


def _draw_plaque_set(parent, body):
    _plated_belt(parent, body, gilded=False)


def _draw_gold_plaques(parent, body):
    _plated_belt(parent, body, gilded=True)


def _cloth_drawstring(parent):
    _stroke(parent, "M0 15Q-11 4-3 0Q6-3 6 5L0 15", "#95755d", 2.6)
    _shape(parent, "M-11 12L-6 16-3 13 3 16 7 12 11 15 7 22Q17 32 16 43"
           "Q14 50-2 51Q-17 49-18 42Q-19 32-8 21Z", "#b29b7b", surface="base")
    _fill(parent, "M5 23Q15 33 15 41Q13 48 3 48Q9 41 5 23Z", "#846d56", "shade")
    _fill(parent, "M-10 25Q-16 36-14 42Q-11 47-8 46Q-12 36-5 24Z", "#dbc39a", "light")
    _stroke(parent, "M-8 21Q0 24 8 21M7 22q12-1 11 8q-3 0-8-5m-1-2q2 8 8 10", "#6a4d40", 1.55)
    _stroke(parent, "M-12 44q14 8 25-1", "#dac6a2", .85, surface="light")


def _small_bag(parent):
    _shape(parent, "M-5 0h10l-1 12h-7Z", "#9c805b", 1.15, surface="base")
    _shape(parent, "M-9 11Q0 9 9 11l3 23q-11 7-24 0Z", "#c0a680", 1.45, surface="base")
    _fill(parent, "M5 13h3l2 20-5 3Z", "#957e60", "shade")
    _stroke(parent, "M-7 18l-2 15Q0 38 9 33", "#e0c599", .85, surface="light")
    _shape(parent, "M-10 12Q0 9 10 12L9 20Q0 26-9 20Z", "#ceb88c", 1.25, surface="light")
    _disc(parent, 0, 20, 1.45, "#796048", surface="fixed")


def _sheathed_belt_knife(parent):
    sheath = node(parent, "g", transform="rotate(-8)")
    _stroke(sheath, "M-3 0q-9 10-3 21", "#937051", 2.7)
    _shape(sheath, "M-3 8q4-2 7 0l-.6 16h-6.7Z", "#614339", 1.45)
    _stroke(sheath, "M-2 13h4M-2 17h4", "#9a7155", 1)
    _shape(sheath, "M-6 22l13 1L5 51Q4 63-4 65L-7 61Q-5 40-6 22Z",
           "#8c5f46", 1.55, surface="base")
    _stroke(sheath, "M-4 28l-.7 30q.4 4 2.4 3", "#c3936c", .95, surface="light")
    _stroke(sheath, "M4 27L2 56l-3 7", "#593d32", 1.1, surface="shade")
    _stroke(sheath, "M-6 23L7 24", _GLINT, 1.85)


def _knife_sheath(parent):
    sheath = node(parent, "g", transform="rotate(16)")
    _shape(sheath, "M-5 0h10l-1 16-6-1Z", "#986d49", 1.25, surface="base")
    _shape(sheath, "M-7 12Q0 15 8 12Q11 27 4 40Q-2 51-11 55"
           "Q-5 35-7 12Z", "#92664a", 1.55, surface="base")
    _fill(sheath, "M4 18Q5 34-8 51Q0 48 5 39Q10 28 8 17Z", "#674636", "shade")
    _stroke(sheath, "M-4 16Q-2 35-8 48M0 20q8 5-3 9q7 3-2 10", "#bc9367", 1.15, surface="light")
    _stroke(sheath, "M-6 13Q0 16 7 13", "#50352b", 2.25)


def _fire_kit_bag(parent):
    _stroke(parent, "M-5 0q-4 7 1 14", "#967652", 2.7)
    _shape(parent, "M-12 15Q0 11 12 15l3 23q-14 9-28 2Z", "#766047", 1.55, surface="shade")
    _shape(parent, "M-5 20l3-11 9 2 5 6-9 10Z", "#727479", 1.15, surface="trim")
    _fill(parent, "M-3 19l2-8 7 2-3 4Z", "#aaa9a0", "trim-light")
    _fill(parent, "M4 23l3-9 4 4-5 7Z", "#4f5057", "trim-shade")
    _shape(parent, "M-12 16Q2 23 11 18l4 20q-14 9-28 2Z", "#a0845f", 1.4, surface="base")
    _stroke(parent, "M-10 20Q1 25 10 21M-10 37Q1 42 12 36", "#c7a782", 1.05, surface="light")


def _ring_fibula(parent, neck):
    pin = node(parent, "g", transform=f"translate({number(173 + neck)} 304) rotate(-21)")
    ring = ("M0-11A11 11 0 1 1 0 11A11 11 0 1 1 0-11Z"
            "M0-6.1A6.1 6.1 0 1 0 0 6.1A6.1 6.1 0 1 0 0-6.1Z")
    path(pin, ring, "#ad895a", fill_rule="evenodd", stroke=_INK, stroke_width=1.1,
         data_material_surface="base")
    _stroke(pin, "M-9 2A9 9 0 0 1 3-8.6M7-5.7l1.6 3.7", _GLINT, 1.15, surface="light")
    _wire(pin, "M-11 4L10-3.5", width=1.6)


def _penannular_fibula(parent, neck):
    pin = node(parent, "g", transform=f"translate({number(173 + neck)} 302) rotate(-20)")
    _wire(pin, "M-7.8 7.4A10.6 10.6 0 1 1 7.8 7.4", width=3.1)
    _shape(pin, "M-11 5l7.7 1.9-4.9 5.1ZM11 5l-7.7 1.9 4.9 5.1Z", _BRONZE, 1.05, surface="base")
    _wire(pin, "M-1-10L1.7 13", width=1.6)


def _pendant(parent, neck, drop=329):
    _pendant_cord(parent, neck, drop, "#a18669")
    _wire(parent, f"M159 {drop-1}q-3 4 0 6q4 .2 3-4", width=1.4)
    return node(parent, "g", transform=f"translate(160 {drop+4})")


def _leaf_pendant(parent, neck):
    leaf = _pendant(parent, neck)
    _shape(leaf, "M0-1Q-10 6-9 13Q-8 19 0 25Q7 19 9 11Q8 5 0-1Z", "#a4a3a0", surface="base")
    _stroke(leaf, "M0 2v19M0 15l-5-5m5 2 5-4m-5 9 4-3", "#e3ddd3", 1.15, surface="light")
    _stroke(leaf, "M0 24Q7 18 8 12", "#625e58", 1.05, surface="shade")


def _amulet_cluster(parent, neck):
    amulets = _pendant(parent, neck, 323)
    _wire(amulets, "M-10 5Q0 8 10 5M-8 5l-4 10M0 7v14M8 5l4 8", width=1.5)
    _shape(amulets, "M-13 13q4 0 2 4l-2 2-2-1zM-13 18l-3 9-2-.5 3-9Z", _BRONZE, 1.1, surface="base")
    _shape(amulets, "M-1 19q5-1 5 3v3H1v4h-2ZM10 13q8 1 6 7q-5 5-7-1Z", _BRONZE, 1.1, surface="base")
    _stroke(amulets, "M-13 15l1 1M1 22h1M11 16l2 1", _GLINT, .85, surface="light")


def _lunula(parent, neck):
    shape = _pendant(parent, neck)
    _shape(shape, "M-14 14Q-14 2-1 0Q12 0 14 14Q7 12 4 7Q0 4-4 8Q-8 13-14 14Z",
           "#a9a5a0", 1.5, surface="base")
    _stroke(shape, "M-12 10Q-7 1 1 1.7Q8 2 12 10", "#e4dbca", 1.15, surface="light")
    for x, y in ((-10, 9), (-6, 6), (0, 4.5), (6, 6), (10, 9)):
        _disc(shape, x, y, .85, "#78716c", surface="shade")


def _encolpion(parent, neck):
    cross = _pendant(parent, neck)
    _shape(cross, "M-4 0q4-3 8 0l1 8 7-1q3 3 1 8l-8 1-1 10q-4 3-8 0l-1-10-8-1"
           "q-2-5 1-8l7 1Z", "#a86b4b", 1.55, surface="base")
    _stroke(cross, "M-3 1h6l1 9 7-1m-21 1 7 1 1 13 4 1", "#deb18a", 1.1, surface="light")
    _stroke(cross, "M1.2 4v18M-7 11.8h14", "#744839", 1.45, surface="shade")
    _disc(cross, 0, 11.8, 2, "#b78458", surface="light")


def _stone_icon(parent, neck):
    icon = _pendant(parent, neck)
    _shape(icon, "M-9 5Q-7 0 0-1Q8 0 9 5v18l-3 3h-12l-3-3Z", "#818278", 1.4, surface="base")
    _stroke(icon, "M-6 22V6Q0 .5 6 6v16Z", "#b1aa98", 1.1, surface="light")
    _disc(icon, 0, 8, 2.15, "#afa48e", surface="light")
    _fill(icon, "M-1.6 10Q0 9 1.7 10l3 11h-9Z", "#5e6056", "shade")
    _stroke(icon, "M-3 20l2.8-7 2.8 7M0 13v6", "#c8bca5", .85, surface="light")


def _zmeevik(parent, neck):
    amulet = _pendant(parent, neck, 330)
    _disc(amulet, 0, 12, 12, "#a86f51")
    _disc(amulet, 0, 12, 3.05, "#bb8658", surface="light")
    for angle in range(0, 360, 60):
        ray = node(amulet, "g", transform=f"rotate({angle} 0 12)")
        _stroke(ray, "M.7 9.1q-4-3.2.5-5.8q2-.7 2.8 1.3", "#694836", 1.3, surface="shade")
        _stroke(ray, "M.6 8.7q-2.8-2.8.8-4.8", "#d5a276", .65, surface="light")


def _amber_drops(parent, neck):
    pendant = _pendant(parent, neck, 329)
    for offset, drop in ((-12, 324), (-21, 314), (12, 324), (21, 314)):
        x = 160 + neck * (offset / 35)
        _disc(parent, x, drop, 2.6, "#b5682f")
        _stroke(parent, f"M{number(x-1.2)} {drop-1}l1.2-.45", "#f1ba63", .8, surface="light")
    _shape(pendant, "M-3 0h6v5h6v4H3v9l-3 5-3-5V9h-6V5h6Z", "#b77335", 1.25, surface="base")
    _fill(pendant, "M-2 1h2v17l-1.5-2V8h-5V6h4.5Z", "#f0b665", "light")
    _stroke(pendant, "M2 10v7L0 21", "#894524", .85, surface="shade")


def _chained_pins(parent, neck):
    spread = neck + 13
    for side in (-1, 1):
        pin = node(parent, "g", transform=f"translate({number(160 + side * spread)} 299) scale({side} 1)")
        _wire(pin, "M0 7L5 35", width=2.6)
        _wire(pin, "M0-5A6 6 0 1 1 0 7A6 6 0 1 1 0-5ZM-4 5L4-3", width=1.75)
    curve = f"M{number(160-spread)} 307Q160 346 {number(160+spread)} 307"
    _wire(parent, curve, width=1.6)
    path(parent, curve, "none", stroke="#f0cd91", stroke_width=1.45, stroke_dasharray="1 3",
         data_material_surface="light")


def _neck_torc(parent, neck):
    left, right = number(163 - neck), number(157 + neck)
    _wire(parent, f"M{left} 276Q{left} 304 153 309M167 309Q{right} 304 {right} 276", width=4.4)
    _wire(parent, "M153 309a3 3 0 1 1-2 4m16-4a3 3 0 1 0 2 4", width=2.15)
    for direction in (-1, 1):
        for step in (1, 2, 3, 4):
            t = step / 5
            x = number(160 + direction * (neck * (1 - t * t) - 3 + 4 * t * t))
            y = number(276 + 56 * t - 23 * t * t)
            _stroke(parent, f"M{x} {y}l{direction * 1.4} -2.1", "#745741", .85, surface="shade")


def _bone_collar_button(parent, neck):
    _disc(parent, 160, 294, 4.1, "#d0c2a3")
    _stroke(parent, "M157.1 293q.3-2.2 3.2-2.1", "#f4e7cc", .85, surface="light")
    _stroke(parent, "M158.8 294.5l2.4-.2", "#67574b", 1.25)


def _bronze_collar_button(parent, neck):
    _shape(parent, "M156 294q0-4 4-5q4 1 4 5l-4 4Z", "#a67e58", 1.25, surface="base")
    _stroke(parent, "M158 293l2-2 2 2", _GLINT, 1.1, surface="light")
    _disc(parent, 160, 295, .75, "#705141", surface="shade")


def _pilgrim_badge(parent, neck):
    shell = node(parent, "g", transform=f"translate({number(160 - .77 * neck)} 309) rotate(12)")
    _shape(shell, "M-4-10h8l1 5q4-1 6 2l-.8 5-.9 4-2.3 2-.8 3q-6 3-12 0l-.8-3"
           "L-9 6l-1-4-1-5q3-3 6-2Z", "#9f9b8f", 1.4, surface="base")
    _stroke(shell, "M0-4v13M-1.3-4l-2.3 12m4.9-12 2.3 12M-2.7-4l-4.1 9m9.5-9 4.1 9",
            "#d1c8b4", .9, surface="light")
    _stroke(shell, "M-4.7-6h9.4", "#605952", 1.15, surface="shade")


def _ear_hoop(parent):
    _wire(parent, "M0 0q4-2 7 3q6 13-1 18q-8 3-9-8q0-7 3-11", width=2.15,
          color="#9c9a95", light="#efe4d0")
    _disc(parent, 0, 0, 1.45, "#c0b6aa")


def _shield_temple_ring(parent):
    _wire(parent, "M-1 0Q10-5 13 7Q14 20 4 23Q-6 25-9 15Q-11 5-5 2", width=2.3,
          color="#a9a6a5", light="#e7e2dc")
    for x, y in ((-4, 19), (3, 22), (10, 17)):
        shield = node(parent, "g", transform=f"translate({x} {y})")
        _shape(shield, "M0-4.5L4 0 0 4.5-4 0Z", "#b2afab", 1, surface="base")
        _stroke(shield, "M-2 .0L0-2.1 2 0", "#f0e5d1", .75, surface="light")


def _hair_spiral(parent):
    _wire(parent, "M-5-6q15-8 20 6q4 11-5 17q-9 5-15-3q-6-9 2-14q7-3 9 4q0 4-4 5",
          width=2.1)
    _disc(parent, 2, 9, 1.35, _BRONZE)


def _riasna(parent):
    for x, end in ((-3, 45), (3, 57), (9, 45)):
        _stroke(parent, f"M0 0q{x} 18 {x} {end}", "#7a7169", 1.15, surface="shade")
        for y in range(8, end, 7):
            link = x * (y / end) ** .8
            _disc(parent, link, y, 1.85, "#a7a4a1")
        _shape(parent, f"M{x} {end}l2.4 4.6-2.4 4.6-2.4-4.6Z", "#c1b8ab", 1.05, surface="base")
        _stroke(parent, f"M{x} {end + 1.4}v4.8", "#eee4d5", .75, surface="light")


def _kolt(parent):
    _wire(parent, "M0 0Q2 25 5 33m-2 .6q-3 5 1 8q4 0 4-5Z", width=1.8,
          color="#cda461", light="#f2cf87")
    face = node(parent, "g", transform="translate(4 47)")
    _shape(face, "M0-9Q-8-8-12 0Q-13 8-4 12Q5 15 12 7Q15-1 8-7Q4-10 0-9Z",
           "#c79a52", 1.45, surface="base")
    _stroke(face, "M-10 4Q-6 13 3 11Q10 9 11 4Q13-5 2-7Q-6-9-10-2", "#edd099", .95,
            surface="light")
    _stroke(face, "M-5 7Q1 6 5 1Q5-2 2-3q-2 0-3 3l-3-2m5 4Q-2 2-3 6m4-4 4 2",
            "#7b583a", 1.4, surface="shade")
    _disc(face, 3.7, -1.6, .6, "#f2cb79", surface="light")


def draw_head_jewelry(parent, look, head, *, show_ears, show_hair):
    style = look.get("jewelry", "none")
    draw = _HEAD_JEWELRY.get(style)
    if draw is None:
        return
    headgear = look.get("headgear", "none")
    if style in {"riasna", "kolt"}:
        if headgear != "rus_diamond_band" or not show_hair:
            return
        fit = HeadwearFit.for_head(look, head)
        x, y = 66 * fit.x_scale, fit.brim_y
    elif style == "ear_hoops":
        if not show_ears:
            return
        width, height, ear_y = ear_fit(look)
        lobe_y = {"attached": 18, "free": 25}.get(look.get("earlobe"), 20)
        x, y = head.cheek_half - 10 + 15 * width, ear_y + lobe_y * height
    else:
        if not show_hair or not show_ears or headgear not in _VISIBLE_TEMPLES:
            return
        if style == "hair_spiral" and look.get("hair_style") in SCALP_STYLES:
            return
        _, _, ear_y = ear_fit(look)
        x, y = head.temple_half + 6, ear_y - 21
    group = node(parent, "g", data_part="head-jewelry", data_style=style, data_material_slot="jewelry")
    for side in (-1, 1):
        ornament = node(group, "g", transform=f"translate({number(160 + side * x)} {number(y)}) scale({side} 1)")
        draw(ornament)


def _bracelet(parent, inside_left, inside_right):
    for y in (451, 454, 457):
        _wire(parent, f"M{inside_left} {y}Q{(inside_left+inside_right)/2} {y+4} {inside_right} {y-1}",
              width=1.45)


def _glass_bracelet(parent, inside_left, inside_right):
    center = (inside_left + inside_right) / 2
    rail = f"M{inside_left} 453Q{center} 461 {inside_right} 452"
    _wire(parent, rail, width=4.1, color="#537b74", light="#a6c9af")
    _stroke(parent, f"M{number(center-2)} 458q4 .2 7-.8", "#3b5d59", .95, surface="shade")


def _plate_bracelet(parent, inside_left, inside_right):
    center = (inside_left + inside_right) / 2
    _shape(parent, f"M{inside_left} 450Q{center} 457 {inside_right} 449l.5 9Q{center} 466 {inside_left} 459Z",
           "#aa8355", 1.05, surface="base")
    _stroke(parent, f"M{inside_left+1} 451.5Q{center} 458 {inside_right-1} 451", _GLINT, 1.05, surface="light")
    for offset in (-6, 0, 6):
        _disc(parent, center + offset, 457.5, .75, "#634938", surface="shade")


def _signet_ring(parent, inside_left, inside_right):
    x = (inside_left + inside_right) / 2 - 2
    ring = node(parent, "g", transform=f"translate({number(x)} 467) rotate(12)")
    _wire(ring, "M-3.5-.4q3.6 1.5 7.2 0", width=1.55, color="#c4bbb0", light="#f0e6dc")
    _shape(ring, "M-2.4-1.1L0-3.6 2.8-1.4 1.4 1.6h-2.7Z", "#a8a39e", .85, surface="base")
    _stroke(ring, "M-.9-1.4l1-1 1 .8", "#eee1cc", .65, surface="light")


def draw_hand_jewelry(parent, equipment, *, left, right, reflected=False):
    style = equipment.get("jewelry", "none")
    draw = _HAND_JEWELRY.get(style)
    if draw is None or reflected != (style == "signet_ring"):
        return
    group = node(parent, "g", data_part="hand-jewelry", data_style=style, data_material_slot="jewelry")
    draw(group, left + 4, right - 2)


_VISIBLE_TEMPLES = {"none", "rus_diamond_band", "nw_baltic_spiral_band", "cap", "felt_cap", "fur_cap"}
_BELTS = {
    "leather": _draw_leather, "woven": _draw_woven, "saaremaa": _draw_saaremaa,
    "child_braid": _draw_child_braid, "plaque_set": _draw_plaque_set, "gold_plaques": _draw_gold_plaques,
}
_POUCHES = {
    "drawstring": _draw_drawstring, "pleated": _draw_pleated, "novgorod_flap": _draw_flap,
    "cloth_drawstring": _cloth_drawstring, "small_bag": _small_bag,
    "sheathed_belt_knife": _sheathed_belt_knife, "knife_sheath": _knife_sheath, "fire_kit_bag": _fire_kit_bag,
}
_CHEST_JEWELRY = {
    "cross": _draw_cross, "quadrifoil": _draw_quadrifoil, "glass_beads": _draw_beads, "noisy_horse": _draw_horse,
    "ring_fibula": _ring_fibula, "penannular_fibula": _penannular_fibula, "leaf_pendant": _leaf_pendant,
    "amulet_cluster": _amulet_cluster, "lunula": _lunula, "encolpion": _encolpion, "stone_icon": _stone_icon,
    "zmeevik": _zmeevik, "amber_drops": _amber_drops, "chained_pins": _chained_pins, "neck_torc": _neck_torc,
    "bone_collar_button": _bone_collar_button, "bronze_collar_button": _bronze_collar_button,
    "pilgrim_badge": _pilgrim_badge,
}
_HEAD_JEWELRY = {
    "ear_hoops": _ear_hoop, "shield_temple_ring": _shield_temple_ring, "hair_spiral": _hair_spiral,
    "riasna": _riasna, "kolt": _kolt,
}
_HAND_JEWELRY = {
    "bracelet": _bracelet, "glass_bracelet": _glass_bracelet, "plate_bracelet": _plate_bracelet,
    "signet_ring": _signet_ring,
}
