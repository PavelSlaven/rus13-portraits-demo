from common import node, number, path


OPTIONS = {
    "belt": {
        "none": "Без пояса",
        "leather": "Мягкий кожаный пояс",
        "woven": "Тканый пояс с узлом",
        "saaremaa": "Пояс с бляшками Сааремаа",
    },
    "belt_pouch": {
        "none": "Без поясной сумки",
        "drawstring": "Круглый кисет на завязке",
        "pleated": "Мягкий кошель со складками",
        "novgorod_flap": "Новгородская сумка с тиснёным клапаном",
    },
    "jewelry": {
        "none": "Без украшений",
        "cross": "Нательный крест",
        "quadrifoil": "Золотой четырёхлистник с синей эмалью",
        "glass_beads": "Разноцветные стеклянные бусы",
        "noisy_horse": "Конёк со звенящими подвесками",
    },
}

LABELS = {
    "belt": "Пояс",
    "belt_pouch": "Поясная сумка",
    "jewelry": "Украшение",
}

_TORSO_MASK = "url(#wardrobe-torso-mask)"
_INK = "#382721"
_BRONZE = "#ac8655"
_GLINT = "#ddbd80"


def _stroke(parent, contour, color, width):
    return path(parent, contour, "none", stroke=color, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round")


def _shape(parent, contour, fill, width=1.75):
    return path(parent, contour, fill, stroke=_INK, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round")


def _waistline(body, y, inset=0):
    half = body.waist + 8 - inset
    return f"M{160 - half} {y - 7}Q160 {y + 7} {160 + half} {y - 7}"


def _waist_y(body, x):
    return 405 - 7 * ((x - 160) / (body.waist + 8)) ** 2


def _buckle(parent, x, y, scale=1):
    buckle = node(parent, "g", transform=f"translate({x} {number(y)}) scale({scale})")
    _shape(buckle, "M-7 -5Q-1 -6 4 -5Q9 -2 7 3Q4 7 -7 6Z", "#795637", 1.65)
    _stroke(buckle, "M-6 -4Q0 -5 4 -4Q8 -1 6 3Q3 5 -6 5Z", _BRONZE, 2.2)
    _stroke(buckle, "M-4 -5Q2 -5 5 -3M5 4l-4 1", _GLINT, .85)
    _stroke(buckle, "M-8 0q7 -1 13 1", _INK, 2.55)
    _stroke(buckle, "M-8 -.35q7 -.8 13 1", "#c9a76d", 1.15)


def _draw_leather(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 13.1)
    _stroke(parent, _waistline(body, 405), "#79523b", 10.1)
    _stroke(parent, _waistline(body, 402.2, 2), "#a37955", 1.65)
    _stroke(parent, _waistline(body, 408.3, 1), "#5e3c2e", 1.15)
    _shape(parent, "M160 400Q174 400 183 399l5 4-5 5-23 2Z", "#966746", 1.25)
    _stroke(parent, "M167 402l15-1", "#ba8c61", 1.05)
    for x, y in ((170, 405), (175, 404.8), (180, 404.5)):
        node(parent, "ellipse", cx=x, cy=y, rx=.85, ry=1.05, fill=_INK)
    _buckle(parent, 156, 405)


def _draw_woven(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 9.1)
    _stroke(parent, _waistline(body, 405), "#80544d", 6.7)
    _stroke(parent, _waistline(body, 403, 1), "#b39870", .8)
    _stroke(parent, _waistline(body, 407, 1), "#9c805e", .75)
    for x in range(161 - body.waist, 160 + body.waist, 7):
        motif = f"M{x} {number(_waist_y(body, x))}l2.35 -1.4 2.35 1.4-2.35 1.4Z"
        path(parent, motif, "#c3a77a", opacity=.87)

    x = number(160 + .43 * body.waist)
    knot = node(parent, "g", transform=f"translate({x} 404)")
    _shape(knot, "M1 0Q6 10 4 16l2 12-6 3Q-4 18-4 7Z", "#8a5b51", 1.4)
    _shape(knot, "M-2 0Q-9 5-10 19l6 3Q-2 11 3 6Z", "#a47763", 1.4)
    _stroke(knot, "M-4 8q-3 6-4 11M2 9q-1 8 2 17", "#c4a27b", .9)
    _stroke(knot, "M-9 22l-1 3m4-2-1 3m6 4 1 3m3-4 1 3m2-4 1 3", "#6c473c", .9)
    _shape(knot, "M-7 0Q-4 -4 1 -4q5 0 6 4l-3 5q-7 2-11-3Z", "#a87961", 1.35)
    _stroke(knot, "M-4 -2Q-2 1 4 1M-4 2l3 1", "#d3af84", .9)


def _draw_saaremaa(parent, body):
    _stroke(parent, _waistline(body, 405), _INK, 13.7)
    _stroke(parent, _waistline(body, 405), "#63463b", 10.9)
    _stroke(parent, _waistline(body, 401.6, 1), "#977354", 1.05)
    _stroke(parent, _waistline(body, 409, 1), "#4c332c", .85)
    for side in (-1, 1):
        for offset in range(22, body.waist, 6):
            x = 160 + side * offset
            y = _waist_y(body, x)
            node(parent, "circle", cx=x, cy=y, r=2.45, fill=_BRONZE,
                 stroke="#553d2c", stroke_width=.8)
            _stroke(parent, f"M{x - 1.2} {number(y - .4)}q.5 -1.15 1.6 -1", _GLINT, .75)
            node(parent, "circle", cx=x + .35, cy=y + .35, r=.52, fill="#765537")

    for x in (150, 170):
        _shape(parent, f"M{x - 7} 401h12l1 7h-13Z", "#8c6047", 1.15)
        _buckle(parent, x, _waist_y(body, x), .8)


def draw_belt(parent, body, style):
    if style == "none":
        return
    belt = node(parent, "g", data_part="belt", data_style=style, clip_path=_TORSO_MASK)
    _BELTS[style](belt, body)


def _draw_drawstring(parent):
    _shape(parent, "M-3 0h6l1 15h-7Z", "#88604a", 1.35)
    outline = ("M-9 13Q-5 15-2 12q3 3 6 0l5 2-3 7q6 4 8 12"
               "q2 10-6 13-11 5-20-2-6-6-2-14 1-5 8-9Z")
    _shape(parent, outline, "#98735b")
    path(parent, "M3 24q11 4 11 13-1 8-10 10-7 1-12-2 10 0 12-7q2-7-1-14Z", "#77543e")
    path(parent, "M-6 25q-7 5-7 11t4 8q-2-4-1-8t4-11Z", "#bf9674")
    _stroke(parent, "M-4 23q-4 8-3 15m9-15q4 8 1 15m-3-24v4m4-4 1 4m-11-3 1 3",
            "#624332", .95)
    _stroke(parent, "M-8 20q9 3 16-1m-16 2q9 3 17-1m-5 3q10 1 8 9m-8-10q9 4 13 5",
            _INK, 1.5)
    _stroke(parent, "M-6 20q7 2 13-.5m0 3 7 4", "#d3ab7e", .8)


def _draw_pleated(parent):
    _shape(parent, "M-10 0h5l1 17h-6ZM5 0h5l1 17H5Z", "#8a614b", 1.3)
    outline = ("M-15 14Q-12 10-8 13q4-3 8 0 4-3 8 0 4-3 7 1l-2 8"
               "q6 7 7 17l-1 9q-3 8-12 8-6 4-12 0-7 2-11-4-6-2-6-11"
               "q0-11 8-20Z")
    _shape(parent, outline, "#8a5f4d")
    path(parent, "M7 21q11 10 12 21 1 9-7 12l-7 2q9-9 4-20Z", "#65483c")
    path(parent, "M-12 23q-9 10-8 20l3 6q-1-11 7-21l-4 15 3 10 2-6q-3-9 3-24Z",
         "#aa7f63")
    path(parent, "M-1 25q-4 13-3 21l2 8q1-8 4-21ZM6 28l5 13-2 8-2-7Z", "#a77b60")
    _stroke(parent, "M-10 22q-6 11-6 23m9-20q-5 15-3 25m9-25q1 7-3 15l1 9m7-23q6 12 4 21",
            "#5e4034", 1.25)
    _stroke(parent, "M-14 19q14 3 29 0M-13 21q12 4 27 0", _INK, 1.45)
    _stroke(parent, "M-13 19q13 3 27 0", "#d2a37b", .85)
    _stroke(parent, "M-14 48q6 6 12 6 9 3 16-4", "#bd9070", .8)


def _draw_flap(parent):
    _shape(parent, "M-11 0h6v23h-6ZM6 0h6v23H6Z", "#76513c", 1.3)
    _stroke(parent, "M-9 2v16M8 2v16", "#a67951", .8)
    _shape(parent, "M-21 20q21-5 42 1l1 25q-1 6-11 7l-24-.5q-9-1-9-7Z", "#6b4938")
    _stroke(parent, "M-20 39v6q1 5 8 5.5l23 .5q7-1 8-5l-.3-8", "#ae8261", 1)
    path(parent, "M-16 40q15 6 33-1l-1 4q-19 5-32 0Z", "#52362c")
    flap = "M-21 20q21-5 42 1l.5 12q-.5 6-9 8-17 4-30-2-4-2-4-5Z"
    _shape(parent, flap, "#9b6a47")
    _stroke(parent, "M-19 22q19-4 38 1l.5 10q-.5 4-7 6-16 4-29-2-3-1-3-4Z", "#c3986b", .9)
    vine = ("M0 36q-3-6-.5-13 3 0 4 3-4 5-3 8m0 3q-7-9-14-5 0 4 9 5"
            "m4-1q6-8 14-5-.4 4-9 6m-5-4q-7-4-8-8 5-2 8 4"
            "m3 4q6-4 7-8-5-1-7 4")
    _stroke(parent, vine, "#694731", 1.45)
    _stroke(parent, "M-11 33q3 .1 6 2m10-.4 5-2m-14-5 2 2m7-1 2-2m-7 0-.4 3",
            "#d1a677", .8)
    _shape(parent, "M-3 37q3-2 6 0l.7 9-4 3-3.8-3Z", "#77513a", 1.25)
    node(parent, "circle", cx=0, cy=44, r=2, fill=_BRONZE, stroke=_INK, stroke_width=.85)
    _stroke(parent, "M-1 43l1.2-.5", _GLINT, .65)


def draw_support_cord(parent, body, *, part):
    support = node(parent, "g", data_part=part, clip_path=_TORSO_MASK)
    _stroke(support, _waistline(body, 405), _INK, 4.3)
    _stroke(support, _waistline(body, 404.6), "#ad8660", 2.25)
    _stroke(support, _waistline(body, 404.5, 1), "#ddbd90", .8)


def draw_pouch(parent, body, style, *, cord):
    if style == "none":
        return
    if cord:
        draw_support_cord(parent, body, part="pouch-cord")

    anchor = number(160 - .42 * body.waist)
    pouch = node(parent, "g", data_part="belt-pouch", data_style=style,
                 transform=f"translate({anchor} 404)")
    _POUCHES[style](pouch)


def _pendant_cord(parent, neck, end_y, color):
    left = number(160 - neck)
    right = number(160 + neck)
    control_y = 273 + (end_y - 273) * .7
    curve = f"M{left} 273Q{left} {control_y} 160 {end_y}Q{right} {control_y - 1} {right} 273"
    _stroke(parent, curve, _INK, 2.45)
    _stroke(parent, curve, color, 1.12)


def _draw_cross(parent, neck):
    _pendant_cord(parent, neck, 327, "#a18364")
    node(parent, "circle", cx=160, cy=328, r=2.15, fill="none",
         stroke=_INK, stroke_width=1.65)
    cross = "M157.2 330q2.8-1 5.6 0v6.5h6.6l-.2 5.2-6.5-.3v10.4l-5.4.2.2-10.5h-6.4v-5.2h6.2Z"
    _shape(parent, cross, "#ab9167", 1.45)
    _stroke(parent, "M159.2 332v17m-6.3-10.3h13.9", "#e1cba1", .95)
    _stroke(parent, "M161.3 341.5v7.6", "#80664a", .8)


def _draw_quadrifoil(parent, neck):
    _pendant_cord(parent, neck, 327, "#b69a67")
    node(parent, "circle", cx=160, cy=328, r=2.3, fill="none",
         stroke="#b1905e", stroke_width=1.3)
    pendant = node(parent, "g", transform="translate(160 341)")
    motif = ("M-11 0q0-3.9 4.8-5v-1.4h1.4Q-3.8-11 0-11q3.9 0 5 4.6h1.4V-5"
             "Q11-3.9 11 0q0 3.9-4.6 5v1.4H5Q3.9 11 0 11q-3.9 0-4.8-4.6h-1.4V5"
             "Q-11 3.9-11 0Z")
    _shape(pendant, motif, "#c99e55", 1.35)
    path(pendant, motif, "none", transform="scale(.89)", stroke="#efd090", stroke_width=.8)
    for angle in (0, 90, 180, 270):
        relief = node(pendant, "g", transform=f"rotate({angle})")
        _stroke(relief, "M-2.6-6.1Q-1.4-8 0-6.7q1.4-1.3 2.6.6M0-6.7v-2.4", "#835e31", .9)
        _stroke(relief, "M-2.4-6.6Q-1.4-7.9 0-7.2q1.4-.7 2.4.6", "#ebcf8b", .62)
    node(pendant, "circle", cx=0, cy=0, r=4.85, fill="#deb970",
         stroke="#886237", stroke_width=.85)
    node(pendant, "circle", cx=0, cy=0, r=3.6, fill="#345874",
         stroke="#644a38", stroke_width=.85)
    path(pendant, "M0-2.2q1.9 0 1.4 1.8 1.1.3 1 1.3-1 .8-1.9.1L0 2.4-.5 1q-.9.7-1.9-.1-.1-1 1-1.3Q-1.9-2.2 0-2.2Z",
         "#b9c8bc")


def _draw_beads(parent, neck):
    left, right = number(160 - neck), number(160 + neck)
    _stroke(parent, f"M{left} 273Q{left} 332 160 335Q{right} 332 {right} 273", _INK, 1.75)
    colors = (("#667b78", "#abd0c4"), ("#526d85", "#91aeba"), ("#a7714f", "#e0b079"),
              ("#795771", "#bc8d9d"), ("#688269", "#a8b78b"), ("#b69259", "#dfbd79"))
    beads = ((-.235, 1.8, 2.3), (-.328, 2, 2.6), (-.43, 2.25, 2.95),
             (-.557, 2.9, 3.1), (-.702, 2.6, 2.7), (-.86, 3.1, 3.35),
             (1, 3.8, 4.15), (.855, 2.9, 3), (.69, 2.65, 3.1),
             (.547, 2.95, 3), (.432, 2.15, 2.7), (.328, 2.05, 2.45),
             (.235, 1.7, 2.4))
    colors_in_order = (0, 1, 2, 3, 4, 5, 0, 2, 3, 4, 5, 0, 1)
    # Place the beads on the two quadratic halves of the thread.
    for (position, rx, ry), color in zip(beads, colors_in_order):
        t = abs(position)
        width = neck * (1 - t * t)
        x = 160 - width if position < 0 else 160 + width
        y = 273 + 118 * t - 56 * t * t
        fill, light = colors[color]
        node(parent, "ellipse", cx=x, cy=y, rx=rx, ry=ry, fill=fill,
             stroke=_INK, stroke_width=1)
        _stroke(parent, f"M{number(x - rx / 2)} {number(y - ry / 5)}q0 -1 1.1 -1.3", light, .85)


def _draw_horse(parent, neck):
    _pendant_cord(parent, neck, 327, "#ac9268")
    horse = ("M-15 7l3-5 1-4 1-3 2 3q5 .7 8 5 3-2 7-1 3-.2 4 1"
             "q3-3 5-2 3 2 0 5l-3 2q-1 4-5 5H-3q-3-1-3-5l-2-5-2 5q-2 2-5 1Z")
    pendant = node(parent, "g", transform="translate(160 332)")
    node(pendant, "circle", cx=0, cy=-1.5, r=3.15, fill="none",
         stroke=_INK, stroke_width=2.2)
    _stroke(pendant, "M-2.8-1.7q.6-3.7 4-2.4", _GLINT, 1.05)
    _shape(pendant, horse, "#a8814e", 1.45)
    path(pendant, "M-5 5q5 2 8 0 5-2 9 .5l-1 3q-2 4-12 3-3-1-4-6.5Z", "#866440")
    _stroke(pendant, "M-13 6l2.5-5 1.1.1M-7-.5q4 2 6.3 5m1.9.1q5-2 9 .5", "#dbb877", .95)
    node(pendant, "circle", cx=-10.25, cy=1.9, r=.85, fill=_INK)
    for x, drop in ((-5, 5), (0, 7), (5, 6), (10, 4)):
        y = 13 + drop
        _stroke(pendant, f"M{x} 13q-2 {drop - 2} 0 {drop}", _INK, 1.9)
        _stroke(pendant, f"M{x} 13q-1.4 {drop - 2} 0 {drop}", _GLINT, .85)
        _shape(pendant, f"M{x} {y}q1.8 1.2 2 4.5l-2 1.7-2-1.7q.2-3.3 2-4.5Z",
               _BRONZE, .9)
        _stroke(pendant, f"M{x - .35} {y + 2}l-.45 1.8", _GLINT, .65)


def draw_jewelry(parent, style, neck):
    if style == "none":
        return
    jewelry = node(parent, "g", data_part="jewelry", data_style=style)
    _JEWELRY[style](jewelry, neck)


_BELTS = {"leather": _draw_leather, "woven": _draw_woven, "saaremaa": _draw_saaremaa}
_POUCHES = {"drawstring": _draw_drawstring, "pleated": _draw_pleated, "novgorod_flap": _draw_flap}
_JEWELRY = {
    "cross": _draw_cross, "quadrifoil": _draw_quadrifoil,
    "glass_beads": _draw_beads, "noisy_horse": _draw_horse,
}
