from common import node, number, path


OPTIONS = {
    "nw_gotland_mens_cloak": "Готландская туника с перекинутым плащом",
    "nw_gotland_womens_mantle": "Готландское платье с ниспадающей накидкой",
}

MEN_CLOAK = ("#78514a", "#a1725e", "#52353a", "#3b2b30")
WOMEN_MANTLE = ("#606f68", "#8b9a86", "#424f4c", "#303a3a")


def _men_cloak_edges(body):
    return 178 + body.hem // 3, 159 + body.hem


def _women_mantle_edges(body):
    return (168 - body.hem, 144 - body.hem // 4,
            175 + body.hem // 4, 154 + body.hem)


def _draped_layer(parent, name, shape, base):
    group = node(parent, "g", data_part=name)
    mask = f"{name}-clip"
    path(node(group, "clipPath", id=mask), shape)
    path(group, shape, base, class_="edge")
    return group, node(group, "g", clip_path=f"url(#{mask})")


def draw_mens_cloak(art):
    body, cloth = art.body, art.cloth
    neck_left = number(160 - art.neck)
    neck_right = number(160 + art.neck)
    left_shoulder = 160 - body.shoulder
    right_shoulder = 160 + body.shoulder
    right_sleeve = 160 + body.sleeve
    left_hem = 160 - body.hem
    y = body.shoulder_y
    inner, outer = _men_cloak_edges(body)
    base, light, shade, deep = MEN_CLOAK

    path(art.front, "M0 273H320V449H0Z", cloth.base)
    path(art.front,
         f"M{left_shoulder + 3} 289Q122 274 141 296Q106 326 {left_shoulder + 7} 358 "
         f"Q{left_hem + 20} 387 {left_hem + 8} 441Q{left_hem - 3} 409 {left_hem - 8} 390 "
         f"L{left_shoulder - 7} 335Z M169 316Q180 350 172 384Q165 416 166 443 "
         "Q161 419 164 388Q169 350 169 316Z", cloth.shade)
    path(art.front,
         "M121 309Q112 338 110 375Q117 353 130 320Z "
         "M150 344Q140 387 145 443Q137 414 139 383Q141 360 150 344Z", cloth.light, opacity=".73")
    path(art.front,
         f"M121 318Q101 343 {left_shoulder + 16} 372 M141 372Q138 405 144 432 M170 354q6 11 4 23",
         class_="seam")
    path(art.front, "M114 364q-5 7-6 15m10 -11-4 10M156 404l-2 17", class_="etch")
    collar = f"M{neck_left} 273Q160 307 {neck_right} 273"
    path(art.front, collar, "none", stroke=cloth.deep, stroke_width=6)
    path(art.front, f"M{neck_left} 279Q160 313 {neck_right} 279", "none",
         stroke=cloth.light, stroke_width=1.6)

    shape = (
         f"M{neck_left} 273C{left_shoulder + 19} 279 {left_shoulder - 4} {y - 4} {left_shoulder - 8} {y + 14} "
         f"Q104 {y + 13} 119 307Q149 318 185 301Q186 335 208 371 "
         f"Q{inner + 2} 406 {inner} 430V449H{outer}V430 "
         f"C{outer + 10} 394 {right_sleeve + 4} 356 {right_shoulder + 13} 321 "
         f"Q{right_shoulder + 7} {y + 2} {neck_right} 273Q186 283 176 290Q146 292 {neck_left} 273Z"
    )
    garment, cloak = _draped_layer(art.outer, "gotland-shoulder-cloak", shape, base)
    path(cloak,
         f"M{neck_left} 278Q141 299 178 292L183 299Q151 313 120 302 "
         f"Q101 295 {left_shoulder + 3} {y + 9}Q{left_shoulder + 19} {y - 3} {neck_left} 278Z",
         light)
    path(cloak,
         f"M188 301Q205 339 224 354Q{inner + 29} 388 {inner + 15} 423V449H{inner + 2}V429 "
         f"Q{inner + 4} 408 210 370Q192 338 188 301Z", deep)
    path(cloak,
         f"M190 300Q218 312 {right_shoulder + 8} 328Q{right_sleeve - 9} 354 {outer + 4} 389 "
         f"L{outer - 2} 426V449H{outer - 9}V428Q{outer + 2} 398 {outer - 7} 367Q223 324 190 300Z",
         shade)
    path(cloak,
         f"M198 317Q225 330 {right_shoulder + 1} 351Q{outer - 4} 377 {inner + 20} 410 "
         f"Q{inner + 25} 388 228 364Q216 337 198 317Z", light)
    path(cloak,
         f"M191 305Q219 320 {right_shoulder + 9} 343Q{outer + 2} 354 {outer + 2} 380 "
         f"L{outer - 13} 387Q{right_shoulder - 1} 345 191 305Z", "url(#ink-lines)", opacity=".45")
    path(cloak,
         f"M{left_shoulder + 8} {y + 4}Q121 285 151 301Q167 306 181 297 "
         f"M200 320Q{right_shoulder + 6} 350 {outer - 11} 393 "
         f"M218 376Q{inner + 19} 403 {inner + 12} 431", class_="seam")
    path(cloak, f"M{outer - 9} 400l-3 11m8 -17 -3 14M213 343q8 7 12 14", class_="etch")

    clasp = node(garment, "g", data_part="gotland-cloak-clasp", transform="translate(186 297) rotate(-17)")
    node(clasp, "ellipse", rx=8.5, ry=6.8, fill="#b39769", stroke="#392b28", stroke_width=2.5)
    node(clasp, "ellipse", rx=4.5, ry=3.65, fill=deep)
    path(clasp, "M-8 0H7M-4 -4l3 -1", "none", stroke="#ddbe86", stroke_width=1.6,
         stroke_linecap="round")


def draw_womens_mantle(art):
    body, cloth = art.body, art.cloth
    neck_left = number(160 - art.neck)
    neck_right = number(160 + art.neck)
    left_shoulder = 160 - body.shoulder
    right_shoulder = 160 + body.shoulder
    left_sleeve = 160 - body.sleeve
    right_sleeve = 160 + body.sleeve
    left_outer, left_inner, right_inner, right_outer = _women_mantle_edges(body)
    base, light, shade, deep = WOMEN_MANTLE

    path(art.front, f"M{neck_left} 278Q160 323 {neck_right} 278", "none", stroke=cloth.deep,
         stroke_width=3.2)
    path(art.front,
         "M145 310Q139 347 146 380Q149 413 145 447H155Q158 420 153 383Q146 341 145 310Z "
         "M179 321Q185 353 177 389Q172 421 180 447H188Q182 416 185 388Q190 350 179 321Z",
         cloth.shade)
    path(art.front, "M155 336Q151 357 156 387Q163 425 157 444 M169 369Q164 407 168 435",
         class_="etch")

    shape = (
         f"M{neck_left} 273Q{left_shoulder + 15} 276 {left_shoulder - 3} {body.shoulder_y + 7} "
         f"Q{left_sleeve + 9} 322 {left_sleeve + 6} 356Q{left_sleeve + 30} 384 {left_outer} 429V449 "
         f"H{left_inner}V430Q{left_inner - 6} 411 124 392Q145 386 145 375Q121 365 111 336 "
         f"Q106 304 {neck_left} 273Z "
         f"M{neck_right} 273Q{right_shoulder - 9} 282 {right_shoulder + 4} {body.shoulder_y + 12} "
         f"Q{right_sleeve - 19} 316 {right_sleeve - 6} 349Q{right_sleeve - 9} 374 {right_outer} 426V449 "
         f"H{right_inner}V426Q{right_inner + 12} 403 194 385Q188 381 176 376 "
         f"Q208 361 209 329Q207 295 {neck_right} 273Z"
    )
    _, mantle = _draped_layer(art.outer, "gotland-open-mantle", shape, base)
    path(mantle,
         f"M{left_shoulder - 2} 299Q{left_sleeve + 18} 330 {left_sleeve + 9} 355 "
         f"Q64 383 {left_outer + 2} 425V449H{left_outer + 11}V425Q99 396 99 377Q67 356 {left_shoulder - 2} 299Z "
         f"M{right_shoulder + 8} 309Q{right_sleeve - 5} 336 {right_sleeve - 10} 354 "
         f"Q{right_outer + 2} 388 {right_outer - 2} 427V449H{right_outer - 13}V427Q{right_outer - 3} 388 222 367 "
         f"Q{right_shoulder + 11} 340 {right_shoulder + 8} 309Z", shade)
    path(mantle,
         f"M112 337Q121 365 143 375Q138 385 124 391Q{left_inner - 7} 414 {left_inner - 2} 431V449 "
         f"H{left_inner - 11}V432Q{left_inner - 18} 406 99 388Q129 383 131 376Q118 367 112 337Z "
         f"M207 345Q198 367 178 376Q195 381 199 392Q{right_inner + 9} 405 {right_inner + 2} 427V449 "
         f"H{right_inner + 10}V427Q{right_inner + 26} 395 192 376Q203 367 207 345Z", deep)
    path(mantle,
         f"M{neck_left} 276Q111 308 99 329Q92 353 124 373Q99 373 81 355 "
         f"Q89 319 {neck_left} 276Z "
         f"M{neck_right} 277Q220 308 228 335Q225 363 191 374Q208 365 210 343Q212 316 {neck_right} 277Z",
         light)
    path(mantle,
         f"M{left_sleeve + 12} 356Q77 373 115 386L104 392Q77 380 {left_sleeve + 12} 356Z "
         f"M{right_sleeve - 13} 348Q237 362 200 378L213 381Q242 366 {right_sleeve - 13} 348Z",
         "url(#ink-lines)", opacity=".54")
    path(mantle,
         f"M{left_shoulder + 1} 310Q67 341 85 360Q103 374 123 377 "
         f"M{left_outer + 4} 398Q{left_outer + 18} 425 {left_outer + 19} 445 "
         f"M{right_shoulder - 7} 303Q244 345 218 362Q206 369 194 373 "
         f"M{right_outer - 9} 393Q{right_outer - 17} 411 {right_outer - 17} 446", class_="seam")
    path(mantle, "M95 369q8 6 19 9m-25 -2 15 7m118 -13 11 -7m-7 14 10 -6", class_="etch")


def draw_mens_lower(parent, body, cloth, *, show_cloak=True):
    left, right = 160 - body.hem, 160 + body.hem
    inner, outer = _men_cloak_edges(body)
    base, light, shade, deep = MEN_CLOAK
    tunic_shape = (f"M{left + 2} 431H{right - 2}Q{right + 1} 493 {right + 6} 555 "
                   f"Q159 575 {left - 8} 550Q{left + 6} 490 {left + 2} 431Z")
    _, tunic = _draped_layer(parent, "gotland-tunic-hem", tunic_shape, cloth.base)
    path(tunic,
         f"M{left + 8} 439Q{left + 21} 470 107 506Q98 528 98 556L{left - 4} 548 "
         f"Q{left + 8} 487 {left + 8} 439Z M165 440Q180 479 184 509Q188 536 201 559L180 562 "
         "Q171 511 165 440Z", cloth.shade)
    path(tunic, "M145 442Q140 478 142 512Q145 538 134 560Q157 565 156 556Q151 505 145 442Z",
         cloth.light, opacity=".73")
    path(tunic,
         f"M{left - 2} 546Q158 568 {right + 1} 550 M126 454Q113 474 117 499Q119 519 109 533 "
         "M171 468Q184 507 183 526", class_="seam")
    if not show_cloak:
        return tunic_shape

    cloak_shape = (f"M{inner} 434H{outer}Q{outer - 1} 476 {outer + 14} 507Q{outer + 21} 533 {outer + 7} 555 "
                   f"Q{outer - 13} 567 {inner + 4} 584Q{inner + 15} 551 {inner + 8} 529Q{inner - 7} 482 {inner} 434Z")
    _, cloak = _draped_layer(parent, "gotland-cloak-free-end", cloak_shape, base)
    path(cloak,
         f"M{inner + 2} 435H{inner + 15}Q{inner + 8} 476 {inner + 22} 520 "
         f"Q{inner + 32} 551 {inner + 20} 575L{inner + 7} 581Q{inner + 20} 547 {inner + 10} 530 "
         f"Q{inner - 5} 479 {inner + 2} 435Z", deep)
    path(cloak,
         f"M{outer - 9} 435H{outer - 2}Q{outer - 5} 479 {outer + 12} 509Q{outer + 20} 534 {outer + 5} 553 "
         f"L{outer - 12} 562Q{outer + 1} 534 {outer + 2} 520Q{outer - 11} 477 {outer - 9} 435Z", shade)
    path(cloak,
         f"M{outer - 20} 453Q{outer - 29} 485 {outer - 9} 520Q{outer + 1} 540 {outer - 11} 555 "
         f"Q{outer - 3} 529 {outer - 20} 515Q{outer - 30} 492 {outer - 20} 453Z", light)
    path(cloak, f"M{inner + 8} 575Q{outer - 4} 562 {outer + 2} 551 M{inner + 19} 466q-3 24 10 52",
         class_="seam")
    return f"{tunic_shape} {cloak_shape}"


def draw_womens_lower(parent, body, cloth, *, show_cloak=True):
    left, right = 160 - body.hem, 160 + body.hem
    left_outer, left_inner, right_inner, right_outer = _women_mantle_edges(body)
    base, light, shade, deep = WOMEN_MANTLE
    gown_shape = (f"M{left + 2} 431H{right - 2}Q{right + 2} 548 {right + 22} 696 "
                  f"Q165 717 {left - 22} 697Q{left - 3} 568 {left + 2} 431Z")
    _, gown = _draped_layer(parent, "gotland-gown-hem", gown_shape, cloth.base)
    path(gown,
         "M145 433H155Q156 526 127 610Q109 669 106 722L84 718Q99 632 126 565Q148 496 145 433Z "
         "M178 433H187Q183 513 194 574Q216 645 228 721L204 725Q191 642 176 573Q169 493 178 433Z",
         cloth.shade)
    path(gown, "M161 455Q173 559 155 649Q147 690 153 722H135Q139 675 151 632Q166 548 161 455Z",
         cloth.light)
    path(gown,
         f"M{left - 16} 691Q164 712 {right + 16} 691 M151 492Q151 551 136 586Q116 660 111 686 "
         "M181 455Q176 523 187 567Q202 613 206 668", class_="seam")
    if not show_cloak:
        return gown_shape

    mantle_shape = (
         f"M{left_outer} 434H{left_inner}Q{left_inner - 3} 532 120 575Q113 634 119 685 "
         f"Q90 691 {left_outer - 25} 666Q{left_outer - 18} 606 {left_outer - 8} 564Q{left_outer - 1} 514 {left_outer} 434Z "
         f"M{right_inner} 434H{right_outer}Q{right_outer + 4} 523 {right_outer + 13} 567 "
         f"Q{right_outer + 24} 624 {right_outer + 16} 682Q{right_outer - 4} 700 198 700 "
         f"Q202 646 {right_inner - 3} 589Q{right_inner - 8} 504 {right_inner} 434Z"
    )
    _, mantle = _draped_layer(parent, "gotland-mantle-hanging-folds", mantle_shape, base)
    path(mantle,
         f"M{left_outer + 2} 435H{left_outer + 11}Q{left_outer + 12} 511 {left_outer + 8} 562 "
         f"Q{left_outer - 3} 615 {left_outer - 10} 672L{left_outer - 22} 664Q{left_outer - 16} 603 {left_outer - 6} 563 "
         f"Q{left_outer + 1} 515 {left_outer + 2} 435Z "
         f"M{right_outer - 13} 435H{right_outer - 2}Q{right_outer + 3} 523 {right_outer + 11} 567 "
         f"Q{right_outer + 22} 622 {right_outer + 14} 679L{right_outer + 2} 686 "
         f"Q{right_outer + 12} 624 {right_outer - 1} 574Q{right_outer - 11} 520 {right_outer - 13} 435Z", shade)
    path(mantle,
         f"M{left_inner - 11} 435H{left_inner - 2}Q{left_inner - 5} 529 118 574Q110 628 117 683L106 685 "
         f"Q98 626 108 570Q{left_inner - 11} 514 {left_inner - 11} 435Z "
         f"M{right_inner + 2} 435H{right_inner + 10}Q{right_inner + 5} 516 {right_inner + 10} 582 "
         f"Q{right_inner + 21} 636 209 696L200 698Q204 645 {right_inner - 1} 587 "
         f"Q{right_inner - 6} 501 {right_inner + 2} 435Z", deep)
    path(mantle,
         f"M{left_outer + 20} 446Q{left_outer + 25} 524 {left_outer + 23} 552Q{left_outer + 3} 628 {left_outer + 4} 670 "
         f"Q{left_outer + 1} 621 {left_outer + 16} 559Q{left_outer + 23} 496 {left_outer + 20} 446Z "
         f"M{right_outer - 21} 447Q{right_outer - 25} 502 {right_outer - 12} 574Q{right_outer - 3} 621 {right_outer - 6} 674 "
         f"Q{right_outer - 10} 628 {right_outer - 25} 571Q{right_outer - 30} 507 {right_outer - 21} 447Z", light)
    path(mantle,
         f"M{left_outer - 20} 663Q{left_outer + 7} 682 115 680 M203 694Q{right_outer - 3} 693 {right_outer + 11} 678",
         class_="seam")
    return f"{gown_shape} {mantle_shape}"


DRAWERS = {
    "nw_gotland_mens_cloak": draw_mens_cloak,
    "nw_gotland_womens_mantle": draw_womens_mantle,
}

LOWER_DRAWERS = {
    "nw_gotland_mens_cloak": draw_mens_lower,
    "nw_gotland_womens_mantle": draw_womens_lower,
}
