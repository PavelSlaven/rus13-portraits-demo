from common import node, number, path


OPTIONS = {
    "nw_gotland_mens_cloak": "Готландская туника с перекинутым плащом",
    "nw_gotland_womens_mantle": "Готландское платье с ниспадающей накидкой",
}

MEN_CLOAK = ("#78514a", "#a1725e", "#52353a", "#3b2b30")
WOMEN_MANTLE = ("#606f68", "#8b9a86", "#424f4c", "#303a3a")


def _men_cloak_edges(body):
    return 178 + body.hem // 3, 159 + body.hem


def _women_mantle_edges(body):
    return (168 - body.hem, 144 - body.hem // 4,
            175 + body.hem // 4, 154 + body.hem)


def _draped_layer(parent, name, shape, base):
    group = node(parent, "g", data_part=name)
    mask = f"{name}-clip"
    path(node(group, "clipPath", id=mask), shape)
    path(group, shape, base, class_="edge")
    return group, node(group, "g", clip_path=f"url(#{mask})")


def draw_mens_cloak(art):
    body, cloth = art.body, art.cloth
    neck_left = number(160 - art.neck)
    neck_right = number(160 + art.neck)
    left_shoulder = 160 - body.shoulder
    right_shoulder = 160 + body.shoulder
    right_sleeve = 160 + body.sleeve
    left_hem = 160 - body.hem
    y = body.shoulder_y
    inner, outer = _men_cloak_edges(body)
    base, light, shade, deep = MEN_CLOAK

    side_fold = (f"Q{left_hem + 20} 387 {left_hem + 8} 441Q{left_hem - 3} 409 {left_hem - 8} 390")
    middle_fold = "Q165 416 166 443 Q161 419 164 388"
    light_fold = "Q140 387 145 443Q137 414 139 383"
    free_end = f"V449H{outer}V430"
    dark_fold = f"V449H{inner + 2}V429"
    outside_fold = f"V449H{outer - 9}V428"
    if art.hem_y is None:
        path(art.front, "M0 273H320V449H0Z", cloth.base)
    else:
        hem = art.hem_y
        left = 160 - art.hem_half
        tip = 160 + art.hem_half - 13
        bend = round((430 + hem) / 2)
        side_fold = (f"Q{left_hem + 20} 387 {left_hem + 8} 441 "
                     f"Q{left_hem + 18} {bend} {left + 13} {hem + 2}L{left + 2} {hem - 7} "
                     f"Q{left_hem + 14} {bend} {left_hem - 8} 390")
        middle_fold = (f"Q167 416 170 443Q174 {bend} 191 {hem + 8}L177 {hem + 12} "
                       "Q159 449 164 388")
        light_fold = (f"Q140 387 145 443Q155 {bend} 149 {hem + 12}H134 "
                      "Q144 484 139 383")
        free_end = (f"C{inner - 6} 459 {inner + 11} {hem - 30} {inner + 3} {hem + 3} "
                    f"Q{tip - 3} {hem - 5} {tip} {hem - 20} "
                    f"C{tip + 10} {hem - 50} {outer - 3} 465 {outer} 430")
        dark_fold = (f"Q{inner + 13} 449 {inner + 24} {hem - 29} "
                     f"Q{inner + 25} {hem - 13} {inner + 17} {hem - 3}L{inner + 5} {hem + 3} "
                     f"Q{inner + 11} {hem - 19} {inner + 5} {hem - 37}Q{inner - 3} 448 {inner + 2} 429")
        outside_fold = (f"Q{outer - 4} 464 {tip + 2} {hem - 44}Q{tip + 7} {hem - 30} {tip - 1} {hem - 21} "
                        f"L{tip - 11} {hem - 12}Q{tip - 4} {hem - 34} {tip - 9} {hem - 54} "
                        f"Q{outer - 10} 466 {outer - 9} 428")
    path(art.front,
         f"M{left_shoulder + 3} 289Q122 274 141 296Q106 326 {left_shoulder + 7} 358 "
         f"{side_fold} L{left_shoulder - 7} 335Z M169 316Q180 350 172 384{middle_fold}"
         "Q169 350 169 316Z", cloth.shade)
    path(art.front,
         "M121 309Q112 338 110 375Q117 353 130 320Z "
         f"M150 344{light_fold}Q141 360 150 344Z", cloth.light, opacity=".73")
    path(art.front,
         f"M121 318Q101 343 {left_shoulder + 16} 372 M141 372Q138 405 144 432 M170 354q6 11 4 23",
         class_="seam")
    path(art.front, "M114 364q-5 7-6 15m10 -11-4 10M156 404l-2 17", class_="etch")
    collar = f"M{neck_left} 273Q160 307 {neck_right} 273"
    path(art.front, collar, "none", stroke=cloth.deep, stroke_width=6)
    path(art.front, f"M{neck_left} 279Q160 313 {neck_right} 279", "none",
         stroke=cloth.light, stroke_width=1.6)
    if art.hem_y is not None:
        path(art.front, f"M126 454Q113 474 117 {hem - 44}Q119 {hem - 28} 109 {hem - 16} "
             f"M171 468Q184 {hem - 40} 183 {hem - 21}", class_="etch")

    shape = (
         f"M{neck_left} 273C{left_shoulder + 19} 279 {left_shoulder - 4} {y - 4} {left_shoulder - 8} {y + 14} "
         f"Q104 {y + 13} 119 307Q149 318 185 301Q186 335 208 371 "
         f"Q{inner + 2} 406 {inner} 430{free_end} "
         f"C{outer + 10} 394 {right_sleeve + 4} 356 {right_shoulder + 13} 321 "
         f"Q{right_shoulder + 7} {y + 2} {neck_right} 273Q186 283 176 290Q146 292 {neck_left} 273Z"
    )
    garment, cloak = _draped_layer(art.outer, "gotland-shoulder-cloak", shape, base)
    path(cloak,
         f"M{neck_left} 278Q141 299 178 292L183 299Q151 313 120 302 "
         f"Q101 295 {left_shoulder + 3} {y + 9}Q{left_shoulder + 19} {y - 3} {neck_left} 278Z",
         light)
    path(cloak,
         f"M188 301Q205 339 224 354Q{inner + 29} 388 {inner + 15} 423{dark_fold} "
         f"Q{inner + 4} 408 210 370Q192 338 188 301Z", deep)
    path(cloak,
         f"M190 300Q218 312 {right_shoulder + 8} 328Q{right_sleeve - 9} 354 {outer + 4} 389 "
         f"L{outer - 2} 426{outside_fold}Q{outer + 2} 398 {outer - 7} 367Q223 324 190 300Z",
         shade)
    path(cloak,
         f"M198 317Q225 330 {right_shoulder + 1} 351Q{outer - 4} 377 {inner + 20} 410 "
         f"Q{inner + 25} 388 228 364Q216 337 198 317Z", light)
    path(cloak,
         f"M191 305Q219 320 {right_shoulder + 9} 343Q{outer + 2} 354 {outer + 2} 380 "
         f"L{outer - 13} 387Q{right_shoulder - 1} 345 191 305Z", "url(#ink-lines)", opacity=".45")
    path(cloak,
         f"M{left_shoulder + 8} {y + 4}Q121 285 151 301Q167 306 181 297 "
         f"M200 320Q{right_shoulder + 6} 350 {outer - 11} 393 "
         f"M218 376Q{inner + 19} 403 {inner + 12} 431", class_="seam")
    path(cloak, f"M{outer - 9} 400l-3 11m8 -17 -3 14M213 343q8 7 12 14", class_="etch")
    if art.hem_y is not None:
        path(cloak, f"M{outer - 20} 434Q{outer - 26} {bend} {tip - 9} {hem - 42} "
             f"Q{tip - 4} {hem - 33} {tip - 12} {hem - 21}Q{tip - 11} {hem - 36} {tip - 18} {hem - 45} "
             f"Q{outer - 27} {bend} {outer - 20} 434Z", light)
        path(cloak, f"M{inner + 9} {hem - 8}Q{tip - 8} {hem - 13} {tip - 5} {hem - 23} "
             f"M{inner + 14} 436Q{inner + 13} 458 {inner + 20} {hem - 38}", class_="seam")

    clasp = node(garment, "g", data_part="gotland-cloak-clasp", transform="translate(186 297) rotate(-17)")
    node(clasp, "ellipse", rx=8.5, ry=6.8, fill="#b39769", stroke="#392b28", stroke_width=2.5)
    node(clasp, "ellipse", rx=4.5, ry=3.65, fill=deep)
    path(clasp, "M-8 0H7M-4 -4l3 -1", "none", stroke="#ddbe86", stroke_width=1.6,
         stroke_linecap="round")


def draw_womens_mantle(art):
    body, cloth = art.body, art.cloth
    neck_left = number(160 - art.neck)
    neck_right = number(160 + art.neck)
    left_shoulder = 160 - body.shoulder
    right_shoulder = 160 + body.shoulder
    left_sleeve = 160 - body.sleeve
    right_sleeve = 160 + body.sleeve
    left_outer, left_inner, right_inner, right_outer = _women_mantle_edges(body)
    base, light, shade, deep = WOMEN_MANTLE

    gown_folds = ("M145 310Q139 347 146 380Q149 413 145 447H155Q158 420 153 383Q146 341 145 310Z "
                  "M179 321Q185 353 177 389Q172 421 180 447H188Q182 416 185 388Q190 350 179 321Z")
    left_end = f"V449 H{left_inner}V430"
    right_end = f"V449 H{right_inner}V426"
    shaded_left = f"V449H{left_outer + 11}V425"
    shaded_right = f"V449H{right_outer - 13}V427"
    dark_left = f"V449 H{left_inner - 11}V432"
    dark_right = f"V449 H{right_inner + 10}V427"
    if art.hem_y is not None:
        hem = art.hem_y
        left_outer = max(left_outer, 164 - body.waist)
        right_outer = min(right_outer, 156 + body.waist)
        left_tip = 175 - art.hem_half
        right_tip = 144 + art.hem_half
        mid = round((430 + hem) / 2)
        gown_folds = (
            f"M145 310Q139 347 146 380C157 465 111 {hem - 86} 106 {hem + 14}L91 {hem + 9} "
            f"C104 {hem - 91} 164 498 153 383Q146 341 145 310Z "
            f"M179 321Q185 353 177 389C158 481 183 {mid} 205 {hem + 14}H224 "
            f"C212 {mid} 169 501 185 388Q190 350 179 321Z"
        )
        left_end = (f"C{left_outer + 2} 484 {left_tip + 14} {mid} {left_tip} {hem - 35} "
                    f"Q{left_tip + 10} {hem - 21} 115 {hem - 21} "
                    f"C106 {hem - 110} {left_inner - 2} {mid - 7} {left_inner} 430")
        right_end = (f"C{right_outer - 2} 486 {right_tip - 8} {mid} {right_tip} {hem - 22} "
                     f"Q{right_tip - 10} {hem - 9} 198 {hem - 8} "
                     f"C202 {hem - 94} {right_inner - 7} {mid - 7} {right_inner} 426")
        shaded_left = (f"C{left_outer + 1} 489 {left_tip + 16} {mid} {left_tip + 1} {hem - 35} "
                       f"L{left_tip + 11} {hem - 27}C{left_tip + 21} {mid} {left_outer + 14} 490 {left_outer + 11} 425")
        shaded_right = (f"C{right_outer - 2} 493 {right_tip - 8} {mid} {right_tip - 1} {hem - 23} "
                        f"L{right_tip - 11} {hem - 15}C{right_tip - 14} {mid} {right_outer - 15} 491 {right_outer - 13} 427")
        dark_left = (f"C{left_inner - 4} 493 104 {hem - 105} 114 {hem - 22} "
                     f"H104C95 {hem - 108} {left_inner - 13} 498 {left_inner - 11} 432")
        dark_right = (f"C{right_inner - 4} 495 204 {hem - 94} 199 {hem - 9} "
                      f"L209 {hem - 11}C211 {hem - 95} {right_inner + 3} 493 {right_inner + 10} 427")

    path(art.front, f"M{neck_left} 278Q160 323 {neck_right} 278", "none", stroke=cloth.deep,
         stroke_width=3.2)
    path(art.front, gown_folds, cloth.shade)
    path(art.front, "M155 336Q151 357 156 387Q163 425 157 444 M169 369Q164 407 168 435",
         class_="etch")
    if art.hem_y is not None:
        path(art.front, f"M161 444Q173 {mid} 149 {hem - 32}Q145 {hem - 6} 153 {hem + 11} "
             f"H135Q139 {hem - 37} 151 {hem - 68}Q166 {mid} 161 444Z", cloth.light)
        half = art.hem_half - 7
        path(art.front, f"M{160 - half} {hem - 12}Q160 {hem + 7} {160 + half} {hem - 12}", "none",
             stroke=cloth.deep, stroke_width=1.6, data_part="gotland-gown-hem")

    shape = (
         f"M{neck_left} 273Q{left_shoulder + 15} 276 {left_shoulder - 3} {body.shoulder_y + 7} "
         f"Q{left_sleeve + 9} 322 {left_sleeve + 6} 356Q{left_sleeve + 30} 384 {left_outer} 429{left_end}"
         f"Q{left_inner - 6} 411 124 392Q145 386 145 375Q121 365 111 336 "
         f"Q106 304 {neck_left} 273Z "
         f"M{neck_right} 273Q{right_shoulder - 9} 282 {right_shoulder + 4} {body.shoulder_y + 12} "
         f"Q{right_sleeve - 19} 316 {right_sleeve - 6} 349Q{right_sleeve - 9} 374 {right_outer} 426{right_end}"
         f"Q{right_inner + 12} 403 194 385Q188 381 176 376 "
         f"Q208 361 209 329Q207 295 {neck_right} 273Z"
    )
    _, mantle = _draped_layer(art.outer, "gotland-open-mantle", shape, base)
    path(mantle,
         f"M{left_shoulder - 2} 299Q{left_sleeve + 18} 330 {left_sleeve + 9} 355 "
         f"Q64 383 {left_outer + 2} 425{shaded_left}Q99 396 99 377Q67 356 {left_shoulder - 2} 299Z "
         f"M{right_shoulder + 8} 309Q{right_sleeve - 5} 336 {right_sleeve - 10} 354 "
         f"Q{right_outer + 2} 388 {right_outer - 2} 427{shaded_right}Q{right_outer - 3} 388 222 367 "
         f"Q{right_shoulder + 11} 340 {right_shoulder + 8} 309Z", shade)
    path(mantle,
         f"M112 337Q121 365 143 375Q138 385 124 391Q{left_inner - 7} 414 {left_inner - 2} 431{dark_left}"
         f"Q{left_inner - 18} 406 99 388Q129 383 131 376Q118 367 112 337Z "
         f"M207 345Q198 367 178 376Q195 381 199 392Q{right_inner + 9} 405 {right_inner + 2} 427{dark_right}"
         f"Q{right_inner + 26} 395 192 376Q203 367 207 345Z", deep)
    path(mantle,
         f"M{neck_left} 276Q111 308 99 329Q92 353 124 373Q99 373 81 355 "
         f"Q89 319 {neck_left} 276Z "
         f"M{neck_right} 277Q220 308 228 335Q225 363 191 374Q208 365 210 343Q212 316 {neck_right} 277Z",
         light)
    path(mantle,
         f"M{left_sleeve + 12} 356Q77 373 115 386L104 392Q77 380 {left_sleeve + 12} 356Z "
         f"M{right_sleeve - 13} 348Q237 362 200 378L213 381Q242 366 {right_sleeve - 13} 348Z",
         "url(#ink-lines)", opacity=".54")
    path(mantle,
         f"M{left_shoulder + 1} 310Q67 341 85 360Q103 374 123 377 "
         f"M{left_outer + 4} 398Q{left_outer + 18} 425 {left_outer + 19} 445 "
         f"M{right_shoulder - 7} 303Q244 345 218 362Q206 369 194 373 "
         f"M{right_outer - 9} 393Q{right_outer - 17} 411 {right_outer - 17} 446", class_="seam")
    path(mantle, "M95 369q8 6 19 9m-25 -2 15 7m118 -13 11 -7m-7 14 10 -6", class_="etch")
    if art.hem_y is not None:
        path(mantle,
             f"M{left_outer + 16} 432C{left_outer + 18} 490 {left_tip + 21} {mid} {left_tip + 13} {hem - 31} "
             f"C{left_tip + 17} {mid} {left_outer + 10} 502 {left_outer + 16} 432Z "
             f"M{right_outer - 16} 432C{right_outer - 21} 499 {right_tip - 23} {mid} {right_tip - 15} {hem - 20} "
             f"C{right_tip - 28} {mid} {right_outer - 29} 485 {right_outer - 16} 432Z", light)
        path(mantle, f"M{left_tip + 4} {hem - 36}Q{left_tip + 14} {hem - 26} 110 {hem - 25} "
             f"M203 {hem - 12}Q{right_tip - 9} {hem - 14} {right_tip - 3} {hem - 24}", class_="seam")


DRAWERS = {
    "nw_gotland_mens_cloak": draw_mens_cloak,
    "nw_gotland_womens_mantle": draw_womens_mantle,
}
