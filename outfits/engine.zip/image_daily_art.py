"""Additional everyday silhouettes from the image index.

The drawings are stylised visual references, not claims of an exact 1230 cut.
META is keyed by the source image/game id. Existing canonical styles are kept.
Lower-body callbacks use native ankle-local coordinates (x=0 at the ankle).
"""

from common import node, number, path


OPTIONS = {
    "shoe_accessory": {"image_bone_skates": "Костяные коньки"},
    "leg_wraps": {"image_leather_footrags": "Кожаные обмотки у стопы"},
    "belt_pouch": {
        "image_travel_bag": "Дорожная сума на плечевом ремне",
        "image_western_bag": "Кожаный кошель западной работы",
        "image_tall_leather_pouch": "Высокий кожаный кошель",
        "image_pointed_flap_pouch": "Кошель с острым клапаном",
        "image_flat_pleated_pouch": "Плоский кожаный кошель со складками",
    },
    "jewelry": {"image_hand_bell": "Малый бубенчик на шнуре"},
    "outfit": {"image_fur_loincloth": "Меховая набедренная повязка"},
}
LABELS = {}
OUTFITS = OPTIONS["outfit"]


def _meta(slot, item, material, limitation, *, trim=()):
    return {
        "selection": {slot: item}, "age": "adult", "cast": None,
        "cultures": ["rus"], "materials": [material],
        "trim_materials": list(trim), "historical_limitation": limitation,
    }


META = {
    "it_ps_bone_skates": _meta("shoe_accessory", "image_bone_skates", "bone",
        "Новгородская музейная пара; отдельная дата не указана, X–XV вв. — интервал выставки.", trim=("leather",)),
    "footrags_leather": _meta("leg_wraps", "image_leather_footrags", "leather",
        "Условная обёртка. Фото показывает сшитую исландскую обувь 1880–1900 гг., а не средневековые кожаные обмотки."),
    "loincloth_fur": _meta("outfit", "image_fur_loincloth", "fur",
        "Фото Эци, IV тыс. до н. э., — дальний аналог. Наличие такого костюма в Новгороде XIII века не подтверждено.", trim=("leather",)),
    "it_ps_travel_bag": _meta("belt_pouch", "image_travel_bag", "leather",
        "В источнике только орнаментированный фрагмент сумы XIV–XV вв.; объём, ремень и полный крой условны."),
    "it_ps_western_bag": _meta("belt_pouch", "image_western_bag", "leather",
        "Маленький кошель XV века; западное изготовление предположительно, купеческая функция не установлена."),
    "leather_pouch": _meta("belt_pouch", "image_tall_leather_pouch", "leather",
        "Кошель из Старой Руссы XII–XIII вв.; способ крепления к поясу условен."),
    "it_ps_hand_bell": _meta("jewelry", "image_hand_bell", "bronze",
        "Новгородские археологические бубенчики разных форм, XII — начало XIV вв.; показана одна простая форма."),
    "it_ps_belt_pouch": _meta("belt_pouch", "image_pointed_flap_pouch", "leather",
        "Отдельный силуэт по простому острому клапану изображения; без добавления тиснёного растительного узора."),
    "belt_pouch:pleated": _meta("belt_pouch", "image_flat_pleated_pouch", "leather",
        "Прямоугольный плоский силуэт по фотографии, складки и подвес к поясу стилизованы."),
}

INK = "#392b27"
LEATHER = "#805943"
LIGHT = "#b38965"
SHADE = "#573d32"
BRONZE = "#ab8452"


def _shape(parent, contour, fill=LEATHER, *, surface="base", width=1.5):
    return path(parent, contour, fill, stroke=INK, stroke_width=width,
                stroke_linejoin="round", data_material_surface=surface)


def _line(parent, contour, color=LIGHT, width=1, *, surface="light"):
    return path(parent, contour, "none", stroke=color, stroke_width=width,
                stroke_linecap="round", stroke_linejoin="round",
                data_material_surface=surface)


def _fill(parent, contour, color, surface):
    return path(parent, contour, color, data_material_surface=surface)


def _pouch_group(parent, body, style):
    anchor = number(160 - .42 * body.waist)
    return node(parent, "g", transform=f"translate({anchor} 404)",
                data_part="belt-pouch", data_style=style, data_material_slot="belt_pouch")


def _suspension(parent, *, two=False):
    if two:
        _shape(parent, "M-12 0h5l1 20h-6ZM7 0h5l1 20H7Z", SHADE, surface="shade", width=1.1)
        _line(parent, "M-10 3l1 11M9 3l1 11", LIGHT, .8)
    else:
        _shape(parent, "M-4 0h8l1 18h-9Z", SHADE, surface="shade", width=1.1)
        _line(parent, "M-2 3v10", LIGHT, .8)


def _tapered_pouch(parent, *, tall=False):
    bottom = 71 if tall else 61
    half = 19 if tall else 24
    top = 11 if tall else 13
    contour = (f"M{-top} 13Q0 15 {top} 13Q{top+1} 34 {half} {bottom-9}"
               f"Q{half+2} {bottom} {half-3} {bottom+2}Q0 {bottom+5} {-half+2} {bottom+1}"
               f"Q{-half-2} {bottom-1} {-half} {bottom-8}Q{-top-1} 35 {-top} 13Z")
    _shape(parent, contour)
    _fill(parent, f"M6 18Q9 39 {half-2} {bottom-5}L8 {bottom+2}Q5 42 3 19Z", SHADE, "shade")
    _fill(parent, f"M-8 19Q-9 39 {-half+2} {bottom-5}L-10 {bottom}Q-7 40-4 20Z", LIGHT, "light")
    for side in (-1, 1):
        _line(parent, f"M{side*8} 18Q{side*7} 40 {side*(half-4)} {bottom-3}", INK, .85, surface="fixed")
        _line(parent, f"M{side*6} 20Q{side*6} 42 {side*(half-6)} {bottom-4}", "#c29b75", .6)
    _line(parent, f"M{-half+4} {bottom-1}Q0 {bottom+3} {half-4} {bottom-1}", LIGHT, .7)
    _line(parent, f"M{-top} 14Q0 19 {top} 14", INK, 1.2, surface="fixed")
    for x in range(-top+3, top, 5):
        node(parent, "ellipse", cx=x, cy=17, rx=.85, ry=1.15, fill=INK, data_material_surface="fixed")
    _line(parent, f"M{-top+1} 17Q0 20 {top-1} 17m-4 1q9 1 8 9m-7-9q7 3 10 5", "#b79973", 1.05, surface="fixed")


def draw_western_bag(parent, body):
    group = _pouch_group(parent, body, "image_western_bag")
    _suspension(group)
    _tapered_pouch(group)


def draw_tall_leather_pouch(parent, body):
    group = _pouch_group(parent, body, "image_tall_leather_pouch")
    _suspension(group)
    _tapered_pouch(group, tall=True)


def _pointed_flap(parent):
    _shape(parent, "M-19 16Q0 14 19 16L20 61Q20 67 14 68H-14Q-20 68-20 61Z")
    _fill(parent, "M13 20h5l.5 40q0 5-5 5h-23q23-2 23-14Z", SHADE, "shade")
    _line(parent, "M-17 22v37q0 6 6 6h23q5 0 5-5V23", LIGHT, .8)
    _shape(parent, "M-20 16Q0 13 20 16L17 27Q8 39 0 46Q-10 38-18 26Z", "#9d7050")
    _line(parent, "M-17 18Q0 16 17 18L14 26Q7 35 0 42Q-8 35-15 25Z", "#c69a6d", .8)
    _line(parent, "M-16 26Q-8 37 0 43Q9 36 16 26", SHADE, 1, surface="shade")


def draw_pointed_flap_pouch(parent, body):
    group = _pouch_group(parent, body, "image_pointed_flap_pouch")
    _suspension(group, two=True)
    _pointed_flap(group)


def _flat_pleated(parent):
    contour = "M-22 15Q-12 12-7 15Q0 12 7 15Q16 12 23 15L25 62Q10 66-4 64Q-16 66-25 62Z"
    _shape(parent, contour)
    for index, x in enumerate((-17, -10, -3, 5, 13, 20)):
        bend = x + (-3 if index % 2 else 2)
        _fill(parent, f"M{x} 18Q{bend} 35 {x-2} 59l4 4Q{x+3} 39 {x+2} 18Z", SHADE, "shade")
        _line(parent, f"M{x-1} 19Q{bend-1} 38 {x-3} 58", LIGHT, .9)
    _line(parent, "M-23 61Q-10 64 0 62Q13 64 23 61", "#c19772", .8)
    _line(parent, "M-23 16Q0 20 23 16M-23 19Q0 23 23 19", INK, 1.1, surface="fixed")
    _line(parent, "M-23 18q-12-1-12 11m12-11q-10 5-13 7M23 18q11-3 12 7", "#b89a75", 1.2, surface="fixed")


def draw_flat_pleated_pouch(parent, body):
    group = _pouch_group(parent, body, "image_flat_pleated_pouch")
    _suspension(group, two=True)
    _flat_pleated(group)


def _travel_bag(parent):
    _shape(parent, "M-28 16Q0 10 28 18L34 55Q31 72 15 76L-18 73Q-34 70-35 56Z", "#76513d")
    _fill(parent, "M18 22Q31 34 31 57Q29 69 16 73L7 72Q20 59 17 35Z", SHADE, "shade")
    _line(parent, "M-30 32l-1 23q2 12 17 14L12 72", LIGHT, 1.2)
    _shape(parent, "M-29 17Q0 8 28 18L26 34Q18 46 1 49Q-18 45-30 35Z", "#a2744f")
    _line(parent, "M-26 19Q0 12 25 20l-2 13Q16 42 1 45Q-17 41-27 34Z", "#d0a273", .9)
    # Restricted ornament recalls the surviving fragment, not an invented exact reconstruction.
    _line(parent, "M0 41q-4-10 0-22q6 0 7 5q-6 6-6 14m-1 3q-10-14-18-6q1 7 13 5m6 0q8-13 18-6q-1 6-13 6", SHADE, 1.5, surface="shade")
    _shape(parent, "M-3 43q4-2 7 1l-1 15-4 4-3-5Z", "#785038", width=1.1)
    node(parent, "circle", cx=0, cy=54, r=1.8, fill=BRONZE, stroke=INK, stroke_width=.7, data_material_surface="fixed")


def draw_travel_bag(parent, body):
    # Shoulder strap is part of the pouch slot, drawn before any overlying cloak.
    anchor = 160 - .68 * body.waist
    group = node(parent, "g", data_part="belt-pouch", data_style="image_travel_bag", data_material_slot="belt_pouch")
    strap = f"M{number(160+body.shoulder*.44)} 283Q171 341 {number(anchor)} 423"
    _line(group, strap, INK, 10, surface="fixed")
    _line(group, strap, "#73503d", 7, surface="base")
    _line(group, strap, "#b58b62", 1.1)
    bag = node(group, "g", transform=f"translate({number(anchor)} 414)")
    _travel_bag(bag)


def _bell(parent):
    # Closed globular body with suspension eye and a sound slit.
    node(parent, "ellipse", cx=0, cy=-13, rx=3.2, ry=4, fill="none", stroke=INK, stroke_width=2.1, data_material_surface="fixed")
    _line(parent, "M-1.7-15q2-2 3.4.5", "#d9bb80", 1)
    _shape(parent, "M-3-10Q-12-7-12 1Q-12 12 0 14Q12 12 12 1Q12-7 3-10Z", BRONZE, width=1.4)
    _fill(parent, "M3-8Q11-4 10 3Q10 10 1 12Q5 6 3-8Z", "#765939", "shade")
    _fill(parent, "M-7-6Q-11-1-8 5L-4 7Q-7 0-3-7Z", "#d5b27a", "light")
    _line(parent, "M-11 0Q0 5 11 0M-11 2Q0 7 11 2", INK, 1.1, surface="fixed")
    _line(parent, "M-5 9Q0 6 5 9", INK, 1.8, surface="fixed")
    for x in (-5, 5):
        node(parent, "circle", cx=x, cy=9, r=1.25, fill=INK, data_material_surface="fixed")
    _line(parent, "M-7-5q1-2 3-2", "#edcd94", .8)


def draw_hand_bell(parent, neck):
    group = node(parent, "g", data_part="jewelry", data_style="image_hand_bell", data_material_slot="jewelry")
    cord = f"M{number(160-neck)} 274Q146 314 160 332Q176 314 {number(160+neck)} 274"
    _line(group, cord, INK, 2.3, surface="fixed")
    _line(group, cord, "#b4976f", 1, surface="fixed")
    _bell(node(group, "g", transform="translate(160 346) scale(.72)"))


def _skate(parent):
    # Long animal bone with enlarged joint ends, flattened sliding surface and lash holes.
    _shape(parent, "M78 728Q83 724 88 728Q110 733 135 726Q141 721 144 726L142 733Q111 741 86 736L78 734Z", "#c2b18d", width=1.5)
    _fill(parent, "M80 732Q111 738 142 730L141 734Q109 741 85 736Z", "#8c795e", "shade")
    _line(parent, "M87 730Q109 735 136 728", "#e2d5b5", 1.1)
    for x, y in ((88, 730), (136, 727)):
        node(parent, "ellipse", cx=x, cy=y, rx=1.5, ry=1, fill=INK, data_material_surface="fixed")
    for x in (100, 127):
        _line(parent, f"M{x-3} 710q-4 8 1 19l5 2q-3-11 1-19", INK, 2.4, surface="fixed")
        _line(parent, f"M{x-3} 710q-4 8 1 19l5 2q-3-11 1-19", "#9d7b51", 1.1, surface="trim")
    _line(parent, "M103 716l7-3m-7 3 6 3", "#c5a678", .9, surface="trim-light")


def draw_shoe_accessory(parent, style):
    if style != "image_bone_skates":
        return
    group = node(parent, "g", data_part="shoe-accessory", data_style=style, data_material_slot="shoe_accessory")
    _skate(node(group, "g", transform="translate(-120 0)"))


def _leather_wrap(parent):
    # Separate overlapping edges, rather than the spiral rhythm of wool leg bands.
    _shape(parent, "M103 674Q119 669 136 677L136 697Q119 704 102 697L100 686Z", "#9b7759")
    _fill(parent, "M126 675l9 3v18l-10 4Q130 686 126 675Z", SHADE, "shade")
    _shape(parent, "M103 678Q115 684 135 680L132 694Q117 688 103 696L100 686Z", "#b18b66", width=1.2)
    _line(parent, "M103 681Q117 687 131 683M104 694Q117 688 131 694", "#d0aa7f", .9)
    _line(parent, "M103 680Q121 686 134 691M105 693Q119 687 134 680", INK, 2.1, surface="fixed")
    _line(parent, "M103 680Q121 686 134 691M105 693Q119 687 134 680", "#a0845e", .9, surface="fixed")
    _line(parent, "M117 686q-5-6-8-2q0 4 8 3q6-6 9-2q-1 4-8 2m0 0-2 9m3-9 5 8", INK, 1.2, surface="fixed")


def draw_leg_wrap(parent, style):
    if style != "image_leather_footrags":
        return
    group = node(parent, "g", data_part="leg-wraps", data_style=style, data_material_slot="leg_wraps")
    _leather_wrap(node(group, "g", transform="translate(-120 0)"))


def _fur_panel(parent):
    contour = ("M116 410Q160 419 204 410L200 430l-5 5 3 6-8 4 2 7-7 2 1 7-8 1 1 8-8-1"
               "-3 8-6-4-6 6-4-7-7 3-3-7-6 2-2-8-7 1-1-7-6-1 1-7-6-4 3-6-4-5Z")
    _shape(parent, contour, "#8a6348", width=1.8)
    _fill(parent, "M163 419Q188 420 200 415l-4 18-8 10-4 17-11 1-10 9Q168 443 163 419Z", "#543e32", "shade")
    _fill(parent, "M123 418Q139 423 150 422L146 443l-9 15-5-12-8-8Z", "#b28a62", "light")
    for x, y in ((127, 427), (141, 433), (152, 424), (170, 432), (184, 429), (157, 448), (143, 452), (177, 451), (162, 461)):
        _line(parent, f"M{x} {y}l-2 6m4-4-2 6m5-5-2 5", "#bf9870", .85)
    _shape(parent, "M113 400Q160 410 207 400l-1 11Q159 422 114 410Z", "#604535", surface="trim", width=1.4)
    _line(parent, "M118 404Q160 413 202 404", "#ad8960", 1, surface="trim-light")
    _shape(parent, "M154 404q6-4 11 0l-2 9h-9Z", "#9e7952", surface="trim", width=1.1)
    _line(parent, "M160 413l-4 16m6-16 5 12", "#ad8960", 1.8, surface="trim-light")


def draw_fur_loincloth(art):
    group = node(art.front, "g", data_part="fur-loincloth", data_style="image_fur_loincloth", data_material_slot="outfit")
    scale = min(1.4, max(.75, art.body.waist / 48))
    _fur_panel(node(group, "g", transform=f"translate(160 400) scale({number(scale)} 1.15) translate(-160 -400)"))


def _detail(drawer, transform):
    def draw(parent):
        drawer(node(parent, "g", transform=transform))
    return draw


POUCH_DRAWERS = {
    "image_travel_bag": draw_travel_bag,
    "image_western_bag": draw_western_bag,
    "image_tall_leather_pouch": draw_tall_leather_pouch,
    "image_pointed_flap_pouch": draw_pointed_flap_pouch,
    "image_flat_pleated_pouch": draw_flat_pleated_pouch,
}
JEWELRY_DRAWERS = {"image_hand_bell": draw_hand_bell}
OUTFIT_DRAWERS = {"image_fur_loincloth": draw_fur_loincloth}
draw_wrap = draw_leg_wrap
DETAIL_DRAWERS = {
    "image_bone_skates": _detail(_skate, "translate(-224 -2170) scale(3.2)"),
    "image_leather_footrags": _detail(_leather_wrap, "translate(-372 -2915) scale(4.5)"),
    "image_hand_bell": _detail(_bell, "translate(160 127) scale(5.1)"),
    "image_travel_bag": _detail(_travel_bag, "translate(160 5) scale(2.8)"),
    "image_western_bag": _detail(_tapered_pouch, "translate(160 4) scale(3.3)"),
    "image_tall_leather_pouch": _detail(lambda parent: _tapered_pouch(parent, tall=True), "translate(160 0) scale(3)"),
    "image_pointed_flap_pouch": _detail(_pointed_flap, "translate(160 -2) scale(3.3)"),
    "image_flat_pleated_pouch": _detail(_flat_pleated, "translate(160 -2) scale(3.3)"),
    "image_fur_loincloth": _detail(_fur_panel, "translate(-288 -1100) scale(2.8)"),
}
