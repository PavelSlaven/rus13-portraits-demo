"""An item in the clothing list and the equipment used to display it."""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ClothingReference:
    slot: str
    item: str
    materials: tuple[str, ...]
    cast: str | None = None
    age: str = "adult"
    equipment: dict[str, str] = field(default_factory=dict)
    detail: bool = False
    trim_materials: tuple[str, ...] = ()

    def selection(self):
        return {**self.equipment, self.slot: self.item}
