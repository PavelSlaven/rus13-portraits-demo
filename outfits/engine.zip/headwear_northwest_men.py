from dataclasses import replace

from common import node, number, path


OPTIONS = {
    "nw_nov_round_cap": "Новгородская шерстяная шапка с отворотом",
    "nw_nov_seamed_cap": "Клинчатая шапка с меховой кромкой",
    "nw_baltic_cloth_cap": "Мягкая шапка с тканым околышем",
    "nw_nordic_hood": "Скандинавский шерстяной капюшон",
}
COVERAGE = dict.fromkeys(OPTIONS, {"hair": True, "ears": True, "neck": True})
COVERAGE["nw_nordic_hood"] = {"hair": False, "ears": False, "neck": False}
HAIR_ROOT_HALF = {"nw_nov_round_cap": 73, "nw_nov_seamed_cap": 75, "nw_baltic_cloth_cap": 72}


def draw_nov_round_cap(parent, look, fit):
    crown = replace(fit, brim_y=fit.brim_y - 6).crown(parent, minimum_y=61)
    path(crown, "M83 105C83 87 105 68 137 65Q160 61 190 66C215 71 232 85 237 106L233 117 "
         "Q158 126 86 117Z", "#81715e", class_="edge")
    path(crown, "M90 101Q105 77 141 72 Q127 87 123 109L90 112Z", "#a39075")
    path(crown, "M186 68 Q224 75 235 105L221 114 194 112Q202 89 186 68Z", "#594a43")
    path(crown, "M119 107Q123 81 143 67M197 110Q203 94 187 68", class_="seam")
    path(crown, "M83 105Q158 113 237 105L236 115Q161 125 84 115Z", "#5d5147", class_="edge")
    path(crown, "M92 111Q162 118 228 110", "none", stroke="#9e8870", stroke_width=1.45)


def draw_nov_seamed_cap(parent, look, fit):
    crown = replace(fit, brim_y=fit.brim_y - 9).crown(parent, minimum_y=39)
    path(crown, "M81 108Q86 87 111 68Q137 56 160 39Q187 55 211 72Q232 90 240 109L235 118 "
         "Q166 128 85 118Z", "#794849", class_="edge")
    path(crown, "M91 105 Q102 76 151 52Q129 74 123 110 Z", "#a26659")
    path(crown, "M165 47Q204 66 223 87L237 109L194 114Q189 82 165 47Z", "#593139")
    path(crown, "M158 45Q140 71 134 108M165 46Q185 74 188 108", "none", stroke="#4c3030", stroke_width=1.7)
    path(crown, "M106 98Q121 76 140 65M187 68Q208 81 219 102", class_="etch")
    path(crown, "M81 106Q121 110 159 108Q204 111 238 105L241 110 238 118Q160 126 83 118Z",
         "#56413a", class_="edge")
    for x in range(91, 233, 13):
        path(crown, f"M{x} 112q3 -4 7 -2m-5 6q4 -3 7 -2", "none", stroke="#a48167", stroke_width=1.45)


def draw_baltic_cloth_cap(parent, look, fit):
    crown = replace(fit, brim_y=fit.brim_y - 8).crown(parent, minimum_y=61)
    path(crown, "M82 113Q83 96 97 81Q115 62 155 63Q199 60 217 76Q236 92 238 110 "
         "L233 119Q159 125 84 118Z", "#5c6670", class_="edge")
    path(crown, "M91 111 Q94 84 137 68Q122 88 123 113Z", "#839098")
    path(crown, "M179 66Q218 71 236 106L216 115H196Q196 88 179 66Z", "#414951")
    path(crown, "M84 108Q159 113 238 107L234 118Q159 125 84 118Z", "#685748", class_="edge")
    for x in range(94, 229, 13):
        path(crown, f"M{x} 112l4 3 4 -3", "none", stroke="#c8af84", stroke_width=1.2)


def draw_nordic_hood(parent, look, fit):
    side = fit.temples(parent)
    brow = fit.brim_y
    chin = fit.chin_y
    crown_top = min(57, fit.top_y - 13)
    opening = (
        f"M97 {number(brow + 10)}Q105 {number(brow + 4)} 119 {number(brow + 3)}"
        f"Q159 {number(brow - 2)} 201 {number(brow + 4)}Q217 {number(brow + 5)} 223 {number(brow + 12)}"
        f"Q225 150 231 180Q230 213 210 {number(chin - 14)}Q160 {number(chin + 24)} 110 {number(chin - 14)}"
        f"Q89 213 90 180Q96 150 97 {number(brow + 10)}Z"
    )
    hood = (
        f"M77 219Q73 175 78 132Q78 {number(crown_top + 3)} 143 {number(crown_top + 4)}"
        f"L170 {number(crown_top - 3)}Q227 {number(crown_top + 7)} 239 120"
        "Q246 170 242 218Q250 269 285 300Q237 315 160 306Q84 315 35 300Q72 263 77 219Z"
    )
    path(side, f"{hood} {opening}", "#574f61", class_="edge", fill_rule="evenodd")
    path(side, f"M88 119Q93 {number(crown_top + 13)} 151 {number(crown_top + 9)}"
         f"Q124 {number(crown_top + 28)} 110 {number(brow - 2)}L94 {number(brow + 7)}Z",
         "#817586")
    path(side, "M70 282Q108 252 109 239Q128 261 144 269Q121 299 91 304Z"
         "M204 245Q219 230 229 198Q228 266 266 295L245 299Q216 288 204 245Z",
         "#413948", opacity=".85")
    path(side, opening, "none", stroke="#a09291", stroke_width=3, opacity=".82")
    path(side, "M50 297Q118 307 160 300Q217 307 271 297 M112 266Q129 278 151 280 "
         "M170 281Q198 276 210 261", class_="seam")


DRAWERS = {
    "nw_nov_round_cap": draw_nov_round_cap,
    "nw_nov_seamed_cap": draw_nov_seamed_cap,
    "nw_baltic_cloth_cap": draw_baltic_cloth_cap,
    "nw_nordic_hood": draw_nordic_hood,
}
