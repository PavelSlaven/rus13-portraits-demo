from math import atan2, degrees

from common import node, number, path
from face_shape import ear_fit, make_head


OPTIONS = {
    "nw_nov_plain_veil": "Простой новгородский плат",
    "nw_nov_povoy": "Тёплый новгородский повой под платом",
    "nw_nov_rhombic_band": "Новгородский плат с ромбощитковыми кольцами",
    "nw_karel_veil": "Карельское покрывало с тканой повязкой",
    "nw_baltic_spiral_band": "Спиральный венчик из Сиксаля",
    "nw_nordic_linen_veil": "Скандинавский льняной плат",
}
COVERAGE = {
    "nw_nov_plain_veil": {"ears": False, "neck": True, "hair": False},
    "nw_nov_povoy": {"ears": False, "neck": False, "hair": False},
    "nw_nov_rhombic_band": {"ears": False, "neck": True, "hair": False},
    "nw_karel_veil": {"ears": False, "neck": True, "hair": False},
    "nw_baltic_spiral_band": {"ears": True, "neck": True, "hair": True},
    "nw_nordic_linen_veil": {"ears": False, "neck": True, "hair": False},
}
HAIR_ROOT_HALF = {}
OPEN_CROWNS = {"nw_baltic_spiral_band"}


def _top(fit, rise):
    # Fit.sides pins the face opening to the brow line. Add the rise above the actual scalp.
    return fit.top_y + 115 - fit.brim_y - rise


def _banded_top(fit, rise):
    # Leave a span of cloth above the brow strip even on short, low foreheads.
    return min(_top(fit, rise), 70)


def _line(parent, shape, color, width):
    path(parent, shape, "none", stroke=color, stroke_width=width, stroke_linecap="round",
         stroke_linejoin="round")


def draw_nov_plain_veil(parent, look, fit):
    # The uninterrupted edge and shoulder fall follow the early Novgorod iconography.
    cloth = fit.sides(parent)
    top = _top(fit, 13)
    path(cloth, f"M65 133 C66 {number(top + 18)} 108 {number(top - 3)} 157 {number(top)} "
         f"C202 {number(top - 2)} 242 {number(top + 13)} 251 132 "
         "C259 171 249 214 267 245 Q273 256 279 262 Q260 273 226 277 "
         "Q221 251 223 224 C232 172 230 143 226 113 Q160 101 96 113 "
         "C91 143 91 187 100 219 Q100 236 105 247 Q81 250 60 243 "
         "Q75 215 69 189 Q62 162 65 133 Z", "#d5c4a7", class_="edge")
    path(cloth, f"M70 140 C70 {number(top + 20)} 117 {number(top + 1)} 161 {number(top + 3)} "
         "Q136 81 114 95 Q98 103 92 119 Q79 152 81 184 Q83 212 70 238 "
         "Q78 213 73 191 Q67 161 70 140 Z", "#eee0c5")
    path(cloth, f"M180 {number(top + 4)} C224 {number(top + 9)} 242 {number(top + 23)} 247 139 "
         "Q253 179 247 207 Q247 244 270 263 Q256 267 247 269 "
         "Q237 242 241 214 Q243 177 238 148 Q237 103 180 " + number(top + 4) + " Z", "#ad997d")
    path(cloth, "M247 164 Q249 190 247 212 Q249 244 269 262 L256 267 Q240 242 243 206 Z",
         "url(#ink-lines)", opacity=".53")
    _line(cloth, "M99 107 Q158 95 222 107 M88 135 Q82 165 87 196 M90 209 L94 229 "
          "M232 152 Q240 187 234 221 Q232 247 239 269", "#f6e8ce", 2.55)
    path(cloth, "M73 231 Q84 234 93 232 M234 270 Q251 267 266 261 M238 125 Q244 142 244 153",
         class_="etch", opacity=".62")


def draw_nov_povoy(parent, look, fit):
    # A wool outer cloth over a gathered cap and neck wrap, after the Novgorod inventory analogies.
    neck = fit.chin(parent)
    path(neck, "M86 213 Q111 221 124 236 Q156 259 189 239 Q208 227 234 211 "
         "L262 271 Q238 289 159 292 Q99 289 62 267 Z", "#865855", class_="edge")
    path(neck, "M97 235 Q124 246 151 251 Q179 257 220 233 Q203 264 162 269 Q124 263 97 235 Z",
         "#ae7466")
    path(neck, "M92 255 Q164 280 231 243 Q208 281 176 288 Q125 283 92 255 Z", "#6a4447")
    path(neck, "M107 251 Q155 277 209 251 M115 276 Q148 289 177 284 M170 271 Q207 267 226 253",
         class_="etch", opacity=".84")

    cloth = fit.sides(parent)
    top = _banded_top(fit, 19)
    path(cloth, f"M65 125 C69 {number(top + 20)} 104 {number(top)} 148 {number(top)} "
         f"C195 {number(top - 3)} 242 {number(top + 11)} 252 132 "
         "Q262 180 253 214 Q249 246 266 275 Q240 289 216 292 "
         "Q208 269 212 245 Q230 193 228 152 Q229 125 220 110 Q155 93 98 110 "
         "Q90 141 91 174 Q92 219 111 247 Q99 276 79 286 Q54 279 48 269 "
         "Q68 225 63 200 Q56 161 65 125 Z", "#76504a", class_="edge")
    path(cloth, f"M68 137 C74 {number(top + 22)} 108 {number(top + 3)} 156 {number(top + 3)} "
         "Q111 79 93 110 Q80 138 81 178 Q83 221 96 246 Q92 266 79 279 "
         "L59 272 Q74 243 71 215 Q63 169 68 137 Z", "#9b6758")
    path(cloth, f"M173 {number(top + 3)} C223 {number(top + 7)} 240 {number(top + 25)} 248 137 "
         "Q257 181 249 218 Q248 250 261 273 Q251 280 238 283 "
         "Q226 265 234 233 Q247 185 239 148 Q234 92 173 " + number(top + 3) + " Z", "#573c3e")
    path(cloth, "M245 140 Q256 179 247 216 Q244 250 259 273 L246 279 Q234 250 241 217 Q250 176 245 140 Z",
         "url(#ink-lines)", opacity=".61")
    _line(cloth, "M82 145 Q77 178 84 207 Q86 230 95 244 M77 215 Q80 245 65 269 "
          "M235 168 Q239 204 224 247 Q219 271 226 282", "#b77e68", 2.2)
    path(cloth, "M91 115 Q98 91 155 90 Q203 88 229 110 L231 122 L224 129 "
         "Q206 113 159 113 Q119 112 96 124 L89 132 Z", "#c4a381", class_="edge")
    _line(cloth, "M97 112 Q126 96 161 98 Q197 96 222 109", "#e1c4a1", 2.7)
    path(cloth, "M104 104 l6 10 m8-15 4 11 m11-15 3 12 m12-13 1 12 m13-13 0 13 "
         "m12-11-1 11 m12-10-2 11 m13-8-3 10 m13-7-4 10 m13-5-3 8",
         class_="etch", opacity=".76")
    _line(cloth, "M68 273 Q76 278 80 278 M222 284 Q244 281 259 272", "#c18a70", 1.45)


def _rhombic_ring(parent, transform):
    ring = node(parent, "g", transform=transform)
    wire = "M-5 -19 C-18 -16 -21 -1 -16 10 Q-9 22 5 19 C19 17 22 3 16 -9 Q11 -18 2 -20"
    _line(ring, wire, "#302c31", 6.8)
    _line(ring, wire, "#a1aeb2", 4.35)
    _line(ring, "M-7 -18 C-16 -15 -19 -6 -18 1 M8 -18 Q15 -14 17 -7", "#e1eced", 3)
    for x, y, angle in ((-13, 10, -23), (0, 19, 0), (13, 12, 30)):
        shield = node(ring, "g", transform=f"translate({x} {y}) rotate({angle})")
        path(shield, "M-8 0 L0-7 8 0 0 7 Z", "#a1aeb2", stroke="#302c31",
             stroke_width=2.1, stroke_linejoin="round")
        path(shield, "M-7 0 L0-6 7 0 0 2.5 Z", "#e0e9e8")
        node(shield, "circle", cx=0, cy=0, r=1.3, fill="#5c6267")


def draw_nov_rhombic_band(parent, look, fit):
    # The silver arcs carry three flattened shields, as in the State Historical Museum types.
    cloth = fit.sides(parent)
    top = _banded_top(fit, 15)
    path(cloth, f"M62 132 C66 {number(top + 14)} 109 {number(top - 2)} 156 {number(top)} "
         f"C207 {number(top - 2)} 253 {number(top + 17)} 257 133 "
         "Q267 159 258 194 Q252 220 270 248 Q253 260 226 258 "
         "Q217 236 223 214 Q234 163 226 113 Q160 102 94 113 "
         "Q85 158 94 200 Q104 238 96 258 Q66 260 48 248 Q65 219 60 194 Q54 158 62 132 Z",
         "#66766a", class_="edge")
    path(cloth, f"M65 138 C75 {number(top + 13)} 109 {number(top + 2)} 150 {number(top + 3)} "
         "Q109 82 88 120 Q72 151 77 186 Q85 220 63 249 L55 247 Q69 220 65 201 Q60 167 65 138 Z",
         "#8c9982")
    path(cloth, f"M180 {number(top + 4)} C223 {number(top + 9)} 243 {number(top + 23)} 253 138 "
         "Q262 167 252 203 Q248 231 264 247 Q249 256 237 253 Q230 239 237 213 "
         "Q248 162 236 129 Q221 88 180 " + number(top + 4) + " Z", "#495954")
    path(cloth, "M243 162 Q250 183 242 209 Q235 235 245 250 L262 247 Q246 229 251 205 Q259 180 251 159 Z",
         "url(#ink-lines)", opacity=".57")
    path(cloth, "M73 181 Q74 215 68 234 M83 214 Q87 237 83 251 M247 211 Q243 235 251 245",
         class_="etch", opacity=".72")
    path(cloth, "M71 109 Q110 91 159 92 Q216 90 248 109 L250 123 "
         "Q208 107 159 108 Q112 108 69 123 Z", "#86544b", class_="edge")
    _line(cloth, "M75 111 Q113 96 160 96 Q210 95 244 111 M82 117 Q120 104 160 104 Q206 102 239 117",
          "#d49b69", 1.8)
    for x, sway in ((77, -6), (243, 6)):
        _line(cloth, f"M{x} 113 q{sway} 8 {sway} 23", "#3c2c2a", 5.2)
        _line(cloth, f"M{x} 113 q{sway} 8 {sway} 23", "#ca946b", 2.5)
        _rhombic_ring(cloth, f"translate({x + sway} 153) rotate({sway + sway})")


def draw_karel_veil(parent, look, fit):
    # The woven band and bronze spiral edging follow grave 1 at Kekomäki. Grave 6 is a separate analogy.
    cloth = fit.sides(parent)
    top = _banded_top(fit, 12)
    path(cloth, f"M67 128 C73 {number(top + 13)} 111 {number(top - 1)} 162 {number(top)} "
         f"C211 {number(top)} 245 {number(top + 17)} 252 130 Q263 160 254 192 Q249 218 259 246 "
         "Q245 255 220 246 Q224 215 229 189 Q237 152 226 112 Q164 99 94 112 "
         "Q86 148 91 186 Q97 214 104 236 Q85 250 62 246 Q71 221 66 195 Q58 161 67 128 Z",
         "#c4b69a", class_="edge")
    path(cloth, f"M73 135 C80 {number(top + 17)} 116 {number(top + 4)} 152 {number(top + 3)} "
         "Q108 90 92 120 Q77 147 81 180 Q86 222 71 241 Q76 223 72 192 Q66 161 73 135 Z", "#e2d4b8")
    path(cloth, f"M178 {number(top + 3)} C226 {number(top + 6)} 244 {number(top + 26)} 249 135 "
         "Q259 165 249 198 Q245 223 254 244 Q246 247 235 245 Q233 231 238 212 "
         "Q246 174 239 148 Q235 104 178 " + number(top + 3) + " Z", "#9a8870")
    path(cloth, "M244 154 Q254 174 246 209 Q242 231 251 243 L242 246 Q234 231 242 202 Z",
         "url(#ink-lines)", opacity=".6")
    path(cloth, "M81 143 Q77 161 82 182 Q92 213 90 227 M237 175 Q239 195 231 215", class_="etch")
    path(cloth, "M75 105 Q110 91 159 91 Q211 90 244 105 L246 119 Q213 108 159 108 "
         "Q112 107 73 119 Z", "#514f52", class_="edge")
    _line(cloth, "M80 107 Q118 94 159 95 Q203 94 240 106 M79 116 Q116 104 160 105 Q203 103 240 116",
          "#c79575", 1.72)
    for x, y in ((89, 109), (103, 105), (117, 102), (131, 100), (145, 99), (159, 99),
                 (173, 99), (187, 99), (201, 101), (215, 104), (229, 107)):
        weave = node(cloth, "g", transform=f"translate({x} {y})")
        _line(weave, "M-4 -1 L0 1.9 4 -1", "#a1a78f", 1.63)
    for x, y, angle in ((67, 242, -4), (74, 242, -7), (81, 241, -13), (88, 240, -23),
                        (95, 237, -32), (224, 245, 18), (231, 247, 12), (238, 248, 6), (245, 248, -7),
                        (252, 246, -13)):
        spiral = node(cloth, "g", transform=f"translate({x} {y}) rotate({angle})")
        _line(spiral, "M-3.1 0 Q-3.6 -3 0 -3 Q3 -3 3 0 Q3 2.1 .6 2 Q-1.1 2 -1 0", "#6e513b", 2.1)
        _line(spiral, "M-3.1 0 Q-3.6 -3 0 -3 Q3 -3 3 0 Q3 2.1 .6 2 Q-1.1 2 -1 0", "#c79b63", 1.22)


def _draw_baltic_trail(trail, look, band):
    x, y = band.point(.88, .58)
    ear_width, ear_height, ear_y = ear_fit(look)
    x_behind_ear = 160 + make_head(look).cheek_half - 10 + 31 * ear_width + 9
    turn = max(y + 13, ear_y - 29 * ear_height - 6)
    trail.set("transform", f"translate({number(x_behind_ear)} 0)")

    sx = x - x_behind_ear
    path(trail, f"M{number(sx)} {number(y - 3)} C{number(sx + 12)} {number(y - 1)} -3 {number(turn - 12)} 4 {number(turn - 1)}"
         f"C12 {number(turn + 9)} 9 181 7 204 Q4 235 4 257 L-13 263 Q-6 237-3 201"
         f"C0 178 2 {number(turn + 10)} -5 {number(turn + 2)} Q-12 {number(turn - 8)} {number(sx)} {number(y + 4)}Z",
         "#ad7e4c", stroke="#46352e", stroke_width=2.9, stroke_linejoin="round")
    _line(trail, f"M{number(sx + 1)} {number(y)} Q-9 {number(turn - 11)} .1 {number(turn + 1)}"
          f"C7 {number(turn + 10)} 6 176 2 203 Q-1 232-2 254 L-7 256",
          "#edc589", 3.6 if band.card else 2.6)
    if not band.card:
        for x, y in ((3, 174), (2, 191), (1, 208), (-1, 225), (-3, 242)):
            motif = f"M{x} {y - 8} l3.2 8-3.2 8-3.2-8Z"
            path(trail, motif, "#66503c", stroke="#d2a365", stroke_width=1.2, stroke_linejoin="round")


def draw_baltic_spiral_band(parent, look, fit):
    # Grave 247b, Siksälä. The woven bronze trail hangs behind the head, with a continuous diamond design.
    trail = node(parent, "g", data_part="headband-attachments")
    band = fit.forehead_band(parent, look, height=20)
    _draw_baltic_trail(trail, look, band)
    path(band.group, band.strip(), "#376764" if band.card else "#594435")
    if band.card:
        path(band.group, band.strip(bottom=.42), "#72cfc3")
        path(band.group, band.strip(top=.42, bottom=.63), "#ffd18e")
        return

    path(band.group, band.strip(top=.09, bottom=.23), "#d8ac75")
    path(band.group, band.strip(top=.77, bottom=.90), "#b1804e")
    for i in range(-6, 7):
        across = i * .145
        x, y = band.point(across, .49)
        x0, y0 = band.point(across - .06, .49)
        x1, y1 = band.point(across + .06, .49)
        angle = degrees(atan2(y1 - y0, x1 - x0))
        width = min(1, (x1 - x0) / 9.5)
        height = min(1, (band.point(across, .76)[1] - band.point(across, .25)[1]) / 7)
        spiral = node(band.group, "g", transform=(f"translate({number(x)} {number(y)}) rotate({number(angle)}) "
                                                  f"scale({number(width)} {number(height)})"))
        _line(spiral, "M-4.1 1 Q-4.8-3 .1-3 Q4-3 4 0 Q4 2.5 .6 2.5 Q-1.6 2.5-1.2 .2 L.4-.5",
              "#dcb17a", 1.67)
        node(spiral, "circle", cx=5.6, cy=.7, r=1.08, fill="#94a595")


def draw_nordic_linen_veil(parent, look, fit):
    # The soft face opening follows the Öja figure and the possible Oslo hodelin. The overlap is reconstructed.
    cloth = fit.sides(parent)
    top = _banded_top(fit, 19)
    path(cloth, f"M65 129 C69 {number(top + 15)} 121 {number(top - 4)} 167 {number(top)} "
         f"C222 {number(top + 2)} 253 {number(top + 16)} 257 131 Q260 162 253 193 "
         "Q249 233 268 253 Q260 268 233 275 Q213 255 219 230 Q232 196 232 165 Q231 137 225 117 "
         "Q163 102 98 111 Q87 137 87 176 Q88 209 106 224 Q95 244 73 251 Q61 245 55 237 "
         "Q73 210 63 181 Q58 149 65 129 Z", "#d8d2c5", class_="edge")
    path(cloth, f"M69 132 C82 {number(top + 14)} 131 {number(top + 2)} 165 {number(top + 3)} "
         "Q129 76 104 95 Q86 106 78 136 Q71 159 79 190 Q88 223 67 241 L61 236 "
         "Q75 214 67 185 Q61 154 69 132 Z", "#f1e6cd")
    path(cloth, f"M177 {number(top + 5)} C220 {number(top + 8)} 246 {number(top + 22)} 253 133 "
         "Q257 163 250 199 Q247 232 263 252 Q254 262 241 265 Q226 236 240 202 "
         "Q249 169 240 136 Q233 91 177 " + number(top + 5) + " Z", "#a49d8e")
    path(cloth, "M247 152 Q256 169 248 202 Q244 232 262 251 L254 258 Q235 237 243 205 Z",
         "url(#ink-lines)", opacity=".61")
    path(cloth, "M81 102 Q132 94 162 91 Q204 83 228 96 Q243 102 249 122 "
         "L232 133 Q220 108 202 106 Q169 103 130 109 Q99 113 78 116 Z",
         "#c2b7a5", stroke="#574b44", stroke_width=1.95, stroke_linejoin="round")
    _line(cloth, "M84 105 Q140 98 163 95 Q203 88 225 99 Q240 105 242 119", "#f8ead3", 3)
    path(cloth, "M236 128 Q248 134 244 156 Q239 185 237 202 Q231 238 250 261 "
         "L234 270 Q218 256 223 230 Q237 192 237 156 Q235 143 231 135 Z", "#e5dac3",
         stroke="#6f6156", stroke_width=1.38, stroke_linejoin="round")
    _line(cloth, "M229 243 Q230 257 236 264 M85 193 Q93 216 101 223 M65 235 Q71 241 76 243", "#f7e9cd", 1.95)


DRAWERS = {
    "nw_nov_plain_veil": draw_nov_plain_veil,
    "nw_nov_povoy": draw_nov_povoy,
    "nw_nov_rhombic_band": draw_nov_rhombic_band,
    "nw_karel_veil": draw_karel_veil,
    "nw_baltic_spiral_band": draw_baltic_spiral_band,
    "nw_nordic_linen_veil": draw_nordic_linen_veil,
}
